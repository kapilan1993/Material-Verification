import xml.etree.ElementTree as ET
from datetime import datetime, timedelta



#Funciones sin usar


def convertXMLtoDataset(root,nodePath):
	headerPath = './/{http://www.sap.com/xMII}' + nodePath + "/Row"
	header = []
	node = root.find('.//{http://www.sap.com/xMII}' + nodePath)
	if node is not None:
		for colName in root.find(headerPath):
			header.append(colName.tag)
		
		rows = []
		for rowData in root.find(nodePath):
			row = []
			for item in rowData:
				row.append(item.text)
			rows.append(row)	
		dataset = system.dataset.toDataSet(header, rows)
		return dataset
	else:
		header = []
		rows = []
		dataset = system.dataset.toDataSet(header, rows)
		return dataset

def handleResponse(responseXML):
	xmlSplit = responseXML.split('<XacuteResponse xmlns="http://www.sap.com/xMII">')
	newXML = "<Response>" +  xmlSplit[1].split('</XacuteResponse>')[0] + "</Response>"
	return newXML

def refreshPOList(resourceName):
	lengthTagPaths = []
	dataTagPaths = []
	for i in range(50):
#		lengthPath = "[default]" + resourceName + "/ViewList/ViewList_" + str(i) + "/LEN"
#		lengthTagPaths.append(lengthPath)
		dataPath = "[default]" + resourceName + "/ViewList/ViewList_" + str(i) + "/DATA"
		dataTagPaths.append(dataPath)

#	lengthValues = system.tag.readBlocking(lengthTagPaths)
	dataValues = system.tag.readBlocking(dataTagPaths)

	poList = []
	for i in range(50):
		if dataValues[i].value is not None:
			poList.append(dataValues[i].value)

	header = ["ID","PO"]
	rows = []
	
	for i in range(len(poList)):
		row = []
		row.append(i+1)
		row.append(poList[i])
		rows.append(row)

	data = system.dataset.toDataSet(header, rows)
	ignPOListPath = "[default]IGNPOList/" + resourceName
	reslut = system.tag.writeBlocking([ignPOListPath], [data])
	return reslut

def handleDate(dataset,rowIndex,columnName):
	if dataset.getValueAt(rowIndex,columnName) is None or str(dataset.getValueAt(rowIndex,columnName)) == "":
		return '<' + columnName + '/>' 
	else:
		dateFormated = system.date.format(dataset.getValueAt(rowIndex,columnName),"yyyy-MM-dd HH:mm:ss")
		dateList = dateFormated.split(" ")
		dateNewFormated = dateList[0] + "T" + dateList[1]
		return '<' + columnName + '>' + dateNewFormated + '</' + columnName + '>'	
		
def writeTextLog(resourceName,logMessage):
	import os
	
	
	rutabase = 'E:\Post_Data_Log_Test'
	ruta1=resourceName + "_log.txt"
	fileName = os.path.join(rutabase,ruta1)
	fileName= os.path.abspath(fileName)
	with open(fileName,"a+") as f:
		f.write(logMessage + "\n")
	
#Funciones auxiliares


def sumar_horas(horas, fecha):
    fecha_como_datetime = datetime.strptime(fecha, '%Y-%m-%dT%H:%M:%S')
    nueva_fecha = fecha_como_datetime + timedelta(hours=horas)
    return nueva_fecha.strftime('%Y-%m-%dT%H:%M:%S')
def restar_horas(horas, fecha):
    fecha_como_datetime = datetime.strptime(fecha, '%Y-%m-%dT%H:%M:%S')
    nueva_fecha = fecha_como_datetime - timedelta(hours=horas)
    return nueva_fecha.strftime('%Y-%m-%dT%H:%M:%S')
    
def get_phase_previus(phase):
	phases=[2010,2020,2030]
	for i in range(0,len(phases)):
		if phase==2010:
			return 2010
		if phases[i] == phase:
			return phases[i-1]
			
def getValueFromXML(xmlString, nodePath):
    # Convertir el string a un objeto de ElementTree
    
    
    root = ET.fromstring(xmlString)
    print(root)
    # Buscamos el valor del nodo
    node = root.find('.//{http://www.sap.com/xMII}' + nodePath)

    if node is not None:
        return node.text
		
    else:
        return None



def handlePhase(dataset,rowIndex,columnName, tagName):
	if dataset.getValueAt(rowIndex,columnName) is None or str(dataset.getValueAt(rowIndex,columnName)) == "":
		return '<' + tagName + '/>' 
	else:
		return '<' + tagName + '>' + str(int(dataset.getValueAt(rowIndex,columnName)))+ '</' + tagName + '>'

def handleValue_batchnr(dataset,rowIndex,columnName, tagName):
	value =dataset.getValueAt(rowIndex,columnName)
	if value is None or str(value) == "" or value=="---" or value=="----":
		return '<' + tagName + '/>' 
	else:
		return '<' + tagName + '>' + str(dataset.getValueAt(rowIndex,columnName))+ '</' + tagName + '>'
		
def handleValue(dataset,rowIndex,columnName, tagName):
	
	
	if dataset.getValueAt(rowIndex,columnName) is None or (dataset.getValueAt(rowIndex,columnName)) == "":
		return '<' + tagName + '/>' 
	else:
		value = str(dataset.getValueAt(rowIndex,columnName))
		return '<' + tagName + '>' +value+ '</' + tagName + '>'



def getInfoFromRowsPhases(xmlString):
    root = ET.fromstring(xmlString)

    # Define el espacio de nombres
    ns = {'xmii': 'http://www.sap.com/xMII'}

    rows = root.findall('.//xmii:Row', ns)

    infoList = []

    for row in rows:
        infoDict = {}
        
		
        infoDict['PHASE'] 			= row.find('xmii:VORNR', ns).text
        #infoDict['S4_MII_STATUS'] 	= row.find('xmii:S4_MII_STATUS', ns).text
        #infoDict['MII_PO_STATUS'] 	= row.find('xmii:MII_PO_STATUS', ns).text
        infoDict['STATUS'] = row.find('xmii:MII_PH_STATUS', ns).text
        infoDict['RESOURCE'] = row.find('xmii:NODENAME', ns).text
		
				
        infoList.append(infoDict)

    return infoList
    


  
def getlistphases(client,plant,po):
	#GET STATUS
	from java.net import URLEncoder
	from urllib import urlencode
	print("Obteniendo fases")
	# URL base
	#url = "http://crlirt35:8080/PR-CID/ShopFloor/MII_Data_Collection_Messages/api/MIIDataCollectionMessages/GET_SAP_MII_MPM_CPS_GetPOHdrRecipeStepsStatus"
	url_0 = "/PR-CID/ShopFloor/MII_Data_Collection_Messages/api/MIIDataCollectionMessages/GET_SAP_MII_MPM_CPS_GetPOHdrRecipeStepsStatus"
	
	###Server connection name from Tag Browser
	Server_BK = "http://crlirt35:8080" 
	Server = str(system.tag.readBlocking("[default]DB_and_Server_Connections/MII_Web_API")[0].getValue())
	
	if Server == "":
	
		Server = Server_BK
		
	
	url = Server + url_0
	
	# Parámetros
	params = {
	    'SAP_CLIENT':client,
	    'SAP_PLANT': plant,
	    'PROCESS_ORDER': po,
	    'SAP_PO_STATUS': '',
	    'NODE_NAME': '',
	    'PHASE':'',
	    'NODE_TYPE': '',
	    'PHASE_STATUS': '',
	    'Enable_Doc_Batch_PO_Header_XML': '0',
	    'Enable_Doc_Batch_BOM_XML': '0',
	    'Enable_Doc_Batch_Recipe_Header_XML': '0',
	    'Enable_Doc_Batch_Recipe_Steps_XML': '1',
	    'ROW_COUNT': '100'
	}
	
	# Construir la cadena de consulta
	queryString = urlencode(params)
	
	# Realizar la petición GET
	response = system.net.httpGet(url + '?' + queryString)
	try:
		list_phases = myScripting_SIQ_idb.getInfoFromRowsPhases(response)
		return list_phases
	except:
		print("ERROR: ",str(sys.exc_info()))
	
	#print(list_phases)
	



import xml.etree.ElementTree as ET

#Convertir respuesta de inventario a lista de diccionarios
def getInfoFromRows(xmlString):
    root = ET.fromstring(xmlString)

    # Define el espacio de nombres
    ns = {'xmii': 'http://www.sap.com/xMII'}

    rows = root.findall('.//xmii:Row', ns)

    infoList = []

    for row in rows:
        infoDict = {}

        infoDict['Material'] = row.find('xmii:Material', ns).text
        infoDict['BatchNumber'] = row.find('xmii:BatchNumber', ns).text
        infoDict['ShelfLifeDate'] = row.find('xmii:ShelfLifeDate', ns).text
        infoDict['Quantity'] = row.find('xmii:Quantity', ns).text
        infoDict['UOM'] = row.find('xmii:UOM', ns).text
        infoDict['StorageLocation'] = row.find('xmii:StorageLocation', ns).text
        infoDict['PSA'] = row.find('xmii:PSA', ns).text
        infoDict['PSA_BIN'] = row.find('xmii:PSA_BIN', ns).text
        infoDict['STORAGE_TYPE'] = row.find('xmii:STORAGE_TYPE', ns).text
        infoDict['PSA_Configuration'] = row.find('xmii:PSA_Configuration', ns).text
        infoDict['PSA_BIN_Configuration'] = row.find('xmii:PSA_BIN_Configuration', ns).text
        infoDict['BATCH_GET_LIST_RESULT_STATUS'] = row.find('xmii:BATCH_GET_LIST_RESULT_STATUS', ns).text
        infoDict['BATCH_GET_LIST_RESULT_STATUS_MSG'] = row.find('xmii:BATCH_GET_LIST_RESULT_STATUS_MSG', ns).text
        infoDict['BLS_STATUS'] = row.find('xmii:BLS_STATUS', ns).text
        infoDict['BLS_MESSAGE'] = row.find('xmii:BLS_MESSAGE', ns).text

        infoList.append(infoDict)

    return infoList
	
def get_inventory(PSA, Matnr, StorageLocation):
	SAP_Client="010"
	SAP_Plant="5144"
	Warehouse="514"
	#GET STATUS
	from java.net import URLEncoder
	from urllib import urlencode
	
	# URL base
	#url = "http://crlirt35:8080//PR-CID/ShopFloor/MII_Data_Collection_Messages/api/MIIDataCollectionMessages/GET_SAP_MII_MPM_CPS_S4MfgGetBatchListForMaterial"
	url_0 = "//PR-CID/ShopFloor/MII_Data_Collection_Messages/api/MIIDataCollectionMessages/GET_SAP_MII_MPM_CPS_S4MfgGetBatchListForMaterial"
	
	###Server connection name from Tag Browser
	Server_BK = "http://crlirt35:8080" 
	Server = str(system.tag.readBlocking("[default]DB_and_Server_Connections/MII_Web_API")[0].getValue())
	
	if Server == "":
	
		Server = Server_BK
		
	
	url = Server + url_0
	
	# Parámetros
	params = {
		
		
	    'SAP_CLIENT': SAP_Client,
	    'SAP_PLANT':SAP_Plant,
	    'WAREHOUSE_NUMBER':Warehouse,
	    'IV_SUPPLY_AREA':PSA,
	    'PROCESS_ORDER': '',
	    'MATERIAL_NUMBER': Matnr,
	    'STORAGE_LOCATION':StorageLocation,
	    'IV_WITH_CONSUMED':'',
	    'IV_LOGSYS':'',
	    'IV_HU_EXID':'',
	    'IV_HU_EXID_TYPE':500,
	    'jSon' :False
	}
	
	# Construir la cadena de consulta
	queryString = urlencode(params)
	
	# Realizar la petición GET
	response = system.net.httpGet(url + '?' + queryString)
	rootMSG = ET.fromstring(response) 
	#description = myScripting_SIQ_idb.convertXMLtoDataset(rootMSG,"Body/XacuteResponse/Rowset").getValueAt(0,"BatchNumber")
	
	infoList=getInfoFromRows(response)
	headers = list(infoList[0].keys())
	rows = [list(d.values()) for d in infoList]
	dataset = system.dataset.toDataSet(headers, rows)
	return dataset
	# Imprimir el resultado
	
	

	
 #####   ####   ####  #####  
#     # #    # #    # #     # 
#       #    # #    # #     # 
#  #### #    # #    # #     #  
#     # #    # #    # #     #  
 #####   ####   ####  ##### 

#####  ####  #### #    # #####   ####
  #   #     #     #    # #      # 
  #   ####   ###  #    # ####   ####
  #   	  #     # #    # #     		#
##### ####  ####   ####  ##### ####



#Version con agrupamiento de good issues


def upload_Good_Issues_dbi():

	connectTimeout 	= 10000
	readTimeout  	= 10000
	
	#debug = system.util.getLogger("Good Issue Validation")
	#debug2 = system.util.getLogger("Good Issue Fase")
	
	#urlpost 		= "http://crlirt35:8080/PR-CID/ShopFloor/MII_Data_Collection_Messages/api/MIIDataCollectionMessages/POST_SAP_MII_MPM_CPS_ProcessMessagesDataWebService"
	urlpost_0 		= "/PR-CID/ShopFloor/MII_Data_Collection_Messages/api/MIIDataCollectionMessages/POST_SAP_MII_MPM_CPS_ProcessMessagesDataWebService"
	
	###Server connection name from Tag Browser
	Server_BK = "http://prcidt32" 
	Server = "http://prcidt32"  #str(system.tag.readBlocking("[default]DB_and_Server_Connections/MII_Web_API")[0].getValue())
	
	if Server == "":
	
		Server = Server_BK
		
	
	urlpost = Server + urlpost_0
	
	database_BK = "DB_Intermedia" ##Ignition database connection
	database = "DB_Intermedia" #str(system.tag.readBlocking("[default]DB_and_Server_Connections/Intermedia_DB")[0].getValue())
	
	if database == "":
	
		database = database_BK	
	
	query 			= "select * from dbo.SF_MII_Goods_Issues_UI where MII_Send = ? and Phase = ? and FailedTimesPosting <3  and FailedTimesValidation <3 and GI_Validation!='ERROR' and Final_Issue='X' "
	newRows 		= system.db.runPrepQuery(query, [0, 2020], database)  		
	print(newRows)
	
	for rowIndex in range(newRows.rowCount):
				MII_Ignition_Library.Logger.Insert_Log.Insert_Error_Log('upload_Good_Issues_dbi', 'Entered for loop')
				FailedTimes    			= newRows.getValueAt(rowIndex,"FailedTimesPosting") 
				sourceID 				= newRows.getValueAt(rowIndex,"seq")
				status 					= newRows.getValueAt(rowIndex,"SAP_Status")
				created_Date 			= system.date.now()	
				phase 					= newRows.getValueAt(rowIndex,"Phase")
				poNumber 				= newRows.getValueAt(rowIndex,"Process_Order")
				resource 				= newRows.getValueAt(rowIndex,"SAPResourceName")
				userID 					= "System"
				datetime				= sumar_horas(6, newRows.getValueAt(rowIndex,"EventDateTime"))
				datetime_original		= newRows.getValueAt(rowIndex,"EventDateTime")
				qty 					= newRows.getValueAt(rowIndex,"Quantity")
				print('*****Checking', sourceID)		
				Sts_Validation		 	= newRows.getValueAt(rowIndex,"GI_Validation")
				Sts_Posting 			= newRows.getValueAt(rowIndex,"GI_Posting") 
				FailedTimesValidation	= newRows.getValueAt(rowIndex,"FailedTimesValidation") 
				FailedTimesPosting		= newRows.getValueAt(rowIndex,"FailedTimesPosting") 	
				MessagePost 			= newRows.getValueAt(rowIndex,"MessagePost") 	
				Materialnr				= newRows.getValueAt(rowIndex,"Material") 
				Batchnr					= newRows.getValueAt(rowIndex,"Batchnr") 
				#GET THE NODENAME OF THE RESOURCE
				psQuery_Resource 		= "select NODENAME from dbo.SF_MII_PO_HEADER_PHASES where PROCESSORDER_AUFNR=? AND RESOURCE_ARBPL=?"
				psData_Resource			= system.db.runPrepQuery(psQuery_Resource, [str(poNumber),str(resource)], database)	
				print("Nodename obtenido",psData_Resource)
				#GET THE RESB POS VALUE
				query_res_pos 			= "Select [RESERVATION_ITEM_RSPOS] from [dbo].[SF_MII_PO_PHASES_RESB] where PROCESSORDER_AUFNR=? and MATERIAL_MATNR=?"
				newRows_res_pos 		= system.db.runPrepQuery(query_res_pos, [poNumber,Materialnr], database)  
				
				if newRows_res_pos.rowCount==0 or psData_Resource.rowCount==0:
					print("Check (0 YES): NodeName",psData_Resource.rowCount,"ResbPos",  newRows_res_pos.rowCount)
					print(sourceID,poNumber,datetime)
					continue
				
				#debug.info("PO: " + str(poNumber) + " / PH: " + str(phase) + " / Mat_#:  " + str(Materialnr) + " / Batch _#: " + str(Batchnr) + " / Qty: " + str(qty))
				
				queryQuantitySum 		= "select sum(Quantity) as Quantity from dbo.SF_MII_Goods_Issues_UI where Material = ? and Batchnr =? and Process_Order=? AND GI_Validation NOT IN ('ERROR', 'FAILED') AND GI_Posting NOT IN ('ERROR', 'FAILED')"
				
				newRowsQuantitySum = system.db.runPrepQuery(queryQuantitySum, [Materialnr,Batchnr,poNumber] , database)
				
				#handleValue(newRowsQuantitySum,0,"Quantity","Quantity") + '\' Modificado 02/27/24 SIQ
				
				print("TEST",newRows.getValueAt(rowIndex,"SAPClient"),sourceID) 
				itemXML			= '<Item>' +'\'
									handleValue(newRows,rowIndex,"Material","Matnr")+ '\'
									handleValue(newRows,rowIndex,"Quantity","Quantity") + '\'
									handleValue(newRows,rowIndex,"UOM","UOM") + '\'
									handleValue_batchnr(newRows,rowIndex,"Batchnr","Batchnr") + '\'
									handleValue(newRows,rowIndex,"StorageLocation","StorageLocation") + '\'
									handleValue(newRows,rowIndex,"ReasonForMov","ReasonForMov") + '\'
									handleValue(newRows,rowIndex,"MovementType","MovementType") + '\'
									handleValue(newRows,rowIndex,"Final_Issue","FinalIssue") + '\' 	
									handleValue(newRows_res_pos,0,"RESERVATION_ITEM_RSPOS","Resb_Pos") + '\' 	
									'</Item>'		
								
				postMessage		 = '<Goods_Issue>' + '\'
									'<row>' + '\'
										handleValue(newRows,rowIndex,"SAPClient","SAPClient") + '\'
										handleValue(newRows,rowIndex,"SAPPlant","SAPPlant") + '\'
										handleValue(psData_Resource,0,"NODENAME","SAPResourceName") + '\'
										handleValue(newRows,rowIndex,"Process_Order","Order") +'\'
										handleValue(newRows,rowIndex,"Phase","Phase") +'\'
										handleValue(newRows,rowIndex,"EventDateTime","EventTime") + '\'
										'<Items>' + '\'
											itemXML + '\'
										'</Items>' + '\'
									'</row>' + '\'
								  '</Goods_Issue>' 				
				MII_Ignition_Library.Logger.Insert_Log.Insert_Error_Log('upload_Good_Issues_dbi', 'xml created')
				description=""
				print("PostMessage",postMessage)
				try:
							
					#GET STATUS
					
					from java.net import URLEncoder
					from urllib import urlencode
					
					# URL base
					#url = "http://crlirt35:8080/PR-CID/ShopFloor/MII_Data_Collection_Messages/api/MIIDataCollectionMessages/GET_SAP_MII_MPM_CPS_GetPOHdrRecipeStepsStatus"
					#Este mensaje es de phase status state
					url_0 = "/PR-CID/ShopFloor/MII_Data_Collection_Messages/api/MIIDataCollectionMessages/GET_SAP_MII_MPM_CPS_GetPOHdrRecipeStepsStatus"
					
					###Server connection name from Tag Browser
					Server_BK = "http://prcidt32" 
					Server = "http://prcidt32"  #str(system.tag.readBlocking("[default]DB_and_Server_Connections/MII_Web_API")[0].getValue())
					
					if Server == "":
					
						Server = Server_BK
						
					
					url = Server + url_0
					
					# Parámetros
					params = {
					    'SAP_CLIENT': newRows.getValueAt(rowIndex,"SAPClient"),
					    'SAP_PLANT': newRows.getValueAt(rowIndex,"SAPPlant"),
					    'PROCESS_ORDER': newRows.getValueAt(rowIndex,"Process_Order") ,
					    'SAP_PO_STATUS': '',
					    'NODE_NAME': '',
					    'PHASE': newRows.getValueAt(rowIndex,"Phase"),
					    'NODE_TYPE': '',
					    'PHASE_STATUS': '',
					    'Enable_Doc_Batch_PO_Header_XML': '0',
					    'Enable_Doc_Batch_BOM_XML': '0',
					    'Enable_Doc_Batch_Recipe_Header_XML': '0',
					    'Enable_Doc_Batch_Recipe_Steps_XML': '1',
					    'ROW_COUNT': '100'
					}
					
					# Construir la cadena de consulta
					queryString = urlencode(params)
					
					# Realizar la petición GET
					response = system.net.httpGet(url + '?' + queryString)
					MII_Ignition_Library.Logger.Insert_Log.Insert_Error_Log('upload_Good_Issues_dbi', 'recipe step status: ' + response)
					# Imprimir el resultado
					print ("Respuesta Status",response)
					returnMessageSts	= myScripting_SIQ_idb.getValueFromXML(str(response), "MII_PH_STATUS")
					print("Status",returnMessageSts)
					#STATUS: NEW, ACT, CMPL
					
					data_dict={
								"Seq"				: int(sourceID),
								"StatusPO"			: returnMessageSts
								}
					system.db.runNamedQuery("DATA_POST/IDB/Update_Status_GI",data_dict)
					
					if returnMessageSts !="ACT":
						
						#debug2.info("Si la fase no esta activa >>>> PO: "  + str(poNumber) + " / PH: " + str(phase) + " / Mat_#:  " + str(Materialnr) + " / Batch _#: " + str(Batchnr) + " / Qty: " + str(qty))
						
						continue
					
					print("Phase Act")

					#VALIDATION
					
					if( (Sts_Validation=="NEW" or Sts_Validation=="PROCESSING") and FailedTimesValidation!=3 ):
						MII_Ignition_Library.Logger.Insert_Log.Insert_Error_Log('upload_Good_Issues_dbi', 'Entered Validation')

						if( Sts_Validation=="NEW"):
							print("Validando")
							data_dict={
										"Seq_Cmp"					: int(sourceID),
										"State_Validation"			: "PROCESSING",
										"FailedTimesValidation"		: FailedTimesValidation,
										"State_Posting"				: Sts_Posting,
										"FailedTimesPosting"		: FailedTimesPosting,
										"Message_Response"			: '',
										"Send"						: 0
										}
							system.db.runNamedQuery("DATA_POST/IDB/Update_GI",data_dict)
							

						#urlvalidation = "http://crlirt35:8080/PR-CID/ShopFloor/MII_Data_Collection_Messages/api/MIIDataCollectionMessages/GET_SAP_MII_MPM_CPS_BLS_CheckConsumptionValid"
						urlvalidation_0 = "/PR-CID/ShopFloor/MII_Data_Collection_Messages/api/MIIDataCollectionMessages/GET_SAP_MII_MPM_CPS_BLS_CheckConsumptionValid"
						
						###Server connection name from Tag Browser
						Server_BK = "http://prcidt32" 
						Server = "http://prcidt32" #str(system.tag.readBlocking("[default]DB_and_Server_Connections/MII_Web_API")[0].getValue())
						
						if Server == "":
						
							Server = Server_BK
							
						
						urlvalidation = Server + urlvalidation_0
						
						# Parámetros
						print(datetime,"fecha")
						
						#Revisar si params se esta utilizando
						params = {
						    'SAP_CLIENT'		: newRows.getValueAt(rowIndex,"SAPClient"),
						    'SAP_PLANT'			: newRows.getValueAt(rowIndex,"SAPPlant"),
						    'PROCESS_ORDER'		: newRows.getValueAt(rowIndex,"Process_Order") ,
						    'SAPResourceName'	: psData_Resource.getValueAt(0,"NODENAME") ,
						    'NodeID': '' ,
						    'NODE_NAME':'',
						    'PHASE'				: newRows.getValueAt(rowIndex,"Phase") ,
						    'EventTime'			: str(datetime),
						    'Matnr'				: newRows.getValueAt(rowIndex,"Material") ,
						    'Quantity'			: newRows.getValueAt(rowIndex,"Quantity") ,
						    'UOM'				: newRows.getValueAt(rowIndex,"UOM") ,
						    'Batchnr'			: newRows.getValueAt(rowIndex,"Batchnr") ,
						    'ReasonForMov'		: newRows.getValueAt(rowIndex,"ReasonForMov") ,
						    'MovementType'		: newRows.getValueAt(rowIndex,"MovementType") ,
						    'FinalIssue'		: newRows.getValueAt(rowIndex,"Final_Issue") ,
						    'Resb_Pos'			: newRows_res_pos.getValueAt(0,"RESERVATION_ITEM_RSPOS") ,
						    'jSon'				: 'False'
						}
						queryString = urlencode(params)
						
											
						print("QuerieValidation", queryString)
						postReturn 			= system.net.httpPost(urlvalidation,'text/xml',postMessage,10000,10000)  
						print(postReturn)
						#response = system.net.httpGet(urlvalidation + '?' + queryString)
						
						returnMessageSts	= myScripting_SIQ_idb.getValueFromXML(str(postReturn), "status")
						print("Status Validation",returnMessageSts)
						msg_validation		= myScripting_SIQ_idb.getValueFromXML(str(postReturn), "Message")
																	
						
						if returnMessageSts == str(1):
							print("PASS VALIDATION")
							# 1 UPDATE BIT SAP_Send
							data_dict={
									"Seq_Cmp"					: int(sourceID),
									"State_Validation"			: "PASS",
									"FailedTimesValidation"		: FailedTimesValidation,
									"State_Posting"				: "NEW",
									"FailedTimesPosting"		: FailedTimesPosting,
									"Message_Response"			: msg_validation,
									"Send"						: 0
									}
							system.db.runNamedQuery("DATA_POST/IDB/Update_GI",data_dict)
							
							# 2 INSERT INTO LOG TABLE
							description 		= "Message successfully queued, validation."
							insertResult		= 1
							messageType			= "G.I"		
							data_dict = {
							    "ID"			: sourceID,
							    "Created_Date"	: datetime_original,
							    "Description"	: description,
							    "MessageType"	: messageType,
							    "Phase"			: phase,
							    "PONumber"		: poNumber,
							    "Resource"		: resource,
							    "Result"		: insertResult,
							    "UserID"		: userID,
							    "XmlSend"		: postMessage
							}
							system.db.runNamedQuery("DATA_POST/IDB/Insert_DataLog",data_dict)

							print str(sourceID) +" " + str(poNumber) + " " + "Success"
							#continue
						elif returnMessageSts == str(0):
							
							#FailedTimesValidation= 1+int(FailedTimesValidation)
							#"FailedTimesValidation"		: FailedTimesValidation Linea Sustituida
							# 1 UPDATE FAILED TIMES
							data_dict={
									"Seq_Cmp"					: int(sourceID),
									"State_Validation"			: "ERROR",
									"FailedTimesValidation"		: 3,
									"State_Posting"				: Sts_Posting,
									"FailedTimesPosting"		: FailedTimesPosting,
									"Message_Response"			: msg_validation,
									"Send"						: 0
									}
							system.db.runNamedQuery("DATA_POST/IDB/Update_GI",data_dict)
															
							# 2 UPDATE LOG TABLE
							description 		=  "Failed: "+msg_validation
							messageType			= "G.I"
							insertResult		= 0	
							data_dict = {
							    "ID"			: sourceID,
							    "Created_Date"	: datetime_original,
							    "Description"	: description+", validation",
							    "MessageType"	: messageType,
							    "Phase"			: phase,
							    "PONumber"		: poNumber,
							    "Resource"		: resource,
							    "Result"		: insertResult,
							    "UserID"		: userID,
							    "XmlSend"		: postMessage
							}
							system.db.runNamedQuery("DATA_POST/IDB/Insert_DataLog",data_dict)
							print str(sourceID)+ " " + str(poNumber) + " " + "Failed"
							
						else:
							print("FALLO COMUNICACION")
							FailedTimesValidation= 1+int(FailedTimesValidation) 
							# 1 UPDATE FAILED TIMES
							if(FailedTimesValidation<3):
								data_dict={
										"Seq_Cmp"					: sourceID,
										"State_Validation"			: Sts_Validation,
										"FailedTimesValidation"		: FailedTimesValidation,
										"State_Posting"				: Sts_Posting,
										"FailedTimesPosting"		: FailedTimesPosting,
										"Message_Response"			: msg_validation,
										"Send"						:0
										}
								print("Registrando error por validacion", data_dict)
								system.db.runNamedQuery("DATA_POST/IDB/Update_GI",data_dict)
								print("LISTO")
							if(FailedTimesValidation==3):
								data_dict={
										"Seq_Cmp"					: int(sourceID),
										"State_Validation"			: "FAILED",
										"FailedTimesValidation"		: FailedTimesValidation,
										"State_Posting"				: Sts_Posting,
										"FailedTimesPosting"		: FailedTimesPosting,
										"Message_Response"			: msg_validation,
										"Send"						:0
										}
								system.db.runNamedQuery("DATA_POST/IDB/Update_GI",data_dict)
															
							# 2 UPDATE LOG TABLE
							description 		=  "Failed: "+msg_validation
							messageType			= "G.I"
							insertResult		= 0	
							data_dict = {
							    "ID"			: sourceID,
							    "Created_Date"	: datetime_original,
							    "Description"	: description,
							    "MessageType"	: messageType,
							    "Phase"			: phase,
							    "PONumber"		: poNumber,
							    "Resource"		: resource,
							    "Result"		: insertResult,
							    "UserID"		: userID,
							    "XmlSend"		: postMessage
							}
							system.db.runNamedQuery("DATA_POST/IDB/Insert_DataLog",data_dict)
							print str(sourceID)+ " " + str(poNumber) + " " + "Failed"
							
							
					#POSTING
					if( (Sts_Posting=="NEW" or Sts_Validation=="PASS") and FailedTimesPosting !=3): 
						MII_Ignition_Library.Logger.Insert_Log.Insert_Error_Log('upload_Good_Issues_dbi', 'Entered GI_Posting')
						print("Checking post")
						postReturn 	= system.net.httpPost(urlpost,'text/xml',postMessage,10000,10000)  
						
						returnMessagePass	= postReturn.find("<Message>Message successfully queued.</Message>\r\n") 
						print('Mensaje return Post',postReturn, postMessage)
						if( Sts_Posting=="NEW"):
							data_dict={
										"Seq_Cmp"					: int(sourceID),
										"State_Validation"			: Sts_Validation,
										"FailedTimesValidation"		: FailedTimesValidation,
										"State_Posting"				: "PROCESSING",
										"FailedTimesPosting"		: FailedTimesPosting,
										"Message_Response"			: MessagePost,
										"Send"						:0
										}
							system.db.runNamedQuery("DATA_POST/IDB/Update_GI",data_dict)
													
													
						if returnMessagePass != -1:
							print("PASS POSTING")
							# 1 UPDATE STATUS
							data_dict={
									"Seq_Cmp"					: int(sourceID),
									"State_Validation"			: Sts_Validation,
									"FailedTimesValidation"		: FailedTimesValidation,
									"State_Posting"				: "PASS",
									"FailedTimesPosting"		: FailedTimesPosting,
									"Message_Response"			: MessagePost,
									"Send"						:1
									}
							system.db.runNamedQuery("DATA_POST/IDB/Update_GI",data_dict)
							
							# 2 INSERT INTO LOG TABLE
							description 		= "Message successfully queued, posting."
							insertResult		= 1
							messageType			= "G.I"		
							data_dict = {
							    "ID"			: sourceID,
							    "Created_Date"	: datetime_original,
							    "Description"	: description,
							    "MessageType"	: messageType,
							    "Phase"			: phase,
							    "PONumber"		: poNumber,
							    "Resource"		: resource,
							    "Result"		: insertResult,
							    "UserID"		: userID,
							    "XmlSend"		: postMessage
							}
							system.db.runNamedQuery("DATA_POST/IDB/Insert_DataLog",data_dict)

							print str(sourceID) +" " + str(poNumber) + " " + "Success"
							
						else:
							# 1 UPDATE STATUS
							FailedTimesPosting= 1+int(FailedTimesPosting)
							if(FailedTimesPosting < 3):
								data_dict={
										"Seq_Cmp"					: int(sourceID),
										"State_Validation"			: Sts_Validation,
										"FailedTimesValidation"		: FailedTimesValidation,
										"State_Posting"				: Sts_Posting,
										"FailedTimesPosting"		: FailedTimesPosting,
										"Message_Response"			: MessagePost ,
										"Send"						:0
										}
								system.db.runNamedQuery("DATA_POST/IDB/Update_GI",data_dict)
								
							if(FailedTimesPosting==3):
								data_dict={
										"Seq_Cmp"					: int(sourceID),
										"State_Validation"			: Sts_Validation,
										"FailedTimesValidation"		: FailedTimesValidation,
										"State_Posting"				:  "FAILED",
										"FailedTimesPosting"		: FailedTimesPosting,
										"Message_Response"			: MessagePost,
										"Send"						:0 
										}
								system.db.runNamedQuery("DATA_POST/IDB/Update_GI",data_dict)
															
							# 2 UPDATE LOG TABLE
							description 		=  "Failed:"+MessagePost
							messageType			= "G.I"
							insertResult		= 0	
							data_dict = {
							    "ID"			: sourceID,
							    "Created_Date"	: datetime_original,
							    "Description"	: description+", posting",
							    "MessageType"	: messageType,
							    "Phase"			: phase,
							    "PONumber"		: poNumber,
							    "Resource"		: resource,
							    "Result"		: insertResult,
							    "UserID"		: userID,
							    "XmlSend"		: postMessage
							}
							system.db.runNamedQuery("DATA_POST/IDB/Insert_DataLog",data_dict)
							print str(sourceID)+ " " + str(poNumber) + " " + "Failed"

							
				except:
					import sys
					print("ERROR EN GI",str(sys.exc_info()))
					
					logMessage 				= str(system.date.format(system.date.now())) + "Result: "+description+" Timeout" + " " + str(sys.exc_info())
					logTableName 			= "DBI_Good_Issues_Exceptions"
					description 		=  "ERROR EXECUTION"
					messageType			= "G.I"
					insertResult		= 0	
					data_dict = {
					    "ID"			: sourceID,
					    "Created_Date"	: datetime_original,
					    "Description"	: logMessage,
					    "MessageType"	: messageType,
					    "Phase"			: phase,
					    "PONumber"		: poNumber,
					    "Resource"		: resource,
					    "Result"		: insertResult,
					    "UserID"		: userID,
					    "XmlSend"		: postMessage
					}
					system.db.runNamedQuery("DATA_POST/IDB/Insert_DataLog",data_dict)
					print(logMessage)
					#break

	return 0



	

 #####   ####  #     # ####### ####### ####### #		#      #	  ######### #######   ####  #     #   ####
#       #    # # #   # #          #    #     # ##      ##     # #         #        #     #    # # #   #  #
#       #    # #  #  # ####       #    # ####  # #    # #    #   #	      #        #     #    # #  #  #  #
#       #    # #   # # #          #    #  #    #  #  #  #   #######	      #        #     #    # #   # #  ####
#       #    # #    ## #          #    #   #   #   #    #  #       #      #        #     #    # #    ##      #
 #####   ####  #     # #	   ####### #    #  #        # #         #     #     #######   ####  #     # ####

def upload_Confirmations_dbi():

	connectTimeout 	= 10000
	readTimeout  	= 10000
	#url 			= "http://crlirt35:8080/PR-CID/ShopFloor/MII_Data_Collection_Messages/api/MIIDataCollectionMessages/POST_SAP_MII_MPM_CPS_ProcessMessagesDataWebService"
	url_0 			= "/PR-CID/ShopFloor/MII_Data_Collection_Messages/api/MIIDataCollectionMessages/POST_SAP_MII_MPM_CPS_ProcessMessagesDataWebService"
	###Server connection name from Tag Browser
	Server_BK = "http://crlirt35:8080" 
	Server = str(system.tag.readBlocking("[default]DB_and_Server_Connections/MII_Web_API")[0].getValue())
	
	if Server == "":
	
		Server = Server_BK
		
	
	url = Server + url_0
	
	
	database_BK = "DB_Intermedia" ##Ignition database connection
	database = str(system.tag.readBlocking("[default]DB_and_Server_Connections/Intermedia_DB")[0].getValue())
	
	if database == "":
	
		database = database_BK
	
	
	import xml.etree.ElementTree as ET
	
	query 			= "select * from dbo.SF_MII_CONFIRMATION_UI where MII_Send = ? and Phase = ? and FailedTimesPosting < 3"
	newRows 		= system.db.runPrepQuery(query, [0, 2020], database) 
	
	print("CNF",newRows.rowCount)
	for rowIndex in range(newRows.rowCount):
	
				FailedTimes   	= newRows.getValueAt(rowIndex,"FailedTimesPosting") 
				sourceID 		= newRows.getValueAt(rowIndex,"Seq")
				status 			= newRows.getValueAt(rowIndex,"MII_Send")
				created_Date 	= system.date.now()	
				phase 			= newRows.getValueAt(rowIndex,"Phase") 
				poNumber 		= newRows.getValueAt(rowIndex,"PO_Number")
				resource 		= newRows.getValueAt(rowIndex,"SAPResource")
				userID 			= "System"
				datetime		= newRows.getValueAt(rowIndex,"EventDateTime")			
				qty_YIELD		= newRows.getValueAt(rowIndex,"Qty_YIELD")		
				qty_SCRAP		= newRows.getValueAt(rowIndex,"Qty_SCRAP")		
				
				
				#GET STATUS
				from java.net import URLEncoder
				from urllib import urlencode
				
				# URL base
				#url_sts = "http://crlirt35:8080/PR-CID/ShopFloor/MII_Data_Collection_Messages/api/MIIDataCollectionMessages/GET_SAP_MII_MPM_CPS_GetPOHdrRecipeStepsStatus"
				url_sts_0 = "/PR-CID/ShopFloor/MII_Data_Collection_Messages/api/MIIDataCollectionMessages/GET_SAP_MII_MPM_CPS_GetPOHdrRecipeStepsStatus"
				###Server connection name from Tag Browser
				Server_BK = "http://crlirt35:8080" 
				Server = str(system.tag.readBlocking("[default]DB_and_Server_Connections/MII_Web_API")[0].getValue())
				
				if Server == "":
				
					Server = Server_BK
					
				
				url_sts = Server + url_sts_0
				
				# Parámetros
				params = {
				    'SAP_CLIENT': newRows.getValueAt(rowIndex,"SAPClient"),
				    'SAP_PLANT': newRows.getValueAt(rowIndex,"SAPPlant"),
				    'PROCESS_ORDER': newRows.getValueAt(rowIndex,"PO_Number") ,
				    'SAP_PO_STATUS': '',
				    'NODE_NAME': '',
				    'PHASE': newRows.getValueAt(rowIndex,"Phase"),
				    'NODE_TYPE': '',
				    'PHASE_STATUS': '',
				    'Enable_Doc_Batch_PO_Header_XML': '0',
				    'Enable_Doc_Batch_BOM_XML': '0',
				    'Enable_Doc_Batch_Recipe_Header_XML': '0',
				    'Enable_Doc_Batch_Recipe_Steps_XML': '1',
				    'ROW_COUNT': '100'
				}
				
				# Construir la cadena de consulta
				queryString_sts = urlencode(params)
				
				
				# Realizar la petición GET
				
				psQuery_Data = []
				psQuery_Check = "select * from dbo.SF_MII_PHASE_STATUS_UI where PO_Number = ? and Phase = '2020' and Status = 'CMPL' "
				psQuery_Data = system.db.runPrepQuery(psQuery_Check, [str(poNumber)], database)
				
				if psQuery_Data.getRowCount() == 0:
					print("PO NOT CMPL",poNumber,sourceID)
					continue
					
				#response = system.net.httpGet(url_sts + '?' + queryString_sts)
				#returnMessageSts	= myScripting_SIQ_idb.getValueFromXML(str(response), "MII_PH_STATUS")
				#print("Status",returnMessageSts)
				#if returnMessageSts!="CMPL":
				#	print("PO NOT CMPL",poNumber,sourceID)
				#	continue
				
				#Check Good Issues Send
				
				psQueryGI_Check 	= "select * from dbo.SF_MII_Goods_Issues_UI where Process_Order = ? and  ( (MII_Send = 0 and FailedTimesPosting <3 and GI_Validation!='ERROR'  )  or (MII_Send = 0 and GI_Validation='ERROR' and Child is NULL) )"
				psDataGI 			= system.db.runPrepQuery(psQueryGI_Check, [str(poNumber)], database)
				
				psQueryGI_CheckExist 	= "select * from dbo.SF_MII_Goods_Issues_UI where Process_Order = ? "
				psDataGIExist			= system.db.runPrepQuery(psQueryGI_CheckExist, [str(poNumber)], database)
				if 	(psDataGI.rowCount > 0 or psDataGIExist==0 ):
					data_dict={
						"Seq_Cmp"			: int(sourceID),
						"Send"				: 0,
						"FailedTimes"		: 0,
						"Message_Response"	:"There are Good Issues Pending:"+str(psDataGI.rowCount) +", or hasn't send yet",
						"State_Posting"		:"NEW"
					}
					system.db.runNamedQuery("DATA_POST/IDB/UPDATE_CNF",data_dict)
					print("There are Good Issues Pending, for :", poNumber)
					continue
				
				#GET THE NODENAME OF THE RESOURCE
				psQuery_Resource 		= "select NODENAME from dbo.SF_MII_PO_HEADER_PHASES where PROCESSORDER_AUFNR=? AND RESOURCE_ARBPL=?"
				psData_Resource			= system.db.runPrepQuery(psQuery_Resource, [str(poNumber),str(resource)], database)	
				
				print("Phase Act",str(qty_YIELD),str(qty_SCRAP))

				print("Nodename",psData_Resource.getValueAt(0,"NODENAME"))
				itemXML=''
												
				if 	(float(qty_YIELD) ==0.0 ) and  float(qty_SCRAP) >0.0:
					print("SCRAP FOUND")
					itemXML 		= '<Item>' + '\'
										handleValue(newRows,rowIndex,"Qty_SCRAP","Quantity") + '\'
										'<Quantity_Type>SCRAP</Quantity_Type>'+ '\'
										handleValue(newRows,rowIndex,"ReasonCode","ReasonCode") + '\'
									'</Item>'
				if 	(float(qty_SCRAP) ==0.0) and float(qty_YIELD) >0.0 :
					print("YIELD FOUND")
					itemXML 		= '<Item>' + '\'
										handleValue(newRows,rowIndex,"Qty_YIELD","Quantity") + '\'
										'<Quantity_Type>YIELD</Quantity_Type>'+ '\'
										'<ReasonCode/>' + '\'
									'</Item>'
				
				
		
				postMessage 	= '<Production_Report>' + '\'
									'<row>' + '\'
										handleValue(newRows,rowIndex,"SAPClient","SAPClient") + '\'
										handleValue(newRows,rowIndex,"SAPPlant","SAPPlant") + '\'
										handleValue(psData_Resource,0,"NODENAME","SAPResourceName") + '\'
										handleValue(newRows,rowIndex,"PO_Number","Order") + '\'
										handlePhase(newRows,rowIndex,"Phase","Phase") + '\'
										handleValue(newRows,rowIndex,"EventDateTime","EventTime") + '\'
										handleValue(newRows,rowIndex,"Material","Matnr") + '\'
										handleValue(newRows,rowIndex,"UOM","UOM") + '\'
										'<Items>' + '\'
												itemXML + '\'
										'</Items>' + '\'
									'</row>' + '\'
								 '</Production_Report>'

				
				
				try:
					print("Mensaje", postMessage)
					postReturn 	= system.net.httpPost(url,'text/xml',postMessage,100000,100000)  #18OCT2023: Esperar a URL
					print("Respuesta: ", postReturn)	
							
					returnMessage	= str(postReturn).find("<Message>Message successfully queued.</Message>\r\n")
					
									
					#DATA SEND SUCCESFULLY		
					if returnMessage != -1: #SE ENVIO CON EXITO
						print("Enviado")
						# 1 UPDATE BIT SAP_Send
						data_dict={
							"Seq_Cmp"			: int(sourceID),
							"Send"				: 1,
							"FailedTimes"		: 0,
							"Message_Response"	:"Message successfully queued" ,
							"State_Posting"		:"PASS"
						}
						print(data_dict)
			
						system.db.runNamedQuery("DATA_POST/IDB/UPDATE_CNF",data_dict)
						
						# 2 INSERT INTO LOG TABLE
						description 		= "Message successfully queued."
						insertResult		= 1
						messageType			= "CNF"
						data_dict = {
						    "ID"			: sourceID,
						    "Created_Date"	: datetime,
						    "Description"	: description,
						    "MessageType"	: messageType,
						    "Phase"			: phase,
						    "PONumber"		: poNumber,
						    "Resource"		: resource,
						    "Result"		: insertResult,
						    "UserID"		: userID,
						    "XmlSend"		: postMessage
						}
						system.db.runNamedQuery("DATA_POST/IDB/Insert_DataLog",data_dict)

			
						print str(sourceID) + " " + str(poNumber) + " " + "Success"
						
					#DATA SEND FAILED
					else:
						returnMessageSts	= myScripting_SIQ_idb.getValueFromXML(str(postReturn), "Message")
						print("No Enviado")
						FailedTimes= 1+int(FailedTimes)
						# 1 UPDATE FAILED TIMES
						if FailedTimes<3:
							data_dict={
										"Seq_Cmp"			: int(sourceID),
										"Send"				: 0,
										"FailedTimes"		: FailedTimes,
										"Message_Response"	:returnMessageSts,
										"State_Posting"		:"PROCESSING"
									}
						if FailedTimes<3:
							data_dict={
										"Seq_Cmp"			: int(sourceID),
										"Send"				: 0,
										"FailedTimes"		: FailedTimes,
										"Message_Response"	:returnMessageSts,
										"State_Posting"		:"FAILED"
									}
						system.db.runNamedQuery("DATA_POST/IDB/UPDATE_CNF",data_dict)
						
						# 2 INSERT INTO LOG TABLE
						#rootMSG 			= ET.fromstring(postReturn) 
						description 		= "Failed" # myScripting.convertXMLtoDataset(rootMSG,"Body/XacuteResponse/Rowset").getValueAt(0,"MSG")
						messageType			= "CNF"
						insertResult		= 0
						data_dict = {
							"ID"			: sourceID,
							"Created_Date"	: datetime,
							"Description"	: description,
							"MessageType"	: messageType,
							"Phase"			: phase,
							"PONumber"		: poNumber,
							"Resource"		: resource,
							"Result"		: insertResult,
							"UserID"		: userID,
							"XmlSend"		: postMessage
												}
						system.db.runNamedQuery("DATA_POST/IDB/Insert_DataLog",data_dict)
						
	
						print str(sourceID) + " " + str(poNumber) + " " + "Failed"
				except:
					import sys
					print(str(sys.exc_info()))
					
					logMessage 				= str(sys.exc_info())
					logTableName 			= "DBI_Confirmations_Exceptions"
					description 		=  "ERROR EXECUTION"
					messageType			= "CNF"
					insertResult		= 0	
					data_dict = {
					    "ID"			: sourceID,
					    "Created_Date"	: datetime,
					    "Description"	:logMessage,
					    "MessageType"	: messageType,
					    "Phase"			: phase,
					    "PONumber"		: poNumber,
					    "Resource"		: resource,
					    "Result"		: insertResult,
					    "UserID"		: userID
					}
					system.db.runNamedQuery("DATA_POST/IDB/Insert_DataLog",data_dict)
	return 0

	
######      #####
#    #     #
#    #     #
#####      ####
#	           #
#	   #  #####		

def upload_phase_status_dbi():

	connectTimeout 	= 10000
	readTimeout  	= 10000
	#url 			= "http://crlirt35:8080/PR-CID/ShopFloor/MII_Data_Collection_Messages/api/MIIDataCollectionMessages/POST_SAP_MII_MPM_CPS_ProcessMessagesDataWebService"
	url_0 			= "/PR-CID/ShopFloor/MII_Data_Collection_Messages/api/MIIDataCollectionMessages/POST_SAP_MII_MPM_CPS_ProcessMessagesDataWebService"
	###Server connection name from Tag Browser
	Server_BK = "http://prcidt32" 
	Server = str(system.tag.readBlocking("[default]DB_and_Server_Connections/MII_Web_API")[0].getValue())
	
	if Server == "":
	
		Server = Server_BK
		
	
	url = Server + url_0
	
	
	database_BK = "DB_Intermedia" ##Ignition database connection
	database = str(system.tag.readBlocking("[default]DB_and_Server_Connections/Intermedia_DB")[0].getValue())
	
	if database == "":
	
		database = database_BK	
	
	import xml.etree.ElementTree as ET
	
	query 			= "select * from dbo.SF_MII_PHASE_STATUS_UI where MII_Send = ? and FailedTimesPosting < 3 and PS_Posting != 'WAIT' and PS_Posting != 'PASS'"
	newRows 		= system.db.runPrepQuery(query, [0], database) 
	send_data=0
	
	#REGLAS 
	#Si es fase 2010, 2030, se envia el phase status sin validar good issues, ni cnfs
	#Si es fase 2020, y status es CMPL, valido que no tenga G.I ni cnfs pendientes
	#Se envia en orden: 2010 ACT, 2010 CMPL, 2020 ACT, 2020 CMPL, 2030 ACT, Y 2030 CMPL
	
	
	
	for rowIndex in range(newRows.rowCount):
	
				FailedTimes   	= newRows.getValueAt(rowIndex,"FailedTimesPosting") 
				sourceID 		= newRows.getValueAt(rowIndex,"Seq")
				created_Date 	= system.date.now()	
				phase 			= newRows.getValueAt(rowIndex,"Phase") 
				status 			= newRows.getValueAt(rowIndex,"Status") 
				poNumber 		= newRows.getValueAt(rowIndex,"PO_Number")
				resource 		= newRows.getValueAt(rowIndex,"PhaseResource")
				sloc 			= newRows.getValueAt(rowIndex,"SLOC")
				userID 			= "System"
				datetime		= newRows.getValueAt(rowIndex,"EventDateTime")			
				psQuery 		= "select * from dbo.SF_MII_PHASE_STATUS_UI where Seq=?"
				psData 			= system.db.runPrepQuery(psQuery, [str(sourceID)], database)
				postMessage		= ''
				send_data		= 0
				psQuery_Resource 		= "select NODENAME from dbo.SF_MII_PO_HEADER_PHASES where PROCESSORDER_AUFNR=? AND RESOURCE_ARBPL=?"
				psData_Resource		= system.db.runPrepQuery(psQuery_Resource, [str(poNumber),str(resource)], database)
				
				#CONDITIONS TO SEND PHASE STATUS DATA
				print("Revisando id",sourceID, phase, status,poNumber)
				if (int(phase) != 2020 ) or (int(phase) == 2020 and (status == "ACT")): 
					if status=="ACT" and int(phase)!=2010:
						print("ACT found")
						previous_phase= myScripting_SIQ_idb.get_phase_previus(int(phase))
						
						query_check_cmpl 			= """SELECT TOP (1) *
											FROM [dbProductionLines].[dbo].[SF_MII_PHASE_STATUS_UI]
											WHERE STATUS='CMPL' AND PhaseResource=? AND PO_NUMBER=? and Phase=? and PS_Posting='PASS' 
											order by seq desc"""
						
						check_cmpl 		= system.db.runPrepQuery(query_check_cmpl, [resource,poNumber,previous_phase], database) 
						
						if check_cmpl.rowCount==0:
							print("ACT ",previous_phase,query_check_cmpl,sourceID,check_cmpl.rowCount)
							msg_response="Previous Phase: "+str(previous_phase)+ " CMPL not send to MII yet."
							data_dict={
										"Message_Response": msg_response,
										"Seq_Cmp": sourceID
										}
							system.db.runNamedQuery("DATA_POST/IDB/Update_PS_msg",data_dict)
																					
					if status=="CMPL":
						print("CMPL found")
						query_check_cmpl 			= """SELECT TOP (1) *
						FROM [dbProductionLines].[dbo].[SF_MII_PHASE_STATUS_UI]
						WHERE STATUS='ACT' AND PhaseResource=? AND PO_NUMBER=? and Phase=? and PS_Posting='PASS'
						order by seq desc"""
						check_cmpl 		= system.db.runPrepQuery(query_check_cmpl, [resource,poNumber,phase], database) 
						if check_cmpl.rowCount==0:
							data_dict={
										"Message_Response": "Phase ACT not send to MII yet",
										"Seq_Cmp": sourceID
										}
							system.db.runNamedQuery("DATA_POST/IDB/Update_PS_msg",data_dict)
												
					if (status == "ACT"  and int(phase)==2010) or ( (status == "ACT" or status == "CMPL") and check_cmpl.rowCount==1) or  (status != "ACT" and status != "CMPL"): #2010 preguntar por el state
						
						#LF04-> 2030 ACT PO 12345, NEW
						
						#LF04-> 2010 ACT PO 54321
						
						
						
						#REVISA SI PARA EL RECURSO ACTUAL HAY OTRA PO ACTIVA
						
						if (status == "ACT"  and int(phase)==2010):
							#Revisar si tiene dato con NEW
							query_check_pendings			= """SELECT *
													FROM [dbProductionLines].[dbo].[SF_MII_PHASE_STATUS_UI]
													WHERE PhaseResource=? and PS_Posting='NEW' and PO_NUMBER != ?"""
							check_pending 		= system.db.runPrepQuery(query_check_pendings, [resource, poNumber], database) 
							if  check_pending.rowCount==0:
								send_data=1
							else:
								data_dict={
											"Message_Response": "There are pending phase status in another PO for this resource",
											"Seq_Cmp": sourceID
											}
								system.db.runNamedQuery("DATA_POST/IDB/Update_PS_msg",data_dict)
								continue
						else:
							print("Enviar", phase, status,poNumber)
							send_data=1
					else:
						send_data=0
						print("No Enviar", phase, status,poNumber)
				
						
				
				elif  (int(phase) == 2020 and (status == "CMPL"  or status == "Complete" ) ):
				
					query_check_act 			= """SELECT TOP (1) *
					FROM [dbProductionLines].[dbo].[SF_MII_PHASE_STATUS_UI]
					WHERE STATUS='ACT' AND PhaseResource=? AND PO_NUMBER=? and Phase=?
					order by seq desc"""
					check_act 		= system.db.runPrepQuery(query_check_act, [resource,poNumber,phase], database) 	
					
					psQueryGI_Check 	= "select * from dbo.SF_MII_Goods_Issues_UI where Process_Order = ? and  ( (MII_Send = 0 and FailedTimesPosting <3 and GI_Validation!='ERROR'  )  or (MII_Send = 0 and GI_Validation='ERROR' and Child is NULL) )"
					psDataGI 			= system.db.runPrepQuery(psQueryGI_Check, [str(poNumber)], database)
					
					psQueryCnf_Check	= "select * from dbo.SF_MII_CONFIRMATION_UI where PO_Number = ? and MII_Send = 0 and FailedTimesPosting <3 "
					psDataCnf			= system.db.runPrepQuery(psQueryCnf_Check, [str(poNumber)], database)
					
					#AQUI REVISO QUE LA FASE ANTERIOR DEL RECURSO SEA: ACT SI LA FASE ACTUAL ES CMPL, Y CMPL SI LA FASE ACTUAL ES ACT
					
					print("CMPL",poNumber,sourceID,	psDataGI.rowCount, psDataCnf.rowCount )
					
					if 	(psDataGI.rowCount == 0 and psDataCnf.rowCount==0) and check_act.rowCount==1:
					#if 	(psDataCnf.rowCount==0) and check_act.rowCount==1:
						send_data	= 1
					else:
						#Update pendientes 
						send_data	= 0
						data_dict={
								"Message_Response": "IGN MESSAGE>>> G.I: "+	str(psDataGI.rowCount)+", CNF: "+str(psDataCnf.rowCount)+", Phase ACT send(1 Yes, 0 No):"+str(check_act.rowCount),
								"Seq_Cmp": sourceID
								}
						system.db.runNamedQuery("DATA_POST/IDB/Update_PS_msg",data_dict)
						
				#SEND PHASE STATUS DATA
				if send_data ==1:
					print("creando xml")
					itemsXML = ''
					postMessage = '<Phase_Status>' + '\'
									'<row>' + '\'
										handleValue(psData,0,"SAPClient","SAPClient") + '\'
										handleValue(psData,0,"SAPPlant","SAPPlant") + '\'
										handleValue(psData_Resource,0,"NODENAME","SAPResourceName") + '\'
										handleValue(psData,0,"PO_Number","Order") + '\'
										handlePhase(psData,0,"Phase","Phase") + '\'
										handleValue(psData,0,"Status","PhaseStatus") + '\'
										handleValue(psData,0,"SLOC","SLOC") + '\'
										handleValue(psData,0,"EventDateTime","EventTime") + '\'
										handleValue(psData,0,"MessageID","MessageID") + '\'
									'</row>' + \
								'</Phase_Status>'
					try:
					
						print(postMessage)
						postReturn 	= system.net.httpPost(url,'text/xml',postMessage,100000,100000)  #18OCT2023: Esperar a URL
						
						returnMessage	= str(postReturn).find("<Message>Message successfully queued.</Message>\r\n")
						
						print("Mensaje encontrado ",returnMessage)
						print("Mensaje recibido ",postReturn)

												
						#DATA SEND SUCCESFULLY
						print("Enviando")
						if returnMessage != -1: 
							print("Enviado")
							# 1 UPDATE BIT SAP_Send
							data_dict={
								"Seq_Cmp"		: int(sourceID),
								"Send"			: 1,
								"FailedTimes"	: 0
							}
							system.db.runNamedQuery("DATA_POST/IDB/Update_PS",data_dict)
							
							# 2 INSERT INTO LOG TABLE
							description 		= "Message successfully queued."
							insertResult		= 1
							messageType			= "PS"
							data_dict = {
							    "ID"			: sourceID,
							    "Created_Date"	: datetime,
							    "Description"	: description,
							    "MessageType"	: messageType,
							    "Phase"			: phase,
							    "PONumber"		: poNumber,
							    "Resource"		: resource,
							    "Result"		: insertResult,
							    "UserID"		: userID,
							    "XmlSend"		: postMessage
							}
							system.db.runNamedQuery("DATA_POST/IDB/Insert_DataLog",data_dict)
							
							print str(sourceID) + " " + str(poNumber) + " " + "Success"
						#DATA SEND FAILED
						else:
							print("No Enviado")
							FailedTimes= 1+int(FailedTimes) 
							# 1 UPDATE FAILED TIMES
							data_dict = {
								"Seq_Cmp": int(sourceID),
								"Send":0,
								"FailedTimes":FailedTimes
							}
							system.db.runNamedQuery("DATA_POST/IDB/Update_PS",data_dict)
							
							# 2 INSERT INTO LOG TABLE
							#rootMSG 			= ET.fromstring(postReturn) 
							description 		= "Failed" # myScripting.convertXMLtoDataset(rootMSG,"Body/XacuteResponse/Rowset").getValueAt(0,"MSG")
							messageType			= "PS"
							insertResult		= 0
							data_dict = {
								"ID"			: sourceID,
								"Created_Date"	: datetime,
								"Description"	: description,
								"MessageType"	: messageType,
								"Phase"			: phase,
								"PONumber"		: poNumber,
								"Resource"		: resource,
								"Result"		: insertResult,
								"UserID"		: userID,
								"XmlSend"		: postMessage
							}
							system.db.runNamedQuery("DATA_POST/IDB/Insert_DataLog",data_dict)
							
							print str(sourceID) + " " + str(poNumber) + " " + "Failed"
					except:
						import sys
						print("ERROR EN PS",str(sys.exc_info())) 
						
						logMessage 			= str(system.date.format(system.date.now())) + "Result: "+description+" Timeout" + " " + str(sys.exc_info())
						logTableName 		= "DBI_´hase_Status_Exceptions"
						description 		=  "ERROR EXECUTION"
						messageType			= "PS"
						insertResult		= 0	
						data_dict = {
						    "ID"			: sourceID,
						    "Created_Date"	: datetime,
						    "Description"	: "Excecution Error, id: "+sourceID+", Detail: "+ str(sys.exc_info()),
						    "MessageType"	: messageType,
						    "Phase"			: phase,
						    "PONumber"		: poNumber,
						    "Resource"		: resource,
						    "Result"		: insertResult,
						    "UserID"		: userID,
						    "XmlSend"		: postMessage
						}
						system.db.runNamedQuery("DATA_POST/IDB/Insert_DataLog",data_dict)
				
	return 0


