def addWcConfigutationInTags(tagProvider, plant, workCenterType, workCenter, functions):
	basePath = tagProvider + 'Coca-Cola/CPS/' + plant + '/'  + workCenterType
	tagPath = basePath + '/' + workCenter
	tags = []
	tag = {	"name" : 'WcConfiguration',
			"typeId" : 'WorkCenterConfiguration',
			"tagType" : "UdtInstance",
			}
	tags.append(tag)
	print tags
	system.tag.configure(tagPath, tags)
	
	nameTagPath = []
	nameTagValue = []
	browseName = system.tag.browse(tagPath +'/'+ 'WcConfiguration')
	for tagName in browseName:
		nameTagPath.append(str(tagName['fullPath']))
	for function in functions:
		nameTagValue.append(function['value'])
	
	system.tag.writeBlocking(nameTagPath, nameTagValue)
	
	
def UpdateDevice(WorkCenter, Devices, User):
	
	#Get WC id
	NamedQuery = 'getWorkCentersDetails'
	Parameter = {"wcName" : WorkCenter}
	WcId = system.db.runNamedQuery(NamedQuery,Parameter)
	
	#Add deivces in tblDeviceMaster
	for Device in Devices:
	    Type = Device['deviceType']
	    Name = Device['deviceName']
	    Capacity = Device['deviceCapacity']
	    UOM = ''
	    NamedQuery = 'WCConfiguration/AddDevice'
	    Parameter = {"Name" : Name, "Type" : Type, "Capacity" : Capacity, "UOM" : UOM, "WcId" : WcId[0][0], "UpdateBy" : User}
	    print Parameter
	    system.db.runNamedQuery('WCConfiguration/AddDevice',Parameter)
	    
	    #def UpdateDevice(WorkCenter, Devices, User):

	WorkCenter = 'LF01'
	#Devices 
	#User
		
	#Get WC id
	NamedQuery = 'getWorkCentersDetails'
	Parameter = {"wcName" : WorkCenter}
	WcId = system.db.runNamedQuery(NamedQuery,Parameter)
	
	
	#find devices in WcId WC which is having IsDeleted = 0
	
	NamedQuery = 'WCConfiguration/getWCDevices'
	Parameter = {"wcId" :WcId, "isDeleted": 0}
	GetDevices = system.db.runNamedQuery(NamedQuery,Parameter)
	print GetDevices
	
	#delete selected devices (make IsDelete Property to 1)
	
	# On save update button add devices on WC.

for Device in Devices:
    Type = Device['deviceType']
    Name = Device['deviceName']
    Capacity = Device['deviceCapacity']
    UOM = ''
    NamedQuery = 'WCConfiguration/AddDevice'
    Parameter = {"Name" : Name, "Type" : Type, "Capacity" : Capacity, "UOM" : UOM, "WcId" : WcId[0][0], "UpdateBy" : User}
    print Parameter
    system.db.runNamedQuery('WCConfiguration/AddDevice',Parameter)
    
def UpdateFuncitons(WorkCenter, Functions, User):
	values = []
	for function in Functions:
		values.append(function["value"])
	NamedQuery = 'WCConfiguration/WcFuncitons'
	Parameter = {"WC" : WorkCenter, "EnableAutoGi" : values[0], "EnableAutoPr" : values[1], "EnableAutoPhaseCom" : values[2], "EnableBbd" : values[3], "EnableMatManage" : values[4], "EnableStockValidation" : values[5], "EnablePartialGi" : values[6], "EnableSkipBbd" : values[7], "PartialGiFreq" : values[8], "User" : User}
	system.db.runNamedQuery(NamedQuery,Parameter)