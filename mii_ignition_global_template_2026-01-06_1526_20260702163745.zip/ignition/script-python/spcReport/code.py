# Function to calculate the standard deviation
def calculate_std_deviation(numbers):
	import math
	# Calculate the mean
	mean = sum(numbers) / len(numbers)
	# Calculate the variance
	variance = sum((x - mean) ** 2 for x in numbers) / len(numbers)
	# Calculate the standard deviation
	std_deviation = round(math.sqrt(variance),3)
	return std_deviation