def Recommendation(PoHeader, PRI_PACK_TOL, PoHeaderPhases, PoPhasesResb, CheckweigherPP, CheckweigherSP):
	#Checking PO is Dry filling / Liquid filling
	Area = PoHeader['AREA']
	print Area
	logger = system.util.getLogger("Operational scenario details ")
	
#Checking workcenter
	Resource = PoHeaderPhases["ARBPL"]
	
	
	MII_Ignition_Library.Logger.Insert_Log.Insert_Info_Log("OperationalScenarios: Recommendation (in) ",str(Area))
	
	
#Checking phantom is present or not
	if len(PRI_PACK_TOL) > 0:
		try:
			PhantomCounts = 0
			for row in PRI_PACK_TOL :
				IsPhantom = row["PHANTOM"]
				if IsPhantom == "X":
					PhantomCounts += 1
			print ("Phantom : " + str(PhantomCounts))
			MII_Ignition_Library.Logger.Insert_Log.Insert_Info_Log("OperationalScenarios: Recommendation (line 23) ",str(PhantomCounts))
		except:
			PhantomCounts = 0
			IsPhantom = PRI_PACK_TOL["PHANTOM"]
			if IsPhantom == "X":
				PhantomCounts += 1
			#print ("Phantom : " + str(PhantomCounts))
#Checking No. of ingredients
	if len(PoPhasesResb) > 0:
		ingredients = 0
		for row in PoPhasesResb:
			if ((row["MTART"] == "ROH") or (row["MTART"] == "HALB") and (row["BDMNG"] != '0') and (row["BDMNG"] != '---') and ((row["MATNR_DESC"]).find('WIP') == -1)):
				ingredients += 1
				
		#print ("Ingredients : " + str(ingredients))
#Checking No. of filled bags
	if PhantomCounts > 0:
	    if ingredients >= 1:
			filledBags = 0
			try:
				for ingredient in PRI_PACK_TOL :
					if ingredient["PHANTOM"] == "X":
						filledBags += 1
				#print ("Filled bags : " + str(filledBags))
			except:
				if PRI_PACK_TOL["PHANTOM"] == "X":
					filledBags += 1
				#print ("Filled bags : " + str(filledBags))
#Checking number of WIPs present
	if len(PoPhasesResb) > 0:
	        WIP = 0
	        for row in PoPhasesResb:
	            MII_Ignition_Library.Logger.Insert_Log.Insert_Info_Log("OperationalScenarios: Before Error 0","Error0")
	            #MII_Ignition_Library.Logger.Insert_Log.Insert_Info_Log("OperationalScenarios: Before Error 0",str(row["MATNR_DESC"]))
	            if (row["MATNR_DESC"] is not None):
	            	if (((row["MATNR_DESC"]).find('WIP') != -1) and (row["BDMNG"] != '0') and (row["BDMNG"] != '---')):
	            		WIP += 1
	            		MII_Ignition_Library.Logger.Insert_Log.Insert_Info_Log("OperationalScenarios: Before ","Error1")

#Checking is full split and partial split are enable or not
	path = 'OperationalSenario/getSplitConfiguration'
	params = {'wc' : Resource}
	split = system.db.runNamedQuery(path, params)
	fullSplit = split[0][0]
	partialSplit = split[0][1]


#Split type defination
# 0 = no split
# 1 = full split
# 2 = partial split

#Checking shopfloor configuration
	#Liquid Scenarios
	if Area == ("LIQ_FILL_AREA" or "LIQUID_FILLING_AREA"):
		#print "Liq"
		#No phantom present
		if PhantomCounts == 0:
		    result = [  {"action": 0,
		        			"description": "PR/GI trigger : Primary Checkweigher",
		        			"opScenario": "Standard Non Phantom",
		       				"srNo": 1, "radioButton": bool(0), "scenarioNumber" : 1, "scenarioType" : 1}]
		    #if CheckweigherPP != 0:
		    #    result = [  {"action": 0,
		    #    			"description": "PR/GI trigger : Primary Checkweigher",
		    #    			"opScenario": "Standard Non Phantom",
		    #   			"srNo": 1, "radioButton": bool(0), "scenarioNumber" : 1, "scenarioType" : 1},{"action": 0,
		    #    			"description": "PR/GI trigger : Filler Head",
		    #    			"opScenario": "Standard Non Phantom with Virtual CW",
		    #    			"srNo": 2, "radioButton": bool(0), "scenarioNumber" : 2, "scenarioType" : 1}]
		    #else:
		    #    result = [  {"action": 0,
		    #    			"description": "PR/GI trigger : Filler Head",
		    #    			"opScenario": "Standard Non Phantom with Virtual CW",
		    #    			"srNo": 1, "radioButton": bool(0), "scenarioNumber" : 2, "scenarioType" : 1}]
		#Multiple phantom present
		else:
			result = [  {"action": 0,
		        			"description": "PR/GI trigger : Secondary Checkweigher",
		        			"opScenario": "Standard Phantom",
		        			"srNo": 1, "radioButton": bool(0), "scenarioNumber" : 3, "scenarioType" : 2}]
		    #if CheckweigherPP > 0 and CheckweigherSP > 0:
		    #	result = [  {"action": 0,
		    #    			"description": "PR/GI trigger : Secondary Checkweigher",
		    #    			"opScenario": "Standard Phantom",
		    #    			"srNo": 1, "radioButton": bool(0), "scenarioNumber" : 3, "scenarioType" : 2},{"action": 0,
		    #    			"description": "PR/GI trigger : Primary Checkweigher",
		    #    			"opScenario": "Standard Phantom with Virtual Assembly",
		    #    			"srNo": 2, "radioButton": bool(0), "scenarioNumber" : 4, "scenarioType" : 2},{"action": 0,
		    #    			"description": "PR/GI trigger : Secondary Checkweigher",
		    #    			"opScenario": "Standard Phantom with missing Drum CW",
		    #    			"srNo": 3, "radioButton": bool(0), "scenarioNumber" : 5, "scenarioType" : 2},{"action": 0,
		    #    			"description": "PR/GI trigger : Filler Head",
		    #    			"opScenario": "Standard Phantom with Virtual Assembly and CW",
		    #    			"srNo": 4, "radioButton": bool(0), "scenarioNumber" : 6, "scenarioType" : 2}]
		        
		    #elif CheckweigherPP > 0 and CheckweigherSP == 0:
		    #    result = [  {"action": 0,
		    #    			"description": "PR/GI trigger : Primary Checkweigher",
		    #    			"opScenario": "Standard Phantom with Virtual Assembly",
		    #    			"srNo": 1, "radioButton": bool(0), "scenarioNumber" : 4, "scenarioType" : 2},{"action": 0,
		    #    			"description": "PR/GI trigger : Primary Checkweigher",
		    #    			"opScenario": "Standard Phantom with Virtual Assembly and CW",
		    #    			"srNo": 2, "radioButton": bool(0), "scenarioNumber" : 6, "scenarioType" : 2}]
		        
		    #elif CheckweigherPP == 0 and CheckweigherSP > 0:
		    #    result = [  {"action": 0,
		    #    			"description": "PR/GI trigger : Secondary Checkweigher",
		    #   			"opScenario": "Standard Phantom with missing Drum CW",
		    #    			"srNo": 1, "radioButton": bool(0), "scenarioNumber" : 5, "scenarioType" : 2},{"action": 0,
		    #    			"description": "PR/GI trigger : Filler Head",
		    #    			"opScenario": "Standard Phantom with Virtual Assembly and CW",
		    #    			"srNo": 2, "radioButton": bool(0), "scenarioNumber" : 6, "scenarioType" : 2}]
		        
		    #else:
		    #    result = [  {"action": 0,
		    #    			"description": "PR/GI trigger : Filler Head",
		    #    			"opScenario": "Standard Phantom with Virtual Assembly and CW",
		    #   			"srNo": 1, "radioButton": bool(0), "scenarioNumber" : 6, "scenarioType" : 2}]
		    
	#Dry Scenarios
	elif Area == ("DRY_FILLING_AREA" or "DRY_FILL_AREA"):
		print "dry"
		#No phantom present
		if PhantomCounts == 0:
			#Multiple Ingredients
			if ingredients > 1:
				if fullSplit == True and partialSplit == True:
					result = [ {"action": 0,
								"description": "PR/GI trigger : Secondary Checkweigher",
								"opScenario": "Dry Filling WIP",
								"srNo": 1, "radioButton": bool(0), "splitType" : 0, "scenarioNumber" : 7, "scenarioType" : 3},{"action": 1,
								"description": "PR/GI trigger : Secondary Checkweigher",
								"opScenario": "Dry Filling WIP with Full Ingredient Split",
								"srNo": 2, "radioButton": bool(0), "splitType" : 1, "scenarioNumber" : 8, "scenarioType" : 3},{"action": 1,
								"description": "PR/GI trigger : Secondary Checkweigher",
								"opScenario": "Dry Filling WIP with Partial Ingredient Split",
								"srNo": 3, "radioButton": bool(0), "splitType" : 2, "scenarioNumber" : 9, "scenarioType" : 3}]
				if fullSplit == True and partialSplit == False:
					result = [ {"action": 0,
								"description": "PR/GI trigger : Secondary Checkweigher",
								"opScenario": "Dry Filling WIP",
								"srNo": 1, "radioButton": bool(0), "splitType" : 0, "scenarioNumber" : 7, "scenarioType" : 3},{"action": 1,
								"description": "PR/GI trigger : Secondary Checkweigher",
								"opScenario": "Dry Filling WIP with Full Ingredient Split",
								"srNo": 2, "radioButton": bool(0), "splitType" : 1, "scenarioNumber" : 8, "scenarioType" : 3}]
				if fullSplit == False and partialSplit == True:
					result = [ {"action": 0,
								"description": "PR/GI trigger : Secondary Checkweigher",
								"opScenario": "Dry Filling WIP",
								"srNo": 1, "radioButton": bool(0), "splitType" : 0, "scenarioNumber" : 7, "scenarioType" : 3},{"action": 1,
								"description": "PR/GI trigger : Secondary Checkweigher",
								"opScenario": "Dry Filling WIP with Partial Ingredient Split",
								"srNo": 2, "radioButton": bool(0), "splitType" : 2, "scenarioNumber" : 9, "scenarioType" : 3}]
				if fullSplit == False and partialSplit == False:
					result = [ {"action": 0,
								"description": "PR/GI trigger : Secondary Checkweigher",
								"opScenario": "Dry Filling WIP",
								"srNo": 1, "radioButton": bool(0), "splitType" : 0, "scenarioNumber" : 7, "scenarioType" : 3}]
			#Single Ingredients
			elif ingredients == 1:
				if fullSplit == True and partialSplit == True:
					result = [ {"action": 0,
								"description": "PR/GI trigger : Secondary Checkweigher",
								"opScenario": "Dry Filling WIP",
								"srNo": 1, "radioButton": bool(0), "splitType" : 0, "scenarioNumber" : 10, "scenarioType" : 4},{"action": 1,
								"description": "PR/GI trigger : Secondary Checkweigher",
								"opScenario": "Dry Filling WIP with Full Ingredient Split",
								"srNo": 2, "radioButton": bool(0), "splitType" : 1, "scenarioNumber" : 11, "scenarioType" : 4},{"action": 1,
								"description": "PR/GI trigger : Secondary Checkweigher",
								"opScenario": "Dry Filling WIP with Partial Ingredient Split",
								"srNo": 3, "radioButton": bool(0), "splitType" : 2, "scenarioNumber" : 12, "scenarioType" : 4}]
				if fullSplit == True and partialSplit == False:
					result = [ {"action": 0,
								"description": "PR/GI trigger : Secondary Checkweigher",
								"opScenario": "Dry Filling WIP",
								"srNo": 1, "radioButton": bool(0), "splitType" : 0, "scenarioNumber" : 10, "scenarioType" : 4},{"action": 1,
								"description": "PR/GI trigger : Secondary Checkweigher",
								"opScenario": "Dry Filling WIP with Full Ingredient Split",
								"srNo": 2, "radioButton": bool(0), "splitType" : 1, "scenarioNumber" : 11, "scenarioType" : 4}]
				if fullSplit == False and partialSplit == True:
					result = [ {"action": 0,
								"description": "PR/GI trigger : Secondary Checkweigher",
								"opScenario": "Dry Filling WIP",
								"srNo": 1, "radioButton": bool(0), "splitType" : 0, "scenarioNumber" : 10, "scenarioType" : 4},{"action": 1,
								"description": "PR/GI trigger : Secondary Checkweigher",
								"opScenario": "Dry Filling WIP with Partial Ingredient Split",
								"srNo": 3, "radioButton": bool(0), "splitType" : 2, "scenarioNumber" : 12, "scenarioType" : 4}]
				if fullSplit == False and partialSplit == False:
					result = [ {"action": 0,
								"description": "PR/GI trigger : Secondary Checkweigher",
								"opScenario": "Dry Filling WIP",
								"srNo": 1, "radioButton": bool(0), "splitType" : 0, "scenarioNumber" : 10, "scenarioType" : 4}]
			elif ingredients == 0:
				result = [ {"action": 0,
							"description": "PR/GI trigger : Secondary Checkweigher",
							"opScenario": "Dry Assembly WIP in Box",
							"srNo": 1, "radioButton": bool(0), "scenarioNumber" : 13, "scenarioType" : 5}]
		#Multple phantom present
		else:
			#Single ingredients and single filledbags with and no WIPs
			if ingredients == 1 and filledBags ==1 and WIP == 0:
				if fullSplit == True and partialSplit == True:
					result = [ {"action": 0,
								"description": "PR/GI trigger : Secondary Checkweigher",
								"opScenario": "Dry Filling Single Phantom no Assembly",
								"srNo": 1, "radioButton": bool(0), "splitType" : 0, "scenarioNumber" : 14, "scenarioType" : 6},{"action": 1,
								"description": "PR/GI trigger : Secondary Checkweigher",
								"opScenario": "Dry Filling Single Phantom no Assembly with Full Ingredient Split",
								"srNo": 2, "radioButton": bool(0), "splitType" : 1, "scenarioNumber" : 15, "scenarioType" : 6},{"action": 1,
								"description": "PR/GI trigger : Secondary Checkweigher",
								"opScenario": "Dry Filling Single Phantom no Assembly with Partial Ingredient Split",
								"srNo": 3, "radioButton": bool(0), "splitType" : 2, "scenarioNumber" : 16, "scenarioType" : 6}]
				if fullSplit == True and partialSplit == False:
					result = [ {"action": 0,
								"description": "PR/GI trigger : Secondary Checkweigher",
								"opScenario": "Dry Filling Single Phantom no Assembly",
								"srNo": 1, "radioButton": bool(0), "splitType" : 0, "scenarioNumber" : 14, "scenarioType" : 6},{"action": 1,
								"description": "PR/GI trigger : Secondary Checkweigher",
								"opScenario": "Dry Filling Single Phantom no Assembly with Full Ingredient Split",
								"srNo": 2, "radioButton": bool(0), "splitType" : 1, "scenarioNumber" : 15, "scenarioType" : 6}]
				if fullSplit == False and partialSplit == True:
					result = [ {"action": 0,
								"description": "PR/GI trigger : Secondary Checkweigher",
								"opScenario": "Dry Filling Single Phantom no Assembly",
								"srNo": 1, "radioButton": bool(0), "splitType" : 0, "scenarioNumber" : 14, "scenarioType" : 6},{"action": 1,
								"description": "PR/GI trigger : Secondary Checkweigher",
								"opScenario": "Dry Filling Single Phantom no Assembly with Partial Ingredient Split",
								"srNo": 3, "radioButton": bool(0), "splitType" : 2, "scenarioNumber" : 16, "scenarioType" : 6}]
				if fullSplit == False and partialSplit == False:
					result = [ {"action": 0,
								"description": "PR/GI trigger : Secondary Checkweigher",
								"opScenario": "Dry Filling Single Phantom no Assembly",
								"srNo": 1, "radioButton": bool(0), "splitType" : 0, "scenarioNumber" : 14, "scenarioType" : 6}]
			
			#Multiple ingredients and single filledbags with and no WIPs
			elif ingredients > 1 and filledBags == 1 and WIP == 0:
				if fullSplit == True and partialSplit == True:
					result = [ {"action": 0,
								"description": "PR/GI trigger : Secondary Checkweigher",
								"opScenario": "Dry Filling Single Phantom no Assembly",
								"srNo": 1, "radioButton": bool(0), "splitType" : 0, "scenarioNumber" : 17, "scenarioType" : 7},{"action": 1,
								"description": "PR/GI trigger : Secondary Checkweigher",
								"opScenario": "Dry Filling Single Phantom no Assembly with Full Ingredient Split",
								"srNo": 2, "radioButton": bool(0), "splitType" : 1, "scenarioNumber" : 18, "scenarioType" : 7},{"action": 1,
								"description": "PR/GI trigger : Secondary Checkweigher",
								"opScenario": "Dry Filling Single Phantom no Assembly with Partial Ingredient Split",
								"srNo": 3, "radioButton": bool(0), "splitType" : 2, "scenarioNumber" : 19, "scenarioType" : 7}]
				if fullSplit == True and partialSplit == False:
					result = [ {"action": 0,
								"description": "PR/GI trigger : Secondary Checkweigher",
								"opScenario": "Dry Filling Single Phantom no Assembly",
								"srNo": 1, "radioButton": bool(0), "splitType" : 0, "scenarioNumber" : 17, "scenarioType" : 7},{"action": 1,
								"description": "PR/GI trigger : Secondary Checkweigher",
								"opScenario": "Dry Filling Single Phantom no Assembly with Full Ingredient Split",
								"srNo": 2, "radioButton": bool(0), "splitType" : 1, "scenarioNumber" : 18, "scenarioType" : 7}]
				if fullSplit == False and partialSplit == True:
					result = [ {"action": 0,
								"description": "PR/GI trigger : Secondary Checkweigher",
								"opScenario": "Dry Filling Single Phantom no Assembly",
								"srNo": 1, "radioButton": bool(0), "splitType" : 0, "scenarioNumber" : 17, "scenarioType" : 7},{"action": 1,
								"description": "PR/GI trigger : Secondary Checkweigher",
								"opScenario": "Dry Filling Single Phantom no Assembly with Partial Ingredient Split",
								"srNo": 3, "radioButton": bool(0), "splitType" : 2, "scenarioNumber" : 19, "scenarioType" : 7}]
				if fullSplit == False and partialSplit == False:
					result = [ {"action": 0,
								"description": "PR/GI trigger : Secondary Checkweigher",
								"opScenario": "Dry Filling Single Phantom no Assembly",
								"srNo": 1, "radioButton": bool(0), "splitType" : 0, "scenarioNumber" : 17, "scenarioType" : 7}]
			
			#Multiple ingredients and multiple filledbags with and no WIPs
			elif ingredients > 1 and filledBags > 1 and WIP == 0:
				if fullSplit == True and partialSplit == True:
					result = [ {"action": 0,
								"description": "PR/GI trigger : Secondary Checkweigher",
								"opScenario": "Dry Filling Multiple Phantom no Assembly",
								"srNo": 1, "radioButton": bool(0), "splitType" : 0, "ScenarioNumber" : 20, "scenarioType" : 8},{"action": 1,
								"description": "PR/GI trigger : Secondary Checkweigher",
								"opScenario": "Dry Filling Multiple Phantom no Assembly with Full Ingredient Split",
								"srNo": 2, "radioButton": bool(0), "splitType" : 1, "scenarioNumber" : 21, "scenarioType" : 8},{"action": 1,
								"description": "PR/GI trigger : Secondary Checkweigher",
								"opScenario": "Dry Filling Multiple Phantom no Assembly with Partial Ingredient Split",
								"srNo": 3, "radioButton": bool(0), "splitType" : 2, "scenarioNumber" : 22, "scenarioType" : 8}]
				if fullSplit == True and partialSplit == False:
					result = [ {"action": 0,
								"description": "PR/GI trigger : Secondary Checkweigher",
								"opScenario": "Dry Filling Multiple Phantom no Assembly",
								"srNo": 1, "radioButton": bool(0), "splitType" : 0, "scenarioNumber" : 20, "scenarioType" : 8},{"action": 1,
								"description": "PR/GI trigger : Secondary Checkweigher",
								"opScenario": "Dry Filling Multiple Phantom no Assembly with Full Ingredient Split",
								"srNo": 2, "radioButton": bool(0), "splitType" : 1, "scenarioNumber" : 21, "scenarioType" : 8}]
				if fullSplit == False and partialSplit == True:
					result = [ {"action": 0,
								"description": "PR/GI trigger : Secondary Checkweigher",
								"opScenario": "Dry Filling Multiple Phantom no Assembly",
								"srNo": 1, "radioButton": bool(0), "splitType" : 0, "scenarioNumber" : 20, "scenarioType" : 8},{"action": 1,
								"description": "PR/GI trigger : Secondary Checkweigher",
								"opScenario": "Dry Filling Multiple Phantom no Assembly with Partial Ingredient Split",
								"srNo": 3, "radioButton": bool(0), "splitType" : 2, "scenarioNumberscenarioNumber" : 22}]
				if fullSplit == False and partialSplit == False:
					result = [ {"action": 0,
								"description": "PR/GI trigger : Secondary Checkweigher",
								"opScenario": "Dry Filling Multiple Phantom no Assembly",
								"srNo": 1, "radioButton": bool(0), "splitType" : 0, "ScenarioNumber" : 20, "scenarioType" : 8}]
			
			#Single ingredients and single filledbags with and WIPs
			elif ingredients == 1 and filledBags == 1 and WIP > 0:
				if fullSplit == True and partialSplit == True:
					result = [ {"action": 0,
								"description": "PR/GI trigger : Secondary Checkweigher",
								"opScenario": "Dry Filling Single Phantom with Assembly",
								"srNo": 1, "radioButton": bool(0), "splitType" : 0, "scenarioNumber" : 23, "scenarioType" : 9},{"action": 1,
								"description": "PR/GI trigger : Secondary Checkweigher",
								"opScenario": "Dry Filling Single Phantom with Assembly with Full Ingredient Split",
								"srNo": 2, "radioButton": bool(0), "splitType" : 1, "scenarioNumber" : 24, "scenarioType" : 9},{"action": 1,
								"description": "PR/GI trigger : Secondary Checkweigher",
								"opScenario": "Dry Filling Single Phantom with Assembly with Partial Ingredient Split",
								"srNo": 3, "radioButton": bool(0), "splitType" : 2, "scenarioNumber" : 25, "scenarioType" : 9}]
				if fullSplit == True and partialSplit == False:
					result = [ {"action": 0,
								"description": "PR/GI trigger : Secondary Checkweigher",
								"opScenario": "Dry Filling Single Phantom with Assembly",
								"srNo": 1, "radioButton": bool(0), "splitType" : 0, "ScenarioNumber" : 23, "scenarioType" : 9},{"action": 1,
								"description": "PR/GI trigger : Secondary Checkweigher",
								"opScenario": "Dry Filling Single Phantom with Assembly with Full Ingredient Split",
								"srNo": 2, "radioButton": bool(0), "splitType" : 1, "scenarioNumber" : 24, "scenarioType" : 9}]
				if fullSplit == False and partialSplit == True:
					result = [ {"action": 0,
								"description": "PR/GI trigger : Secondary Checkweigher",
								"opScenario": "Dry Filling Single Phantom with Assembly",
								"srNo": 1, "radioButton": bool(0), "splitType" : 0, "scenarioNumber" : 23, "scenarioType" : 9},{"action": 1,
								"description": "PR/GI trigger : Secondary Checkweigher",
								"opScenario": "Dry Filling Single Phantom with Assembly with Partial Ingredient Split",
								"srNo": 3, "radioButton": bool(0), "splitType" : 2, "ScenarioNumber" : 25, "scenarioType" : 9}]
				if fullSplit == False and partialSplit == False:
					result = [ {"action": 0,
								"description": "PR/GI trigger : Secondary Checkweigher",
								"opScenario": "Dry Filling Single Phantom with Assembly",
								"srNo": 1, "radioButton": bool(0), "splitType" : 0, "scenarioNumber" : 23, "scenarioType" : 9}]
			
			#Multiple ingredients and single filledbags with and WIPs
			elif ingredients > 1 and filledBags == 1 and WIP > 0:
				if fullSplit == True and partialSplit == True:
					result = [ {"action": 0,
								"description": "PR/GI trigger : Secondary Checkweigher",
								"opScenario": "Dry Filling Single Phantom with Assembly",
								"srNo": 1, "radioButton": bool(0), "splitType" : 0, "scenarioNumber" : 26, "scenarioType" : 10},{"action": 1,
								"description": "PR/GI trigger : Secondary Checkweigher",
								"opScenario": "Dry Filling Single Phantom with Assembly with Full Ingredient Split",
								"srNo": 2, "radioButton": bool(0), "splitType" : 1, "scenarioNumber" : 27, "scenarioType" : 10},{"action": 1,
								"description": "PR/GI trigger : Secondary Checkweigher",
								"opScenario": "Dry Filling Single Phantom with Assembly with Partial Ingredient Split",
								"srNo": 3, "radioButton": bool(0), "splitType" : 2, "scenarioNumber" : 28, "scenarioType" : 10}]
				if fullSplit == True and partialSplit == False:
					result = [ {"action": 0,
								"description": "PR/GI trigger : Secondary Checkweigher",
								"opScenario": "Dry Filling Single Phantom with Assembly",
								"srNo": 1, "radioButton": bool(0), "splitType" : 0, "scenarioNumber" : 26, "scenarioType" : 10},{"action": 1,
								"description": "PR/GI trigger : Secondary Checkweigher",
								"opScenario": "Dry Filling Single Phantom with Assembly with Full Ingredient Split",
								"srNo": 2, "radioButton": bool(0), "splitType" : 1, "scenarioNumber" : 27, "scenarioType" : 10}]
				if fullSplit == False and partialSplit == True:
					result = [ {"action": 0,
								"description": "PR/GI trigger : Secondary Checkweigher",
								"opScenario": "Dry Filling Single Phantom with Assembly",
								"srNo": 1, "radioButton": bool(0), "splitType" : 0, "scenarioNumber" : 26, "scenarioType" : 10},{"action": 1,
								"description": "PR/GI trigger : Secondary Checkweigher",
								"opScenario": "Dry Filling Single Phantom with Assembly with Partial Ingredient Split",
								"srNo": 3, "radioButton": bool(0), "splitType" : 2, "scenarioNumber" : 28, "scenarioType" : 10}]
				if fullSplit == False and partialSplit == False:
					result = [ {"action": 0,
								"description": "PR/GI trigger : Secondary Checkweigher",
								"opScenario": "Dry Filling Single Phantom with Assembly",
								"srNo": 1, "radioButton": bool(0), "splitType" : 0, "scenarioNumber" : 26, "scenarioType" : 10}]
			
			#Multiple ingredients and multiple filledbags with and WIPs
			elif ingredients > 1 and filledBags > 1 and WIP > 0:
				if fullSplit == True and partialSplit == True:
					result = [ {"action": 0,
								"description": "PR/GI trigger : Secondary Checkweigher",
								"opScenario": "Dry Filling Multiple Phantom with Assembly",
								"srNo": 1, "radioButton": bool(0), "splitType" : 0, "scenarioNumber" : 29, "scenarioType" : 11},{"action": 1,
								"description": "PR/GI trigger : Secondary Checkweigher",
								"opScenario": "Dry Filling Multiple Phantom with Assembly with Full Ingredient Split",
								"srNo": 2, "radioButton": bool(0), "splitType" : 1, "scenarioNumber" : 30, "scenarioType" : 11},{"action": 1,
								"description": "PR/GI trigger : Secondary Checkweigher",
								"opScenario": "Dry Filling Multiple Phantom with Assembly with Partial Ingredient Split",
								"srNo": 3, "radioButton": bool(0), "splitType" : 2, "scenarioNumber" : 31, "scenarioType" : 11}]
				if fullSplit == True and partialSplit == False:
					result = [ {"action": 0,
								"description": "PR/GI trigger : Secondary Checkweigher",
								"opScenario": "Dry Filling Multiple Phantom with Assembly",
								"srNo": 1, "radioButton": bool(0), "splitType" : 0, "scenarioNumber" : 29, "scenarioType" : 12},{"action": 1,
								"description": "PR/GI trigger : Secondary Checkweigher",
								"opScenario": "Dry Filling Multiple Phantom with Assembly with Full Ingredient Split",
								"srNo": 2, "radioButton": bool(0), "splitType" : 1, "scenarioNumber" : 30, "scenarioType" : 12}]
				if fullSplit == False and partialSplit == True:
					result = [ {"action": 0,
								"description": "PR/GI trigger : Secondary Checkweigher",
								"opScenario": "Dry Filling Multiple Phantom with Assembly",
								"srNo": 1, "radioButton": bool(0), "splitType" : 0, "scenarioNumber" : 29, "scenarioType" : 12},{"action": 1,
								"description": "PR/GI trigger : Secondary Checkweigher",
								"opScenario": "Dry Filling Multiple Phantom with Assembly with Partial Ingredient Split",
								"srNo": 3, "radioButton": bool(0), "splitType" : 2, "scenarioNumber" : 31, "scenarioType" : 12}]
				if fullSplit == False and partialSplit == False:
					result = [ {"action": 0,
								"description": "PR/GI trigger : Secondary Checkweigher",
								"opScenario": "Dry Filling Multiple Phantom with Assembly",
								"srNo": 1, "radioButton": bool(0), "splitType" : 0, "scenarioNumber" : 26, "scenarioType" : 12}]
	return result
	
def uniqueMaterial(materials):
    uniqueList = []
    result = []

    # Dictionary to store the summed quantities
    materialDict = {}

    # Traverse for all elements and sum quantities
    for material in materials:
        matnr = material["MATNR"]
        bdmng = 0
        try:
        	bdmng = float(material["BDMNG"])
        except:
        	MII_Ignition_Library.Logger.Insert_Log.Insert_Info_Log("OperationalScenario Resultado: ","Quantity conversion Error")
        	
        if bdmng != 0:
	        if matnr in materialDict:
	            materialDict[matnr]["BDMNG"] += bdmng
	        else:
	            # Initialize with a new dictionary copying all keys from material except BDMNG
	            materialDict[matnr] = {key: value for key, value in material.items() if key != "BDMNG"}
	            materialDict[matnr]["BDMNG"] = bdmng

    # Convert materialDict to result list
    result = list(materialDict.values())

    
    return result

def datasetToDictionary(data):
	dataset = system.dataset.toPyDataSet(data)
	dictionary = []
	for row in dataset:
		dictSet = {	 'AUFNR' : row['PROCESS_ORDER']
					,'ARBPL' : row['RESOURCE']
					,'MATNR' : row['MATERIAL_NUMBER']
					,'MATNR_DESC' : row['MATERIAL_DESCRIPTION']
					,'MATNR_HLVL' : row['MATERIAL_HLVL']
					,'MTART' : row['MATERIAL_TYPE']
					,'CHARG' : row['BATCH_NUMBER']
					,'LGORT' : row['STORAGE_LOCATION']
					,'RSPOS' : row['RESB_POS']
					,'BDMNG' : row['BATCH_TARGET']
					,'MEINS' : row['UOM']
					,'SETPOINT' : row['SETPOINT']
					,'SETPOINT_UOM' : row['SETPOINT_UOM']
					,'ING_TARGET' : row['ING_TARGET']
					,'ING_TARGET_UOM' : row['ING_TARGET_UOM']
					,'ING_TARGET_LL' : row['ING_TARGET_LL']
					,'ING_TARGET_UL' : row['ING_TARGET_UL']
					,'BWART' :  row['MOVEMENT_TYPE']}
		dictionary.append(dictSet)
	return dictionary

def ScenarioData(poHeader, priPackTol, poHeaderPhases, poResb, fillerHeads, primaryCWs, secondaryCWs):
	#fillerHeads = No. of filler heads available at SF
	#primaryCWs = No. of Primary CWs available at SF
	#secondaryCWs = No. of Secondary CWs available at SF
	main = {}
	ARBPL = poHeaderPhases["ARBPL"]
	WERKS = poHeader["WERKS"]
	data1 = poHeader
	
	#Checking phantom is present or not
	if len(priPackTol) > 0:
		try:
			PhantomCounts = 0
			for row in priPackTol :
				IsPhantom = row["PHANTOM"]
				if IsPhantom == "X":
					PhantomCounts += 1
			#print ("Phantom : " + str(PhantomCounts))
		except:
			PhantomCounts = 0
			IsPhantom = priPackTol["PHANTOM"]
			if IsPhantom == "X":
				PhantomCounts += 1
			#print ("Phantom : " + str(PhantomCounts))
	
	#If phatom is present
	#Secondary checkweigher material
	ingredients = uniqueMaterial(poResb)
	for ingredientRow in ingredients:
			totalIngredients = 0
			if (((ingredientRow["MTART"] == "ROH") or (ingredientRow["MTART"] == "HALB")) and (ingredientRow["BDMNG"] != "0") and (ingredientRow["BDMNG"] != "---") and ((ingredientRow["MATNR_DESC"]).find('WIP') == -1)):
				totalIngredients += 1
	#MII_Ignition_Library.Logger.Insert_Log.Insert_Info_Log("Totalingredients: ",str(totalIngredients) + " " + str(ingredients))
	if PhantomCounts > 0 and secondaryCWs > 0 :
		cws = []
		cwsResult = {'MATNR': data1['MATNR'],
		'MATNR_DESC' : data1['MAKTX'],
		'TargetWeight' : data1['SP_TARGET'],
		'UL' : data1['SP_TARGET_UL'],
		'LL' : data1['SP_TARGET_LL'],
		'CHARG' : data1['ORDERCHARG'],
		'PlannedQty' : data1['BMENGE'],
		'SLOC' : '',
		'UOM' : data1['SP_TARGET_UOM']}
		cws.append(cwsResult)
		main = {'CWS' : cws}
		
	#Logic for DA line checking and ROH or HALB ingredients are not present
	
	elif ((poHeader["AREA"] == "DRY_FILL_AREA") or (poHeader["AREA"] == "DRY_FILLING_AREA")) and totalIngredients == 0 and secondaryCWs > 0 :
		cws = []
		cwsResult = {'MATNR': data1['MATNR'],
		'MATNR_DESC' : data1['MAKTX'],
		'TargetWeight' : data1['SP_TARGET'],
		'UL' : data1['SP_TARGET_UL'],
		'LL' : data1['SP_TARGET_LL'],
		'CHARG' : data1['ORDERCHARG'],
		'PlannedQty' : data1['BMENGE'],
		'SLOC' : '',
		'UOM' : data1['SP_TARGET_UOM']}
		cws.append(cwsResult)
		main = {'CWS' : cws}
	
	#Primary checkweigher material
	data2 = priPackTol
	#MII_Ignition_Library.Logger.Insert_Log.Insert_Info_Log("OperationalScenarios: ScenarioData",str(data2))
	cwp = []
	if PhantomCounts == 0 and primaryCWs > 0 :
		cwpResult = {'MATNR': data1['MATNR'],
		'MATNR_DESC' : data1['MAKTX'],
		'TargetWeight' : data1['SP_TARGET'],
		'UL' : data1['SP_TARGET_UL'],
		'LL' : data1['SP_TARGET_LL'],
		'CHARG' : data1['ORDERCHARG'],
		'PlannedQty' : data1['BMENGE'],
		'SLOC' : '',
		'UOM' : data1['SP_TARGET_UOM']}
		cwp.append(cwpResult)
#If single ingredient is used in both line in PUNE(DF03) both line primary cw should assign same material - site specific case #############
	elif((PhantomCounts == 1) and ARBPL == "DF03" and WERKS == "0384" and primaryCWs > 0):
		try:
			for data2 in priPackTol:
				if data2['PHANTOM'] == 'X':
					cwpResult = {'MATNR': data2['INGREDIENT'],
					'MATNR_DESC' : 'PHANTOM',
					'TargetWeight' : data2['PRIM_PACK_PER_SPACK_SP'],
					'UL' : data2['PRIM_PACK_PER_SPACK_SP_UL'],
					'LL' : data2['PRIM_PACK_PER_SPACK_SP_LL'],
					'CHARG' : '',
					'PlannedQty' : '',
					'SLOC' : '',
					'UOM' : data2['PRIM_PACK_PER_SPACK_SP_UOM']}
					cwp.append(cwpResult)
			for data2 in priPackTol:
				if data2['PHANTOM'] == 'X':
					cwpResult = {'MATNR': data2['INGREDIENT'],
					'MATNR_DESC' : 'PHANTOM',
					'TargetWeight' : data2['PRIM_PACK_PER_SPACK_SP'],
					'UL' : data2['PRIM_PACK_PER_SPACK_SP_UL'],
					'LL' : data2['PRIM_PACK_PER_SPACK_SP_LL'],
					'CHARG' : '',
					'PlannedQty' : '',
					'SLOC' : '',
					'UOM' : data2['PRIM_PACK_PER_SPACK_SP_UOM']}
					cwp.append(cwpResult)
		except:
			if priPackTol['PHANTOM'] == 'X' and primaryCWs > 0:
					cwpResult = {'MATNR': priPackTol['INGREDIENT'],
					'MATNR_DESC' : 'PHANTOM',
					'TargetWeight' : priPackTol['PRIM_PACK_PER_SPACK_SP'],
					'UL' : priPackTol['PRIM_PACK_PER_SPACK_SP_UL'],
					'LL' : priPackTol['PRIM_PACK_PER_SPACK_SP_LL'],
					'CHARG' : '',
					'PlannedQty' : '',
					'SLOC' : '',
					'UOM' : priPackTol['PRIM_PACK_PER_SPACK_SP_UOM']}
					cwp.append(cwpResult)
			if priPackTol['PHANTOM'] == 'X' and primaryCWs > 0:
				cwpResult = {'MATNR': priPackTol['INGREDIENT'],
				'MATNR_DESC' : 'PHANTOM',
				'TargetWeight' : priPackTol['PRIM_PACK_PER_SPACK_SP'],
				'UL' : priPackTol['PRIM_PACK_PER_SPACK_SP_UL'],
				'LL' : priPackTol['PRIM_PACK_PER_SPACK_SP_LL'],
				'CHARG' : '',
				'PlannedQty' : '',
				'SLOC' : '',
				'UOM' : priPackTol['PRIM_PACK_PER_SPACK_SP_UOM']}
				cwp.append(cwpResult)
#############################Site specific case pune ########################################################################################
	else:
		try:
			for data2 in priPackTol:
				if data2['PHANTOM'] == 'X' and primaryCWs > 0:
					cwpResult = {'MATNR': data2['INGREDIENT'],
					'MATNR_DESC' : 'PHANTOM',
					'TargetWeight' : data2['PRIM_PACK_PER_SPACK_SP'],
					'UL' : data2['PRIM_PACK_PER_SPACK_SP_UL'],
					'LL' : data2['PRIM_PACK_PER_SPACK_SP_LL'],
					'CHARG' : '',
					'PlannedQty' : '',
					'SLOC' : '',
					'UOM' : data2['PRIM_PACK_PER_SPACK_SP_UOM']}
					
					cwp.append(cwpResult)
		except:
				if primaryCWs > 0:
					cwpResult = {'MATNR': priPackTol['INGREDIENT'],
					'MATNR_DESC' : 'PHANTOM',
					'TargetWeight' : priPackTol['PRIM_PACK_PER_SPACK_SP'],
					'UL' : priPackTol['PRIM_PACK_PER_SPACK_SP_UL'],
					'LL' : priPackTol['PRIM_PACK_PER_SPACK_SP_LL'],
					'CHARG' : '',
					'PlannedQty' : '',
					'SLOC' : '',
					'UOM' : priPackTol['PRIM_PACK_PER_SPACK_SP_UOM']}
					
					cwp.append(cwpResult)
		
	fh = []
	#Finding unique material for the resb table
	test = uniqueMaterial(poResb)
	if ((poHeader["AREA"] == "LIQ_FILL_AREA") or (poHeader["AREA"] == "LIQUID_FILLING_AREA")):
		index = 0
		while fillerHeads > index:
			for data3 in test:
				if (((data3["MTART"] == "ROH") or (data3["MTART"] == "HALB")) and (data3["BDMNG"] != "0") and ((data3["MATNR_DESC"]).find('WIP') == -1)):
				    fhResult = {'MATNR': data3['MATNR'],
				    'MATNR_DESC' : data3['MATNR_DESC'],
				    'TargetWeight' : data3['ING_TARGET'],
				    'UL' : data3['ING_TARGET_UL'],
				    'LL' : data3['ING_TARGET_LL'],
				    'CHARG' : data3['CHARG'],
				    'PlannedQty' : data3['BDMNG'],
				    'SLOC' : data3['LGORT'],
				    'UOM' : data3['ING_TARGET_UOM']}
				    fh.append(fhResult)
			index += 1

	elif ((poHeader["AREA"] == "DRY_FILL_AREA") or (poHeader["AREA"] == "DRY_FILLING_AREA")):
		for data3 in test:
			#if ((row["MTART"] == "ROH") or (row["MTART"] == "HALB") and (row["BDMNG"] != '0') and (row["BDMNG"] != '---') and ((data3["MATNR_DESC"]).find('WIP') == -1)):
			if (((data3["MTART"] == "ROH") or (data3["MTART"] == "HALB")) and (data3["BDMNG"] != "0") and ((data3["MATNR_DESC"]).find('WIP') == -1)):
			    fhResult = {'MATNR': data3['MATNR'],
			    'MATNR_DESC' : data3['MATNR_DESC'],
			    'TargetWeight' : data3['ING_TARGET'],
			    'UL' : data3['ING_TARGET_UL'],
			    'LL' : data3['ING_TARGET_LL'],
			    'CHARG' : data3['CHARG'],
			    'PlannedQty' : data3['BDMNG'],
			    'SLOC' : data3['LGORT'],
			    'UOM' : data3['ING_TARGET_UOM']}
			    fh.append(fhResult)
	
	wc = poHeaderPhases['ARBPL']
	nodeName = poHeaderPhases['NODENAME']
	

	main['CWP'] = cwp
	main['FH'] = fh
	main['WC'] = wc
	main['PO'] = poHeader['AUFNR']
	main['nodeName'] = nodeName
	return main