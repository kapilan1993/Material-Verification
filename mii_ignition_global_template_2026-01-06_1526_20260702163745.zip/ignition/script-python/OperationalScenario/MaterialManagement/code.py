def getMaterialWeigher(materialdata,weigherList):
	materialdata.sort(key=lambda x: x['target'])
	weigherList.sort(key=lambda x: x['capmax'])
	weigher_used=[]
	assigned_material=[]
	count = 0
	for i in materialdata:
		for m in weigherList:
			count+=1
			assigned = False
			if  m['capmin']<= i['target'] <= m['capmax'] and m["devicename"] not in weigher_used:
				print "assigned"
				
				assigned_material.append({"materialNo": i['materialNo'],"batchNo": i['batchNo'], "target": i['target'],
				"description": i['description'],"quantity":i['quantity'], "lowerLimit":i['lowerLimit'],"upperLimit":i['upperLimit'],
				"uom": i['uom'],"sloc": i['sloc'],"weigher": m["devicename"],"batchSel":''})
				weigher_used.append(m["devicename"])
				assigned =True
				break
		if not assigned:
		#elif not assigned and m["devicename"] not in weigher_used:
			print("not in assigned material")
			assigned_material.append({"materialNo": '',"batchNo": '', "weigher": ''})
			ErrorMessage = "Weigher not assigned" + " to material no: "+ str(i['materialNo'])+ " tolerance outside range or not configured"
			system.perspective.openPopup("alertPopup",'Popup/materialManagementMsgPopup', params = {'source':'/system/images/Icons/Alert.svg','text':ErrorMessage}, showCloseIcon = False, resizable = False, modal = True, overlayDismiss = True)

					#weigher_used.append(m["devicename"])
	return assigned_material
	
	
###GET Material Management History
def getMaterialWeigherMappingHistory(workcenter,poType,scenarioNumber,PO,materialList,weigherList):
	assigned_weighers = set() 
	assigned_material=[]
	##Get History from tblPOMaterialMangementHistory table..need to modify
	mmhparams = {'wc':workcenter,'poType':poType,'scenarioNr': scenarioNumber}
	weigherMaterialList= system.db.runNamedQuery('OperationalSenario/GetMaterialManagementHistory', mmhparams)
	weigherMaterialNew =system.dataset.sort(weigherMaterialList, 'Count',False)
	
	for i in materialList:
		materialNo = i['materialNo']
		system.perspective.print("-------")
		system.perspective.print(materialNo)
		target = i['target']
		assigningWeigher = ''
		device=''
	
	
		for idx in range(weigherMaterialNew.rowCount):
			if (weigherMaterialNew.getValueAt(idx,"Material_No") == materialNo and 
				weigherMaterialNew.getValueAt(idx,"Weigher_Name") not in assigned_weighers):  # To Check if weigher is already assigned
				 
				assigningWeigher = weigherMaterialNew.getValueAt(idx,"Weigher_Name")
				break
	   
	
	
		assigned = False
		if weigherList:
			for m in weigherList:
				if  m["devicename"] not in assigned_weighers:
					device = m["devicename"]
				#### If device is in material management History table and target is within tolerance 
				if (m["devicename"] == assigningWeigher and m['capmin'] <= target <= m['capmax']):
					assigned_material.append({"materialNo": i['materialNo'],"batchNo": i['batchNo'], "target": i['target'],"description": i['description'],"quantity":i['quantity'], "lowerLimit":i['lowerLimit'],"upperLimit":i['upperLimit'], "uom": i['uom'],"sloc": i['sloc'],"weigher": assigningWeigher,"batchSel":''})
					system.perspective.print("assignedWeigher")
					system.perspective.print(assigningWeigher)
					assigned_weighers.add(assigningWeigher) 
					assigned = True
					break 
	
		if not assigned:
			system.perspective.print("yes not assigned from history")
			for m in weigherList:
				if  (m["devicename"] not in assigned_weighers and m['capmin'] <= target <= m['capmax']):
					assigned_material.append({"materialNo": i['materialNo'],"batchNo": i['batchNo'], "target": i['target'],"description": i['description'],"quantity":i['quantity'], "lowerLimit":i['lowerLimit'],"upperLimit":i['upperLimit'], "uom": i['uom'],"sloc": i['sloc'],"weigher": m["devicename"],"batchSel":''})
					assigned_weighers.add(m["devicename"]) 
					#print assigned_weighers
					assigned = True
					break
			if not assigned:
				assigned_material.append({"materialNo": '',"batchNo": '', "weigher": ''})
				ErrorMessage = " Weigher not assigned" + " to material no: "+ str(materialNo)+ " tolerance outside range or not configured .Please configure device correctly!"
				system.perspective.openPopup("alertPopup",'Popup/materialManagementMsgPopup', params = {'source':'/system/images/Icons/Alert.svg','text':ErrorMessage}, showCloseIcon = False, resizable = False, modal = True, overlayDismiss = True)
				
		assigned_material.sort(key=lambda x: x['weigher'])
	
	return assigned_material

def getWeigherList(devicename, workcenter):
	weigherList=[]
	params = {'wc':workcenter}
	weigher= system.db.runNamedQuery('OperationalSenario/WcDevicesTarget', params)
	print weigher
	for i in range(weigher.getRowCount()):
				if devicename in weigher.getValueAt(i,'NAME')  and weigher !='' :
					if weigher.getValueAt(i,'FIX_AND_MANUAL')==1:
						movparams = {'wc':workcenter,'ID':weigher.getValueAt(i,'ID')}
						movableweigher= system.db.runNamedQuery('OperationalSenario/WcMovableDevicesTarget', movparams)
						if len(movableweigher)!=0:
							weigherList.append({"devicename":weigher.getValueAt(i,'NAME'),
												"capmin":movableweigher.getValueAt(0,'SCALE_MIN'),
												"capmax":movableweigher.getValueAt(0,'SCALE_MAX')
												})
						else: 
							weigherList.append({"devicename":weigher.getValueAt(i,'NAME'),
												"capmin":'',
												"capmax":''
												})
					elif  weigher.getValueAt(i,'FIX_AND_MANUAL')==0:
						if len(weigher)!=0:
							weigherList.append({"devicename":weigher.getValueAt(i,'NAME'),
							"capmin":weigher.getValueAt(i,'CAPACITY_MIN'),
							"capmax":weigher.getValueAt(i,'CAPACITY_MAX')
							})
						else: 
							weigherList.append({"devicename":weigher.getValueAt(i,'NAME'),
												"capmin":'',
												"capmax":''
												})
					
					else:
						pass
	return weigherList
	
def getmaterialList(po_data,weigherKey):
	materialdata=[]
	for key, materials in  po_data.items():
			## Secondary CheckWeigher
			if key!= 'WC' and key!= 'PO' and key!='nodeName' and key == weigherKey  :            
			    for material in materials:
					if material['MATNR'] !='---' and material['TargetWeight']!=0 and material['PlannedQty']!=0:
						materialdata.append({"materialNo": material['MATNR'],
						"batchNo": material['CHARG']  ,
						"description": material['MATNR_DESC'],
						"quantity":round(material['PlannedQty'],5) if isinstance(material['PlannedQty'],float) else material['PlannedQty'],
						"target":  round(float(material['TargetWeight']),5)	if material['TargetWeight'] else material['TargetWeight'],
						"lowerLimit":  round( float(material['LL']),5) if material['LL'] else material['LL'],
						"upperLimit": round(float(material['UL']),5)if material['UL'] else material['UL'],
						"uom": material['UOM'],
						"sloc": material['SLOC']
						})
					else:
						pass

	return materialdata	
## Update Batches in tblBatchManagement when Added or Changed from Add Batches UI
def updateBatches(database,workCenter,PO,materialNo,instance,UPDATED_BY):
	try:
		queryparams = {'database':database,'wc':workCenter,'po':PO,'materialNo': materialNo}
		dataset= system.db.runNamedQuery('OperationalSenario/getMaterialBatchManagement', queryparams)
		data= system.dataset.toDataSet(dataset)
		system.perspective.print("data"+str(data))
		# Initialize sets to keep track of batch numbers and locations in data
		data_batches = [data.getValueAt(row, 'BATCH_NUMBER') for row in range(data.rowCount)]
		data_locations = [data.getValueAt(row, 'STORAGE_LOCATION') for row in range(data.rowCount)]
		for i in instance:
			
			batchNo=i['batchNo']
			sloc=i['sloc']
			plannedQty=i['targetQuantity']
			priority=i['batchSel']
			shelfLife=i['shelf']
			found_in_data = False
			system.perspective.print(batchNo)
			system.perspective.print(sloc)
			system.perspective.print(data_batches)
			system.perspective.print(data_locations)
			for idx in range(data.rowCount):
				CLIENT=data.getValueAt(0, 'CLIENT')
				PLANT=data.getValueAt(0, 'PLANT')
				ING_TARGET=data.getValueAt(0, 'ING_TARGET')
				PLANNED_QUANTITY = data.getValueAt(0, 'PLANNED_QUANTITY')
				ING_TARGET_UL=data.getValueAt(0, 'ING_TARGET_UL')
				ING_TARGET_LL=data.getValueAt(0, 'ING_TARGET_LL')
				ING_TARGET_UOM=data.getValueAt(0, 'ING_TARGET_UOM')
				MATERIAL_DESCRIPTION=data.getValueAt(0, 'MATERIAL_DESCRIPTION')
				MATERIAL_HLVL=data.getValueAt(0, 'MATERIAL_HLVL')
				MATERIAL_TYPE=data.getValueAt(0, 'MATERIAL_TYPE')
				SETPOINT=data.getValueAt(0, 'SETPOINT')
				SETPOINT_UOM=data.getValueAt(0, 'SETPOINT_UOM')
				UOM=data.getValueAt(0, 'UOM')
				RESB_POS=data.getValueAt(0, 'RESB_POS')
				BACKFLUSH =data.getValueAt(0, 'BACKFLUSH')
				MATKL =data.getValueAt(0, 'MATKL')
				PAS_NO =data.getValueAt(0, 'PAS_NO')
				PVZNR =data.getValueAt(0, 'PVZNR')
				RSNUM =data.getValueAt(0, 'RSNUM')
				VORNR =data.getValueAt(0, 'VORNR')
				WAREHOUSE_NO =data.getValueAt(0, 'WAREHOUSE_NO')
				XCHPF =data.getValueAt(0, 'XCHPF')
				if (data.getValueAt(idx, 'BATCH_NUMBER') == batchNo and data.getValueAt(idx, 'STORAGE_LOCATION') == sloc):
					##Update PLANNED_QUANTITY in tblBatchManangement   
					updatequeryparams = {'database':database,'wc':workCenter,'po':PO,'materialNo': materialNo,'batchNo': batchNo, 'sloc':sloc,'plannedQty':plannedQty,'priority':priority,'shelfLife':shelfLife,'UPDATED_BY': UPDATED_BY}
					system.db.runNamedQuery('OperationalSenario/UpdatePlannedQtyBatchManagement', updatequeryparams)
					system.perspective.print("Updated")
					found_in_data = True
					break
		
		          
			if not found_in_data:
				if batchNo not in data_batches:
						insertqueryparams = {'database':database,'client':CLIENT,'plant':PLANT,'wc':workCenter,'po':PO,'materialNo': materialNo,'batchNo': batchNo, 'sloc':sloc,'plannedQty':'0', 'batchTarget':plannedQty, 'priority':priority,'shelfLife':shelfLife,"target": ING_TARGET, "target_UL":ING_TARGET_UL,"target_LL":ING_TARGET_LL , "target_UOM":ING_TARGET_UOM ,"description":MATERIAL_DESCRIPTION,
						"hlvl":MATERIAL_HLVL , "materilaType": MATERIAL_TYPE, "movementReason" :'', "setpoint":SETPOINT, "setpointUOM":SETPOINT_UOM, "UOM":UOM,"resbPos":RESB_POS,"backflush" :BACKFLUSH,"matkl":MATKL,"passNo":PAS_NO,"pvznr":PVZNR,"rsnum":RSNUM,"vorNr":VORNR,"warehouseNr":WAREHOUSE_NO,"xcpf":XCHPF,'updatedBy': UPDATED_BY}
						system.db.runNamedQuery('OperationalSenario/InserttblBatchManagement', insertqueryparams)
						system.perspective.print("Inserted")
				for batch,loc in zip(data_batches,data_locations):
					if batchNo ==batch and sloc!=loc:
						insertqueryparams = {'database':database,'client':CLIENT,'plant':PLANT,'wc':workCenter,'po':PO,'materialNo': materialNo,'batchNo': batchNo, 'sloc':sloc,'plannedQty':'0', 'batchTarget':plannedQty, 'priority':priority,'shelfLife':shelfLife,"target": ING_TARGET, "target_UL":ING_TARGET_UL,"target_LL":ING_TARGET_LL , "target_UOM":ING_TARGET_UOM ,"description":MATERIAL_DESCRIPTION,
						"hlvl":MATERIAL_HLVL , "materilaType": MATERIAL_TYPE, "movementReason" :'', "setpoint":SETPOINT, "setpointUOM":SETPOINT_UOM, "UOM":UOM,"resbPos":RESB_POS,"backflush" :BACKFLUSH,"matkl":MATKL,"passNo":PAS_NO,"pvznr":PVZNR,"rsnum":RSNUM,"vorNr":VORNR,"warehouseNr":WAREHOUSE_NO,"xcpf":XCHPF,'updatedBy': UPDATED_BY}
						system.db.runNamedQuery('OperationalSenario/InserttblBatchManagement', insertqueryparams)
						system.perspective.print("Inserted")
#				elif batchNo in data_batches and sloc not in data_locations:
#					deletequeryparams = {'database':database,'wc':workCenter,'po':PO,'materialNo': materialNo,'batchNo': batchNo, 'sloc':sloc,'UPDATED_BY': UPDATED_BY}
#					system.db.runNamedQuery('OperationalSenario/UpdateIsDeletedBatchManagement', deletequeryparams)
#					system.perspective.print("Deleted"+str(deletequeryparams))
		
		# If there are other rows in data but not in instance, consider them for deletion
		# Iterate over each instance entry
		for idx in range(data.rowCount):
	    # Get the batch number and location from the dataset
		    data_batch = data.getValueAt(idx, 'BATCH_NUMBER')
		    data_loc = data.getValueAt(idx, 'STORAGE_LOCATION')
		    # Assume match is not found initially
		    match_found = False
		    # Check if this batch number and location combination exists in the entire 'instance' list
		    for i in instance:
		        if i['batchNo'] == data_batch and i['sloc'] == data_loc:
		            match_found = True
		            break  # Exit loop early if a match is found
		    # If no match is found after checking all instances, print a message indicating the batch number and location to be deleted
		    if not match_found:
				deletequeryparams = {'database':database,'wc':workCenter,'po':PO,'materialNo': materialNo,'batchNo': data_batch, 'sloc':data_loc,'UPDATED_BY': UPDATED_BY}
				result =system.db.runNamedQuery('OperationalSenario/UpdateIsDeletedBatchManagement', deletequeryparams)
				
				system.perspective.print("Deleted not batch"+str(batchNo) +str(sloc) + '   '+str(deletequeryparams)+'  '+str(result))
	except:
		MII_Ignition_Library.Logger.Insert_Log.Insert_Error_Log('Update Batches', str(sys.exc_info()))
##Check Batch Selection is empty for more than two batches
def checkBatchSel(data):
	qtyError={}
	batchList=[]
	batchSelList=[]
	batchselError = []
	slocList=[]
	slocSelList=[]
	slocError = []
	qtyList=[]
	qtySelList=[]
	qtyError = []
	errorMessage=''
	for i in data:		
		batchList.append(i['batchNo'])
		batchSelList.append(i['batchSel'])
		slocSelList.append(i['sloc'])
		qtySelList.append(i['targetQuantity'])
	if len(batchSelList)!= len(set(batchSelList)):
		errorMessage="Same priority is  selected"
	
	if len(batchList)>1:
		system.perspective.print("batchSelList" +str(batchSelList))
		batchselError=[value for value in batchSelList if value == "" or value== '---' or value==  ","  in str(value)]
	if batchselError:
		errorMessage="Batch priority is not selected"
	if len(batchList)>0:		
		slocError=[value for value in slocSelList if value == "" or value== '---' or value==  "," in str(value)]
		qtyError=[value for value in qtySelList if value == "" or value== '0' or value==  "," in str(value)]
	if slocError:
		errorMessage="Storage Location not assigned for Batch"
	if qtyError:
		errorMessage="Target Quantity not assigned for Batch"
	return errorMessage	
def allverifiedBarcodeValidation(instances):
	for instance in instances:        
		verify= instance.get('verified', False)
		if not verify:
			return False  
	return True


def updateBatchesFromAddInventory(database,workCenter,PO,materialNo,instance,updatedBy):
	try:
		queryparams = {'database':database,'wc':workCenter,'po':PO,'materialNo': materialNo}
		dataset= system.db.runNamedQuery('Inventory/getMaterialDataBatchManagement', queryparams)
		data= system.dataset.toDataSet(dataset)
		system.perspective.print("data"+str(data))
		# Initialize sets to keep track of batch numbers and locations in data
		data_batches = [data.getValueAt(row, 'BATCH_NUMBER') for row in range(data.rowCount)]
		data_locations = [data.getValueAt(row, 'STORAGE_LOCATION') for row in range(data.rowCount)]

		for i in instance:
			batchNo=i['batchNo']
			sloc=i['sloc']
			plannedQty=i['targetQuantity']
			priority=i['batchSel']
			shelfLife=i['shelf']
			found_in_data = False
			system.perspective.print(batchNo)
			system.perspective.print(sloc)
			system.perspective.print(data_batches)
			system.perspective.print(data_locations)
			for idx in range(data.rowCount):
				CLIENT=data.getValueAt(idx, 'CLIENT')
				PLANT=data.getValueAt(idx, 'PLANT')
				ING_TARGET=data.getValueAt(idx, 'ING_TARGET')
				PLANNED_QUANTITY = data.getValueAt(idx, 'PLANNED_QUANTITY')
				ING_TARGET_UL=data.getValueAt(idx, 'ING_TARGET_UL')
				ING_TARGET_LL=data.getValueAt(idx, 'ING_TARGET_LL')
				ING_TARGET_UOM=data.getValueAt(idx, 'ING_TARGET_UOM')
				MATERIAL_DESCRIPTION=data.getValueAt(idx, 'MATERIAL_DESCRIPTION')
				MATERIAL_HLVL=data.getValueAt(idx, 'MATERIAL_HLVL')
				MATERIAL_TYPE=data.getValueAt(idx, 'MATERIAL_TYPE')
				SETPOINT=data.getValueAt(idx, 'SETPOINT')
				SETPOINT_UOM=data.getValueAt(idx, 'SETPOINT_UOM')
				UOM=data.getValueAt(idx, 'UOM')
				RESB_POS=data.getValueAt(idx, 'RESB_POS')
				BACKFLUSH =data.getValueAt(idx, 'BACKFLUSH')
				MATKL =data.getValueAt(idx, 'MATKL')
				PAS_NO =data.getValueAt(idx, 'PAS_NO')
				PVZNR =data.getValueAt(idx, 'PVZNR')
				RSNUM =data.getValueAt(idx, 'RSNUM')
				VORNR =data.getValueAt(idx, 'VORNR')
				WAREHOUSE_NO =data.getValueAt(idx, 'WAREHOUSE_NO')
				XCHPF =data.getValueAt(idx, 'XCHPF')
				IS_DELETED  = data.getValueAt(idx, 'IS_DELETED') 
				
				if (data.getValueAt(idx, 'BATCH_NUMBER') == batchNo and data.getValueAt(idx, 'STORAGE_LOCATION') == sloc) and IS_DELETED == 0:
					##Update BATCH_TARGET in tblBatchManangement   / here plannedQty is batch target quantity
					updatequeryparams = {'database':database,'wc':workCenter,'po':PO,'materialNo': materialNo,'batchNo': batchNo, 'sloc':sloc,'plannedQty':plannedQty,'priority':priority,'shelfLife':shelfLife, 'isVerified':1, 'UPDATED_BY': updatedBy}
					system.db.runNamedQuery('Inventory/UpdateQtyBatchManagement', updatequeryparams)
					system.perspective.print("Update when delete 0" + str(updatequeryparams))
					system.perspective.print("Updated BY RIA")
					found_in_data = True
					break
					##Update BATCH_TARGET in tblBatchManangement   / here plannedQty is batch target quantity
				if (data.getValueAt(idx, 'BATCH_NUMBER') == batchNo and data.getValueAt(idx, 'STORAGE_LOCATION') == sloc) and IS_DELETED ==1:
					updatequeryparams = {'database':database,'wc':workCenter,'po':PO,'materialNo': materialNo,'batchNo': batchNo, 'sloc':sloc,'plannedQty':plannedQty,'priority':priority,'shelfLife':shelfLife,'isVerified':1,'UPDATED_BY': updatedBy}
					system.db.runNamedQuery('Inventory/UpdateBatchManagement', updatequeryparams)
					system.perspective.print("Update when delete 1" + str(updatequeryparams))
					
					
					found_in_data = True
					break

			if not found_in_data:

				if batchNo not in data_batches:
					  
						insertqueryparams = {'database':database,'client':CLIENT,'plant':PLANT,'wc':workCenter,'po':PO,'materialNo': materialNo,'batchNo': batchNo, 'sloc':sloc,'plannedQty':'0', 'batchTarget':plannedQty,'priority':priority, 'shelfLife':shelfLife,"target": ING_TARGET, "target_UL":ING_TARGET_UL,"target_LL":ING_TARGET_LL , "target_UOM":ING_TARGET_UOM ,"description":MATERIAL_DESCRIPTION,
						"hlvl":MATERIAL_HLVL , "materilaType": MATERIAL_TYPE, "movementReason" :'', "setpoint":SETPOINT, "setpointUOM":SETPOINT_UOM, "UOM":UOM,"resbPos":RESB_POS,"backflush" :BACKFLUSH,"matkl":MATKL,"passNo":PAS_NO,"pvznr":PVZNR,"rsnum":RSNUM,"vorNr":VORNR,"warehouseNr":WAREHOUSE_NO,"xcpf":XCHPF, 'isVerified':1, 'updatedBy': updatedBy}
						system.perspective.print("Inserted1" + str(insertqueryparams))
						system.db.runNamedQuery('Inventory/InserttblBatchManagement', insertqueryparams)
						system.perspective.print("Inserted1")
						
				for batch,loc in zip(data_batches,data_locations):
					if batchNo == batch and sloc!= loc:
						insertqueryparams = {'database':database,'client':CLIENT,'plant':PLANT,'wc':workCenter,'po':PO,'materialNo': materialNo,'batchNo': batchNo, 'sloc':sloc,'plannedQty':'0','batchTarget':plannedQty,'priority':priority,'shelfLife':shelfLife,"target": ING_TARGET, "target_UL":ING_TARGET_UL,"target_LL":ING_TARGET_LL , "target_UOM":ING_TARGET_UOM ,"description":MATERIAL_DESCRIPTION,
						"hlvl":MATERIAL_HLVL , "materilaType": MATERIAL_TYPE, "movementReason" :'', "setpoint":SETPOINT, "setpointUOM":SETPOINT_UOM, "UOM":UOM,"resbPos":RESB_POS,"backflush" :BACKFLUSH,"matkl":MATKL,"passNo":PAS_NO,"pvznr":PVZNR,"rsnum":RSNUM,"vorNr":VORNR,"warehouseNr":WAREHOUSE_NO,"xcpf":XCHPF, 'isVerified':1, 'updatedBy': updatedBy}
						system.perspective.print("Inserted2" + str(insertqueryparams))
						system.db.runNamedQuery('Inventory/InserttblBatchManagement', insertqueryparams)
						system.perspective.print("Inserted2")
		return 'success'
	except:
		MII_Ignition_Library.Logger.Insert_Log.Insert_Error_Log('Update Batches', str(sys.exc_info()))
		return 'Error while updating inventory'
		
		
		
def checkIfBatchIsVerifiedAndUpdate(ide,database):
	try:
		params = {'database':database,'id':ide}
		idData = system.db.runNamedQuery("Inventory/getAllRowDataFromID", params)
		for idx in range(idData.rowCount):
			batchNo = idData.getValueAt(0, 'BATCH_NUMBER')
			sloc = idData.getValueAt(0, 'STORAGE_LOCATION')
			quantity = idData.getValueAt(0, 'BATCH_TARGET')
			priority = idData.getValueAt(0, 'PRIORITY')
			if batchNo != '---' and batchNo != ' ' and sloc != '---' and sloc != ' ' and quantity != '0' and quantity != '' and priority != 0 and priority != ' ':
				isVerified = True
			else:
				isVerified = False
		params = {'database':database, 'id':ide, 'verify':isVerified }
		system.db.runNamedQuery("Inventory/updateVerify", params)
	except:
		MII_Ignition_Library.Logger.Insert_Log.Insert_Error_Log('Update Batches', str(sys.exc_info()))