def productionDevice(database, tagProvider, plant, area, wc, po):
	path = "OperationalSenario/getProductionDevice"
	params = {"database" : database, "wc" : wc, "po" : po}
	prDevice = system.db.runNamedQuery(path, params)
	
	#No of Primary and secondary checkweigher and fillerheads available
	path = 'OperationalSenario/WcDevices'
	params = {'wc':wc}
	weigher = system.db.runNamedQuery(path, params)
	resultTagPaths = []
	resultTagValues = []
	for i in range(weigher.getRowCount()):
		if ('CheckWeigher_SP' in weigher.getValueAt(i,'NAME')  and weigher !='' and prDevice != weigher.getValueAt(i,'NAME')):
			device = weigher.getValueAt(i,'NAME')
			tagPath = tagProvider +"Coca-Cola/CPS/"+plant+"/" +area+ "/"+wc+"/SF_Equipment/Checkweigher/Secondary_Packaging/"+device+"/usedForPr"
			tagValue = "0"
			resultTagPaths.append(tagPath)
			resultTagValues.append(tagValue)
		elif ('CheckWeigher_PP' in weigher.getValueAt(i,'NAME')  and weigher !='' and prDevice != weigher.getValueAt(i,'NAME')):
			device = weigher.getValueAt(i,'NAME')
			tagPath = tagProvider +"Coca-Cola/CPS/"+plant+"/" +area+ "/"+wc+"/SF_Equipment/Checkweigher/Primary_Packaging/"+device+"/usedForPr"
			tagValue = "0"
			resultTagPaths.append(tagPath)
			resultTagValues.append(tagValue)
		elif ('FillerHead' in weigher.getValueAt(i,'NAME')  and weigher !='' and prDevice != weigher.getValueAt(i,'NAME')):
			device = weigher.getValueAt(i,'NAME')
			tagPath = tagProvider +"Coca-Cola/CPS/"+plant+"/" +area+ "/"+wc+"/SF_Equipment/Filler/"+device+"/usedForPr"
			tagValue = "0"
			resultTagPaths.append(tagPath)
			resultTagValues.append(tagValue)
		elif (prDevice in weigher.getValueAt(i,'NAME')  and weigher !=''):
			device = weigher.getValueAt(i,'NAME')
			if ('CheckWeigher_SP' in device):
				tagPath = tagProvider +"Coca-Cola/CPS/"+plant+"/" +area+ "/"+wc+"/SF_Equipment/Checkweigher/Secondary_Packaging/"+device+"/usedForPr"
			elif ('CheckWeigher_PP' in device):
				tagPath = tagProvider +"Coca-Cola/CPS/"+plant+"/" +area+ "/"+wc+"/SF_Equipment/Checkweigher/Primary_Packaging/"+device+"/usedForPr"
			elif ('FillerHead' in device):
				tagPath = tagProvider +"Coca-Cola/CPS/"+plant+"/" +area+ "/"+wc+"/SF_Equipment/Checkweigher/Filler/"+device+"/usedForPr"
			tagValue = "1"
			resultTagPaths.append(tagPath)
			resultTagValues.append(tagValue)
		system.tag.writeBlocking(resultTagPaths, resultTagValues)

