#XML to Dataset conversion script#
def convertXMLtoDataset(root,nodePath):
	headerPath = nodePath + "/Row"
	header = []
	if len(root.find(nodePath)) > 0:
		for colName in root.find(headerPath):
			header.append(colName.tag)
		
		rows = []
		for rowData in root.find(nodePath):
			row = []
			for item in rowData:
				row.append(item.text)
			rows.append(row)	
		dataset = system.dataset.toDataSet(header, rows)
		return dataset
	else:
		header = []
		rows = []
		dataset = system.dataset.toDataSet(header, rows)
		return dataset