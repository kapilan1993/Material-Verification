def AfterInsertintoProcessOrderData():
	### Get Process order list with NEW status
	poparams={'database':'GlobalTemplateDBProduction','STATUS':'NEW'}
	process_orders = system.db.runNamedQuery("InsertintoXPO/GetPO",poparams)
	process_orders_list=system.dataset.toPyDataSet(process_orders)
	###Insert new PO with Status NEW in XPO 
	for row in process_orders_list:
		po = row["PROCESS_ORDER"]
		check_query = "SELECT 1 FROM xPO WHERE PROCESS_ORDER = ?"
		check_result = system.db.runPrepQuery(check_query, [po])
		##If inserted PO is present in ProcessOrderData and not in xPO then insert
		if len(check_result) == 0:		 	
			resparams={'database':'GlobalTemplateDBProduction','PO':po}
			resource = system.db.runNamedQuery("InsertintoXPO/ExtractResource",resparams)			
			insertparams={'database':'GlobalTemplateDBProduction','PO':po,'RESOURCE':resource}
			system.db.runNamedQuery("InsertintoXPO/InsertintoXPO",insertparams)
			##To check if correct Json is inserted else insert it twice and exit
			InsertUpdatexPO.CheckforInsertPO(po)
			print(po)
			print('inserted')
			##Insert into WorkCenterMaster table
			nodeparams={'database':'GlobalTemplateDBProduction','PO':po}
			nodename = system.db.runNamedQuery("InsertintoXPO/ExtractNodeName",nodeparams)
			areaparams={'database':'GlobalTemplateDBProduction','PO':po}
			area = system.db.runNamedQuery("InsertintoXPO/GetArea",areaparams)
			insertwcparams={'database':'GlobalTemplateDBProduction','RESOURCE':resource,"NODENAME":nodename,"AREA": area}
			##Check if workcenter already exists
			checkwcparams = {'database': 'GlobalTemplateDBProduction', 'RESOURCE':resource}
			check_wcresult = system.db.runNamedQuery("InsertintoXPO/CheckWorkCenterexist", checkwcparams)
			if len(check_wcresult) == 0:
				system.db.runNamedQuery("InsertintoXPO/InsertintoWorkCenterMaster",insertwcparams)
			else:
				pass
			##Insert in xPhase table after deleting PO
			deleteparams = {'database': 'GlobalTemplateDBProduction', 'PO': po}
			system.db.runNamedQuery("InsertintoXPO/DeletePOXPhase", deleteparams)
			##Insert into xPhase
			xphaseinsertparams={'database':'GlobalTemplateDBProduction','PO':po}
			system.db.runNamedQuery("InsertintoXPO/InsertintoXPhase",xphaseinsertparams)
			
		else:
			pass
def AfterUpdateinProcessOrderData():
	### Get Process order list with updated status 
	uppoparams={'database':'GlobalTemplateDBProduction','STATUS':'UPDATED'}
	update_process_orders = system.db.runNamedQuery("InsertintoXPO/GetPO",uppoparams)
	update_process_orders_list=system.dataset.toPyDataSet(update_process_orders)
	###Update new PO with Status UPDATED in XPO 
	for i in update_process_orders_list:
		updatepo = i["PROCESS_ORDER"]
		updateddate =i['UPDATED_DATE']	
		print updatepo
		update_check_query = "SELECT 1 FROM xPO WHERE PROCESS_ORDER = ? AND UPDATED_DATE=?"
		update_check_result = system.db.runPrepQuery(update_check_query, [updatepo,system.date.format(updateddate, "yyyy-MM-dd HH:mm:ss.SSS")])
		##If updated PO is present in ProcessOrderData and not in xPO then update
		if len(update_check_result) == 0:
			upresparams={'database':'GlobalTemplateDBProduction','PO':updatepo}
			upresource = system.db.runNamedQuery("InsertintoXPO/ExtractResource",upresparams)
			print upresource
			updateparams={'database':'GlobalTemplateDBProduction','PO':updatepo,'RESOURCE':upresource}
			system.db.runNamedQuery("InsertintoXPO/UpdateXPO",updateparams)
			##To check if correct Json is updated else insert it twice and exit
			InsertUpdatexPO.CheckforInsertPO(updatepo)
			print('updated')
			##Update WorkCenter Master table
			nodeparams={'database':'GlobalTemplateDBProduction','PO':updatepo}
			nodename = system.db.runNamedQuery("InsertintoXPO/ExtractNodeName",nodeparams)
			areaparams={'database':'GlobalTemplateDBProduction','PO':updatepo}
			area = system.db.runNamedQuery("InsertintoXPO/GetArea",areaparams)
			updatewcparams={'database':'GlobalTemplateDBProduction','RESOURCE':upresource,"NODENAME":nodename,"AREA": area}
			system.db.runNamedQuery("InsertintoXPO/UpdateWorkCenterMaster",updatewcparams)
			##Insert in xPhase table after deleting PO
			deleteparams = {'database': 'GlobalTemplateDBProduction', 'PO': updatepo}
			system.db.runNamedQuery("InsertintoXPO/DeletePOXPhase", deleteparams)
			##Insert into xPhase
			xphaseinsertparams={'database':'GlobalTemplateDBProduction','PO':updatepo}
			system.db.runNamedQuery("InsertintoXPO/InsertintoXPhase",xphaseinsertparams)
def ADDPO():
	##After Insert in Process Order data ,Insert in xPO,tblWorkCenterMaster
	InsertUpdatexPO.AfterInsertintoProcessOrderData()
	##After Update in Process Order data ,Update in xPO,tblWorkCenterMaster
	InsertUpdatexPO.AfterUpdateinProcessOrderData()
## Check key in JSON
def check_key(json):
	for i in json:
		findvalue = i.get('INSPLOT', 'NOT')
		if findvalue != 'NOT':
			return True
	return False
# Run loop twice to check if key is present
def CheckforInsertPO(PO):
	for attempt in range(2):
		selectparams={'database':'GlobalTemplateDBProduction','PO':PO}
		POData=system.db.runNamedQuery("InsertintoXPO/GetPODataJson",selectparams)
		jsonData =system.util.jsonDecode(POData)		
		json =jsonData['DOWNLOAD_RECIPE']['PO_HEADER_PHASES']['Rowsets']['Rowset']['Row']
		if InsertUpdatexPO.check_key(json):
			print("Key is present.")
			break
		else:
			print('key not present')
			# Delete PO if key is not present
			deleteparams = {'database': 'GlobalTemplateDBProduction', 'PO': PO}
			system.db.runNamedQuery("InsertintoXPO/DeletePO", deleteparams)
			#print('deleted')
			# Insert PO after delete
			resparams={'database':'GlobalTemplateDBProduction','PO':PO}
			resource = system.db.runNamedQuery("InsertintoXPO/ExtractResource",resparams)
			insertparams={'database':'GlobalTemplateDBProduction','PO':PO,'RESOURCE':resource}
			system.db.runNamedQuery("InsertintoXPO/InsertintoXPO",insertparams)
			#print('inserted')
			selectparams={'database':'GlobalTemplateDBProduction','PO':PO}
			POData=system.db.runNamedQuery("InsertintoXPO/GetPODataJson",selectparams)
			jsonData =system.util.jsonDecode(POData)
			newjson =jsonData['DOWNLOAD_RECIPE']['PO_HEADER_PHASES']['Rowsets']['Rowset']['Row']
			if InsertUpdatexPO.check_key(newjson) ==False:
				MII_Ignition_Library.Logger.Insert_Log.Insert_Error_Log("Trigger Insert/Update Logger",str('Error:INSPLOT not found after two attempts'))
				
		