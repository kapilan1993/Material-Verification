def createAutoGiMessage(po, wc, device):
	try:
		#create logger
		workCenter = wc #workcenter needs to be changed accordingly
		logger = system.util.getLogger('Automatic buffer reset ' + str(workCenter))
		
		#get parameters
		tagProvider = system.tag.readBlocking("[Shop_Floor]Coca-Cola/CPS/Site_Settings/General_Configuration/sfTagProvider")[0].value
		client = system.tag.readBlocking("[Shop_Floor]Coca-Cola/CPS/Site_Settings/Plant_Configuration/client")[0].value
		plant = system.tag.readBlocking("[Shop_Floor]Coca-Cola/CPS/Site_Settings/Plant_Configuration/plant")[0].value
		database = system.tag.readBlocking("[Shop_Floor]Coca-Cola/CPS/Site_Settings/dB_Configuration/ignitiondB")[0].value
		
		if workCenter[0:2] == 'LF': #Liquid Filling 
			areaPrefix = 'LF' 
		elif workCenter[0:2] == 'DF' or workCenter[0:2] == 'DA': #Dry Processing 
			areaPrefix = 'DP'
		
		#create base path
		wcConfigPath = str(tagProvider)+"Coca-Cola/CPS/"+plant+"/"+areaPrefix+"/"+workCenter+"/WorkCenterConfiguration/"
		poPhasePath = str(tagProvider)+"Coca-Cola/CPS/"+plant+"/"+areaPrefix+"/"+workCenter+"/PO/Phase/"
		
		#get wc configuration enable GI status
		autoGI = system.tag.readBlocking(str(wcConfigPath)+"enableAutoGI")[0].value
		
		#get global variables from tags
		phase = system.tag.readBlocking(str(poPhasePath)+"pPhase")[0].value
		operation = system.tag.readBlocking(str(poPhasePath)+"pOperation")[0].value
		area = system.tag.readBlocking(str(wcConfigPath)+"areaDescription")[0].value
		
		#get partial frequency from tag
		partialFreq = system.tag.readBlocking(str(wcConfigPath)+"partialConfirmationFrequency")[0].value
		
		#list of different materials
		ingMaterial = []
		packMaterial = []
		
		logger.info(str(autoGI))
		#check if auto gi is enabled
		if autoGI == True or autoGI == 1:
			#get all the material of the PO where consumed = 0 from tblBatchManagement
			#insert query result into tempBatchManagement
			path = 'AutoGI/insertIntoTempBatchManagement'
			param = {'database':database, 'po':po, 'wc':wc}
			query = system.db.runNamedQuery(path,param)
			logger.info('insert in tempBatchMgmt '+str(query))
			# check if query row count > 0
			if query:
				#get data from tblSpcWeightHistory and insert into tempSpcWeightHistory
				path = 'AutoGI/insertIntoTempSpcWeightHistory'
				param = {'database':database, 'po':po, 'wc':wc}
				query = system.db.runNamedQuery(path,param)
				logger.info('insert in temp spc history '+str(query))
				# check if query row count > 0
				if query:
					#get the unique materials from tempSpcWeightHistory
					path = 'AutoGI/getAllMaterialsFromTempSpcHistory'
					param = {'database':database, 'po':po, 'wc':wc}
					query = system.db.runNamedQuery(path,param)
					logger.info(str(query))
					if query:
						for row in range(query.getRowCount()):
							if str(query.getValueAt(row, "INGREDIENT_MAT")) != '':
								ingMat = str(query.getValueAt(row, "INGREDIENT_MAT"))
								ingMaterial.append(ingMat)
							if str(query.getValueAt(row, "PACKAGING_MAT")) != '':
								packMat = str(query.getValueAt(row, "PACKAGING_MAT"))
								packMaterial.append(packMat)
							
					#list of all materials
					allMaterials = ingMaterial + packMaterial
					logger.info(str(allMaterials))
					if len(allMaterials)>0:
						#loop each material and fetch all rows for the material from tempSpcWeightHistory and dump it into tempBatchingTable
						for i in range(len(allMaterials)):
							path = 'AutoGI/insertIntoTempBatchingTable'
							param = {'database':database, 'po':po, 'wc':wc, 'material':allMaterials[i]}
							query = system.db.runNamedQuery(path,param)
							logger.info('insert in temp batching '+str(query))
							# check if query row count > 0
							path1 = 'AutoGI/getRowCountForEachMaterialFromTempBatchingTable'
							param1 = {'database':database, 'po':po, 'wc':wc, 'material':allMaterials[i]}
							query1 = system.db.runNamedQuery(path1,param1)
							logger.info('get row count for each mat '+str(query1.getValueAt(0,0)))
							logger.info('partial freq '+str(partialFreq))
							if query1:
								#check count of material > partial frequency
								if int(query1.getValueAt(0,0)) > int(partialFreq):
									#check if current material is ingredient
									if allMaterials[i] in ingMaterial:
										logger.info(str(allMaterials[i]))
										try:
											#call function here
											ingredientMat = AutoGI.AutoGIBundling.ingredientMaterial(database, client, plant, po, wc, partialFreq, allMaterials[i], phase, operation, area)
											logger.info('ingredient func '+str(ingredientMat))
											#check if function return 'Success'
											if 'Success' in ingredientMat:
												#check tempSpcWeightHistory row count,
												path = 'AutoGI/getRowCountOfTempSpcHistory'
												param = {'database':database, 'po':po, 'wc':wc}
												query = system.db.runNamedQuery(path,param)
												if query == 1:
													if int(query.getValueAt(0,0)) == 0:
														# if 0 then update all processed to 1 inn tblSpcWeightHistory
														path1 = 'AutoGI/updateUnprocessedSpcData'
														param1 = {'database':database, 'po':po, 'wc':wc}
														query1 = system.db.runNamedQuery(path1,param1)
														
														if query1 == 1:
															#if update successful, then move all data from tempGIStaging to xMII_GI_Queue_Message_Log
															path2 = 'AutoGI/insertIntoGIQueueMessageLog'
															param2 = {'database':database, 'po':po, 'wc':wc}
															query2 = system.db.runNamedQuery(path2,param2)
												# check if query row count > 0
												path = 'AutoGI/getRowCountForEachMaterialFromTempBatchingTable'
												param = {'database':database, 'po':po, 'wc':wc, 'material':allMaterials[i]}
												query = system.db.runNamedQuery(path,param)
												if query == 1:
													#check count of material > partial frequency
													if int(query.getValueAt(0,0)) > int(partialFreq):
														#call function here
														ingredientMat = AutoGI.AutoGIBundling.ingredientMaterial(database, client, plant, po, wc, partialFreq, allMaterials[i], phase, operation, area)
														if 'Success' in ingredientMat:
															#check tempSpcWeightHistory row count,
															path = 'AutoGI/getRowCountOfTempSpcHistory'
															param = {'database':database, 'po':po, 'wc':wc}
															query = system.db.runNamedQuery(path,param)
															if query == 1:
																if int(query.getValueAt(0,0)) == 0:
																	# if 0 then update all processed to 1 inn tblSpcWeightHistory
																	path1 = 'AutoGI/updateUnprocessedSpcData'
																	param1 = {'database':database, 'po':po, 'wc':wc}
																	query1 = system.db.runNamedQuery(path1,param1)
																	
																	if query1 == 1:
																		#if update successful, then move all data from tempGIStaging to xMII_GI_Queue_Message_Log
																		path2 = 'AutoGI/insertIntoGIQueueMessageLog'
																		param2 = {'database':database, 'po':po, 'wc':wc}
																		query2 = system.db.runNamedQuery(path2,param2)
															
													
											else:
												MII_Ignition_Library.Logger.Insert_Log.Insert_Error_Log("Failed Ingredient Auto GI : "+str(wc)+"--"+str(po), "Auto GI failed for ingredient material")
										except:
											MII_Ignition_Library.Logger.Insert_Log.Insert_Error_Log("Ingredient Material Auto GI For : "+str(wc)+"--"+str(po), str(sys.exc_info()))
											
									elif allMaterials[i] in packMaterial:
										try:
											#call function here
											packagingMat = AutoGI.AutoGIBundling.packagingMaterial(database, client, plant, po, wc, partialFreq, allMaterials[i], phase, operation, device, area)
											
											#check if function return 'Success'
											if 'Success' in packagingMat:
												#check tempSpcWeightHistory row count,
												path = 'AutoGI/getRowCountOfTempSpcHistory'
												param = {'database':database, 'po':po, 'wc':wc}
												query = system.db.runNamedQuery(path,param)
												if query == 1:
													if int(query.getValueAt(0,0)) == 0:
														# if 0 then update all processed to 1 inn tblSpcWeightHistory
														path1 = 'AutoGI/updateUnprocessedSpcData'
														param1 = {'database':database, 'po':po, 'wc':wc}
														query1 = system.db.runNamedQuery(path1,param1)
														
														if query1 == 1:
															#if update successful, then move all data from tempGIStaging to xMII_GI_Queue_Message_Log
															path2 = 'AutoGI/insertIntoGIQueueMessageLog'
															param2 = {'database':database, 'po':po, 'wc':wc}
															query2 = system.db.runNamedQuery(path2,param2)
												# check if query row count > 0
												path = 'AutoGI/getRowCountForEachMaterialFromTempBatchingTable'
												param = {'database':database, 'po':po, 'wc':wc, 'material':allMaterials[i]}
												query = system.db.runNamedQuery(path,param)
												if query == 1:
													#check count of material > partial frequency
													if int(query.getValueAt(0,0)) > int(partialFreq):
														#call function here
														packagingMat = AutoGI.AutoGIBundling.ingredientMaterial(database, client, plant, po, wc, partialFreq, allMaterials[i], phase, operation, area)
														if 'Success' in packagingMat:
															#check tempSpcWeightHistory row count,
															path = 'AutoGI/getRowCountOfTempSpcHistory'
															param = {'database':database, 'po':po, 'wc':wc}
															query = system.db.runNamedQuery(path,param)
															if len(query) > 0:
																if int(query.getValueAt(0,0)) == 0:
																	# if 0 then update all processed to 1 inn tblSpcWeightHistory
																	path1 = 'AutoGI/updateUnprocessedSpcData'
																	param1 = {'database':database, 'po':po, 'wc':wc}
																	query1 = system.db.runNamedQuery(path1,param1)
																	
																	if query1 == 1:
																		#if update successful, then move all data from tempGIStaging to xMII_GI_Queue_Message_Log
																		path2 = 'AutoGI/insertIntoGIQueueMessageLog'
																		param2 = {'database':database, 'po':po, 'wc':wc}
																		query2 = system.db.runNamedQuery(path2,param2)
													
											else:
												MII_Ignition_Library.Logger.Insert_Log.Insert_Error_Log("Packaging Material Auto GI For : "+str(wc)+"--"+str(po), "Auto GI failed for packaging material")
										except:
											MII_Ignition_Library.Logger.Insert_Log.Insert_Error_Log("Packaging Material Auto GI For : "+str(wc)+"--"+str(po), str(sys.exc_info()))
											
										
									else:
										None
								else:
									None
									#counts are lower than partial frequency
				else:
					None
					#spc weight row count is 0 check again
			else:
				None
				#batch mgmt row count is 0 check again
		else:
			None
			#auto Gi is disabled for this wc
		
	except:
		MII_Ignition_Library.Logger.Insert_Log.Insert_Error_Log("Auto GI For : "+str(wc)+"--"+str(po), str(sys.exc_info()))
		
def ingredientMaterial(database, client, plant, po, wc, partialFreq, material, phase, operation, area):
	try:
		#create logger
		workCenter = wc #workcenter needs to be changed accordingly
		logger = system.util.getLogger('Automatic buffer reset ' + str(workCenter))
		
		#get net weight from tblSpcWeightHistory
		path = 'AutoGI/getAggregateNetWeightFromSpcWeightHistory'
		param = {'database':database,'partialFreq':int(partialFreq), 'po':po, 'wc':wc, 'material':material}
		query = system.db.runNamedQuery(path,param)
		netWeight = []
		logger.info('get aggregated wgt ' +str(query))
		if query:
			for row in range(query.getRowCount()):
				netWeight.append(query.getValueAt(row,'NetWeight'))
		#total of netweight for partial frequency rows
		aggregatedNetWeight = sum(netWeight)
		logger.info('aggregated wgt ' +str(aggregatedNetWeight))
		
		#get current batch, current consumed and planned quantity for this material
		path2 = 'AutoGI/getCurrentBatchFromTempBatchManagement'
		param2 = {'database':database, 'po':po, 'wc':wc, 'material':material}
		query2 = system.db.runNamedQuery(path2,param2)
		logger.info('current btch query' +str(query2))
		
		if query2:
			currentBatch = str(query2.getValueAt(0,'BATCH_NUMBER'))
			plannedQty = str(query2.getValueAt(0,'PLANNED_QUANTITY'))
			currentConsumption = str(query2.getValueAt(0,'CONSUMED_QUANTITY'))
		logger.info('current btch ' +str(currentBatch))
		logger.info('planned qty ' +str(plannedQty))
		#insert current consumption in tempBatchManagement
		path3 = 'AutoGI/updateConsumedQtyInTempBatchManagement'
		param3 = {'database':database, 'po':po, 'wc':wc, 'material':material, 'batch': currentBatch, 'consumedQty':currentConsumption}
		query3 = system.db.runNamedQuery(path3,param3)
		
		if query3:
			logger.info('a'+str(type(aggregatedNetWeight)) + 'c'+str(type(aggregatedNetWeight)) + 'p'+str(type(aggregatedNetWeight)))
			if (float(aggregatedNetWeight) + float(currentConsumption)) > float(plannedQty):
				#call a function to create and send GI msg
				giMsg = AutoGI.AutoGIBundling.createAndSendGIMsg(database, client, plant, po, wc, material, partialFreq, phase, operation, aggregatedNetWeight,area)
				
				if 'Success' in giMsg:
					#update tempBatchManagement table 
					#set consumed = 1 and consumedQty = plannedQty
					path = 'AutoGI/updateConsumedAndConsumedQtyInTempBatchManagement'
					param = {'database':database, 'po':po, 'wc':wc, 'material':material, 'batch': currentBatch, 'consumedQty':plannedQty, 'consumed':'1'}
					query = system.db.runNamedQuery(path,param)
					
					if query:
						#create next batch aggregated weight
						nextBatchAggregatedNetWeight = aggregatedNetWeight - float(plannedQty)
						logger.info('next aggregated wgt ' +str(nextBatchAggregatedNetWeight))
						#get current batch for this material
						path1 = 'AutoGI/getCurrentBatchFromTempBatchManagement'
						param1 = {'database':database, 'po':po, 'wc':wc, 'material':material}
						query1 = system.db.runNamedQuery(path1,param1)
						logger.info('next batch query '+str(query1))
						if query1:
							nextCurrentBatch = str(query1.getValueAt(0,'BATCH_NUMBER'))
							nextPlannedQty = str(query1.getValueAt(0,'PLANNED_QUANTITY'))
								
						logger.info('current btch ' +str(nextCurrentBatch))
						logger.info('planned qty ' +str(nextPlannedQty))
						#insert next batch aggregated weight in second row
						path2 = 'AutoGI/updateConsumedQtyInTempBatchManagement'
						param2 = {'database':database, 'po':po, 'wc':wc, 'material':material, 'batch': nextCurrentBatch, 'consumedQty':float(nextBatchAggregatedNetWeight)}
						query2 = system.db.runNamedQuery(path2,param2)
						
						if query2 == 1:
							#call a function to create and send GI msg
							giMsg = AutoGI.AutoGIBundling.createAndSendGIMsg(database, client, plant, po, wc, material, partialFreq, phase, operation, nextBatchAggregatedNetWeight,area)
							return giMsg
				
			else:
				#call a function to create and send GI msg
				giMsg = AutoGI.AutoGIBundling.createAndSendGIMsg(database, client, plant, po, wc, material, partialFreq, phase, operation, aggregatedNetWeight,area)
				return giMsg
				
	except:
		MII_Ignition_Library.Logger.Insert_Log.Insert_Error_Log("Auto GI For : "+str(wc)+"--"+str(po), str(sys.exc_info()))
		return str(sys.exc_info())
		
def packagingMaterial(database, client, plant, po, wc, partialFreq, material, phase, operation, device, area):
	try:
		#create logger
		workCenter = wc #workcenter needs to be changed accordingly
		logger = system.util.getLogger('Automatic buffer reset ' + str(workCenter))
		
		#get current batch, current consumed and planned quantity for this material
		path2 = 'AutoGI/getCurrentBatchFromTempBatchManagement'
		param2 = {'database':database, 'po':po, 'wc':wc, 'material':material}
		query2 = system.db.runNamedQuery(path2,param2)
		logger.info('current btch query' +str(query2))
		
		if query2:
			currentBatch = str(query2.getValueAt(0,'BATCH_NUMBER'))
			plannedQty = str(query2.getValueAt(0,'PLANNED_QUANTITY'))
			currentConsumption = str(query2.getValueAt(0,'CONSUMED_QUANTITY'))
		
		#get PO planned quantity as final product target
		path1 = 'AutoGI/getPlannedQtyOfPO'
		param1 = {'database':database, 'po':po}
		query1 = system.db.runNamedQuery(path1,param1)
		
		if query1:
			finalProductCount = str(query1.getValueAt(0,'BMENGE'))
		
		#get product count from tblSpcWeightHistory where productionStatus = 1 and device = auto PR device (getting pr device from timer script)
		path2 = 'AutoGI/getAggregateProductCountFromSpcWeightHistory'
		param2 = {'database':database,'partialFreq':int(partialFreq), 'po':po, 'wc':wc, 'material':material, 'device':device}
		query2 = system.db.runNamedQuery(path2,param2)
		packingCount = []
		
		if query2:
			for row in range(query2.getRowCount()):
				packingCount.append(query2.getValueAt(row,'ProductCount'))
		#total of netweight for partial frequency rows
		aggregatedPackingCount = sum(packingCount)
		
		#to be posted quantity for GI message
		#target for the material(from material db) / final product target(from po db)
		PerCountGIQty = float(plannedQty)/float(finalProductCount)
		GIToBePostedQty = float(PerCountGIQty)*float(aggregatedPackingCount)
		
		
		
		
		#insert current consumption in tempBatchManagement
		path4 = 'AutoGI/updateConsumedQtyInTempBatchManagement'
		param4 = {'database':database, 'po':po, 'wc':wc, 'material':material, 'batch': currentBatch[1:], 'consumedQty':currentConsumption}
		query4 = system.db.runNamedQuery(path4,params4)
		
		if query4:
			if (aggregatedPackingCount + currentConsumption) > float(plannedQty):
				
				#call a function to create and send GI msg
				giMsg = AutoGI.AutoGIBundling.createAndSendGIMsg(database, client, plant, po, wc, material, partialFreq, phase, operation, aggregatedPackingCount,area)
				
				if 'Success' in giMsg:
					#update tempBatchManagement table 
					#set consumed = 1 and consumedQty = plannedQty
					path = 'AutoGI/updateConsumedAndPlannedQtyInTempBatchManagement'
					param = {'database':database, 'po':po, 'wc':wc, 'material':material, 'batch': currentBatch, 'plannedQty':plannedQty, 'consumed':'1'}
					query = system.db.runNamedQuery(path,param)
					
					if query:
						#create next batch aggregated weight
						nextBatchAggregatedPackingCount = aggregatedPackingCount - float(plannedQty)
						
						#get current batch for this material
						path1 = 'AutoGI/getCurrentBatchFromTempBatchManagement'
						param1 = {'database':database, 'po':po, 'wc':wc, 'material':material}
						query1 = system.db.runNamedQuery(path1,param1)
						
						
						if query1:
							nextCurrentBatch = str(query1.getValueAt(0,'BATCH_NUMBER'))
							nextPlannedQty = str(query1.getValueAt(0,'PLANNED_QUANTITY'))
								
						#insert next batch aggregated weight in second row
						path2 = 'AutoGI/updateConsumedQtyInTempBatchManagement'
						param2 = {'database':database, 'po':po, 'wc':wc, 'material':material, 'batch': nextCurrentBatch, 'consumedQty':nextBatchAggregatedPackingCount}
						query2 = system.db.runNamedQuery(path2,param2)
						
						if query2:
							#call a function to create and send GI msg
							giMsg = AutoGI.AutoGIBundling.createAndSendGIMsg(database, client, plant, po, wc, material, partialFreq, phase, operation, nextBatchAggregatedPackingCount,area)
							return giMsg
				
			else:
				#call a function to create and send GI msg
				giMsg = AutoGI.AutoGIBundling.createAndSendGIMsg(database, client, plant, po, wc, material, partialFreq, phase, operation, GIToBePostedQty,area)
				return giMsg
				
	except:
		MII_Ignition_Library.Logger.Insert_Log.Insert_Error_Log("Auto GI For : "+str(wc)+"--"+str(po), str(sys.exc_info()))
		return str(sys.exc_info())
		
def createAndSendGIMsg(database,client,plant,po,wc,material,partialFreq,phase,operation,quantity,area):
	try:
		#create logger
		workCenter = wc #workcenter needs to be changed accordingly
		logger = system.util.getLogger('Automatic buffer reset ' + str(workCenter))
		
		#create variables
		Client= client
		Plant= plant
		Phase= phase
		Operation= operation
		EventTime= system.date.format(system.date.now(), "yyyy-MM-dd HH:mm:ss").replace(" ","T")
		User_ID= 'Auto'
		Final_Issue= ''
		Reason_For_Movement= ''
		Quantity= str(quantity)
		
		#create variable for GI msg from tempBatchManagement
		path = 'AutoGI/getGIMsgParamFromTempBatchManagement'
		param = {'database':database, 'po':po, 'wc':wc, 'material':material}
		query = system.db.runNamedQuery(path,param)
		if query:
			SAP_Resource_Name= str(query.getValueAt(0,'RESOURCE'))
			Nodename= str(query.getValueAt(0,'RESOURCE'))
			Node_ID= ''#str(query.getValueAt(0,'NODE_ID'))
			PO= str(query.getValueAt(0,'PROCESS_ORDER'))
			Material= str(query.getValueAt(0,'MATERIAL_NUMBER'))
			UOM= str(query.getValueAt(0,'UOM'))
			Batch_Number= str(query.getValueAt(0,'BATCH_NUMBER'))
			Storage_Location= str(query.getValueAt(0,'STORAGE_LOCATION'))
			Movement_Type= str(query.getValueAt(0,'MOVEMENT_TYPE'))
			Resb_Pos= str(query.getValueAt(0,'RESB_POS'))
		
			#create GI xml message
			xmlMsg = MII_Ignition_Library.Production_Data.Good_Issues.Create_Good_Issue_XML(Client, Plant, SAP_Resource_Name, Nodename, Node_ID, PO, Phase, Operation, EventTime, User_ID, Material, Quantity, UOM, Batch_Number, Storage_Location, Reason_For_Movement, Movement_Type, Final_Issue, Resb_Pos)
			logger.info(str(xmlMsg))
			#post GI msg in tempGIStagingTable
			path1 = 'AutoGI/insertIntoTempGIStagingTable'
			param1 = {'database':database,'client': client,'plant':plant ,'wc': wc,'po': po,'operation': operation,'phase':phase ,'message':xmlMsg, 'eventTime':EventTime ,'processed': "0",'messageType': "Good Issues",'inspchar': "",'attempts': "0",'response': "",'area': area,'updatedBy':User_ID ,'bagNumber':""}
			query1 = system.db.runNamedQuery(path1,param1)
			
			if query1:
				#delete record from tempSpcWeightHistory and tempBatchingTable for top(partialFreq)
				path = 'AutoGI/deleteProcessedDataFromTemp'
				param = {'database':database,'partialFreq':int(partialFreq), 'po':po, 'wc':wc, 'material':material}
				query = system.db.runNamedQuery(path,param)
				return 'Success'
	except:
		MII_Ignition_Library.Logger.Insert_Log.Insert_Error_Log("Create Auto GI Msg For : "+str(wc)+"--"+str(po), str(sys.exc_info()))
		return str(sys.exc_info())
		
def postDataToGIQueueMsg(database,partialFreq,client,plant,po,resource,nodename,nodeID,phase,operation,area,autoGI,phaseSts):
	try:
		#check if po is active
		if phaseSts == 'ACT' or phaseSts == 'RESUME':
			#check if auto gi is enabled
			if autoGI == 1:
				#call stored procedure
				path = 'AutoGI/sp_Insert_xMII_AutoGI_Message'
				param = {'database':database, 'partialFreq':partialFreq, 'client':client, 'plant':plant, 'po':po, 'resource':resource, 'nodename':nodename, 'nodeID':nodeID, 'phase':phase, 'operation':operation, 'area':area}
				query = system.db.runNamedQuery(path,param)
				#MII_Ignition_Library.Logger.Insert_Log.Insert_Info_Log("Create Auto GI Msg For : "+str(resource)+"--"+str(po), str(query))
				return query
			else:
				MII_Ignition_Library.Logger.Insert_Log.Insert_Info_Log("Create Auto GI Msg For : "+str(resource)+"--"+str(po), "Auto GI is disabled!")
				return "Auto GI is disabled!"
	except:
		MII_Ignition_Library.Logger.Insert_Log.Insert_Error_Log("Create Auto GI Msg For : "+str(resource)+"--"+str(po), str(sys.exc_info()))
		return str(sys.exc_info())
		