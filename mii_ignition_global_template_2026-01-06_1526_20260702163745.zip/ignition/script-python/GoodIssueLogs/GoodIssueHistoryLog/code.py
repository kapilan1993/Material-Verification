def PostGoodIssueHistory(Database, Client, Plant, PO, Area1, Work_Center, Nodename, Phase, Operation, EventTime, Material, Quantity, UOM, NetWeight, BatchNumber, StorageLocation, ReasonForMove, UserID, ItemCount, DeviceName, SAPResourceName, NodeID, MovementType, FinalIssue, ResbPos):
	import xml.etree.ElementTree as ET
	import json
	Json = "True"
	
	try:
		logger = system.util.getLogger("Good Issue Log")
		### Starting the development of the XML  ###
							
		# Create the root element
		root = ET.Element("Goods_Issue")
		
		# Create the 'row' element
		row = ET.SubElement(root, "row")
		
		# Create and fill the child elements
		sap_client_element = ET.SubElement(row, "SAPClient")
		sap_client_element.text = Client
		
		sap_plant_element = ET.SubElement(row, "SAPPlant")
		sap_plant_element.text = Plant
		
		sap_resource_name_element = ET.SubElement(row, "SAPResourceName")
		sap_resource_name_element.text = SAPResourceName
		
		sap_node_name_element = ET.SubElement(row, "NodeName")
		sap_node_name_element.text = Nodename
		
		sap_node_id_element = ET.SubElement(row, "NodeID")
		sap_node_id_element.text = NodeID
		
		order_element = ET.SubElement(row, "Order")
		order_element.text = PO
		
		phase_element = ET.SubElement(row, "Phase")
		phase_element.text = Phase
		
		event_time_element = ET.SubElement(row, "EventTime")
		event_time_element.text = EventTime
		
		user_element = ET.SubElement(row, "User")
		user_element.text = UserID
		
		items_element = ET.SubElement(row, "Items")
		item1_element = ET.SubElement(items_element, "Item")
		
		matnr_element = ET.SubElement(item1_element, "Matnr")
		matnr_element.text = Material
		
		quantity_element = ET.SubElement(item1_element, "Quantity")
		quantity_element.text = NetWeight
		
		uom_element = ET.SubElement(item1_element, "UOM")
		uom_element.text = UOM
		
		batchnr_element  = ET.SubElement(item1_element, "Batchnr")
		batchnr_element.text = BatchNumber
		
		storage_loc_element = ET.SubElement(item1_element, "StorageLocation")
		storage_loc_element.text = StorageLocation
		
		reason_for_move_element = ET.SubElement(item1_element, "ReasonForMove")
		reason_for_move_element.text = ReasonForMove
		
		movement_type_element = ET.SubElement(item1_element, "MovementType")
		movement_type_element.text = MovementType
		
		final_issue_element = ET.SubElement(item1_element, "FinalIssue")
		final_issue_element.text = FinalIssue
		
		resb_pos_element = ET.SubElement(item1_element, "Resb_Pos")
		resb_pos_element.text = ResbPos
		
		# Create the XML string
		xml_str = ET.tostring(root, encoding="utf-8", method="xml")
			
		# Convert bytes to string
		xml_str = xml_str.decode("utf-8")
		
		if Database != None:
			#create parameters
			newDataset = {'database':Database,'Client':Client,'Plant':Plant,'PO':PO,'Area':Area1, 'WorkCenter':Work_Center, 'Nodename':Nodename,'Phase':Phase,'Operation':Operation,'EventTime':EventTime,'DeviceName':DeviceName,'Material':Material,'Quantity':Quantity,'UOM':UOM,'NetWeight':NetWeight,'BatchNumber':BatchNumber,'StorageLocation':StorageLocation,'ReasonForMove':ReasonForMove,'UpdatedBy':'Auto','ItemCount':ItemCount, 'Message':xml_str, 'Processed':'0', 'Attempts':'0', 'Retry_Limit':'3'}
			#add data into database
			insertQuery = system.db.runNamedQuery('GoodIssue/InsertGoodIssueHistoryLogs', newDataset)
			logger.info("Insert response is : " + str(insertQuery))
			
			return insertQuery
		else:
			MII_Ignition_Library.Logger.Insert_Log.Insert_Error_Log(Client + "_" + Plant + "_" + "PostGoodIssueHistory", "Error: Tag path is not available!"+str(sys.exc_info()))
			return "Error: Tag path is not available"
	except:
		
		MII_Ignition_Library.Logger.Insert_Log.Insert_Error_Log(Client + "_" + Plant + "_" + DeviceName + "_" + "PostGoodIssueHistory", "Error: GoodIssueLogs.GoodIssueHistoryLog.PostGoodIssueHistory has failed. Check logger for details."+str(sys.exc_info()))
		return "Error: GoodIssueLogs.GoodIssueHistoryLog.PostGoodIssueHistory has failed.Check logger for details."
		
