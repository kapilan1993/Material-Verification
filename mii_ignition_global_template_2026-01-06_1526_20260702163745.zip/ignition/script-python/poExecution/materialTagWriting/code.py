def tagWrite(client, plant, tagProvider, area, resource, po, poResbMaterial, prePackTolMaterial, headerMaterial,database):
	try:
		tagPaths = []
		tagValues = []
		#Creating path for tag writing
		basePath = tagProvider + "Coca-Cola/CPS/" + plant + "/" + area + "/" + resource + "/SF_Equipment/"
		
		#Writing checkweigher data
		primaryCheckweigherPath = basePath + "Checkweigher/Primary_Packaging/"
		secondaryCheckweigherPath = basePath + "Checkweigher/Secondary_Packaging/"
		    
		#Get Secondary packaging Quantity
		try:
			SecondaryPackQty = poExecution.getSpackQty.getPhantomSpackQty(client,plant,database,po)    
		except:
			SecondaryPackQty = 0
		#Writing filler data
		fillerHeadPath = basePath + "Filler/"
		
		#Filetering ROH and HALB materila
		filteredResb = []
		for row1 in poResbMaterial:
		    if (row1['MTART'] == 'ROH' or row1['MTART'] == 'HALB') and row1['BDMNG'] != "0":
		        filteredResb.append(row1)
		        
		#Checkweigher material from pre_pack_tol
		filteredPpCheckweihger = []
		try:
			for row2 in prePackTolMaterial:
			    if (row2['PHANTOM'] == 'X'):
			        filteredPpCheckweihger.append(row2)
			       
		except:
			row2 = {'INGREDIENT': prePackTolMaterial['INGREDIENT'],
					'PRIM_PACK_PER_SPACK_SP' : prePackTolMaterial['PRIM_PACK_PER_SPACK_SP'],
					'PRIM_PACK_PER_SPACK_SP_UL' : prePackTolMaterial['PRIM_PACK_PER_SPACK_SP_UL'],
					'PRIM_PACK_PER_SPACK_SP_LL' : prePackTolMaterial['PRIM_PACK_PER_SPACK_SP_LL'],
					'PRIM_PACK_PER_SPACK_SP_UOM' : prePackTolMaterial['PRIM_PACK_PER_SPACK_SP_UOM']}
			filteredPpCheckweihger.append(row2)
		
	#	#Secondary checkweigher data for po header
	#	filteredSpCheckweihger = []
	#	filteredSpCheckweihger.append(headerMaterial)
		
		#Get materials from history table
		path = "POExecution/GetFinalMaterialMaterials"
		params = {"po" : po , "wc" : resource}
		deviceDetails =  system.db.runNamedQuery(path,params)
		
		
		
		#Creating tag path and values
		for device in deviceDetails:
			print device[0],device[1]
			if (device[0].find("FillerHead") == 0) :
				for rowResb in filteredResb:
					if rowResb["MATNR"] == device[1]:
						print device[1]#[Shop_Floor]Coca-Cola/CPS/0384/DP/DF05/SF_Equipment/Filler/FillerHead_2/MessageDownload/SET_MaterialNumber
						tagPaths.append(fillerHeadPath+device[0]+"/MessageDownload/SET_MaterialNumber")
						tagPaths.append(fillerHeadPath+device[0]+"/MessageDownload/SET_BatchNo")
						tagPaths.append(fillerHeadPath+device[0]+"/MessageDownload/SET_TargetWeight")
						tagPaths.append(fillerHeadPath+device[0]+"/MessageDownload/SET_LowerLimit")
						tagPaths.append(fillerHeadPath+device[0]+"/MessageDownload/SET_UpperLimit")
						tagPaths.append(fillerHeadPath+device[0]+"/MessageDownload/SET_WeightUOM")
						tagValues.append(rowResb["MATNR"])
						tagValues.append((rowResb["CHARG"]).split(',')[0].lstrip())
						tagValues.append(float(rowResb["ING_TARGET"]))
						tagValues.append(float(rowResb["ING_TARGET_LL"]))
						tagValues.append(float(rowResb["ING_TARGET_UL"]))
						tagValues.append(rowResb["ING_TARGET_UOM"])
			elif (device[0].find("CheckWeigher_PP") == 0):
				if len(filteredPpCheckweihger) > 0:
					for rowPpCheckweigher in filteredPpCheckweihger:
						if rowPpCheckweigher["INGREDIENT"] == device[1]:
							tagPaths.append(primaryCheckweigherPath+device[0]+"/MessageDownload/SET_MaterialNumber")
							tagPaths.append(primaryCheckweigherPath+device[0]+"/MessageDownload/SET_BatchNo")
							tagPaths.append(primaryCheckweigherPath+device[0]+"/MessageDownload/SET_TargetWeight")
							tagPaths.append(primaryCheckweigherPath+device[0]+"/MessageDownload/SET_LowerLimit")
							tagPaths.append(primaryCheckweigherPath+device[0]+"/MessageDownload/SET_UpperLimit")
							tagPaths.append(primaryCheckweigherPath+device[0]+"/MessageDownload/SET_WeightUOM")
							tagPaths.append(primaryCheckweigherPath+device[0]+"/MessageDownload/SET_SpackQty")
							tagValues.append(rowPpCheckweigher["INGREDIENT"])
							tagValues.append("---")
							tagValues.append(float(rowPpCheckweigher["PRIM_PACK_PER_SPACK_SP"]))
							tagValues.append(float(rowPpCheckweigher["PRIM_PACK_PER_SPACK_SP_LL"]))
							tagValues.append(float(rowPpCheckweigher["PRIM_PACK_PER_SPACK_SP_UL"]))
							tagValues.append(rowPpCheckweigher["PRIM_PACK_PER_SPACK_SP_UOM"])
							tagValues.append(float(SecondaryPackQty))
							
				else:
					tagPaths.append(primaryCheckweigherPath+device[0]+"/MessageDownload/SET_MaterialNumber")
					tagPaths.append(primaryCheckweigherPath+device[0]+"/MessageDownload/SET_BatchNo")
					tagPaths.append(primaryCheckweigherPath+device[0]+"/MessageDownload/SET_TargetWeight")
					tagPaths.append(primaryCheckweigherPath+device[0]+"/MessageDownload/SET_LowerLimit")
					tagPaths.append(primaryCheckweigherPath+device[0]+"/MessageDownload/SET_UpperLimit")
					tagPaths.append(primaryCheckweigherPath+device[0]+"/MessageDownload/SET_WeightUOM")
					tagPaths.append(primaryCheckweigherPath+device[0]+"/MessageDownload/SET_SpackQty")
					tagPaths.append(primaryCheckweigherPath+device[0]+"/MessageDownload/SET_TargetQuantity")
					tagPaths.append(secondaryCheckweigherPath+"CheckWeigher_SP_1/MessageDownload/SET_SpackQty")
					tagValues.append(headerMaterial["MATNR"])
					tagValues.append(headerMaterial["ORDERCHARG"])
					tagValues.append(float(headerMaterial["SP_TARGET"]))
					tagValues.append(float(headerMaterial["SP_TARGET_LL"]))
					tagValues.append(float(headerMaterial["SP_TARGET_UL"]))
					tagValues.append(headerMaterial["SP_TARGET_UOM"])
					tagValues.append(float(SecondaryPackQty))
					tagValues.append(float(headerMaterial["BMENGE"]))
					tagValues.append(float(SecondaryPackQty))
					
		
			elif (device[0].find("CheckWeigher_SP") == 0):
				tagPaths.append(secondaryCheckweigherPath+device[0]+"/MessageDownload/SET_MaterialNumber")
				tagPaths.append(secondaryCheckweigherPath+device[0]+"/MessageDownload/SET_BatchNo")
				tagPaths.append(secondaryCheckweigherPath+device[0]+"/MessageDownload/SET_TargetWeight")
				tagPaths.append(secondaryCheckweigherPath+device[0]+"/MessageDownload/SET_LowerLimit")
				tagPaths.append(secondaryCheckweigherPath+device[0]+"/MessageDownload/SET_UpperLimit")
				tagPaths.append(secondaryCheckweigherPath+device[0]+"/MessageDownload/SET_WeightUOM")
				tagPaths.append(secondaryCheckweigherPath+device[0]+"/MessageDownload/SET_SpackQty")
				tagPaths.append(secondaryCheckweigherPath+device[0]+"/MessageDownload/SET_TargetQuantity")
				tagValues.append(headerMaterial["MATNR"])
				tagValues.append(headerMaterial["ORDERCHARG"])
				tagValues.append(float(headerMaterial["SP_TARGET"]))
				tagValues.append(float(headerMaterial["SP_TARGET_LL"]))
				tagValues.append(float(headerMaterial["SP_TARGET_UL"]))
				tagValues.append(headerMaterial["SP_TARGET_UOM"])
				tagValues.append(float(SecondaryPackQty))
				tagValues.append(float(headerMaterial["BMENGE"]))
				
		
#		MII_Ignition_Library.Logger.Insert_Log.Insert_Error_Log(client +"--"+plant+"--Tag Writing Script ",str(tagPaths))
#		MII_Ignition_Library.Logger.Insert_Log.Insert_Error_Log(client +"--"+plant+"--Tag Writing Script ",str(tagValues))
		system.tag.writeBlocking(tagPaths, tagValues)
	
	except Exception as e: #ALF / SRC
		Status = e	
	#except:
		MII_Ignition_Library.Logger.Insert_Log.Insert_Error_Log(client +"--"+plant+"--Tag Writing Script ", str(Status) + " " + str(sys.exc_info())) 