def BufferData(tagProvider, plant, po, resource):
	path = "POExecution/GetFinalMaterialMaterials"
	params = {"po" : po , "wc" : resource}
	deviceDetails =  system.db.runNamedQuery(path,params)
	
	#Area finding
	if resource[0:2] == 'LF': #Liquid Filling
		areaPrefix = 'LF'
	elif resource[0:2] == 'DF' or resource[0:2] == 'DA': #Dry Processing
		areaPrefix = 'DP'
	
	#creating tag paths
	basePath = tagProvider + 'Coca-Cola/CPS/' + plant + '/' + areaPrefix + '/' + resource + '/Gateway_Devices/SpcWeight/'
	tagPaths = []
	#Creating tag path and values
	for device in deviceDetails:
		tagPaths.append(basePath + device[0] + '/BufferCount')
	tagValues = system.tag.readBlocking(tagPaths)
	
	for tagValue in tagValues:
		if tagValue.value == '0' or tagValue.value == 0:
			result = False
		else:
			result = True

	return result