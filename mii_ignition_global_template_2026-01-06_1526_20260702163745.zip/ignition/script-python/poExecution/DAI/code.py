def insertDaiMessage(database, Po, MaterialNo, BatchNo, Qty, Uom):
	logger = system.util.getLogger("name")
	logger.info(BatchNo)
	#print(BatchNo)
	finalMaterialNo = MaterialNo.zfill(18)
	finalQty = "{:.3f}".format(float(Qty))
	if BatchNo == "" or BatchNo == None:
		finalBatchNo = " "
	else:
		finalBatchNo = BatchNo.zfill(10)
	daiMessage = "CONSUMED " + str(Po) + " " + str(finalMaterialNo) + " " + str(finalBatchNo) + " " + str(finalQty) + " " + str(Uom)
	
	#inserting data in CONSUMPTIONS_FOR_DAI
	path = 'DAI/insertDAI'
	params = {'database' : database, 'po' : Po, 'daiMessage' : daiMessage}
	system.db.runNamedQuery(path, params)