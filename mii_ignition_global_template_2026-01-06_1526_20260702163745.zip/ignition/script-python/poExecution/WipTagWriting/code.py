def WipTagWrite(plant, tagProvider, area, resource, poResbMaterial, prePackTolMaterial):
	try:
		tagPaths = []
		tagValues = []
		basePath = tagProvider + "Coca-Cola/CPS/" + plant + "/" + area + "/" + resource + "/WIP/WIP_"
		
		#writing wip tags only for DA lines
		if 'DA' in resource:
			#pass null value before starting
			wipTagPaths = []
			wipTagValues = []
			count = 1
			while count < 11:
				wipTagPaths.append(basePath + str(count) + "/MaterialNo")
				wipTagPaths.append(basePath + str(count) + "/MaterialDesc")
				wipTagPaths.append(basePath + str(count) + "/BatchNo")
				wipTagPaths.append(basePath + str(count) + "/BathcQty")
				wipTagPaths.append(basePath + str(count) + "/LowerLimit")
				wipTagPaths.append(basePath + str(count) + "/Quantity")
				wipTagPaths.append(basePath + str(count) + "/QuantityUom")
				wipTagPaths.append(basePath + str(count) + "/Target")
				wipTagPaths.append(basePath + str(count) + "/Uom")
				wipTagPaths.append(basePath + str(count) + "/UpperLimit")
				wipTagValues.append("")
				wipTagValues.append("")
				wipTagValues.append("")
				wipTagValues.append(float('0'))
				wipTagValues.append(float('0.0'))
				wipTagValues.append(float('0.0'))
				wipTagValues.append("")
				wipTagValues.append(float('0.0'))
				wipTagValues.append("")
				wipTagValues.append(float('0.0'))
				count += 1
			system.tag.writeBlocking(wipTagPaths, wipTagValues)
	
			index = 0
#			MII_Ignition_Library.Logger.Insert_Log.Insert_Error_Log("--"+plant+"--WIP Tag Writing Script ", str(poResbMaterial)) 
			for row in poResbMaterial:
				if 'WIP' in row['MATNR_DESC'] and row['CHARG']!='---' and row['BDMNG']!=0:
#					MII_Ignition_Library.Logger.Insert_Log.Insert_Error_Log("--"+plant+"--WIP Tag Writing Script ", str(row)) 
					index += 1
					if index < 10:
						tagPaths.append(basePath + str(index) + "/MaterialNo")
						tagPaths.append(basePath + str(index) + "/MaterialDesc")
						tagPaths.append(basePath + str(index) + "/BatchNo")
						tagPaths.append(basePath + str(index) + "/BatchQty")
						
						tagValues.append(row['MATNR'])
						tagValues.append(row['MATNR_DESC'])
						tagValues.append(row['CHARG'])
						tagValues.append(float(row['BDMNG']))
#						MII_Ignition_Library.Logger.Insert_Log.Insert_Error_Log("--"+plant+"--WIP Tag Writing Script ", str(row['CHARG'])) 
						try:
							for pric in prePackTolMaterial:
								if row['MATNR']==pric['INGREDIENT']:
#									MII_Ignition_Library.Logger.Insert_Log.Insert_Error_Log("--"+plant+"--WIP Tag Writing Script ", str(pric)) 
									tagPaths.append(basePath + str(index) + "/LowerLimit")
									tagPaths.append(basePath + str(index) + "/Quantity")
									tagPaths.append(basePath + str(index) + "/QuantityUom")
									tagPaths.append(basePath + str(index) + "/Target")
									tagPaths.append(basePath + str(index) + "/Uom")
									tagPaths.append(basePath + str(index) + "/UpperLimit")
									
									tagValues.append(float(pric['PRIM_PACK_PER_SPACK_SP_LL']))
									tagValues.append(float(pric['PRIM_PACK_PER_SPACK_QTY']))
									tagValues.append(pric['PRIM_PACK_PER_SPACK_QTY_UOM'])
									tagValues.append(float(pric['PRIM_PACK_PER_SPACK_SP']))
									tagValues.append(pric['PRIM_PACK_PER_SPACK_SP_UOM'])
									tagValues.append(float(pric['PRIM_PACK_PER_SPACK_SP_UL']))   
#							MII_Ignition_Library.Logger.Insert_Log.Insert_Error_Log("--"+plant+"--WIP Tag Writing Script ", "try executed") 
						except:
							prePackTolArray = [prePackTolMaterial] 
							for pric in prePackTolArray:
								if row['MATNR']==pric['INGREDIENT']:
							
									tagPaths.append(basePath + str(index) + "/LowerLimit")
									tagPaths.append(basePath + str(index) + "/Quantity")
									tagPaths.append(basePath + str(index) + "/QuantityUom")
									tagPaths.append(basePath + str(index) + "/Target")
									tagPaths.append(basePath + str(index) + "/Uom")
									tagPaths.append(basePath + str(index) + "/UpperLimit")
									
									tagValues.append(float(pric['PRIM_PACK_PER_SPACK_SP_LL']))
									tagValues.append(float(pric['PRIM_PACK_PER_SPACK_QTY']))
									tagValues.append(pric['PRIM_PACK_PER_SPACK_QTY_UOM'])
									tagValues.append(float(pric['PRIM_PACK_PER_SPACK_SP']))
									tagValues.append(pric['PRIM_PACK_PER_SPACK_SP_UOM'])
									tagValues.append(float(pric['PRIM_PACK_PER_SPACK_SP_UL']))
#							MII_Ignition_Library.Logger.Insert_Log.Insert_Error_Log("--"+plant+"--WIP Tag Writing Script ", "except executed") 
#			MII_Ignition_Library.Logger.Insert_Log.Insert_Error_Log("--"+plant+"--WIP Tag Writing Script ", str(tagPaths)) 
#			MII_Ignition_Library.Logger.Insert_Log.Insert_Error_Log("--"+plant+"--WIP Tag Writing Script ", str(tagValues)) 
			system.tag.writeBlocking(tagPaths, tagValues)
	except Exception as e: #ALF / SRC
		Status = e	
	#except:
		MII_Ignition_Library.Logger.Insert_Log.Insert_Error_Log("--"+plant+"--WIP Tag Writing Script ", str(Status) + " " + str(sys.exc_info())) 