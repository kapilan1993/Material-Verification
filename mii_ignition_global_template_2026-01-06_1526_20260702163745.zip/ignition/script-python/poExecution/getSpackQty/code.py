def getPhantomSpackQty(client,plant,database,po):
	path = "POExecution/xMII_Data"
	params = {"PO" : po, "CLIENT": client, "PLANT": plant, "database" : database}
	MII_DATA = system.db.runNamedQuery(path, params)
	json = system.util.jsonDecode(MII_DATA)
 
	PoPriPackTol = json["DOWNLOAD_RECIPE"]["PRI_PACK_TOL"]["Rowsets"]["Rowset"]["Row"]
	#print PoPriPackTol
	try:
		if PoPriPackTol["PHANTOM"] == "X":
			return PoPriPackTol["PRIM_PACK_PER_SPACK_QTY"]
		else:
			return 0
	except:
		if PoPriPackTol["PHANTOM"] == "X":
			return PoPriPackTol["PRIM_PACK_PER_SPACK_QTY"]
		else:
			return 0