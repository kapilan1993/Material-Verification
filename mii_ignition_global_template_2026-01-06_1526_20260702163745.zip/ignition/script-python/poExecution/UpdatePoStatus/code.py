def poStatus(Database, Tag_Provider, Client, Plant, PO, Resource):
	try:
		#Get area
		Area = MII_Ignition_Library.ToolsSet.Tools.areaFinding(Resource)
	
		#Populate MII_PO_Status and validate if  tag writing fails in the process 
		phase = system.tag.readBlocking(Tag_Provider + "Coca-Cola/CPS/" + Plant + "/" + Area + "/" + Resource + "/PO/Phase/pPhase")[0].value
		phaseStatus = system.tag.readBlocking(Tag_Provider + "Coca-Cola/CPS/" + Plant + "/" + Area + "/" + Resource + "/PO/Phase/pMIIPHStatus")[0].value
		poStatus = system.tag.readBlocking(Tag_Provider + "Coca-Cola/CPS/" + Plant + "/" + Area + "/" + Resource + "/PO/Phase/pMIIPOStatus")[0].value
		
		#Get S4Status
		if poStatus in ['ACT', 'RESUME', 'HOLD', 'CMPL','ABORT','OBS']:
			s4Status = "COMPLETED"
		elif poStatus in ['CANCEL']:
			s4Status = "DISCARDED"
		else:
			s4Status = '---'
#		MII_Ignition_Library.Logger.Insert_Log.Insert_Error_Log(Client +"--"+Plant+"--PO Update ",str(poStatus))
#		MII_Ignition_Library.Logger.Insert_Log.Insert_Error_Log(Client +"--"+Plant+"--PO Update ",str(s4Status))
		#Update Status in DB
		params = {"database" : Database,
		"po" : PO,
		"phase" : phase,
		"phaseStatus" : phaseStatus,
		"poStatus" : poStatus,
		"s4Status" : s4Status}
		
		MII_DB_Response = system.db.runNamedQuery("POExecution/UpdatePoStatus", params)
		MII_PO_Status = MII_DB_Response.getValueAt(0, "MII_PO_Status")
	except:
		MII_Ignition_Library.Logger.Insert_Log.Insert_Error_Log(Client +"--"+Plant+"--PO Update ",str(sys.exc_info()))