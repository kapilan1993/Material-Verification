def addDevice(database, workCenter, devices, user):
	#Get WC id
	namedQuery = 'WcConfiguration/getWorkCentersDetails'
	parameter = {"database":database,"workCenter" : workCenter}
	wcId = system.db.runNamedQuery(namedQuery,parameter)
	
	#Add deivces in tblDeviceMaster
	for device in devices:
	    types = device['deviceType']
	    name = device['deviceName']
	    capacityMin = device['min']
	    capacityMax = device['max']
	    resolution = device['resolution']
	    priOrSec = device['priOrSec']
	    fixOrManual= device['fixedOrManual']
	    usbOrGateway = device['usbOrGateway']
	    uomId = device['deviceCapacityUnit']
	    namedQuery = 'WcConfiguration/addDevice'
	    parameter = {"database":database, "name" : name, "type" : types,  "capacityMin" :capacityMin, "capacityMax": capacityMax, "resolution":resolution, "uomId" :uomId,"priOrSec":priOrSec, "fixOrManual": fixOrManual , "wcId" : wcId[0][0], "usbOrGateway":usbOrGateway,"updateBy" : user}
	    system.db.runNamedQuery(namedQuery,parameter)
	   
def updateWorkCenter(database,workCenter, wcType, description, area):
	namedQuery = 'WcConfiguration/updateWorkCenters'
	parameter = {"database":database, "wc" : workCenter, "isConfigured" : 1, "workCenterType" : wcType, "description": description, "area":area}
	wcId = system.db.runNamedQuery(namedQuery,parameter)
	
def creareUdtInstance(tagPath, udtName, udtType):
	udtInstance = {	"name" : udtName,
		"typeId" : udtType,
		"tagType" : "UdtInstance",
		}

	system.tag.configure(tagPath, udtInstance)
	    
def addnewDevice(database, workCenter, deviceType,deviceName,capacityMin,capacityMax, resolution,priOrSec, fixOrManual, usbOrGateway, uomId, user):

	#Get WC id
	namedQuery = 'WcConfiguration/getWorkCentersDetails'
	parameter = {"database":database, "workCenter" : workCenter}
	wcId = system.db.runNamedQuery(namedQuery,parameter)
	
	#Add deivces in tblDeviceMaster
	namedQuery = 'WcConfiguration/addDevice'
	parameter = {"database":database, "name" : deviceName, "type" : deviceType,  "capacityMin" :capacityMin, "capacityMax": capacityMax, "resolution":resolution, "uomId" :uomId, "priOrSec":priOrSec, "fixOrManual": fixOrManual , "wcId" : wcId[0][0],"usbOrGateway":usbOrGateway, "updateBy" : user}
	system.db.runNamedQuery(namedQuery,parameter)

def updateFunctions(database, workCenter, functions, user):
	params = {'source':'/system/images/Icons/Alert.svg','text':'Error while updating the function!'}
	try:
		values = []
		uomIDs=[]
		for function in functions:
			uomID = function['unit']
			uomIDs.append(uomID)
			system.perspective.print("uomID"+str(uomID))
			values.append(function["value"])
		idu = uomIDs[12]
		
		namedQuery = 'WcConfiguration/updateWcFuncitons'
		parameter = {"database": database, "wc" : workCenter, "enableAutoGi" : values[0], "enableAutoPr" : values[2], "enableAutoPhaseCom" : values[1], "enableBbd" : values[3], "enableMatManage" : values[5], "enableStockValidation" : values[10], "enablePartialGi" : values[11], "enableSkipBbd" : values[4], "partialGiFreq" : values[12], "enablePartialSplit" :values[7],  "enableFullSplit":values[8], "enableScrapReason":values[9], "enableBarcodeValidation":values[6],"enableBatchVerifiedPrePOExecution":values[13],"enableBBDValidation":values[14] ,"enableBarcodeValidationPrePOExecution":values[15] ,"enableBarcodeValidationPostPOExecution":values[16],"enableViewScales":values[17],"enableManualFilling":values[18], "uomId":idu,  "user" : user}
		system.db.runNamedQuery(namedQuery,parameter)
	except:
		MII_Ignition_Library.Logger.Insert_Log.Insert_Error_Log('UpdateWCFunctionInDB', str(sys.exc_info()))
		MII_Ignition_Library.OpenPopup.openErrorPopup(params)
	
def updateDevicesToDelete(workCenter):
	params = {"IsDeleted": 1, "wc":workCenter}
	system.db.runNamedQuery("WcConfiguration/updateDevices", params)
	

def folderExist(tagPath):
	folderExist = system.tag.exists(tagPath)
	return folderExist

def createFolder(basePath, folderName):
	#creating workcenter folder
	tagFolder = {'tagtype' : 'Folder',
					'name' : folderName,
				}
	system.tag.configure(basePath, tagFolder, 'o')
	
def createQueueFolder(tagPath, folderName):
	basePath = tagPath
	tagFolder = {
		  "name": folderName,
		  "tagType": "Folder",
		  "tags": [
		    {
		      "valueSource": "memory",
		      "dataType": "DataSet",
		      "name": "Queue",
		      "value": "",
		      "tagType": "AtomicTag",
		      "timestamp": 1722020062000
		    }
		  ]
		}
	system.tag.configure(basePath, tagFolder, 'o')
	

	
def createWcFolder(tagPath, folderName, plant, wcType, tagProvider):
	opcSer = system.opc.getServers(includeDisabled = True)[0]
#	opcSer = "BRMAO-MIIT.la.ko.com"
	basePath = tagPath
	#creating workcenter folder
	tagFolder = {
  "name": folderName,
  "tagType": "Folder",
  "tags": [
    {
      "name": "OEE",
      "typeId": "UNS/OEE",
      "tagType": "UdtInstance"
    },
    {
      "name": "Gateway_Devices",
      "tagType": "Folder",
      "tags": [
        {
          "name": "Metering",
          "tagType": "Folder",
          "tags": [
            {
              "name": "Humidity",
              "tagType": "Folder"
            },
            {
              "name": "Energy",
              "tagType": "Folder"
            }
          ]
        },
        {
          "name": "Barcode_Scanner",
          "tagType": "Folder",
          "tags": [
            {
              "name": "Fixed_Scanner",
              "tagType": "Folder"
            },
            {
              "name": "Handheld_Scanner",
              "tagType": "Folder"
            }
          ]
        },
        {
          "name": "Checkweigher",
          "tagType": "Folder"
        },
        {
          "name": "Sensors",
          "tagType": "Folder",
          "tags": [
            {
              "name": "Humidity",
              "tagType": "Folder"
            },
            {
              "name": "Temperature",
              "tagType": "Folder"
            },
            {
              "name": "Alarm",
              "tagType": "Folder"
            }
          ]
        },
        {
          "name": "Filler",
          "tagType": "Folder",
          "tags": [
		    {
		      "valueSource": "opc",
		      "opcItemPath": " ",
		      "dataType": "Boolean",
		      "name": "FillerPlcStatus",
		      "tagType": "AtomicTag",
		      "opcServer": opcSer
		    }
		  ]
        },
        {
          "name": "PO",
          "tagType": "Folder",
          "tags": [
            {
              "valueSource": "opc",
              "opcItemPath": "nsu=KEPServerEX;s=Coca-Cola."+plant+"."+wcType+"."+folderName+".PO.Cmd_Abort",
              "dataType": "String",
              "name": "Cmd_Abort",
              "tagType": "AtomicTag",
              "opcServer": opcSer
            },
            {
              "valueSource": "opc",
              "opcItemPath": "nsu=KEPServerEX;s=Coca-Cola."+plant+"."+wcType+"."+folderName+".PO.Cmd_Cancel",
              "dataType": "String",
              "name": "Cmd_Cancel",
              "tagType": "AtomicTag",
              "opcServer": opcSer
            },
            {
              "valueSource": "opc",
              "opcItemPath": "nsu=KEPServerEX;s=Coca-Cola."+plant+"."+wcType+"."+folderName+".PO.Sts_POExecutionStarted",
              "dataType": "String",
              "name": "Sts_POExecutionStarted",
              "tagType": "AtomicTag",
              "opcServer": opcSer
            },
            {
              "valueSource": "opc",
              "opcItemPath": "nsu=KEPServerEX;s=Coca-Cola."+plant+"."+wcType+"."+folderName+".PO.Sts_Held",
              "dataType": "String",
              "name": "Sts_Held",
              "tagType": "AtomicTag",
              "opcServer": opcSer
            },
            {
              "valueSource": "opc",
              "opcItemPath": "nsu=KEPServerEX;s=Coca-Cola."+plant+"."+wcType+"."+folderName+".PO.Sts_Aborted",
              "dataType": "String",
              "name": "Sts_Aborted",
              "tagType": "AtomicTag",
              "opcServer": opcSer
            },
            {
              "valueSource": "opc",
              "opcItemPath": "nsu=KEPServerEX;s=Coca-Cola."+plant+"."+wcType+"."+folderName+".PO.HMI_SetPONo",
              "dataType": "String",
              "name": "HMI_SetPONo",
              "tagType": "AtomicTag",
              "opcServer": opcSer
            },
            {
              "valueSource": "opc",
              "opcItemPath": "nsu=KEPServerEX;s=Coca-Cola."+plant+"."+wcType+"."+folderName+".PO.Sts_POState",
              "dataType": "String",
              "name": "Sts_POState",
              "tagType": "AtomicTag",
              "opcServer": opcSer
            },
            {
              "valueSource": "opc",
              "opcItemPath": "nsu=KEPServerEX;s=Coca-Cola."+plant+"."+wcType+"."+folderName+".PO.Sts_Cancelled",
              "dataType": "String",
              "name": "Sts_Cancelled",
              "tagType": "AtomicTag",
              "opcServer": opcSer
            },
            {
              "valueSource": "opc",
              "opcItemPath": "nsu=KEPServerEX;s=Coca-Cola."+plant+"."+wcType+"."+folderName+".PO.Cmd_StartPOExecution",
              "dataType": "String",
              "name": "Cmd_StartPOExecution",
              "tagType": "AtomicTag",
              "opcServer": opcSer
            },
            {
              "valueSource": "opc",
              "opcItemPath": "nsu=KEPServerEX;s=Coca-Cola."+plant+"."+wcType+"."+folderName+".PO.HMI_SetPhase",
              "dataType": "String",
              "name": "HMI_SetPhase",
              "tagType": "AtomicTag",
              "opcServer": opcSer
            },
            {
              "valueSource": "opc",
              "opcItemPath": "nsu=KEPServerEX;s=Coca-Cola."+plant+"."+wcType+"."+folderName+".PO.Cmd_Resume",
              "dataType": "String",
              "name": "Cmd_Resume",
              "tagType": "AtomicTag",
              "opcServer": opcSer
            },
            {
              "valueSource": "opc",
              "opcItemPath": "nsu=KEPServerEX;s=Coca-Cola."+plant+"."+wcType+"."+folderName+".PO.Cmd_Hold",
              "dataType": "String",
              "name": "Cmd_Hold",
              "tagType": "AtomicTag",
              "opcServer": opcSer
            },
            {
              "valueSource": "opc",
              "opcItemPath": "nsu=KEPServerEX;s=Coca-Cola."+plant+"."+wcType+"."+folderName+".PO.Sts_FirstGoodFill",
              "dataType": "String",
              "name": "Sts_FirstGoodFill",
              "tagType": "AtomicTag",
              "opcServer": opcSer
            },
            {
              "valueSource": "opc",
              "opcItemPath": "nsu=KEPServerEX;s=Coca-Cola."+plant+"."+wcType+"."+folderName+".PO.HMI_SetStsPhase",
              "dataType": "String",
              "name": "HMI_SetStsPhase",
              "tagType": "AtomicTag",
              "opcServer": opcSer
            },
            {
              "valueSource": "opc",
              "opcItemPath": "nsu=KEPServerEX;s=Coca-Cola."+plant+"."+wcType+"."+folderName+".PO.HMI_SetBatchNo",
              "dataType": "String",
              "name": "HMI_SetBatchNo",
              "tagType": "AtomicTag",
              "opcServer": opcSer
            },
            {
              "valueSource": "opc",
              "opcItemPath": "nsu=KEPServerEX;s=Coca-Cola."+plant+"."+wcType+"."+folderName+".PO.Sts_Phase",
              "dataType": "String",
              "name": "Sts_Phase",
              "tagType": "AtomicTag",
              "opcServer": opcSer
            }
          ]
        },
        {
          "name": "SpcWeight",
          "tagType": "Folder"
        },
        {
		  "name": "WIP",
		  "tagType": "Folder"
		}
      ]
    },
    {
      "name": "PO",
      "typeId": "UNS/PO",
      "parameters": {
        "TagReferencePath": {
          "dataType": "String",
          "value": tagProvider+"Coca-Cola/CPS/"+plant+"/"+wcType+"/"+folderName+"/Gateway_Devices/PO/"
        }
      },
      "tagType": "UdtInstance"
    },
    {
      "name": "SF_Equipment",
      "tagType": "Folder",
      "tags": [
        {
          "name": "Camera",
          "tagType": "Folder"
        },
        {
          "name": "Palletizer",
          "tagType": "Folder"
        },
        {
          "name": "Wrapper",
          "tagType": "Folder"
        },
        {
          "name": "Filler",
          "tagType": "Folder"
        },
        {
          "name": "BarcodeReader",
          "tagType": "Folder"
        },
		{
		  "name": "Checkweigher",
		  "tagType": "Folder",
		  "tags": [
		    {
		      "name": "Primary_Packaging",
		      "tagType": "Folder"
		    },
		    {
		      "name": "Secondary_Packaging",
		      "tagType": "Folder"
		    }
		  ]
		},
        {
          "name": "Scale",
          "tagType": "Folder"
        },
        {
          "name": "Conveyor",
          "tagType": "Folder"
        }
      ]
    },
    {
      "name": "MII_Posting",
      "tagType": "Folder"
    }
  ]
}
	
	#inside filler folder in SF_Equipmet
	WcConfiguration.creareUdtInstance(tagPath +'/'+folderName + '/SF_Equipment/Filler', "FillerRawData", "UNS/FillerRawData")
	WcConfiguration.creareUdtInstance(tagPath +'/'+folderName + '/SF_Equipment/Filler', "Header", "UNS/Filler")
	WcConfiguration.creareUdtInstance(tagPath +'/'+folderName + '/SF_Equipment/Filler', "Metering", "UNS/Metering")
	WcConfiguration.creareUdtInstance(tagPath +'/'+folderName + '/SF_Equipment/Filler', "SPC", "UNS/SPC")
	
	# insert into MII_Posting folder
	WcConfiguration.creareUdtInstance(tagPath +'/'+folderName + '/MII_Posting', "GoodIssuePosting", "UNS/GoodIssuePosting")
	WcConfiguration.creareUdtInstance(tagPath +'/'+folderName + '/MII_Posting', "MachineStatusPosting", "UNS/MachineStatusPosting")
	WcConfiguration.creareUdtInstance(tagPath +'/'+folderName + '/MII_Posting', "PhaseStatusPosting", "UNS/PhaseStatusPosting")
	WcConfiguration.creareUdtInstance(tagPath +'/'+folderName + '/MII_Posting', "ProductionReportPosting", "UNS/ProductionReportPosting")
	
	# create CIP udt istance inside work center folder
	WcConfiguration.creareUdtInstance(tagPath +'/'+folderName, "Metering", "UNS/Metering")
	
	# create CIP udt istance inside work center folder
	WcConfiguration.creareUdtInstance(tagPath +'/'+folderName, "CIP", "UNS/CIP")
	
	# create WIP's in workcenter
	WcConfiguration.creareUdtInstance(tagPath +'/'+folderName, "WIP", "UNS/WIP")
	        
	#add checweigherRawData UDT instance inside Primary_Packaging 
	WcConfiguration.creareUdtInstance(tagPath +'/'+ folderName + '/SF_Equipment/Checkweigher', "ChechweigherRawData", "UNS/ChechweigherRawData")
	
	#create workCenterConfiguration UDT
	WcConfiguration.creareUdtInstance(tagPath +'/'+folderName, "WorkCenterConfiguration", "UNS/WorkCenterConfiguration")
	
	
	system.tag.configure(basePath, tagFolder, 'o')
	
	
def createAutoPhaseCompletionTag(tagPath, deviceType):
	autoPhaseCompletionTag = {
	  "alarms": [
	    {
	      "setpointA": 1.0,
	      "name": "2010AutoPhaseCompletion",
	      "priority": "Critical",
	      "ackMode": "Unused",
	      "displayPath": {
	        "bindType": "Expression",
	        "value": "concat({[.]../../../WorkCenterConfiguration/workCenterName},\"--\",{[.]../../../PO/Header/processOrder}}"
	      }
	    }
	  ],
	  "name": "2010AutoPhaseCompletionAlert",
	  "value": 0,
	  "tagType": "AtomicTag"
	}
	
	phaseCompletionTrigger = {
	  "eventScripts": [
	    {
	      "eventid": "valueChanged",
	      "script": "\tif currentValue.value == 1 and previousValue.value == 0:\n\t\ttry:\n\t\t\tAutoPhaseCompletion = system.tag.readBlocking(\"[.]../../../WorkCenterConfiguration/EnableAutoPhaseCompletion\")[0].value\n\t\t\tTag_Provider = system.tag.readBlocking(\"[.]../../../../../../Site_Settings/General_Configuration/sfTagProvider\")[0].value\n\t\t\tMII_Ignition_Library.Logger.Insert_Log.Insert_Error_Log(\"Auto phase completion tag script\",\"Message 3\")\n\t\t\tAPI_Protocol = system.tag.readBlocking(\"[.]../../../../../../Site_Settings/MII_Configuration/miiApiProtocol\")[0].value\n\t\t\tAPI_Server = system.tag.readBlocking(\"[.]../../../../../../Site_Settings/MII_Configuration/miiApiServer\")[0].value\n\t\t\tSAP_Status = system.tag.readBlocking(\"[.]../../../../../../Site_Settings/MII_Configuration/sapStatus\")[0].value\n\t\t\tMII_Status = system.tag.readBlocking(\"[.]../../../../../../Site_Settings/MII_Configuration/miiStatus\")[0].value\n\t\t\tDB_Status = system.tag.readBlocking(\"[.]../../../../../../Site_Settings/dB_Configuration/ignitiondBStatus\")[0].value\n\t\t\tDatabase = system.tag.readBlocking(\"[.]../../../../../../Site_Settings/dB_Configuration/ignitiondB\")[0].value\n\t\t\tMII_Ignition_Library.Logger.Insert_Log.Insert_Error_Log(\"Auto phase completion tag script\",\"DB Status : \" + str(DB_Status))\n\t\t\tClient = system.tag.readBlocking(\"[.]../../../PO/Phase/pClient\")[0].value\n\t\t\tPlant = system.tag.readBlocking(\"[.]../../../PO/Phase/pPlant\")[0].value\n\t\t\tWork_Center = system.tag.readBlocking(\"[.]../../../WorkCenterConfiguration/workCenterName\")[0].value\n\t\t\tSAP_Resource_Name = system.tag.readBlocking(\"[.]../../../PO/Phase/pNodeName\")[0].value\n\t\t\tPO = system.tag.readBlocking(\"[.]../../../PO/Header/processOrder\")[0].value\n\t\t\tOperation = system.tag.readBlocking(\"[.]../../../PO/Phase/pOperation\")[0].value\n\t\t\tPhase = system.tag.readBlocking(\"[.]../../../PO/Phase/pPhase\")[0].value\n\t\t\tcurrentPhase = system.tag.readBlocking(\"[.]../../../PO/Phase/pMIIPHStatus\")[0].value\n\t\t\tPhaseStatus = \"CMPL\"\n\t\t\tNext_Status = \"ACT\"\n\t\t\tSLOC = \"\"\n\t\t\tEventTime = system.date.format(system.date.now(), \"yyyy-MM-dd HH:mm:ss\").replace(\" \",\"T\")\n\t\t\tMessage_ID = \"\" \n\t\t\tUser_ID = \"Auto\"\n\t\t\tArea = system.tag.readBlocking(\"[.]../../../PO/Phase/pArea\")[0].value\n\t\n\t\t\t#MII_Ignition_Library.Logger.Insert_Log.Insert_Error_Log(\"Auto phase completion tag script\",PhaseStatus + \" \" + Phase)\n\t\t\tif Phase == '2010' and (currentPhase == 'ACT' or currentPhase == 'RESUME'):\n\t\t\t\tpoExecution.AutoCompletion2010.autoCompletion(AutoPhaseCompletion, API_Protocol, API_Server, SAP_Status, MII_Status, DB_Status, Database, Client, Plant, Work_Center, SAP_Resource_Name, PO, Operation, Phase, PhaseStatus, Next_Status, SLOC, EventTime, Message_ID, User_ID, Area)\n\t\t\t\t#system.tag.writeBlocking(\"[.]../../../PO/Phase/pMIIPHStatus\", Next_Status)\n\t\t\telse:\n\t\t\t\tMII_Ignition_Library.Logger.Insert_Log.Insert_Error_Log(\"Auto phase completion tag script\",\"Not correct phase or phase status\")\n\t\texcept:\n\t\t\tMII_Ignition_Library.Logger.Insert_Log.Insert_Error_Log(\"Auto phase completion tag script\",str(sys.exc_info()))"
	    }
	  ],
	  "valueSource": "expr",
	  "expression": "{[.]CheckWeigher_"+deviceType+"_1/firstGoodFillSts}||{[.]CheckWeigher_"+deviceType+"_2/firstGoodFillSts}",
	  "name": "2010CompletionTrigger",
	  "tagType": "AtomicTag"
	}
	
	system.tag.configure(tagPath, autoPhaseCompletionTag)
	system.tag.configure(tagPath, phaseCompletionTrigger)
	
	

def addWorkCenterTags(tagProvider, plant, workCenterType, workCenter, devices):
	basePath = tagProvider + 'Coca-Cola/CPS/' + plant + '/'  + workCenterType
	#creating workcenter folder
	tagFolder = {'tagtype' : 'Folder',
					'name' : workCenter,
				}
	system.tag.configure(basePath, tagFolder, 'o')
	


#	creating udt instance as per devices
	tagPath = basePath + '/' + workCenter
	tags = []
	for device in devices:
		tag = {	"name" : device["deviceName"],
				"typeId" : "UNS/" + device["deviceType"],
				"tagType" : "UdtInstance",
				}
		tags.append(tag)
	print tags
	system.tag.configure(tagPath, tags)
	
	
	#adding values to udt tags of devices
	nameTagPath = []
	nameTagValue = []
	for device in dvices:
		nameTagPathList = tagPath + '/' + device["deviceName"] + '/' + 'Name'
		nameTagValueList = device["deviceName"]
		nameTagPath.append(nameTagPathList)
		nameTagValue.append(nameTagValueList)
	
	system.tag.writeBlocking(nameTagPath, nameTagValue)
	
	
	
def addWorkCenterUdts(tagProvider, workCenter, configurations):
	
	basePath = tagProvider + '_types_/'
	
	#creating workcenter UDTs
	tagFolder =	{'tagtype' : 'UdtType',
				 'name' : workCenter,
	}
	system.tag.configure(basePath, tagFolder, 'o')
	
	
	#creating udt instance as per workcenter
	tagPath = basePath + '/' + workCenter
	tags = []
	for configuration in configurations:
		tag = {
				"valueSource": "memory",
				"dataType": "String",
				"name": configuration,
				"tagType": "AtomicTag",
				"value": "null"
		}
		tags.append(tag)
	print tags
	system.tag.configure(tagPath, tags)
	
def addDeviceTags(tagPath ,deviceName,deviceType):
	tags = []	
	tag = {	"name" : deviceName,
				"typeId" : "UNS/" + deviceType,
				"tagType" : "UdtInstance",
				}
	tags.append(tag)

	print system.tag.configure(tagPath, tags,"o")
	
def deleteDevices(basePath, plant,workCenterType,workCenter,updatedDevices):
	devicepath  = basePath +'/'+ plant +'/'+ workCenterType +'/' + workCenter
	system.perspective.print(devicepath)
	equimentName ='SF_Equipment'
	system.perspective.print("len(devices)"+ str(len(updatedDevices)))
	
	params = {"workCenter":workCenter}
	wcId = system.db.runNamedQuery('WcConfiguration/getWorkCenterID', params)
	for i in range(0,len(updatedDevices)):
		if len(updatedDevices)!= 0:
			deviceType = updatedDevices[i]['deviceType']
			deviceName = updatedDevices[i]['deviceName']
			isDeleted = updatedDevices[i]['isDeleted']
			system.perspective.print(deviceType)
			### ADD Tags for Checkweigher  
			if deviceType=='CheckWeigher':
				
				if 'PP' in deviceName:			 	
				 	print deviceName	 	
				 	primarycwtagpath = devicepath +'/'+ equimentName +'/'+ deviceType + '/Primary_Packaging/' 			 		
				 	primaryCWexist = system.tag.exists(devicepath +'/'+ equimentName +'/'+ deviceType + '/Primary_Packaging/' + deviceName)
				 	
				 	#print primaryCWexist
				 	if primaryCWexist == True:
				 		if isDeleted == 1:
				 			dv_params = {"IsDeleted": 1, "wc":workCenter,"deviceName":deviceName}
							system.db.runNamedQuery("WcConfiguration/deleteDevices", dv_params)
							params = {"deviceName":deviceName, "wcId":wcId}
							deviceExistInScale = system.db.runNamedQuery("WcConfiguration/deviceExist", params)
							if deviceExistInScale != None or deviceExistInScale != '':
								params = {'workCenter':'', 'deviceId':'', 'scaleId':deviceExistInScale}
								system.db.runNamedQuery('MovableScaleAssignment/updateScale', params )
					 		system.tag.deleteTags([devicepath +'/'+ equimentName +'/'+ deviceType + '/Primary_Packaging/' + deviceName])
					 		system.tag.deleteTags([devicepath + '/Gateway_Devices/SpcWeight/'+deviceName])
				 			system.perspective.print('okay')
				 		
				 	else:
						continue

				elif 'SP' in deviceName:			 	
				 	print deviceName						 	
				 	secondarycwtagpath = devicepath +'/'+ equimentName +'/'+ deviceType + '/Secondary_Packaging/' 
				 	secondaryCWexist = system.tag.exists(devicepath +'/'+ equimentName +'/'+ deviceType + '/Secondary_Packaging/' + deviceName)
				 	
				 	if secondaryCWexist == True:
				 		if isDeleted == 1:
			 				dv_params = {"IsDeleted": 1, "wc":workCenter,"deviceName":deviceName}
							system.db.runNamedQuery("WcConfiguration/deleteDevices", dv_params)
							params = {"deviceName":deviceName, "wcId":wcId}
							deviceExistInScale = system.db.runNamedQuery("WcConfiguration/deviceExist", params)
							if deviceExistInScale != None or deviceExistInScale != '':
								params = {'workCenter':'', 'deviceId':'', 'scaleId':deviceExistInScale}
								system.db.runNamedQuery('MovableScaleAssignment/updateScale', params )
				 			system.tag.deleteTags([devicepath +'/'+ equimentName +'/'+ deviceType + '/Secondary_Packaging/' + deviceName])
				 			system.tag.deleteTags([devicepath + '/Gateway_Devices/SpcWeight/'+deviceName])
				 		
				 	else:
						continue
			elif deviceType=='FillerHead':
				 	deviceTagpath =  devicepath +'/'+ equimentName +'/Filler'
				 	deviceTagExist = system.tag.exists(devicepath +'/'+ equimentName +'/Filler/' + deviceName)
				 	
				 	if deviceTagExist == True:
				 		if isDeleted == 1:
			 				dv_params = {"IsDeleted": 1, "wc":workCenter,"deviceName":deviceName}
							system.db.runNamedQuery("WcConfiguration/deleteDevices", dv_params)
							params = {"deviceName":deviceName, "wcId":wcId}
							deviceExistInScale = system.db.runNamedQuery("WcConfiguration/deviceExist", params)
							if deviceExistInScale != None or deviceExistInScale != '':
								params = {'workCenter':'', 'deviceId':'', 'scaleId':deviceExistInScale}
								system.db.runNamedQuery('MovableScaleAssignment/updateScale', params )
				 			system.tag.deleteTags([devicepath +'/'+ equimentName +'/Filler/' + deviceName])
				 			system.tag.deleteTags([devicepath + '/Gateway_Devices/SpcWeight/'+ deviceName])
				 		
				 	else:
						continue

			else :
			  	devicetagPath = devicepath +'/'+ equimentName +'/'+ deviceType
			  	system.perspective.print(devicetagPath)
			  	
			  	tagPathexist = system.tag.exists(devicepath +'/'+ equimentName +'/'+ deviceType +'/' + deviceName)		  	
			  	system.perspective.print("tagPathexist" +str(tagPathexist))
			  	
			  	
			  	if tagPathexist == True:
			  		if isDeleted == 1:
			  			system.perspective.print("isDelete 1")
			  			dv_params = {"IsDeleted": 1, "wc":workCenter,"deviceName":deviceName}
						system.db.runNamedQuery("WcConfiguration/deleteDevices", dv_params)
						system.perspective.print("delete NQ RUn")
						system.tag.deleteTags([devicepath +'/'+ equimentName +'/'+ deviceType +'/' + deviceName])
						system.tag.deleteTags([devicepath + '/Gateway_Devices/SpcWeight/'+deviceName])
						system.perspective.print("deleted")
			  		
			  	else:
			  		continue


def addWcConfigutationInTags(tagProvider, plant, workCenterType, workCenter, functions, wcDes):
	basePath = tagProvider + 'Coca-Cola/CPS/' + plant + '/'  + workCenterType
	tagPath = basePath + '/' + workCenter
	tags = []
	tag = {	"name" : 'WorkCenterConfiguration',
			"typeId" : 'UNS/WorkCenterConfiguration',
			"tagType" : "UdtInstance",
			}
	tags.append(tag)
	system.tag.configure(tagPath, tags)
	for function in functions:
		if function['label'] == 'Enable Auto GI':
			enableAutoGI = function['value']
		elif function['label'] == 'Enable Auto Phase Completion':
			enableAutoPhaseCompletion = function['value']
		elif function['label'] == 'Enable Auto PR':
			enableAutoPR = function['value']
		elif function['label'] == 'Enable BBD':
			enableBBD = function['value']
		elif function['label'] == 'Enable Full Split':
			enableFullSplit = function['value']
		elif function['label'] == 'Enable Partial Split':
			enablePartialSplit = function['value']
		elif function['label'] == 'Enable Partial Confirmation':
			enablePartialConfirmation = function['value']
		elif function['label'] == 'Enable Material Management':
			enableMaterialManagement = function['value']
		elif function['label'] == 'Enable Scrap Reason':
			enableScrapReason = function['value']
		elif function['label'] == 'Enable Skip BBD':
			enableSkipBBD = function['value']
		elif function['label'] == 'Enable Stock Validation':
			enableStockValidation = function['value']
		elif function['label'] == 'Enable Barcode Validation':
			enableBarcodeValidation = function['value']
		elif function['label'] == 'Partial Confirmation Frequency':
			partialConfirmationFreq = function['value']	
			params={"ID":function['unit']}
			uom=system.db.runNamedQuery('WcConfiguration/getCapacityUnitsID', params)
			partialConfirmationFreqUOM = uom
		elif function['label']=='Enable Barcode Validation Pre-POExecution':
			enableBarcodeValidationPrePOExecution = function['value']
		elif function['label']=='Enable Barcode Validation Post-POExecution':
			enableBarcodeValidationPostPOExecution = function['value']
		elif function['label']=='Enable View Scales':
			enableViewScales = function['value']
		elif function['label']=='Enable Manual Filling':
			enableManualFilling = function['value']
		elif function['label']=='Enable BBD Validation':
			enableBBDValidation = function['value']
		elif function['label'] =='Enable Batch Verfication Pre-POExecution':
			enableBatchVerificationPrePOExecution = function['value']
			
	basePath = tagProvider+'Coca-Cola/CPS/'+plant+'/'+workCenterType+'/'+workCenter+'/WorkCenterConfiguration/'
	path = basePath + 'enableAutoGI'
	path1 = basePath + 'enableAutoPhaseCompletion'
	path2 = basePath + 'enableAutoPR'
	path3 = basePath + 'enableBBD'
	path4 = basePath + 'enableFullSplit'
	path5 = basePath + 'enableMaterialManagement'
	path6 = basePath + 'enablePartialConfirmation'
	path7 = basePath + 'enablePartialSplit'
	path8 = basePath + 'enableScrapReason'
	path9 = basePath + 'enableSkipBBD'
	path10 = basePath + 'enableStockValidation'
	path11 = basePath + 'enableBarcodeValidation'
	path12 = basePath + 'partialConfirmationFrequency'
	path13 = basePath + 'workCenterName'
	path14 = basePath + 'Parameters.TagProvider'
	path15 = basePath + 'areaDescription'
	path16=  basePath + 'enableBarcodeValidationPrePOExecution'
	path17=  basePath + 'enableBarcodeValidationPostPOExecution'
	path18 = basePath + 'enableViewScales'
	path19 = basePath + 'enableManualFilling'
	path20 = basePath + 'partialConfirmationFrequencyUOM'
	path21 = basePath + 'enableBBDValidation'
	path22 = basePath + 'enableBatchVerificationPrePOExecution'
	nameTagPath = [path, path1, path2, path3, path4, path5, path6, path7, path8, path9, path10, path11, path12, path13, path14, path15,path16,path17,path18,path19,path20,path21,path22]
	nameTagValue = [enableAutoGI, enableAutoPhaseCompletion,  enableAutoPR, enableBBD, enableFullSplit,enableMaterialManagement,enablePartialConfirmation, enablePartialSplit,enableScrapReason, enableSkipBBD, enableStockValidation, enableBarcodeValidation, partialConfirmationFreq, workCenter, tagProvider, wcDes,enableBarcodeValidationPrePOExecution,enableBarcodeValidationPostPOExecution,enableViewScales,enableManualFilling,partialConfirmationFreqUOM,enableBBDValidation,enableBatchVerificationPrePOExecution]
	
	system.tag.writeBlocking(nameTagPath, nameTagValue)

	
	
	
def updateDbDevices(database, workCenter, capacityMin,capacityMax, resolution,  uomId, deviceName):
	namedQuery = 'WcConfiguration/updateDbDevices'
	params = {'database':database, 'wc':workCenter, 'capacityMin':capacityMin, 'capacityMax':capacityMax, 'resolution':resolution,'uomId':uomId, 'deviceName':deviceName}
	system.db.runNamedQuery(namedQuery, params)
	

def insertWorkCenter(database, workCenter, wcType, description, area):
	params = {"database": database, "workCenter": workCenter, "wcType": wcType, "description": description, "area":area,"isConfig":1}
	system.db.runNamedQuery('WcConfiguration/insertWc', params)
	
def workCenterExist(database, workCenter):
	params = {"database": database, "workCenter": workCenter}
	system.db.runNamedQuery('WcConfiguration/wcExist', params)
	
	
def updateMultipleDbDevices(database, workCenter, updatedDevices):
	for i in range(0,len(updatedDevices)):
		if len(updatedDevices)!= 0:
			deviceType = updatedDevices[i]['deviceType']
			deviceName = updatedDevices[i]['deviceName']
			capacityMin = updatedDevices[i]['min']
			capacityMax = updatedDevices[i]['max']
			resolution = updatedDevices[i]['resolution']
			uomId = updatedDevices[i]['deviceCapacityUnit']
			priOrSec = updatedDevices[i]['priOrSec']
			fixOrManual = updatedDevices[i]['fixedOrManual']
			usbOrGateway = updatedDevices[i]['usbOrGateway']
	
			namedQuery = 'WcConfiguration/updateDbDevices'
			params = {'database':database, 'wc':workCenter, 'capacityMin':capacityMin, 'capacityMax':capacityMax, 'resolution':resolution,'uomId':uomId, 'deviceName':deviceName}
			print params
			system.db.runNamedQuery(namedQuery, params)
			
			
def createSiteSettingFolder(basePath, folderName):
	#create wc type/ plant folder (basePath, wctype)
	#creating workcenter folder
	tagFolder ={
  "name": "Site_Settings",
  "tagType": "Folder",
  "tags": [
    {
      "name": "MII_Configuration",
      "tagType": "Folder",
      "tags": [
        {
          "valueSource": "memory",
          "dataType": "String",
          "name": "miiApiProtocol",
          "value": "",
          "tagType": "AtomicTag"
        },
        {
          "valueSource": "memory",
          "dataType": "String",
          "name": "miiApiServer",
          "value": "",
          "tagType": "AtomicTag"
        },
        {
          "valueSource": "memory",
          "dataType": "Int4",
          "name": "sapStatus",
          "value": "",
          "tagType": "AtomicTag"
        },
        {
          "valueSource": "memory",
          "dataType": "Int4",
          "name": "miiStatus",
          "value": "",
          "tagType": "AtomicTag"
        },
        {
          "valueSource": "memory",
          "dataType": "String",
          "name": "miiTime",
          "tagType": "AtomicTag"
        }
      ]
    },
    {
      "name": "Plant_Configuration",
      "tagType": "Folder",
      "tags": [
        {
          "valueSource": "memory",
          "dataType": "String",
          "name": "client",
          "value": "",
          "tagType": "AtomicTag"
        },
        {
          "valueSource": "memory",
          "dataType": "String",
          "name": "cpsLocation",
          "value": "",
          "tagType": "AtomicTag"
        },
        {
          "valueSource": "memory",
          "dataType": "String",
          "name": "plantName",
          "value": "",
          "tagType": "AtomicTag"
        },
        {
          "valueSource": "memory",
          "dataType": "String",
          "name": "plant",
          "value": "",
          "tagType": "AtomicTag"
        }
      ]
    },
    {
      "name": "General_Configuration",
      "tagType": "Folder",
      "tags": [
        {
          "valueSource": "memory",
          "dataType": "String",
          "name": "sfTagProviderRemote03",
          "tagType": "AtomicTag"
        },
        {
          "valueSource": "memory",
          "name": "defaultDaysForPoData",
          "value": "",
          "tagType": "AtomicTag"
        },
        {
          "valueSource": "memory",
          "dataType": "String",
          "name": "sfTagProvider",
          "value": "",
          "tagType": "AtomicTag"
        },
        {
          "valueSource": "memory",
          "dataType": "String",
          "name": "sfTagProviderRemote01",
          "tagType": "AtomicTag"
        },
        {
          "valueSource": "memory",
          "dataType": "String",
          "name": "sfTagProviderRemote02",
          "tagType": "AtomicTag"
        },
        {
          "valueSource": "memory",
          "name": "bbdBackDateDays",
          "value": "",
          "tagType": "AtomicTag"
        },
        {
          "valueSource": "memory",
          "name": "apiTimeoutDuration",
          "value": "",
          "tagType": "AtomicTag"
        }
      ]
    },
    {
      "name": "dB_Configuration",
      "tagType": "Folder",
      "tags": [
        {
          "valueSource": "memory",
          "dataType": "String",
          "name": "ignitiondB",
          "value": "",
          "tagType": "AtomicTag"
        },
        {
          "valueSource": "memory",
          "dataType": "Int4",
          "name": "ignitiondBStatus",
          "value": "",
          "tagType": "AtomicTag"
        }
      ]
    },
    {
      "name": "CIP_Configuration",
      "tagType": "Folder",
      "tags": [
        {
          "valueSource": "memory",
          "dataType": "String",
          "name": "cipApiProtocol",
          "tagType": "AtomicTag"
        },
        {
          "valueSource": "memory",
          "dataType": "String",
          "name": "cipApiServer",
          "tagType": "AtomicTag"
        }
      ]
    }
  ]
}
	system.tag.configure(basePath, tagFolder, 'o')
	
	
	
def createSPCWeightDeviceTag(basePath, folderName):
	opcSer = system.opc.getServers(includeDisabled = True)[0]

	udtInstance = {	"name" : folderName,
		"typeId" : "UNS/SpcRawData",
		"tagType" : "UdtInstance",
		}

	system.tag.configure(basePath, udtInstance)

	
	