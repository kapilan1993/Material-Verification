def printDataSet(datasetIn):
    from itertools import izip
    import ast
    if 'PropertyTreeScriptWrapper$ArrayWrapper' in str(type(datasetIn)):
        headers = datasetIn[0].keys()
        data = []
        for row in datasetIn:
            data.append([item.value for item in row.values()])
        
        datasetIn = system.dataset.toDataSet(headers, data)
        
    # Get Row and Column counts
    nrows = datasetIn.getRowCount()
    ncols = datasetIn.getColumnCount()
                                    
    # Get max length of row labels
    rowLen = len(max(['row']+[unicode(i) for i in range(nrows)], key=len))
    # Get column names
    colNames = datasetIn.getColumnNames()
    # initialize lists to process columns
    headerList = []
    colData = []
    maxLen = []
    # Process columns
    for i, col in izip(range(ncols), colNames):
        # Get column as list, converting all elemenst to unicode strings
        colIn = ([unicode(element) for element in list(datasetIn.getColumnAsList(i))])
        # Get max lentgh of the column, including the column name
        maxLen = len(max([col]+colIn, key=len))
        # Append data as left justified strings.
        # ljust() will automatically pad to the max string length
        colData.append([element.ljust(maxLen) for element in colIn])
        # Append column name, also using the max string length
        headerList.append(col.ljust(maxLen))
    # Concatenate the header string and print it.
    headerString= 'row'.ljust(rowLen) + ' | ' + ' | '.join(headerList)
    
    print headerString
    # Print a bunch of dashes the same length as the header string
    print'-' * len(headerString)
    # Print the rows
    for row in enumerate(izip(*colData)):
        print unicode(row[0]).ljust(rowLen) + ' | ' + ' | '.join(row[1])
    print '-' * len(headerString)
        # Print
        
def dictToDataset1(dict, listName):
	header = []
	data = [] 	
	for my_list in listName:
		if my_list in dict[0].keys():
			header.append(my_list)
	for value in dict:
		row = []
		for head in header: 
			row.append(value[head])
		data.append(row)
	return system.dataset.toDataSet(header,data)

def dictToDataset(dict):
	data = [] 	
	columns = dict[0].keys()
	for value in dict:
		row = []
		for column in columns: 
			row.append(value[column])
		data.append(row)
	return system.dataset.toDataSet(columns,data)
			
			
def tableform(po):
	path = "POExecution/xMII_Data"
	params = {"PO" : po, "CLIENT": "010", "PLANT": "5040", "database" : "GlobalTemplateDB"}
	MII_DATA = system.db.runNamedQuery(path, params)
	json = system.util.jsonDecode(MII_DATA)
	PoHeader = json["DOWNLOAD_RECIPE"]["PO_HEADER"]["Rowsets"]["Rowset"]["Row"]
	PoHeaderPhases = json["DOWNLOAD_RECIPE"]["PO_HEADER_PHASES"]["Rowsets"]["Rowset"]["Row"]
	PoPhasesResb = json["DOWNLOAD_RECIPE"]["PO_PHASES_RESB"]["Rowsets"]["Rowset"]["Row"]
	PoPriPackTol = json["DOWNLOAD_RECIPE"]["PRI_PACK_TOL"]["Rowsets"]["Rowset"]["Row"]
	ResbList = ["RSNUM","MATNR","MATNR_DESC","MATNR_HLVL","CHARG","BDMNG","MTART","ING_TARGET","ING_TARGET_UL","ING_TARGET_LL","LGORT"]
	print "PO_HEADER"
	print printDataSet(dictToDataset([PoHeader]))
	print "PO_HEADER_PHASES"
	print printDataSet(dictToDataset(PoHeaderPhases))
	print "PO_PHASES_RESB"
	print printDataSet(dictToDataset1(PoPhasesResb, ResbList))
	print "PRI_PACK_TOL"
	try:
		print printDataSet(dictToDataset(PoPriPackTol))
	except:
		print printDataSet(dictToDataset([PoPriPackTol]))
#	return PoPhasesResb
