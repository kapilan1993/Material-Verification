def AddScale(scaleName,  serialNo, ip , scaleMin , scaleMax, scaleResolution, uomId, updateBy, wcId ):
	#Add Scale into the database
	NamedQuery = 'ScaleOnboading/insertScale'
	Parameter = {"scaleName" :scaleName,  "serialNo" :serialNo,  "ip":ip , "scaleMin" :scaleMin , "scaleMax":scaleMax , "scaleResolution":scaleResolution, "uomId" :uomId,"updateBy":updateBy,  "wcId":wcId }
	system.db.runNamedQuery(NamedQuery,Parameter)
	
def AddMovableScaleTags(tagProvider, scaleName, scaleMax, scaleMin, scaleResolution,ip,serialNo):
	try:
		#create udt of entered scale
		TagPath = tagProvider+'Coca-Cola/CPS/MovableScale'
		tag = {
			  "name": scaleName,
			  "typeId": "MovableScale",
			  "tagType": "UdtInstance",
				}
		system.tag.configure(TagPath, tag)
	except:
		MII_Ignition_Library.Logger.Insert_Log.Insert_Error_Log('ScaleUDT', str(sys.exc_info()))
	
	try:
		#Inserting values in UDT Instance
		tagPathLst = []
		tagPath = tagProvider + 'Coca-Cola/CPS/MovableScale/'+scaleName
		tags = system.tag.browse(tagPath)
		for idx in tags:
			tagPath =  idx['fullPath'] 
			tagPathLst.append(str(tagPath))
		tagValuesLst = [ip, scaleMax,scaleMin,scaleResolution,serialNo]
		system.tag.writeBlocking(tagPathLst, tagValuesLst)
	except:
		MII_Ignition_Library.Logger.Insert_Log.Insert_Error_Log('ScaleUDTInstance', str(sys.exc_info()))
	
def UpdateMovableScale(database, scaleName,  serialNo, ip , scaleMin , scaleMax, scaleResolution, uomId, updateBy ):
	NamedQuery = 'ScaleOnboading/updateMovableScale'
	Parameter = {"database":database, "scaleName" :scaleName,  "serialNo" :serialNo,  "ip":ip , "scaleMin" :scaleMin , "scaleMax":scaleMax , "scaleResolution":scaleResolution, "uomId" :uomId,"updateBy":updateBy}
	system.db.runNamedQuery(NamedQuery,Parameter)

	