##### Stock validation
Server = 'inpnqmiit'
SAP_CLIENT = '010'
SAP_PLANT = '0384'
WAREHOUSE_NUMBER = '384'
IV_SUPPLY_AREA = 'DF03'
PROCESS_ORDER = '000100042508'
MATERIAL_NUMBER = '1776331'
STORAGE_LOCATION = '0010'
IV_WITH_CONSUMED = ''
IV_LOGSYS = ''
IV_HU_EXID = 'DP01'
IV_HU_EXID_TYPE = '500'
MIIIgnitionLibrary.InventoryData.Inventory.Get_Batch_List_For_Material(Server, SAP_CLIENT, SAP_PLANT, WAREHOUSE_NUMBER, IV_SUPPLY_AREA, PROCESS_ORDER, MATERIAL_NUMBER, STORAGE_LOCATION, IV_WITH_CONSUMED, IV_LOGSYS, IV_HU_EXID, IV_HU_EXID_TYPE)

##inventory
Server='inpnqmiit'
endpoint  ='http://' + str(Server) + '/PR-CID/ShopFloor/MII_Data_Collection_Messages/api/MIIDataCollectionMessages/GET_SAP_MII_MPM_CPS_S4MfgGetBatchListForMaterial?'
	#endpoint  = miiurl + inventorycheckurl     #"http://idbogmiiappprod.apac.ko.com/PR-CID/ShopFloor/MII_Data_Collection_Messages/api/MIIDataCollectionMessages/GET_SAP_MII_MPM_CPS_S4MfgGetBatchListForMaterial?"
SAP_CLIENT = '010'
SAP_PLANT ='0384'
MaterialNumber='1776331'
WAREHOUSENUMBER = "384"
#PROCESS_ORDER = system.tag.read ('[default]CPS_INDONESIA/'+WorkCenter+'_CHOSEN/PO')
PROCESS_ORDER = ""
path = "SAP_CLIENT=" + SAP_CLIENT +\
			"&SAP_PLANT=" + SAP_PLANT +\
			"&WAREHOUSE_NUMBER=" + WAREHOUSENUMBER +\
			"&IV_SUPPLY_AREA="+\
			"&PROCESS_ORDER="+PROCESS_ORDER+\
			"&MATERIAL_NUMBER="+MaterialNumber+\
			"&STORAGE_LOCATION="+\
			"&IV_WITH_CONSUMED="+\
			"&IV_LOGSYS="+\
			"&IV_HU_EXID="+\
			"&IV_HU_EXID_TYPE=500" +\
			"jSon=True"
			
url = endpoint +path
	

connectTimeout = 5000
readTimeout = 10000	
response = system.net.httpGet(url,connectTimeout,readTimeout)
responseJson = system.util.jsonDecode(response)
						
#status = responseJson["Rowset"]["Row"][0]["status"]
#message = responseJson["Rowset"]["Row"][0]["Message"]
print responseJson