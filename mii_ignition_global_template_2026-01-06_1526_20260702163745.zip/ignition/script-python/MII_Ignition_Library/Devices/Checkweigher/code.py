def Checkweigher_Write_Start(Tag_Provider, Client, Plant, PO, Resource, Resource_Description, Material, Material_Description, Batch_Number, Area_Description):
 
 	try:
 
 		#Local Parameters
 		Area = ''						   #Area: Used to determine resource area prefix.
 
 		#Verify Resource Area Prefix
  		Status,ReturnVal = MII_Ignition_Library.ToolsSet.Tools.GetArea(Client,Plant,Resource,Area_Description)
  						
 		if Status != "Success.":
 			return Status
 		else:
 			Area = ReturnVal
 		
 		
 		### Search for available Checkweighers ###
 		Primary_Packaging_Path = Tag_Provider + "Coca-Cola/CPS/" + Plant + "/" + Area + "/" + Resource + "/SF_Equipment/Checkweigher/Primary_Packaging"
 		Secundary_Packaging_Path = Tag_Provider + "Coca-Cola/CPS/" + Plant + "/" + Area + "/" + Resource + "/SF_Equipment/Checkweigher/Secundary_Packaging"
 		
 		tag_info = []
 		
 		
 		# Define paths to browse
 		paths = [Primary_Packaging_Path,Secundary_Packaging_Path]
 		
 		# Empty list to store combined results
 		combined_results = []
 		
 		# Loop through each path and browse tags
 		for path in paths:
 		    results = system.tag.browse(path, filter={'name':'*Checkweigher*'})
 		    combined_results.extend(results.getResults())
 		
 		# Empty list to store tag info
 		tag_info = []
 		
 		for result in combined_results:
 		
 			#Verify Checkweigher Write Tag Exists
	 		if MII_Ignition_Library.Validation.Verify_Tag_Existence.Tag_Existence_Non_Report(str(result['fullPath']) + "/writeCommand") == True:
	 			
	 			#Verify if Checkweigher Enabler Tag Exists
	 			if MII_Ignition_Library.Validation.Verify_Tag_Existence.Tag_Existence_Report(str(result['fullPath']) + "/enabled", Client + "_" + Plant + "_" + "Filling_Checkweighers_Module", "Error: Tag Path " + str(result['fullPath']) + "/enabled" + " does not exist.") == True:
	 			
	 				#Verify Checkweigher is enabled
	 				if system.tag.read(str(result['fullPath']) + "/enabled").value == True:
	 				
	 					#Verify if Checkweigher Connected Tag Exists
	 					if MII_Ignition_Library.Validation.Verify_Tag_Existence.Tag_Existence_Report(str(result['fullPath']) + "/isConnected", Client + "_" + Plant + "_" + "Filling_Checkweighers_Module", "Error: Tag Path " + str(result['fullPath']) + "/isConnected" + " does not exist.") == True:
	 					
	 						#Verify if Checkweigher is Connected
	 						if system.tag.read(str(result['fullPath']) + "/isConnected").value == True:
	 							
	 							
	 							
	 							#Send Start command to Checkweigher
	 							Start_Response = system.tag.writeBlocking(str(result['fullPath']) + "/writeCommand","WD_START\r\n")
	 							if str(Start_Response[0]) != 'Good':
	 								MII_Ignition_Library.Logger.Insert_Log.Insert_Error_Log(Client + "_" + Plant + "_" + "Filling_Checkweighers_Module", "Error: An error ocurred while trying to Start " + str(result['name']) + " " + str(result['fullPath']) + "/writeCommand" + " " + str(Start_Response[0]))
	 								return "Error: An error ocurred while trying to Start " + str(result['name']) + " " + str(result['fullPath']) + "/writeCommand" + " " + str(Start_Response[0])
	 						
	 							else: #Checkweigher Start was written succesffuly
	 								None #return "Success."
	 								
	 						     
	 							
	 						else: #Checkweigher is not Connected
	 							MII_Ignition_Library.Logger.Insert_Log.Insert_Error_Log(Client + "_" + Plant + "_" + "Filling_Checkweighers_Module", "Error: " + Resource + " " + Resource_Description + " " + str(result['name']) + " is not connected.")
	 							return "Error: " + Resource + " " + Resource_Description + " " + str(result['name']) + " is not connected."
	 			
	 					else: #Checkweigher Connected Tag does not exist.
	 						MII_Ignition_Library.Logger.Insert_Log.Insert_Error_Log(Client + "_" + Plant + "_" + "Filling_Checkweighers_Module", "Error: Tag Path " + str(result['fullPath']) + "/isConnected" + " does not exist.")
	 						return "Error: Tag Path " + str(result['fullPath']) + "/isConnected" + " does not exist."
	 				else: #Checkweigher is not enabled.
	 					None #return "Success."
	 			else: #Checkweigher enabled tag does not exist.
	 				MII_Ignition_Library.Logger.Insert_Log.Insert_Error_Log(Client + "_" + Plant + "_" + "Filling_Checkweighers_Module", "Error: Tag Path " + str(result['fullPath']) + "/enabled" + " does not exist.")
	 				return "Error: Tag Path " + str(result['fullPath']) + "/enabled" + " does not exist."		
	 		else: #Checkweigher Write Tag does not exist.
	 			None
	 			
 		
 
 		
 		#Script executed succesffuly
 		return "Success."
 	
 	except Exception as e:
 			Status = e
 			return Status
 			MII_Ignition_Library.Logger.Insert_Log.Insert_Error_Log(Status)	
 	#except:
 	 	#MII_Ignition_Library.Logger.Insert_Log.Insert_Error_Log(Client + "_" + Plant + "_" + "Filling_Checkweighers_Module", "Error: MII_Ignition_Library.Devices.Checkweigher.Checkweigher_Write_Start has failed. Check log for details. Resource: " + Resource_Description)
 		#return "Error: MII_Ignition_Library.Devices.Checkweigher.Checkweigher_Write_Start has failed. Check log for details. Resource: " + Resource_Description
 	 
  
  
  
  
  
  
def Checkweigher_Write_Stop(Tag_Provider, Client, Plant, PO, Resource, Resource_Description, Material, Material_Description, Batch_Number, Area_Description):
  
  	try:
  
  		#Local Parameters
  		Area = ''						   #Area: Used to determine resource area prefix.
  		
  		#Verify Resource Area Prefix	
  		Status,ReturnVal = MII_Ignition_Library.ToolsSet.Tools.GetArea(Client,Plant,Resource,Area_Description)
  						
 		if Status != "Success.":
 			return Status
 		else:
 			Area = ReturnVal
  		
  		
  		### Search for available Checkweighers ###
 		Primary_Packaging_Path = Tag_Provider + "Coca-Cola/CPS/" + Plant + "/" + Area + "/" + Resource + "/SF_Equipment/Checkweigher/Primary_Packaging"
 		Secundary_Packaging_Path = Tag_Provider + "Coca-Cola/CPS/" + Plant + "/" + Area + "/" + Resource + "/SF_Equipment/Checkweigher/Secundary_Packaging"
 		
 		tag_info = []
 		
 		
 		# Define paths to browse
 		paths = [Primary_Packaging_Path,Secundary_Packaging_Path]
 		
 		# Empty list to store combined results
 		combined_results = []
 		
 		# Loop through each path and browse tags
 		for path in paths:
 		    results = system.tag.browse(path, filter={'name':'*Checkweigher*'})
 		    combined_results.extend(results.getResults())
 		
 		# Empty list to store tag info
 		tag_info = []
 		
 		for result in combined_results:
 		
 			#Verify Checkweigher Write Tag Exists
	 		if MII_Ignition_Library.Validation.Verify_Tag_Existence.Tag_Existence_Non_Report(str(result['fullPath']) + "/writeCommand") == True:
	 			
	 			#Verify if Checkweigher Enabler Tag Exists
	 			if MII_Ignition_Library.Validation.Verify_Tag_Existence.Tag_Existence_Report(str(result['fullPath']) + "/enabled", Client + "_" + Plant + "_" + "Filling_Checkweighers_Module", "Error: Tag Path " + str(result['fullPath']) + "/enabled" + " does not exist.") == True:
	 			
	 				#Verify Checkweigher is enabled
	 				if system.tag.read(str(result['fullPath']) + "/enabled").value == True:
	 				
	 					#Verify if Checkweigher Connected Tag Exists
	 					if MII_Ignition_Library.Validation.Verify_Tag_Existence.Tag_Existence_Report(str(result['fullPath']) + "/isConnected", Client + "_" + Plant + "_" + "Filling_Checkweighers_Module", "Error: Tag Path " + str(result['fullPath']) + "/isConnected" + " does not exist.") == True:
	 					
	 						#Verify if Checkweigher is Connected
	 						if system.tag.read(str(result['fullPath']) + "/isConnected").value == True:
	 							
	 							
	 							
	 							#Send Stop command to Checkweigher
	 							Stop_Response = system.tag.writeBlocking(str(result['fullPath']) + "/writeCommand","WD_STOP\r\n")
	 							if str(Stop_Response[0]) != 'Good':
	 								MII_Ignition_Library.Logger.Insert_Log.Insert_Error_Log(Client + "_" + Plant + "_" + "Filling_Checkweighers_Module", "Error: An error ocurred while trying to Stop " + str(result['name']) + " " + str(result['fullPath']) + "/writeCommand" + " " + str(Stop_Response[0]))
	 								return "Error: An error ocurred while trying to Stop " + str(result['name']) + " " + str(result['fullPath']) + "/writeCommand" + " " + str(Stop_Response[0])
	 						
	 							else: #Checkweigher Stop was written succesffuly
	 								None #return "Success."
	 								
	 						     
	 							
	 						else: #Checkweigher is not Connected
	 							MII_Ignition_Library.Logger.Insert_Log.Insert_Error_Log(Client + "_" + Plant + "_" + "Filling_Checkweighers_Module", "Error: " + Resource + " " + Resource_Description + " " + str(result['name']) + " is not connected.")
	 							return "Error: " + Resource + " " + Resource_Description + " " + str(result['name']) + " is not connected."
	 			
	 					else: #Checkweigher Connected Tag does not exist.
	 						MII_Ignition_Library.Logger.Insert_Log.Insert_Error_Log(Client + "_" + Plant + "_" + "Filling_Checkweighers_Module", "Error: Tag Path " + str(result['fullPath']) + "/isConnected" + " does not exist.")
	 						return "Error: Tag Path " + str(result['fullPath']) + "/isConnected" + " does not exist."
	 				else: #Checkweigher is not enabled.
	 					None #return "Success."
	 			else: #Checkweigher enabled tag does not exist.
	 				MII_Ignition_Library.Logger.Insert_Log.Insert_Error_Log(Client + "_" + Plant + "_" + "Filling_Checkweighers_Module", "Error: Tag Path " + str(result['fullPath']) + "/enabled" + " does not exist.")
	 				return "Error: Tag Path " + str(result['fullPath']) + "/enabled" + " does not exist."		
	 		else: #Checkweigher Write Tag does not exist.
	 			None
  		
  		
  		
  		#Script executed succesffuly
  		return "Success."
  	
  	except Exception as e:
		Status = e
		return Status
		MII_Ignition_Library.Logger.Insert_Log.Insert_Error_Log(Status)		
  	#except:
  	 	#MII_Ignition_Library.Logger.Insert_Log.Insert_Error_Log(Client + "_" + Plant + "_" + "Filling_Checkweighers_Module", "Error: MII_Ignition_Library.Devices.Checkweigher.Checkweigher_Write_Stop has failed. Check log for details. Resource: " + Resource_Description)
  		#return "Error: MII_Ignition_Library.Devices.Checkweigher.Checkweigher_Write_Stop has failed. Check log for details. Resource: " + Resource_Description
  		
  		
  

def Checkweigher_Write_Protocol(Tag_Provider, Client, Plant, PO, Resource, Resource_Description, Material, Material_Description, Batch_Number, Area_Description):
 
 	try:
 
 		#Local Parameters
 		Area = ''						   #Area: Used to determine resource area prefix.
 
 		#Verify Resource Area Prefix
  		Status,ReturnVal = MII_Ignition_Library.ToolsSet.Tools.GetArea(Client,Plant,Resource,Area_Description)
  						
 		if Status != "Success.":
 			return Status
 		else:
 			Area = ReturnVal
 		
 		
 		### Search for available Checkweighers ###
 		Primary_Packaging_Path = Tag_Provider + "Coca-Cola/CPS/" + Plant + "/" + Area + "/" + Resource + "/SF_Equipment/Checkweigher/Primary_Packaging"
 		Secundary_Packaging_Path = Tag_Provider + "Coca-Cola/CPS/" + Plant + "/" + Area + "/" + Resource + "/SF_Equipment/Checkweigher/Secundary_Packaging"
 		
 		tag_info = []
 		
 		
 		# Define paths to browse
 		paths = [Primary_Packaging_Path,Secundary_Packaging_Path]
 		
 		# Empty list to store combined results
 		combined_results = []
 		
 		# Loop through each path and browse tags
 		for path in paths:
 		    results = system.tag.browse(path, filter={'name':'*Checkweigher*'})
 		    combined_results.extend(results.getResults())
 		
 		# Empty list to store tag info
 		tag_info = []
 		
 		for result in combined_results:
 		
 			#Verify Checkweigher Write Tag Exists
	 		if MII_Ignition_Library.Validation.Verify_Tag_Existence.Tag_Existence_Non_Report(str(result['fullPath']) + "/writeCommand") == True:
	 			
	 			#Verify if Checkweigher Enabler Tag Exists
	 			if MII_Ignition_Library.Validation.Verify_Tag_Existence.Tag_Existence_Report(str(result['fullPath']) + "/enabled", Client + "_" + Plant + "_" + "Filling_Checkweighers_Module", "Error: Tag Path " + str(result['fullPath']) + "/enabled" + " does not exist.") == True:
	 			
	 				#Verify Checkweigher is enabled
	 				if system.tag.read(str(result['fullPath']) + "/enabled").value == True:
	 				
	 					#Verify if Checkweigher Connected Tag Exists
	 					if MII_Ignition_Library.Validation.Verify_Tag_Existence.Tag_Existence_Report(str(result['fullPath']) + "/isConnected", Client + "_" + Plant + "_" + "Filling_Checkweighers_Module", "Error: Tag Path " + str(result['fullPath']) + "/isConnected" + " does not exist.") == True:
	 					
	 						#Verify if Checkweigher is Connected
	 						if system.tag.read(str(result['fullPath']) + "/isConnected").value == True:
	 							
	 							
	 							
	 							#Send Protocol command to Checkweigher
	 							Protocol_Response = system.tag.writeBlocking(str(result['fullPath']) + "/writeCommand","WD_SET_FORMAT 4\r\n")
	 							if str(Protocol_Response[0]) != 'Good':
	 								MII_Ignition_Library.Logger.Insert_Log.Insert_Error_Log(Client + "_" + Plant + "_" + "Filling_Checkweighers_Module", "Error: An error ocurred while trying to Start " + str(result['name']) + " " + str(result['fullPath']) + "/writeCommand" + " " + str(Protocol_Response[0]))
	 								return "Error: An error ocurred while trying to Start " + str(result['name']) + " " + str(result['fullPath']) + "/writeCommand" + " " + str(Protocol_Response[0])
	 						
	 							else: #Checkweigher Protocol was written succesffuly
	 								None #return "Success."
	 								
	 						     
	 							
	 						else: #Checkweigher is not Connected
	 							MII_Ignition_Library.Logger.Insert_Log.Insert_Error_Log(Client + "_" + Plant + "_" + "Filling_Checkweighers_Module", "Error: " + Resource + " " + Resource_Description + " " + str(result['name']) + " is not connected.")
	 							return "Error: " + Resource + " " + Resource_Description + " " + str(result['name']) + " is not connected."
	 			
	 					else: #Checkweigher Connected Tag does not exist.
	 						MII_Ignition_Library.Logger.Insert_Log.Insert_Error_Log(Client + "_" + Plant + "_" + "Filling_Checkweighers_Module", "Error: Tag Path " + str(result['fullPath']) + "/isConnected" + " does not exist.")
	 						return "Error: Tag Path " + str(result['fullPath']) + "/isConnected" + " does not exist."
	 				else: #Checkweigher is not enabled.
	 					None #return "Success."
	 			else: #Checkweigher enabled tag does not exist.
	 				MII_Ignition_Library.Logger.Insert_Log.Insert_Error_Log(Client + "_" + Plant + "_" + "Filling_Checkweighers_Module", "Error: Tag Path " + str(result['fullPath']) + "/enabled" + " does not exist.")
	 				return "Error: Tag Path " + str(result['fullPath']) + "/enabled" + " does not exist."		
	 		else: #Checkweigher Write Tag does not exist.
	 			None
	 			
 		
 
 		
 		#Script executed succesffuly
 		return "Success."
 	
 	except Exception as e:
 			Status = e
 			return Status
 			MII_Ignition_Library.Logger.Insert_Log.Insert_Error_Log(Status)	
 	#except:
 	 	#MII_Ignition_Library.Logger.Insert_Log.Insert_Error_Log(Client + "_" + Plant + "_" + "Filling_Checkweighers_Module", "Error: MII_Ignition_Library.Devices.Checkweigher.Checkweigher_Write_Start has failed. Check log for details. Resource: " + Resource_Description)
 		#return "Error: MII_Ignition_Library.Devices.Checkweigher.Checkweigher_Write_Start has failed. Check log for details. Resource: " + Resource_Description
 	 
  
  
  
  
'''
  
 def Checkweigher_Handshake(Tag_Provider, Client, Plant, Resource, PO_InProgress_Flag):
  
 	#Local Parameters
 	Area = ''						   #Area: Used to determine resource area prefix.
 	
 	#Verify Resource Area Prefix
 	if Resource[0:2] == 'LF': #Liquid Filling
 		Area = 'LF'
 		
 	elif Resource[0:2] == 'DF' or Resource[0:2] == 'DA': #Dry Processing
 		Area = 'DP'
 	
 	#elif Area_Description == 'LIQ_PROCESS_AREA': #Skip MFG Temporarly
 		#return "Success."
 				
 	else: #Resource Area not Found
 		MII_Ignition_Library.Logger.Insert_Log.Insert_Error_Log(Client + "_" + Plant + "_" + "Filling_Checkweighers_Module", "Error: Resource Area Prefix not found. Resource: "  + Resource)
 		return "Error: Resource Area Prefix not found. Resource: "  + Resource
 		
 		
 		
 	#Verify if PP Checkweigher Enabler Tag Exists
 	if MII_Ignition_Library.Validation.Verify_Tag_Existence.Tag_Existence_Report(Tag_Provider + "Coca-Cola/CPS/" + Plant + "/" + Area + "/" + Resource + "/Checkweigher_PP/enabled", Client + "_" + Plant + "_" + "Filling_Checkweighers_Module", "Error: Tag Path " + Tag_Provider + "Coca-Cola/CPS/" + Plant + "/" + Area + "/" + Resource + "/Checkweigher_PP/enabled" + " does not exist.") == True:
 	
 		#Verify if PP Checkweigher is enabled
 		if system.tag.read(Tag_Provider + "Coca-Cola/CPS/" + Plant + "/" + Area + "/" + Resource + "/Checkweigher_PP/enabled").value == True:
 		
 			#Write PO In Progress Flag
 			PO_InProgress_Response = system.tag.writeBlocking(Tag_Provider + "Coca-Cola/CPS/" + Plant + "/" + Area + "/" + Resource + "/Checkweigher_PP/Handshake/PO_InProgress",0) #PO_InProgress_Flag
 			
 			if str(PO_InProgress_Response[0]) != 'Good':
 				MII_Ignition_Library.Logger.Insert_Log.Insert_Error_Log(Client + "_" + Plant + "_" + "Filling_Checkweighers_Module", "Handshake Error: " + Tag_Provider + "Coca-Cola/CPS/" + Plant + "/" + Area + "/" + Resource + "/Checkweigher_PP/Handshake/PO_InProgress" + " " + str(PO_InProgress_Response[0]) + " Inserted Handshake Value: " + PO_InProgress_Flag)
 
 
  		else: #PP Checkweigher is not enabled.
   			None #return "Success."
  									
   	else: #PP Checkweigher enabled tag does not exist.
   		MII_Ignition_Library.Logger.Insert_Log.Insert_Error_Log(Client + "_" + Plant + "_" + "Filling_Checkweighers_Module", "Error: Tag Path " + Tag_Provider + "Coca-Cola/CPS/" + Plant + "/" + Area + "/" + Resource + "/Checkweigher_PP/enabled" + " does not exist.")
   		return "Error: Tag Path " + Tag_Provider + "Coca-Cola/CPS/" + Plant + "/" + Area + "/" + Resource + "/Checkweigher_PP/enabled" + " does not exist."	
   		
   			
   				
   					
 	#Verify if SP Checkweigher Enabler Tag Exists
 	if MII_Ignition_Library.Validation.Verify_Tag_Existence.Tag_Existence_Report(Tag_Provider + "Coca-Cola/CPS/" + Plant + "/" + Area + "/" + Resource + "/Checkweigher_SP/enabled", Client + "_" + Plant + "_" + "Filling_Checkweighers_Module", "Error: Tag Path " + Tag_Provider + "Coca-Cola/CPS/" + Plant + "/" + Area + "/" + Resource + "/Checkweigher_SP/enabled" + " does not exist.") == True:
 	
 		#Verify if PP Checkweigher is enabled
 		if system.tag.read(Tag_Provider + "Coca-Cola/CPS/" + Plant + "/" + Area + "/" + Resource + "/Checkweigher_SP/enabled").value == True:
 		
 			#Write PO In Progress Flag
 			PO_InProgress_Response = system.tag.writeBlocking(Tag_Provider + "Coca-Cola/CPS/" + Plant + "/" + Area + "/" + Resource + "/Checkweigher_SP/Handshake/PO_InProgress", PO_InProgress_Flag)
 			
 			if str(PO_InProgress_Response[0]) != 'Good':
 				MII_Ignition_Library.Logger.Insert_Log.Insert_Error_Log(Client + "_" + Plant + "_" + "Filling_Checkweighers_Module", "Handshake Error: " + Tag_Provider + "Coca-Cola/CPS/" + Plant + "/" + Area + "/" + Resource + "/Checkweigher_SP/Handshake/PO_InProgress" + " " + str(PO_InProgress_Response[0]) + " Inserted Handshake Value: " + PO_InProgress_Flag)
 
 
  		else: #PP Checkweigher is not enabled.
   			None #return "Success."
  									
   	else: #PP Checkweigher enabled tag does not exist.
   		MII_Ignition_Library.Logger.Insert_Log.Insert_Error_Log(Client + "_" + Plant + "_" + "Filling_Checkweighers_Module", "Error: Tag Path " + Tag_Provider + "Coca-Cola/CPS/" + Plant + "/" + Area + "/" + Resource + "/Checkweigher_SP/enabled" + " does not exist.")
   		return "Error: Tag Path " + Tag_Provider + "Coca-Cola/CPS/" + Plant + "/" + Area + "/" + Resource + "/Checkweigher_SP/enabled" + " does not exist."		
 
  
''' 
  


def Clear_Checkweigher_Configuration(Tag_Provider, Client, Plant, Resource, Area_Description):
  
  try:
  
		#Local Parameters
		Area = ''						   #Area: Used to determine resource area prefix.


		Status,ReturnVal = MII_Ignition_Library.ToolsSet.Tools.GetArea(Client,Plant,Resource,Area_Description)
		  						
 		if Status != "Success.":
 			return Status
 		else:
 			Area = ReturnVal
  
  
  		### Search for available Checkweighers ###
 		Primary_Packaging_Path = Tag_Provider + "Coca-Cola/CPS/" + Plant + "/" + Area + "/" + Resource + "/SF_Equipment/Checkweigher/Primary_Packaging"
 		Secundary_Packaging_Path = Tag_Provider + "Coca-Cola/CPS/" + Plant + "/" + Area + "/" + Resource + "/SF_Equipment/Checkweigher/Secundary_Packaging"
 		
 		tag_info = []
 		
 		
 		# Define paths to browse
 		paths = [Primary_Packaging_Path,Secundary_Packaging_Path]
 		
 		# Empty list to store combined results
 		combined_results = []
 		
 		# Loop through each path and browse tags
 		for path in paths:
 		    results = system.tag.browse(path, filter={'name':'*Checkweigher*'})
 		    combined_results.extend(results.getResults())
 		
 		# Empty list to store tag info
 		tag_info = []
 		
 		for result in combined_results:
 		
 			#Clear Configuration Tags
 			system.tag.writeBlocking(str(result['fullPath']) + "/materialNumber",None)
 			system.tag.writeBlocking(str(result['fullPath']) + "/materialBatchNumber",None)
 			system.tag.writeBlocking(str(result['fullPath']) + "/uslWeight",None)
  			system.tag.writeBlocking(str(result['fullPath']) + "/lslWeight",None)
  			system.tag.writeBlocking(str(result['fullPath']) + "/targetWeight",None)
  			
  			#Reset Count
  			system.tag.writeBlocking(str(result['fullPath']) + "/goodCount",0)
  			system.tag.writeBlocking(str(result['fullPath']) + "/rejectCount",0)
  			system.tag.writeBlocking(str(result['fullPath']) + "/totalCount",0)
  
  
  except Exception as e:
  		Status = e
  		return Status
  		MII_Ignition_Library.Logger.Insert_Log.Insert_Error_Log(Status)	
  
  
  
  
  
def Validate_Checkweigher_Configuration(Tag_Provider, Client, Plant, Resource, Area_Description):
  
  try:
  
		#Local Parameters
		Area = ''						   #Area: Used to determine resource area prefix.
		Configuration_Flag = 1     		  #Configuration_Flag: Used to determine if configuration has not been completed. 
										  #1 = Okay  , 0 = Configuration Missing

		Status,ReturnVal = MII_Ignition_Library.ToolsSet.Tools.GetArea(Client,Plant,Resource,Area_Description)
		  						
 		if Status != "Success.":
 			return Status
 		else:
 			Area = ReturnVal
  
  
  		### Search for available Checkweighers ###
 		Primary_Packaging_Path = Tag_Provider + "Coca-Cola/CPS/" + Plant + "/" + Area + "/" + Resource + "/SF_Equipment/Checkweigher/Primary_Packaging"
 		Secundary_Packaging_Path = Tag_Provider + "Coca-Cola/CPS/" + Plant + "/" + Area + "/" + Resource + "/SF_Equipment/Checkweigher/Secundary_Packaging"
 		
 		tag_info = []
 		
 		
 		# Define paths to browse
 		paths = [Primary_Packaging_Path,Secundary_Packaging_Path]
 		
 		# Empty list to store combined results
 		combined_results = []
 		
 		# Loop through each path and browse tags
 		for path in paths:
 		    results = system.tag.browse(path, filter={'name':'*Checkweigher*'})
 		    combined_results.extend(results.getResults())
 		
 		# Empty list to store tag info
 		tag_info = []
 		
 		#Check if Head exists, to continue
 		if combined_results is not None:
 		
	 		for result in combined_results:
	 			
	 			#Validate Configuration Tags
	 			res = system.tag.readBlocking(str(result['fullPath']) + "/materialNumber")[0].value
	 			if res == None or res == '' or res == 'null' or res == '---':
	 				Configuration_Flag = 0
	 			
	 			res = system.tag.readBlocking(str(result['fullPath']) + "/materialBatchNumber")[0].value
	 			if res == None or res == '' or res == 'null' or res == '---':
	 				Configuration_Flag = 0
	 				 				
	 			res = system.tag.readBlocking(str(result['fullPath']) + "/uslWeight")[0].value
	 			if res == None or res == '' or res == 'null' or res == '---':
	 				Configuration_Flag = 0
	 				
 				res = system.tag.readBlocking(str(result['fullPath']) + "/lslWeight")[0].value
	 			if res == None or res == '' or res == 'null' or res == '---':
	 				Configuration_Flag = 0
	 			
	 			res = system.tag.readBlocking(str(result['fullPath']) + "/targetWeight")[0].value
	 			if res == None or res == '' or res == 'null' or res == '---':
	 				Configuration_Flag = 0
	 				 				
	 			#res = system.tag.readBlocking(str(result['fullPath']) + "/weightUom")[0].value
	 			#if res == None or res == '' or res == 'null' or res == '---':
	 				#Configuration_Flag = 0			
	  	
	  	return Configuration_Flag 
  
  
  except Exception as e:
  		Status = e
  		return Status
  		MII_Ignition_Library.Logger.Insert_Log.Insert_Error_Log(Status)	
  
