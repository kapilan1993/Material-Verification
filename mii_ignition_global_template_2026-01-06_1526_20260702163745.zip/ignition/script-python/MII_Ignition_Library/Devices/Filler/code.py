def Clear_Filler_Head_Configuration(Tag_Provider, Client, Plant, Resource, Area_Description):
  
  try:
  
		#Local Parameters
		Area = ''						   #Area: Used to determine resource area prefix.


		Status,ReturnVal = MII_Ignition_Library.ToolsSet.Tools.GetArea(Client,Plant,Resource,Area_Description)
		  						
 		if Status != "Success.":
 			return Status
 		else:
 			Area = ReturnVal
  
  
  		### Search for available Checkweighers ###
 		Filler_Head_Path = Tag_Provider + "Coca-Cola/CPS/" + Plant + "/" + Area + "/" + Resource + "/SF_Equipment/Filler"
 		
 		tag_info = []
 		
 		
 		# Define paths to browse
 		paths = [Filler_Head_Path]
 		
 		# Empty list to store combined results
 		combined_results = []
 		
 		# Loop through each path and browse tags
 		for path in paths:
 		    results = system.tag.browse(path, filter={'name':'*Head_*'})
 		    combined_results.extend(results.getResults())
 		
 		# Empty list to store tag info
 		tag_info = []
 		
 		for result in combined_results:
 			#Clear Configuration Tags
 			system.tag.writeBlocking(str(result['fullPath']) + "/materialNumber",None)
 			system.tag.writeBlocking(str(result['fullPath']) + "/materialBatchNumber",None)
 			system.tag.writeBlocking(str(result['fullPath']) + "/uslWeight",None)
  			system.tag.writeBlocking(str(result['fullPath']) + "/lslWeight",None)
  			system.tag.writeBlocking(str(result['fullPath']) + "/targetWeight",None)
  			system.tag.writeBlocking(str(result['fullPath']) + "/weightUom",None)
  
  
  except Exception as e:
  		Status = e
  		return Status
  		MII_Ignition_Library.Logger.Insert_Log.Insert_Error_Log(Status)	
  		
  		
  		
  		

def Validate_Filler_Head_Configuration(Tag_Provider, Client, Plant, Resource, Area_Description):
  
  try:
  
		#Local Parameters
		Area = ''						   #Area: Used to determine resource area prefix.
		Configuration_Flag = 1      	  #Empty_Configuration_Flag: Used to determine if configuration has not been completed. 
										  #1 = Okay  , 0 = Configuration Missing

		Status,ReturnVal = MII_Ignition_Library.ToolsSet.Tools.GetArea(Client,Plant,Resource,Area_Description)
		  						
 		if Status != "Success.":
 			return Status
 		else:
 			Area = ReturnVal
  
  
  		### Search for available Checkweighers ###
 		Filler_Head_Path = Tag_Provider + "Coca-Cola/CPS/" + Plant + "/" + Area + "/" + Resource + "/SF_Equipment/Filler"
 		
 		tag_info = []
 		
 		
 		# Define paths to browse
 		paths = [Filler_Head_Path]
 		
 		# Empty list to store combined results
 		combined_results = []
 		
 		# Loop through each path and browse tags
 		for path in paths:
 		    results = system.tag.browse(path, filter={'name':'*Head_*'})
 		    combined_results.extend(results.getResults())
 		
 		# Empty list to store tag info
 		tag_info = []
 		
 		#Check if Head exists, to continue
 		if combined_results is not None:
 		
	 		for result in combined_results:
	 			
	 			#Validate Configuration Tags
	 			res = system.tag.readBlocking(str(result['fullPath']) + "/materialNumber")[0].value
	 			if res == None or res == '' or res == 'null' or res == '---':
	 				Configuration_Flag = 0
	 			
	 			res = system.tag.readBlocking(str(result['fullPath']) + "/materialBatchNumber")[0].value
	 			if res == None or res == '' or res == 'null' or res == '---':
	 				Configuration_Flag = 0
	 				 				
	 			res = system.tag.readBlocking(str(result['fullPath']) + "/uslWeight")[0].value
	 			if res == None or res == '' or res == 'null' or res == '---':
	 				Configuration_Flag = 0 
	 				
 				res = system.tag.readBlocking(str(result['fullPath']) + "/lslWeight")[0].value
	 			if res == None or res == '' or res == 'null' or res == '---':
	 				Configuration_Flag = 0
	 			
	 			res = system.tag.readBlocking(str(result['fullPath']) + "/targetWeight")[0].value
	 			if res == None or res == '' or res == 'null' or res == '---':
	 				Configuration_Flag = 0
	 				 				
	 			res = system.tag.readBlocking(str(result['fullPath']) + "/weightUom")[0].value
	 			if res == None or res == '' or res == 'null' or res == '---':
	 				Configuration_Flag = 0				
	  	
	  	return Configuration_Flag 
  
  
  except Exception as e:
  		Status = e
  		return Status
  		MII_Ignition_Library.Logger.Insert_Log.Insert_Error_Log(Status)	