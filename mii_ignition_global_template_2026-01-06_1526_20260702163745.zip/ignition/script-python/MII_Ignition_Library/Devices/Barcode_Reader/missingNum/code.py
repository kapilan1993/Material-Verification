def find_missing_numbers(arr, start, end):
	#Convert string to integers
	numbers = [int(num) for num in arr]
	
	# Create a set of all numbers in the specified range
	expected_numbers = set(range(start, end +1))
	
	# Find missing numbers
	missing_numbers = list(expected_numbers - set(numbers))
	
	return missing_numbers