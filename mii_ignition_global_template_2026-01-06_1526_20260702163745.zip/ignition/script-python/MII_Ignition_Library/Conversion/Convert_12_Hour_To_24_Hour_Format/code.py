def convert_to_24_hour_format(time_12_hour):
    # Split the time string into components
    time_parts = time_12_hour.split(':')
    hour = int(time_parts[0])
    minute = time_parts[1]
    second, am_pm = time_parts[2].split(' ')
    
    # Convert hour based on AM/PM
    if am_pm.lower() == 'pm' and hour != 12:
        hour += 12
    elif am_pm.lower() == 'am' and hour == 12:
        hour = 0
    
    # Format the hour, minute, and second into a 24-hour time string
    time_24_hour = str(hour) + ":" + str(minute) + ":" + str(second)
    
    return time_24_hour