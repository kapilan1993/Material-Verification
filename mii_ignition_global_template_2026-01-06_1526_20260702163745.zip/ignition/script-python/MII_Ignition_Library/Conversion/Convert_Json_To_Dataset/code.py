import json
from system.dataset import toDataSet  
from com.inductiveautomation.ignition.common.util import DatasetBuilder
from system.util import jsonDecode as json_loads

def jsonToDataset(json_string):
 
  raw = iter(json.loads(json_string))
    
  firstRow = next(raw)
  headers = sorted(firstRow.keys())
  data = [[firstRow[key] for key in headers]]
  for row in raw:
   data.append([row[key] for key in headers])
    
  return system.dataset.toDataSet(headers, data)

def jsonToDataset_No_Key(json_string):
 
	# Load the JSON string into a Python object
	json_data = json.loads(json_string)
	
	# Dynamically access the first value in the JSON data, without specifying the key name
	first_data_set = next(iter(json_data.values()))  
	
	if not first_data_set:
	 return {"headers": [], "data": []}
	
	# Extract headers (keys) from the first element, assuming all entries have the same structure
	headers = list(first_data_set[0].keys())
	
	# Extract data
	data = []
	for item in first_data_set:  
	 row = [item[key] for key in headers]
	 data.append(row)
    
	return system.dataset.toDataSet(headers, data) #{"headers": headers, "data": data}
