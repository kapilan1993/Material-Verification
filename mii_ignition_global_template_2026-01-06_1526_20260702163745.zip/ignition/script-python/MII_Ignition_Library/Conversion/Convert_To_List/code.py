def ensure_conversion(input_data):
    """Ensure the input is always a list, converting if necessary."""
    if isinstance(input_data, dict):
        return [input_data]
    return input_data