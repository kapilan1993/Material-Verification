def XML_String_To_Dataset(XML):
	from xml.etree import ElementTree as ET
	
	# Parse the XML file
	root = ET.fromstring(XML)
	
	# Create a list for the datasets that will be derived from each node
	datasets = []
	
	for node in root:
	
		# Use a set to keep track of all unique tags (to be used as headers)
		tags = set()
		
		# Find all tags in the node to use as headers
		for subnode in node:
			for child in subnode.iter():
				tags.add(child.tag)
		
		# Get the headers and sort them
		headers = sorted(list(tags))
		
		# Create a List for the rows
		data = []
		
		# Process each sub-node as a row, and add the row to the data list
		for subnode in node:
			entry = {}
			for child in subnode.iter():
				if '\n' not in (child.text or ''):
					entry[child.tag] = child.text or ''
			row = [entry.get(header, '') for header in headers]
			
			#Check if all values in the row are blank
			if all(value == '' for value in row):
			    None
			else:
				data.append(row)
		
	# Convert the headers and data to a dataset, and add them to the datasets list
	return system.dataset.toDataSet(headers, data)