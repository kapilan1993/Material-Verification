def pyDataSetToListOfDicts(pyDataSet):
    """
    Convert a PyDataSet to a list of dictionaries
    """
    columnNames = [colName for colName in pyDataSet.getUnderlyingDataset().getColumnNames()]
    listOfDicts = []
    for row in pyDataSet:
        # Create a dictionary for each row where column names are keys
        rowDict = {columnName: row[columnIndex] for columnIndex, columnName in enumerate(columnNames)}
        listOfDicts.append(rowDict)
    return listOfDicts