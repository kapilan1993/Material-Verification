def GetArea(Client,Plant,Work_Center,Area_Description):
#GeetArea
#usage: 
	"""
	Status,ReturnVal = MII_Ignition_Library.ToolsSet.Tools.GetArea("010","0047","LF13")
	Concatenate the strings
	full_message="{}, {}".format(Status, ReturnVal)
	Print the concatenated string
	print(full_message)
	"""
	try:
 		
		#Local Parameters
		Area = ''						   #Area: Used to determine resource area prefix.
				
		#Verify Resource Area Prefix
		if Area_Description == 'LIQ_FILL_AREA': #Liquid Filling
			Area = 'LF'
			
		elif Area_Description == 'LIQUID_FILLING_AREA':
			Area = 'LF'
			
		elif Area_Description == 'DRY_FILLING_AREA': #Dry Processing
			Area = 'DP'
		
		elif Area_Description == 'LIQ_PROCESS_AREA': #MFG
			Area = 'LP/LP' + str(Work_Center[0:2])
			#return "Success."
		
		else: #Resource Area not Found
			MII_Ignition_Library.Logger.Insert_Log.Insert_Error_Log(Client + "_" + Plant + "_" + "Populate_", "Error: Resource Area Prefix not found. Resource: " + Work_Center)
			#Area
			return "Error: Resource Area Prefix not found. Resource: " + Work_Center

		if(Area!=""):
		#Script executed succesffuly
			Status = "Success."
			ReturnVal = Area
			return Status,ReturnVal
		else:
			raise Exception(Client + "_" + Plant + "_" + "Populate_", "Error: Resource Area Prefix not found. Resource: " + Work_Center)
			
	except Exception as e:
		Status = e
		ReturnVal = Area
		return Status,ReturnVal
		MII_Ignition_Library.Logger.Insert_Log.Insert_Error_Log(Status)
		
	
	#result_sum, result_product = calculate_values(3, 4)
	#print(f"Sum: {result_sum}, Product: {result_product}")
	
			
					
							
																					
																	
def GenerateRandomNumbers(spMin,spMax,iRange):
#Generate 10 random numbers between 1 and 100
#usage: MII_Ignition_Library.ToolsSet.Tools.GenerateRandomNumbers(198,201,1)
	import random
	try:
        #random_numbers = [random.randfloat(iMinI, iMaxI) for _ in range(iRange)]
        #random_floats = [round(random.uniform(spMin, spMax),3) for _ in range(iRange)]
		#random_doubles = [round(random.uniform(spMin, spMax),3) for _ in range(iRange)] #this return a list
		random_doubles = round(random.uniform(spMin, spMax),3)
		return float(random_doubles)
	except Exception as e:
		return e
        

def GenerateRandomWeightDataAnsSetHeadValue(Client,Plant,tag_Provider,Work_Center,Head,Area_Description):
#Generate 10 random numbers between 1 and 100
#usage: MII_Ignition_Library.ToolsSet.Tools.GenerateRandomWeightDataAnsSetHeadValue()
	"""
	Status,ReturnVal = MII_Ignition_Library.ToolsSet.Tools.GenerateRandomWeightDataAnsSetHeadValue("LF13")
	#Concatenate the strings
	full_message="{}, {}".format(Status, ReturnVal)
	#Print the concatenated string
	print(full_message)
	"""
# List of tag paths
#tag_paths = ["[default]MyFolder/MyTag1", "[default]MyFolder/MyTag2"]
# Corresponding list of values to write (each value is a float)
#values = [199.382, 150.246]
# Write the values to the tags
#system.tag.writeBlocking(tag_paths, values)

	# Import the system.tag module
	import system.tag
	import time
	#Client = "010"
	#Plant = "0047"
	#Work_Center = "LF13"
	
	try:               
		#tag_Site_Specifc_Path = "[Ignition_Site_Tags_Config]Settings/SiteSpecificSettings/" #"[Ignition_Site_Tags_Config]Settings/SiteSpecificSettings/]"
		#tag_Site_Specifc_Name = "client"
		#Client=system.tag.readBlocking(tag_Site_Specifc_Path+tag_Site_Specifc_Name)[0].value
		#tag_Site_Specifc_Name = "plant"
		#Plant=system.tag.readBlocking(tag_Site_Specifc_Path + tag_Site_Specifc_Name)[0].value
		#tag_Site_Specifc_Name = "tagProviderRemote_01"
		#tagProviderRemote_01 = system.tag.readBlocking(tag_Site_Specifc_Path+tag_Site_Specifc_Name)[0].value
		tagProviderRemote_01 = tag_Provider
		
		#Work_Center = "LF13"
		
		
		Status,Area=MII_Ignition_Library.ToolsSet.Tools.GetArea(Client, Plant, Work_Center, Area_Description)
		#Area = "LF"
		#tagProviderRemote_01 = "ignition_PRCIDB68_Shop_Floor"
		
		if(Status=="Success."):
			# Tag path
	 		
	 		#tag_path = "[ignition_PRCIDB68_Shop_Floor]Coca-Cola/CPS/0047/LF/LF13/SF_Equipment/Filler/FillerRawData/FillRpt/Upld/Data/"
			tag_path = tagProviderRemote_01 +  "Coca-Cola/CPS/"+ str(Plant) + "/" + Area + "/" + Work_Center + "/SF_Equipment/Filler/FillerRawData/FillRpt/Upld/Data/"
			tag_path2 = tagProviderRemote_01  + "Coca-Cola/CPS/"+ str(Plant) + "/" + Area + "/" + Work_Center + "/SF_Equipment/Filler/FillerRawData/FillRpt/Upld/Data/StartTime/"
			tag_path3 = tagProviderRemote_01  + "Coca-Cola/CPS/"+ str(Plant) + "/" + Area + "/" + Work_Center + "/SF_Equipment/Filler/FillerRawData/FillRpt/Upld/Data/EndTime/"
			tag_path4 = tagProviderRemote_01  + "Coca-Cola/CPS/"+ str(Plant) + "/" + Area + "/" + Work_Center + "/SF_Equipment/Filler/Head_" + str(Head) + "/"
			tag_path5 = tagProviderRemote_01  + "Coca-Cola/CPS/"+ str(Plant) + "/" + Area + "/" + Work_Center + "/SF_Equipment/Filler/FillerRawData/FillRpt/Upld/Data/Setpts/"
			tag_name = "WtTare"
			
			# Value to write to the tag
			#[ignition_PRCIDB68_Shop_Floor]Coca-Cola/CPS/0047/LF/LF13/SF_Equipment/Filler/Head_1/lslWeight
			#[ignition_PRCIDB68_Shop_Floor]Coca-Cola/CPS/0047/LF/LF13/SF_Equipment/Filler/Head_1/uslWeight
			
			lslWeight = system.tag.readBlocking(tag_path4 + "lslWeight")[0].value
			uslWeight = system.tag.readBlocking(tag_path4 + "uslWeight")[0].value
			tareWeight = system.tag.readBlocking(tag_path4 + "tareWeight")[0].value
			targetWeight = system.tag.readBlocking(tag_path4 + "targetWeight")[0].value
			#grossWeight = system.tag.readBlocking(tag_path4 + "grossWeight")[0].value
			weight = MII_Ignition_Library.ToolsSet.Tools.GenerateRandomNumbers(lslWeight,uslWeight,1)
	
			# Write the value to the tag
			#Response = MII_Ignition_Library.Tags.Write.Write_Single_Value(tag_path,Execution_StartDateTime)
			
			
			StartDay = system.date.format(system.date.now(),"dd")
			StartHour = system.date.format(system.date.now(),"HH")
			StartMicroSecond=system.date.format(system.date.now(),"ss")
			StartMinute=system.date.format(system.date.now(),"mm")
			StartMonth = system.date.format(system.date.now(),"MM") #getDayOfMonth(system.date.now())
			StartSecond=system.date.format(system.date.now(),"ss")
			StartYear=system.date.format(system.date.now(),"yyyy")
			
			EndDay = system.date.format(system.date.now(),"dd")
			EndHour = system.date.format(system.date.now(),"HH")
			EndMicroSecond=system.date.format(system.date.now(),"ss")
			EndMinute=system.date.format(system.date.now(),"mm")
			EndMonth = system.date.format(system.date.now(),"MM") #getDayOfMonth(system.date.now())
			EndSecond=system.date.format(system.date.addSeconds(system.date.now(),30),"ss")
			EndYear=system.date.format(system.date.now(),"yyyy")
			
			FillSeq = system.tag.readBlocking(tag_path + "FillSeq")[0].value + 1
			FillStorRecNum = 1
			FillSysNum = 3
			
			ReturnVal = system.tag.writeBlocking(tag_path5 + "SetPointTargetWtLoLim",lslWeight)
			ReturnVal = system.tag.writeBlocking(tag_path5 + "SetPointFillTargetWt",targetWeight)
			ReturnVal = system.tag.writeBlocking(tag_path5 + "SetPointTargetWtHiLim",uslWeight)
			
			ReturnVal = system.tag.writeBlocking(tag_path + "LanceNum",Head)
			LanceNum = system.tag.readBlocking(tag_path + "LanceNum")[0].value
			
			OrderNum = system.tag.readBlocking(tag_path + "OrderNum")[0].value
			Temperature = 0.0
			WtTare = 1.1 #tareWeight
			WtGross = weight + 1
			WtNet = weight
						
			tag_paths=[tag_path+"FillSeq",tag_path+"FillStorRecNum",tag_path+"FillSysNum",tag_path+"LanceNum",tag_path+"OrderNum",tag_path+"Temperature",tag_path+"WtGross",tag_path+"WtNet",tag_path + "WtTare",tag_path2+"StartDay",tag_path2+"StartHour",tag_path2+"StartMicroSec",tag_path2+"StartMinute",tag_path2+"StartMonth",tag_path2+"StartSecond",tag_path2+"StartYear",tag_path3+"EndDay",tag_path3+"EndHour",tag_path3+"EndMicroSec",tag_path3+"EndMinute",tag_path3+"EndMonth",tag_path3+"EndSecond",tag_path3+"EndYear"]
			values=[FillSeq,FillStorRecNum,FillSysNum,LanceNum,OrderNum,Temperature,WtGross,WtNet,WtTare,StartDay,StartHour,StartMicroSecond,StartMinute,StartMonth,StartSecond,StartYear,EndDay,EndHour,EndMicroSecond,EndMinute,EndMonth,EndSecond,EndYear]
			
			#Status = system.tag.writeBlocking(tag_path + tag_name, value)
			ReturnVal = system.tag.writeBlocking(tag_paths,values)
			
			time.sleep(2)
			
			tag_path = tagProviderRemote_01 + "Coca-Cola/CPS/"+ str(Plant) + "/" + Area + "/" + Work_Center + "/SF_Equipment/Filler/FillerRawData/FillRpt/Upld/Comm/"
			tag_name = "DataReady"
			value = 1
			ReturnVal = system.tag.writeBlocking(tag_path + tag_name, value)
			
			# Pause execution for 5 seconds
			time.sleep(2)
			value = 0
			ReturnVal = system.tag.writeBlocking(tag_path + tag_name, value)
			Status = tag_path #"Success."
			return Status,1
		else:
			raise Exception("Error: Resource Area Prefix not found. Resource: ") + Work_Center

	except Exception as e:
		return str(e),0
		
def remove_first_row_from_dataset(tagPath):
	"""
	Removes the first row from the dataset stored in the specified tag path.
	
	Parameters:
	tagPath (str): The path to the tag containing the dataset.
	"""
    
	try:
		# Read the dataset from the tag
		dataset = system.tag.readBlocking([tagPath])[0].value
		
		# Check if the dataset has rows
		if dataset.rowCount > 0:
			# Get the column headers
			headers = list(dataset.getColumnNames())
			
			# Initialize an empty list to hold the remaining rows
			remainingRows = []
		else:
			return
		# Add all rows except the first one to the list
		for rowIndex in range(1, dataset.rowCount):
		    row = [dataset.getValueAt(rowIndex, colIndex) for colIndex in range(dataset.columnCount)]
		    remainingRows.append(row)
		
		# Create a new dataset without the first row
		newDataset = system.dataset.toDataSet(headers, remainingRows)
		
		# Write the new dataset back to the tag
		system.tag.writeBlocking([tagPath], [newDataset])
		
	except:
		return
		
def g():
    
	Status,ReturnVal = Shared_MII_Ignition_Library.ToolsSet.Tools.GenerateRandomWeightDataAnsSetHeadValue("LF13",1)
	#Status,ReturnVal = MII_Ignition_Library.ToolsSet.Tools.GenerateRandomWeightDataAnsSetHeadValue("LF13")
	#Concatenate the strings
	full_message="{}, {}".format(Status, ReturnVal)
	#Print the concatenated string
	return(full_message)
	
def areaFinding(resource):
	#Area finding
	if resource[0:2] == 'LF': #Liquid Filling
		area = 'LF'
	elif resource[0:2] == 'DF' or resource[0:2] == 'DA': #Dry Processing
		area = 'DP'
	if resource[0:2] == 'LP': #Liquid Filling
		area = 'LP'
	return area