# Script Library: utilities
def get_session_property(session, property_name):
    """
    Retrieve a session property value.
    
    Parameters:
        session: The session object.
        property_name (str): The name of the session property.

    Returns:
        The value of the session property, or None if not found.
    """
    try:
        # Access the session properties dictionary
        session_properties = session.custom
        # Retrieve the property value
        property_value = session_properties.get(property_name, None)
        return property_value
    except Exception as e:
        # Handle exceptions and log error
        system.util.getLogger("SessionUtilities").error(str(e))
        return None