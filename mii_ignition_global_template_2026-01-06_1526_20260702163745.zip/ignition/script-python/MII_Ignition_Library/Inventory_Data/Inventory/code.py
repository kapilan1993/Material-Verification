def Calculate_Expiration_Date(Server, Client, Plant, PO, Order_Type, Nodename, Prod_Date, Materials_Dataset, apiReadTimeout):

	#Capture Reservation Table Materials
	
	Rowset = ''
	try:
		for rowIndex in range(Materials_Dataset.rowCount):
			
			Material = Materials_Dataset.getValueAt(rowIndex,1) 
			Batch_Number = Materials_Dataset.getValueAt(rowIndex,2) 
			Phase = Materials_Dataset.getValueAt(rowIndex,25)  #To be evaluated!
			#19,41,6
			row = ''
			row = 	'<Row>'+'\'
						'<MATNR>'+ Material +'</MATNR>'+'\'
						'<BATCH>'+ Batch_Number +'</BATCH>'+'\'
					'</Row>'
					
			Rowset = Rowset + row
	
		Post_XML = 	'<ProdExpDate>'+'\'
						'<SAPClient>' + Client + '</SAPClient>'+'\'
						'<SAPPlant>' + Plant + '</SAPPlant>' +'\'
						'<Order>' + PO + '</Order>' +'\'
						'<OrderType>' + Order_Type + '</OrderType>' +'\'
						'<Material>' + Material + '</Material>' +'\'
						'<Batchnr>' + Batch_Number + '</Batchnr>'+'\'
						'<SAPResourceName>' + Nodename + '</SAPResourceName>'+'\'
						'<Phase>' + Phase + '</Phase>'+'\'
						'<ProdDate>'+ Prod_Date +'</ProdDate>'+'\'
						'<Rowset>'+'\'
						 	Rowset +'\'
						'</Rowset>'+'\'
					'</ProdExpDate>'
		system.perspective.print("Post_XML"+str(Post_XML))
		#MII_Ignition_Library.Logger.Insert_Log.Insert_Error_Log('Expiration Date', Post_XML)
		url =  'http://' + str(Server) + '//PR-CID/ShopFloor/MII_Data_Collection_Messages/api/MIIDataCollectionMessages/POST_SAP_MII_MPM_CPS_Calculate_ProdExpDates'
		#url = "http://inpnqmiit//PR-CID/ShopFloor/MII_Data_Collection_Messages/api/MIIDataCollectionMessages/POST_SAP_MII_MPM_CPS_Calculate_ProdExpDates"
		postReturn = system.net.httpPost(url, 'text/xml', Post_XML, 10000, apiReadTimeout)
		MII_Ignition_Library.Logger.Insert_Log.Insert_Info_Log('ExpirayDatePostedXML', url +" "+ Post_XML)

		MII_Ignition_Library.Logger.Insert_Log.Insert_Info_Log('ExpiryDatePostReturn', postReturn)
		msg = myScripting_SIQ_idb.getValueFromXML(postReturn, "Message")
		sts = myScripting_SIQ_idb.getValueFromXML(postReturn, "status")
	
		response = [msg,sts]
		
		return response
		#return Post_XML
	except:
		MII_Ignition_Library.Logger.Insert_Log.Insert_Error_Log("BBD Calculation Post XML",str(sys.exc_info()))
		system.perspective.openPopup("alertPopup",'Popup/SuccessMsgPopup', params = {'source':'/system/images/Icons/Alert.svg','text':str(sys.exc_info())}, showCloseIcon = True, resizable = False, modal = True, overlayDismiss = True)
def Calculate_Expiration_Date_BATCH(Server, Client, Plant, PO, Order_Type, Nodename, Prod_Date, Material ,Batch_Number,Phase, apiReadTimeout):
	Rowset = ''
	try:
		
		row = ''
		row = 	'<Row>'+'\'
					'<MATNR>'+ Material +'</MATNR>'+'\'
					'<BATCH>'+ Batch_Number +'</BATCH>'+'\'
				'</Row>'
				
		Rowset = Rowset + row
	
		Post_XML = 	'<ProdExpDate>'+'\'
						'<SAPClient>' + Client + '</SAPClient>'+'\'
						'<SAPPlant>' + Plant + '</SAPPlant>' +'\'
						'<Order>' + PO + '</Order>' +'\'
						'<OrderType>' + Order_Type + '</OrderType>' +'\'
						'<Material>' + Material + '</Material>' +'\'
						'<Batchnr>' + Batch_Number + '</Batchnr>'+'\'
						'<SAPResourceName>' + Nodename + '</SAPResourceName>'+'\'
						'<Phase>' + Phase + '</Phase>'+'\'
						'<ProdDate>'+ Prod_Date +'</ProdDate>'+'\'
						'<Rowset>'+'\'
						 	Rowset +'\'
						'</Rowset>'+'\'
					'</ProdExpDate>'
		system.perspective.print("Post_XML"+str(Post_XML))
		#MII_Ignition_Library.Logger.Insert_Log.Insert_Error_Log('Expiration Date', Post_XML)
		url =  'http://' + str(Server) + '//PR-CID/ShopFloor/MII_Data_Collection_Messages/api/MIIDataCollectionMessages/POST_SAP_MII_MPM_CPS_Calculate_ProdExpDates'
		#url = "http://inpnqmiit//PR-CID/ShopFloor/MII_Data_Collection_Messages/api/MIIDataCollectionMessages/POST_SAP_MII_MPM_CPS_Calculate_ProdExpDates"
		postReturn = system.net.httpPost(url, 'text/xml', Post_XML, 10000, apiReadTimeout)
		MII_Ignition_Library.Logger.Insert_Log.Insert_Info_Log('ExpirayDatePostedXML', url +" "+ Post_XML)

		MII_Ignition_Library.Logger.Insert_Log.Insert_Info_Log('ExpiryDatePostReturn', postReturn)
		msg = myScripting_SIQ_idb.getValueFromXML(postReturn, "Message")
		sts = myScripting_SIQ_idb.getValueFromXML(postReturn, "status")
		response = [msg,sts]
		return response
	except:
		print str(sys.exc_info())
		MII_Ignition_Library.Logger.Insert_Log.Insert_Error_Log("BBD Calculation Post XML",str(sys.exc_info()))
		#system.perspective.openPopup("alertPopup",'Popup/SuccessMsgPopup', params = {'source':'/system/images/Icons/Alert.svg','text':str(sys.exc_info())}, showCloseIcon = True, resizable = False, modal = True, overlayDismiss = True)

def Get_PSA_BIN(Server, Client, Warehouse, Material, Plant, PSA_Supply_Area):
	try:
			url = 'http://' + str(Server) + '//PR-CID/ShopFloor/MII_Data_Collection_Messages/api/MIIDataCollectionMessages/GET_SAP_MII_MPM_CPS_BLS_YPP_MII_GET_BIN_FOR_PSA?SAP_CLIENT=' + str(Client) + '&IV_LGNUM_wHouseNo=' + str(Warehouse) + '&IV_MATNR=' + str(Material) + '&IV_PLANT=' + str(Plant) + '&IV_PRVBE_psaSupplyArea='+ str(PSA_Supply_Area) +'&jSon=False'
					
			json_data = system.net.httpGet(url)
			#system.perspective.print("uRL send")
#			system.perspective.print(url)
#			system.perspective.print("uRL send1")
			return json_data
			MII_Ignition_Library.Logger.Insert_Log.Insert_Info_Log('stockValidationPSAbin', url +" "+ json_data)
	except:
		MII_Ignition_Library.Logger.Insert_Log.Insert_Error_Log(Client + "_" + Plant + "_" + "Inventory", "Error: MII_Ignition_Library.Inventory.Get_PSA_BIN has failed. Check log for details.")
		return "Error: MIIIgnitionLibrary.Inventory.Get_PSA_BIN has failed. Check log for details."
		


def Get_Batch_List_For_Material(Server, SAP_CLIENT, SAP_PLANT, WAREHOUSE_NUMBER, IV_SUPPLY_AREA, PROCESS_ORDER, MATERIAL_NUMBER, STORAGE_LOCATION, IV_WITH_CONSUMED, IV_LOGSYS, IV_HU_EXID, IV_HU_EXID_TYPE):
	try:
			PROCESS_ORDER =''
			url = 'http://' + str(Server) + '/PR-CID/ShopFloor/MII_Data_Collection_Messages/api/MIIDataCollectionMessages/GET_SAP_MII_MPM_CPS_S4MfgGetBatchListForMaterial?SAP_CLIENT=' + SAP_CLIENT + '&SAP_PLANT=' + SAP_PLANT + '&WAREHOUSE_NUMBER=' + WAREHOUSE_NUMBER + '&IV_SUPPLY_AREA=' + IV_SUPPLY_AREA + '&PROCESS_ORDER=' + PROCESS_ORDER + '&MATERIAL_NUMBER=' + MATERIAL_NUMBER + '&STORAGE_LOCATION=' + STORAGE_LOCATION + '&IV_WITH_CONSUMED=' + IV_WITH_CONSUMED + '&IV_LOGSYS=' + IV_LOGSYS + '&IV_HU_EXID=' + IV_HU_EXID + '&IV_HU_EXID_TYPE=' + IV_HU_EXID_TYPE + '&jSon=False'
#			system.perspective.print("uRL send")
#			system.perspective.print(url)
#			system.perspective.print("uRL send1")
			connectTimeout = 5000
			readTimeout = (int(system.tag.readBlocking('[Shop_Floor]Coca-Cola/CPS/Site_Settings/General_Configuration/apiTimeoutDuration')[0].value)*60000)
			response = system.net.httpGet(url,connectTimeout,readTimeout)
			responseJson = system.util.jsonDecode(response)
			MII_Ignition_Library.Logger.Insert_Log.Insert_Info_Log('stockValidationResponse', url +" "+ responseJson)
			print responseJson
			return responseJson
	except:
		MII_Ignition_Library.Logger.Insert_Log.Insert_Error_Log(Client + "_" + Plant + "_" + "Inventory", "Error: MII_Ignition_Library.Inventory.Get_Batch_List_For_Material has failed. Check log for details.")
		return "Error: MII_Ignition_Library.Inventory.Get_Batch_List_For_Material. Check log for details."



### Getting Batch List from Inventory Response
def GetBatchLists (responseJson,POBatch,TargetQty,SLOCs):
	import xml.etree.ElementTree as ET
	a = """</soap:Body>"""
	b = """<soap:Envelope xmlns:soap="http://schemas.xmlsoap.org/soap/envelope/" xmlns:xsd="http://www.w3.org/2001/XMLSchema" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance">"""
	c =  """ xmlns="http://www.sap.com/xMII"""""
	messaged = responseJson.replace (a,'')
	messaged = messaged.replace (b,'')
	messaged = messaged.replace (c,'')
	messaged = messaged.replace ("""<XacuteResponse">""","<XacuteResponse>")
	messaged = messaged.replace ("<soap:Body>","")
	messaged = messaged.replace ("</soap:Envelope>","")
	import xml.etree.ElementTree as ET
	root = ET.fromstring(messaged)
	data = GeneralScripts.convertXMLtoDataset(root,"Rowset")
	
	pydata = system.dataset.toPyDataSet(data)
	Header = ['Batchno','Qty','UOM','Sloc','Selected','PlannedQty','BatchSel','ShelfLifeDate','PsaBin']
	Value = []
	BatchList = []
	Quantity = []
	cnt=0
	for row in pydata:		
		BatchList = row["BatchNumber"]
		Quantity = row['Quantity']
		SLOC = row["StorageLocation"]
		UOM = row["UOM"]
		ShelfLifeDate = row["ShelfLifeDate"]
		PsaBin =row['PSA_BIN']
		Selected = False
		PlannedQty = "0"
		BatchSel = ''
		for Batch, Qty,sloc1 in zip(POBatch, TargetQty,SLOCs):
			if BatchList ==Batch and SLOC==sloc1:
				cnt+=1
				Selected = True
				PlannedQty = Qty
				system.perspective.print(str(Batch) + str(Qty))
				break
        
		Value.append([BatchList, Quantity, UOM, SLOC, Selected, PlannedQty, BatchSel, ShelfLifeDate,PsaBin])
    
	data = system.dataset.toDataSet(Header,Value)
	datasortedbyDate= system.dataset.sort(data, 'ShelfLifeDate',True)
	datasorted= system.dataset.sort(datasortedbyDate, 'Selected',False)
	return datasorted
def GetInventoryViewBatchLists(responseJson):
	import xml.etree.ElementTree as ET
	a = """</soap:Body>"""
	b = """<soap:Envelope xmlns:soap="http://schemas.xmlsoap.org/soap/envelope/" xmlns:xsd="http://www.w3.org/2001/XMLSchema" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance">"""
	c =  """ xmlns="http://www.sap.com/xMII"""""
	messaged = responseJson.replace (a,'')
	messaged = messaged.replace (b,'')
	messaged = messaged.replace (c,'')
	messaged = messaged.replace ("""<XacuteResponse">""","<XacuteResponse>")
	messaged = messaged.replace ("<soap:Body>","")
	messaged = messaged.replace ("</soap:Envelope>","")
	import xml.etree.ElementTree as ET
	root = ET.fromstring(messaged)
	data = GeneralScripts.convertXMLtoDataset(root,"Rowset")
	
	pydata = system.dataset.toPyDataSet(data)
	Header = ['Batchno','Qty','UOM','Sloc','Selected','PlannedQty','BatchSel','ShelfLifeDate','PsaBin']
	Value = []
	BatchList = []
	Quantity = []
	cnt=0
	for row in pydata:		
		BatchList = row["BatchNumber"]
		Quantity = row['Quantity']
		SLOC = row["StorageLocation"]
		UOM = row["UOM"]
		ShelfLifeDate = row["ShelfLifeDate"]
		PsaBin =row['PSA_BIN']
		Selected = False
		PlannedQty = "0"
		BatchSel = ''
		Value.append([BatchList, Quantity, UOM, SLOC, Selected, PlannedQty, BatchSel, ShelfLifeDate,PsaBin])
    
	data = system.dataset.toDataSet(Header,Value)
	datasortedbyDate= system.dataset.sort(data, 'ShelfLifeDate',True)
	#datasorted= system.dataset.sort(datasortedbyDate, 'Selected',False)
	return datasortedbyDate
	
	
	
	
	
	
	
	
	
#d ef GetBatchLists (responseJson,POBatch):
#	import xml.etree.ElementTree as ET
#	a = """</soap:Body>"""
#	b = """<soap:Envelope xmlns:soap="http://schemas.xmlsoap.org/soap/envelope/" xmlns:xsd="http://www.w3.org/2001/XMLSchema" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance">"""
#	c =  """ xmlns="http://www.sap.com/xMII"""""
#	messaged = responseJson.replace (a,'')
#	messaged = messaged.replace (b,'')
#	messaged = messaged.replace (c,'')
#	messaged = messaged.replace ("""<XacuteResponse">""","<XacuteResponse>")
#	messaged = messaged.replace ("<soap:Body>","")
#	messaged = messaged.replace ("</soap:Envelope>","")
#	import xml.etree.ElementTree as ET
#	root = ET.fromstring(messaged)
#	data = GeneralScripts.convertXMLtoDataset(root,"Rowset")
#	pydata = system.dataset.toPyDataSet(data)
#	Header = ['Batchno','Qty','UOM','Sloc','Selected','PlannedQty','BatchSel','ShelfLifeDate']
#	Value = []
#	BatchList = []
#	Quantity = []
#	for row in pydata :
#		BatchList = row ["BatchNumber"]
#		Quantity = row ['Quantity']
#		SLOC = row ["StorageLocation"]
#		UOM = row["UOM"]
#		ShelfLifeDate = row ["ShelfLifeDate"]
#		if BatchList in POBatch :
#			Selected = True
#		
#		else :
#			Selected = False
#		PlannedQty = "0"
#		BatchSel=''
#		Value.append([BatchList,Quantity,UOM,SLOC,Selected,PlannedQty,BatchSel,ShelfLifeDate])
#	data = system.dataset.toDataSet(Header,Value)
#	datasorted= system.dataset.sort(data, 'ShelfLifeDate',True)
#	return datasorted
	

def InventoryCheck(Server,Client,Plant,processOrder,workCenter,materialNumber):
	#miiurl = system.tag.read ('MasterData/MIIUrl').value
	#inventorycheckurl = system.tag.read ('MasterData/InventoryCheckUrl').value
	endpoint  ='http://' + str(Server) + '/PR-CID/ShopFloor/MII_Data_Collection_Messages/api/MIIDataCollectionMessages/GET_SAP_MII_MPM_CPS_S4MfgGetBatchListForMaterial?'
	#endpoint  = miiurl + inventorycheckurl     #"http://idbogmiiappprod.apac.ko.com/PR-CID/ShopFloor/MII_Data_Collection_Messages/api/MIIDataCollectionMessages/GET_SAP_MII_MPM_CPS_S4MfgGetBatchListForMaterial?"
	SAP_CLIENT = Client
	SAP_PLANT = Plant
	WAREHOUSENUMBER = "384"
	#PROCESS_ORDER = system.tag.read ('[default]CPS_INDONESIA/'+WorkCenter+'_CHOSEN/PO')
	PROCESS_ORDER = ""
	path = "SAP_CLIENT=" + SAP_CLIENT +\
				"&SAP_PLANT=" + SAP_PLANT +\
				"&WAREHOUSE_NUMBER=" + WAREHOUSENUMBER +\
				"&IV_SUPPLY_AREA="+\
				"&PROCESS_ORDER="+PROCESS_ORDER+\
				"&MATERIAL_NUMBER="+materialNumber+\
				"&STORAGE_LOCATION="+\
				"&IV_WITH_CONSUMED="+\
				"&IV_LOGSYS="+\
				"&IV_HU_EXID="+\
				"&IV_HU_EXID_TYPE=500" +\
				"jSon=True"
				
	url = endpoint +path
		
	try:
		connectTimeout = 5000
		readTimeout =  (int(system.tag.readBlocking('[Shop_Floor]Coca-Cola/CPS/Site_Settings/General_Configuration/apiTimeoutDuration')[0].value)*60000)	
		response = system.net.httpGet(url,connectTimeout,readTimeout)
		responseJson = system.util.jsonDecode(response)
		system.perspective.print(responseJson)				
		#status = responseJson["Rowset"]["Row"][0]["status"]
		#message = responseJson["Rowset"]["Row"][0]["Message"]
		return responseJson
	except :
		return "connection_failed : "+url
	#SAP_CLIENT=010&SAP_PLANT=0047&WAREHOUSE_NUMBER=023&IV_SUPPLY_AREA=&PROCESS_ORDER=&MATERIAL_NUMBER=1913128&STORAGE_LOCATION=&IV_WITH_CONSUMED= &IV_LOGSYS=&IV_HU_EXID=&IV_HU_EXID_TYPE=500&jSon=false
	
	
def BBDGetBatchLists (responseJson,poBatch):
	import xml.etree.ElementTree as ET
	a = """</soap:Body>"""
	b = """<soap:Envelope xmlns:soap="http://schemas.xmlsoap.org/soap/envelope/" xmlns:xsd="http://www.w3.org/2001/XMLSchema" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance">"""
	c =  """ xmlns="http://www.sap.com/xMII"""""
	messaged = responseJson.replace (a,'')
	messaged = messaged.replace (b,'')
	messaged = messaged.replace (c,'')
	messaged = messaged.replace ("""<XacuteResponse">""","<XacuteResponse>")
	messaged = messaged.replace ("<soap:Body>","")
	messaged = messaged.replace ("</soap:Envelope>","")
	import xml.etree.ElementTree as ET
	root = ET.fromstring(messaged)
	data = GeneralScripts.convertXMLtoDataset(root,"Rowset")
	test = MII_Ignition_Library.Conversion.Convert_XML_to_JSon.XML_to_Json(messaged)
#	system.perspective.print(test)
	pydata = system.dataset.toPyDataSet(data)
	
	Header = ['Batchno','Qty','UOM','Sloc','Selected','PlannedQty','ShelfLifeDate']
	Value = []
	BatchList = []
	Quantity = []
	for row in pydata :
		
		BatchList = row ["BatchNumber"]
		Quantity = row ['Quantity']
		SLOC = row ["StorageLocation"]
		UOM = row["UOM"]
		ShelfLifeDate = row ["ShelfLifeDate"]
		if BatchList in poBatch :
			Selected = True
		else :
			Selected = False
		PlannedQty = '0'
		Value.append([BatchList,Quantity,UOM,SLOC,Selected,PlannedQty,ShelfLifeDate])
	data = system.dataset.toDataSet(Header,Value)
	datasortedbyDate= system.dataset.sort(data, 'ShelfLifeDate',True)
	datasorted= system.dataset.sort(datasortedbyDate, 'Selected',False)
	return datasorted
	
	
def GetInventoryBatchLists(responseJson,poBatch, enteredSloc):
	import xml.etree.ElementTree as ET
	a = """</soap:Body>"""
	b = """<soap:Envelope xmlns:soap="http://schemas.xmlsoap.org/soap/envelope/" xmlns:xsd="http://www.w3.org/2001/XMLSchema" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance">"""
	c =  """ xmlns="http://www.sap.com/xMII"""""
	messaged = responseJson.replace (a,'')
	messaged = messaged.replace (b,'')
	messaged = messaged.replace (c,'')
	messaged = messaged.replace ("""<XacuteResponse">""","<XacuteResponse>")
	messaged = messaged.replace ("<soap:Body>","")
	messaged = messaged.replace ("</soap:Envelope>","")
	import xml.etree.ElementTree as ET
	root = ET.fromstring(messaged)
	data = GeneralScripts.convertXMLtoDataset(root,"Rowset")
	test = MII_Ignition_Library.Conversion.Convert_XML_to_JSon.XML_to_Json(messaged)
#	system.perspective.print(test)
	pydata = system.dataset.toPyDataSet(data)
	
	Header = ['Batchno','Qty','UOM','Sloc','Selected','PlannedQty','ShelfLifeDate']
	Value = []
	BatchList = []
	Quantity = []
	for row in pydata :
		
		BatchList = row ["BatchNumber"]
		Quantity = row ['Quantity']
		SLOC = row ["StorageLocation"]
		UOM = row["UOM"]
		ShelfLifeDate = row ["ShelfLifeDate"]
		if (BatchList in poBatch) and SLOC == enteredSloc:
			Selected = True
			system.perspective.print("SLOC in response TRUE" + str(SLOC))
		else :
			Selected = False
		PlannedQty = '0'
		Value.append([BatchList,Quantity,UOM,SLOC,Selected,PlannedQty,ShelfLifeDate])
	data = system.dataset.toDataSet(Header,Value)
	datasortedbyDate= system.dataset.sort(data, 'ShelfLifeDate',True)
	datasorted= system.dataset.sort(datasortedbyDate, 'Selected',False)
	return datasorted
	
	
	
	
def InventoryGetBatchLists(responseJson,poBatch, sloc):
	import xml.etree.ElementTree as ET
	a = """</soap:Body>"""
	b = """<soap:Envelope xmlns:soap="http://schemas.xmlsoap.org/soap/envelope/" xmlns:xsd="http://www.w3.org/2001/XMLSchema" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance">"""
	c =  """ xmlns="http://www.sap.com/xMII"""""
	messaged = responseJson.replace (a,'')
	messaged = messaged.replace (b,'')
	messaged = messaged.replace (c,'')
	messaged = messaged.replace ("""<XacuteResponse">""","<XacuteResponse>")
	messaged = messaged.replace ("<soap:Body>","")
	messaged = messaged.replace ("</soap:Envelope>","")
	import xml.etree.ElementTree as ET
	root = ET.fromstring(messaged)
	data = GeneralScripts.convertXMLtoDataset(root,"Rowset")
	test = MII_Ignition_Library.Conversion.Convert_XML_to_JSon.XML_to_Json(messaged)
#	system.perspective.print(test)
	pydata = system.dataset.toPyDataSet(data)
	
	Header = ['Batchno','Qty','UOM','Sloc','Selected','PlannedQty','ShelfLifeDate']
	Value = []
	BatchList = []
	Quantity = []
	for row in pydata :
		
		BatchList = row ["BatchNumber"]
		Quantity = row ['Quantity']
		SLOC = row ["StorageLocation"]
		UOM = row["UOM"]
		ShelfLifeDate = row ["ShelfLifeDate"]
		if BatchList in poBatch:
			Selected = True
		else :
			Selected = False
		PlannedQty = '0'
		Value.append([BatchList,Quantity,UOM,SLOC,Selected,PlannedQty,ShelfLifeDate])
	data = system.dataset.toDataSet(Header,Value)
	datasortedbyDate= system.dataset.sort(data, 'ShelfLifeDate',True)
	datasorted= system.dataset.sort(datasortedbyDate, 'Selected',False)
	return datasorted
	