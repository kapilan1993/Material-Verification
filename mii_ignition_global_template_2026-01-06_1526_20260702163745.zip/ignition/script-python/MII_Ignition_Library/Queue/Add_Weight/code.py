def add_node(tagPath, client, plant, order, sapResource, operation, phase, materialNumber, weightUom, goodCount, rejectCount, rejectCode, unsClass):
    logger = system.util.getLogger("SMIL.Queue.Add_Weight.add_node")
    logger.info(str("Loading"))
    try:
        readDataset = system.tag.readBlocking([tagPath])[0].value
        newRow = [[client, plant, order, sapResource, operation, phase, materialNumber, weightUom, goodCount, rejectCount, rejectCode]]
        if (readDataset == None or readDataset == []):
            headers = ["client", "plant", "order", "sapResource", "operation", "phase", "materialNumber", "weightUom", "goodCount", "rejectCount", "rejectCode"]
            logger.info(str(len(headers)))
            logger.info(str(len(newRow)))
            dataset = system.dataset.toDataSet(headers, newRow)
            Response = system.tag.writeBlocking([tagPath], dataset)
        else:        
       		headers = ["client", "plant", "order", "sapResource", "operation", "phase", "materialNumber", "weightUom", "goodCount", "rejectCount", "rejectCode"]
       		writeDataset = system.dataset.toDataSet(headers, newRow)
       		dataset = system.dataset.appendDataset(readDataset, writeDataset)
        	Response = system.tag.writeBlocking([tagPath], [dataset])
        
        if str(Response) != 'Good':
            Status = str(Response)
            return Status,0
        else:
            Status = 'Success.'
            return Status,1  
    except Exception as e:
        Status = str(e)
        logger.error(Status)
        return Status,0

def remove_first_row_from_dataset(tagPath):
    """
    Removes the first row from the dataset stored in the specified tag path.
    
    Parameters:
    tagPath (str): The path to the tag containing the dataset.
    """
    
    try:
        # Read the dataset from the tag
        dataset = system.tag.readBlocking([tagPath])[0].value
        
        # Check if the dataset has rows
        if dataset.rowCount > 0:
            # Get the column headers
            headers = list(dataset.getColumnNames())
            
            # Initialize an empty list to hold the remaining rows
            remainingRows = []
            
        # Add all rows except the first one to the list
        for rowIndex in range(1, dataset.rowCount):
            row = [dataset.getValueAt(rowIndex, colIndex) for colIndex in range(dataset.columnCount)]
            remainingRows.append(row)
        
        # Create a new dataset without the first row
        newDataset = system.dataset.toDataSet(headers, remainingRows)
        
        # Write the new dataset back to the tag
        system.tag.writeBlocking([tagPath], [newDataset])
        
    except:
        return