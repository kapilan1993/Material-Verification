def Get_Resource_List(API_Protocol, API_Server, SAP_Status, MII_Status, DB_Status, Database, Client, Plant, RowCount):
	try:
			
		url = str(API_Protocol) + '://' + str(API_Server) + '/PR-CID/ShopFloor/MII_Data_Collection_Messages/api/MIIDataCollectionMessages/GET_SAP_MII_ResourcesData?SAP_CLIENT=' + str(Client) + '&SAP_PLANT=' + str(Plant) + '&RowCount=' + str(RowCount) + '&jSon=true'
				
		json_data = system.net.httpGet(url)
				
		return json_data
	
	except Exception as e:
		Status = e
		return Status
		MII_Ignition_Library.Logger.Insert_Log.Insert_Error_Log(str(Client) + "_" + str(Plant) + "_" + "Get_Resource_List", Status)