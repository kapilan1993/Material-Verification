import threading
import os
import time
import datetime
#from java.lang import Thread
import system

loggerName = "ALF-Logger: Cidra Ignition"
logger = system.util.getLogger(loggerName)

def dbProcedure(Database,Work_Center,T):
	#import time
	import datetime
	#from java.lang import Thread
	import system
	#logger = system.util.getLogger(loggerName)
	#Database = 'IGNPEDB_prcidT55'
	#myThreadName = str(Thread.currentThread())
	#Work_Center = 'LF13'
	#time.sleep(10)  # Simulate a long-running task
	print("Long-running task completed")
	Message = "Long-running task completed"
	#MII_Ignition_Library.Logger.Insert_Log.Insert_Error_Log("Thread Result", str(Message))
	### Insert into Database ###			
	#Dictionary for the table QUEUE MESSAGE LOG
	
	#logger.info("Insert record into dB: {}" + Work_Center + "-" + T, "Ignition_Posted_Time: " + str(datetime.datetime.now()))
	
	SQL_Parameters = {"database": Database ,"Work_Center": Work_Center + "-" + T, "Ignition_Posted_Time":datetime.datetime.now()}
	#Query to update table QUEUE MESSAGE LOG
	system.db.runNamedQuery("MII_Ignition_Queries/Test_Queries/Thread_Insert_Test", SQL_Parameters)
	
def dbBrokerService(Database, Client, Plant, API_Protocol, API_Server, Area_Path):
	import json 
	
	#Declare Parameters
	#API_Protocol = 'http'
	#API_Server = 'prcidt32'
	#Database = 'IGNPEDB_prcidT55'
	#Config_Tag_Provider = "[Ignition_Site_Tags_Config]"			
	#Client = system.tag.readBlocking(str(Config_Tag_Provider) + "Settings/SiteSpecificSettings/client")[0].value
	#Plant = system.tag.readBlocking(str(Config_Tag_Provider) + "Settings/SiteSpecificSettings/plant")[0].value
	#Work_Center = 'LF13'

	#Get MII Status
	try:
		MII_Status_Response = system.net.httpGet(str(API_Protocol) + "://" + str(API_Server) + "/PR-CID/ShopFloor/MII_Data_Collection_Messages/api/MIIDataCollectionMessages/Get_BLS_DateTimePlant?SAP_CLIENT=" + str(Client) + "&SAP_PLANT=" + str(Plant))
	
		if len(MII_Status_Response) > 0:
			MII_Status = 1
		else:
			MII_Status = 0
	except:
		MII_Status = 0
		
	#Get SAP Status	
	try:
		SAP_Status_Response = system.net.httpGet(str(API_Protocol) + "://" + str(API_Server) + "/PR-CID/ShopFloor/MII_Data_Collection_Messages/api/MIIDataCollectionMessages/GET_SAP_MII_MPM_CPS_BLS_YPP_MII_GET_BIN_FOR_PSA?SAP_CLIENT=" + str(Client) + "&IV_LGNUM_wHouseNo=x&IV_MATNR=x&IV_PLANT=" + str(Plant) + "&IV_PRVBE_psaSupplyArea=x&jSon=true")
	
		if len(SAP_Status_Response) > 0:
			SAP_Status = 1
		else:
			SAP_Status = 0
	except:
		SAP_Status = 0	
		
	#Get MII Database Status
	try:
		MII_DB_Query_Parameters = {"database": Database}
		MII_DB_Response = system.db.runNamedQuery("MII_Ignition_Queries/Database_Status/Get_xMII_DB_Status", MII_DB_Query_Parameters)
		
		if MII_DB_Response:
			MII_DB_Status = 1
		else:
			MII_DB_Status = 0
	except:
		MII_DB_Status = 0	
	
	
	
	
	if MII_Status == 1 and SAP_Status == 1 and MII_DB_Status == 1:	
		
		
		###Search for Work Centers inside Area Path###
		
		# Initialize the list to store folder names
		work_centers = []
		
		# Iterate through each path
		for path in Area_Path:
		    # Get the list of folders in the current path
		    tags = system.tag.browse(path, filter={"tagType": "Folder"})  # Filter set to only fetch folders
		    
		    # Iterate through tags and append folder names to the list
		    for tag in tags.getResults():
		        work_center_name = tag['name']
		        work_centers.append({"Work_Center": work_center_name})
		
		# Convert list to JSON formatted string
		Work_Centers_Json_String = json.dumps(work_centers)
		
		# Parse the JSON string back to a Python list of dictionaries
		Work_Centers_Json_List = json.loads(Work_Centers_Json_String )
		
		###Iterate thorugh each found Work Center###
		
		for row in Work_Centers_Json_List:
		
			#Retrieve Work Center from JSON
			Work_Center = row['Work_Center']
			#MII_Ignition_Library.Logger.Insert_Log.Insert_Info_Log('WC Loop', 'Working with ' + str(Work_Center))
			#Query_Parameters = {"database": Database, "SAPClient":Client, "SAPPlant":Plant, "Work_Center":Work_Center}
			Query_Parameters = {"database": Database, "SAPClient":Client, "SAPPlant":Plant}
					
			#Query_Result = system.db.runNamedQuery("MII_Ignition_Queries/xMII_Message_Log/XMII_QUEUE_MESSAGE_LOG_GET_UNPROCESSED_MSG_BY_WC", Query_Parameters)
			Query_Result = system.db.runNamedQuery("MII_Ignition_Queries/xMII_Message_Log/XMII_QUEUE_MESSAGE_LOG_GET_UNPROCESSED_MSG", Query_Parameters)
						
			#len(Query_Result) == 1 Record Found
			#len(Query_Result) == 0 Record Not Found
			if len(Query_Result) == 1: 
			
				Message_Type = Query_Result.getValueAt(0, "MessageType")
				
				ID = Query_Result.getValueAt(0, "ID")
				ConcatenatedRecordIDs =  Query_Result.getValueAt(0, "ConcatenatedRecordIDs")
				SAPClient = Query_Result.getValueAt(0, "SAPClient")
				SAPPlant = Query_Result.getValueAt(0, "SAPPlant")
				XML = Query_Result.getValueAt(0, "Message")
				
				#Increase Attempt Counter
				Attempt_Query_Parameters = {"database": Database, "SAPClient":SAPClient, "SAPPlant":SAPPlant, "Message_ID" : ConcatenatedRecordIDs}
				system.db.runNamedQuery("MII_Ignition_Queries/xMII_Message_Log/XMII_QUEUE_MESSAGE_LOG_INCREASE_ATTEMPT_COUNT", Attempt_Query_Parameters)
				
				
				#Execute XML Posting BLS Depending on MessageType
				if Message_Type == '<Phase_Status>' or Message_Type == 'Good Issues' or Message_Type == 'Production Report' or Message_Type == 'Machine_Status':
					
					BLS_Response, BLS_Status = MII_Ignition_Library.Production_Data.BLS.BLS_ProcessProductionDocuments(API_Protocol, API_Server, SAP_Status, MII_Status, MII_DB_Status, Database, SAPClient, SAPPlant, XML, Message_Type)
					Update_Response_Parameters = {"database": Database, "SAPClient":SAPClient, "SAPPlant":SAPPlant, "Message_ID" : ConcatenatedRecordIDs, "Response": BLS_Response}
					system.db.runNamedQuery("MII_Ignition_Queries/xMII_Message_Log/XMII_QUEUE_MESSAGE_LOG_UPDATE_MSG_RESPONSE", Update_Response_Parameters)
					
					#if BLS_Response == 'Success.':
					if BLS_Status == '1':
						
						Update_Query_Parameters = {"database": Database, "SAPClient":SAPClient, "SAPPlant":SAPPlant, "Message_ID" : ConcatenatedRecordIDs}
						system.db.runNamedQuery("MII_Ignition_Queries/xMII_Message_Log/XMII_QUEUE_MESSAGE_LOG_UPDATE_UNPROCESSED_MSG", Update_Query_Parameters)
					
				
				elif Message_Type == '<QUALITY_RESULTS>':
				
					BLS_Response, BLS_Status = MII_Ignition_Library.Production_Data.BLS.Post_Quality_Inspection_Record_Results_IGN_SAP(API_Protocol, API_Server, SAP_Status, MII_Status, MII_DB_Status, Database,  SAPClient, SAPPlant, XML)
					Update_Response_Parameters = {"database": Database, "SAPClient":SAPClient, "SAPPlant":SAPPlant, "Message_ID" : ConcatenatedRecordIDs, "Response": BLS_Response}
					system.db.runNamedQuery("MII_Ignition_Queries/xMII_Message_Log/XMII_QUEUE_MESSAGE_LOG_UPDATE_MSG_RESPONSE", Update_Response_Parameters)
					
					
					#if BLS_Response == 'Posted Completed':
					if BLS_Status == 'P':
						
						Update_Query_Parameters = {"database": Database, "SAPClient":SAPClient, "SAPPlant":SAPPlant, "Message_ID" : ConcatenatedRecordIDs}
						system.db.runNamedQuery("MII_Ignition_Queries/xMII_Message_Log/XMII_QUEUE_MESSAGE_LOG_UPDATE_UNPROCESSED_MSG", Update_Query_Parameters)	


	
def dbBrokerServiceByWorkCenter(Database, Client, Plant, API_Protocol, API_Server, Work_Center):
	#Get MII Status
	try:
		MII_Status_Response = system.net.httpGet(str(API_Protocol) + "://" + str(API_Server) + "/PR-CID/ShopFloor/MII_Data_Collection_Messages/api/MIIDataCollectionMessages/Get_BLS_DateTimePlant?SAP_CLIENT=" + str(Client) + "&SAP_PLANT=" + str(Plant))
	
		if len(MII_Status_Response) > 0:
			MII_Status = 1
		else:
			MII_Status = 0
	except:
		MII_Status = 0
		
	#Get SAP Status	
	try:
		SAP_Status_Response = system.net.httpGet(str(API_Protocol) + "://" + str(API_Server) + "/PR-CID/ShopFloor/MII_Data_Collection_Messages/api/MIIDataCollectionMessages/GET_SAP_MII_MPM_CPS_BLS_YPP_MII_GET_BIN_FOR_PSA?SAP_CLIENT=" + str(Client) + "&IV_LGNUM_wHouseNo=x&IV_MATNR=x&IV_PLANT=" + str(Plant) + "&IV_PRVBE_psaSupplyArea=x&jSon=true")
	
		if len(SAP_Status_Response) > 0:
			SAP_Status = 1
		else:
			SAP_Status = 0
	except:
		SAP_Status = 0	
		
	#Get MII Database Status
	try:
		MII_DB_Query_Parameters = {"database": Database}
		MII_DB_Response = system.db.runNamedQuery("MII_Ignition_Queries/Database_Status/Get_xMII_DB_Status", MII_DB_Query_Parameters)
		
		if MII_DB_Response:
			DB_Status = 1
		else:
			DB_Status = 0
	except:
		DB_Status = 0	
	
	
	
	
	if MII_Status == 1 and SAP_Status == 1 and DB_Status == 1:	
		#MII_Ignition_Library.Logger.Insert_Log.Insert_Info_Log('Single WC Broker Service', 'Working with ' + str(Work_Center))
		Query_Parameters = {"database": Database, "SAPClient":Client, "SAPPlant":Plant, "Work_Center":Work_Center}
				
		Query_Result = system.db.runNamedQuery("MII_Ignition_Queries/xMII_Message_Log/XMII_QUEUE_MESSAGE_LOG_GET_UNPROCESSED_MSG_BY_WC_1", Query_Parameters)
		
		#len(Query_Result) == 1 Record Found
		#len(Query_Result) == 0 Record Not Found
		if len(Query_Result) == 1: 
		
			MessageType = Query_Result.getValueAt(0, "MessageType")
			
			ID = Query_Result.getValueAt(0, "ID")
			ConcatenatedRecordIDs =  Query_Result.getValueAt(0, "ConcatenatedRecordIDs")
			SAPClient = Query_Result.getValueAt(0, "SAPClient")
			SAPPlant = Query_Result.getValueAt(0, "SAPPlant")
			XML = Query_Result.getValueAt(0, "Message")
			
			#Increase Attempt Counter
			Attempt_Query_Parameters = {"database": Database, "SAPClient":SAPClient, "SAPPlant":SAPPlant, "Message_ID" : ConcatenatedRecordIDs}
			system.db.runNamedQuery("MII_Ignition_Queries/xMII_Message_Log/XMII_QUEUE_MESSAGE_LOG_INCREASE_ATTEMPT_COUNT", Attempt_Query_Parameters)
			
			
			
			#Execute XML Posting BLS Depending on MessageType
			if MessageType == '<Phase_Status>' or MessageType == 'Good Issues' or MessageType == 'Production Report' or MessageType == 'Machine_Status':
				
				BLS_Response, BLS_Status = MII_Ignition_Library.Production_Data.BLS.BLS_ProcessProductionDocuments(API_Protocol, API_Server, SAP_Status, MII_Status, DB_Status, Database, Client, Plant, XML, MessageType)
				Update_Response_Parameters = {"database": Database, "SAPClient":SAPClient, "SAPPlant":SAPPlant, "Message_ID" : ConcatenatedRecordIDs, "Response": BLS_Response}
				system.db.runNamedQuery("MII_Ignition_Queries/xMII_Message_Log/XMII_QUEUE_MESSAGE_LOG_UPDATE_MSG_RESPONSE", Update_Response_Parameters)
											
				#if BLS_Response == 'Success.':
				if BLS_Status == '1':
					
					Update_Query_Parameters = {"database": Database, "SAPClient":SAPClient, "SAPPlant":SAPPlant, "Message_ID" : ConcatenatedRecordIDs}
					system.db.runNamedQuery("MII_Ignition_Queries/xMII_Message_Log/XMII_QUEUE_MESSAGE_LOG_UPDATE_UNPROCESSED_MSG", Update_Query_Parameters)
					
			
			elif MessageType == '<QUALITY_RESULTS>':
			
				BLS_Response, BLS_Status = MII_Ignition_Library.Production_Data.BLS.Post_Quality_Inspection_Record_Results_IGN_SAP(API_Protocol, API_Server, SAP_Status, MII_Status, DB_Status, Database,  SAPClient, SAPPlant, XML)
				Update_Response_Parameters = {"database": Database, "SAPClient":SAPClient, "SAPPlant":SAPPlant, "Message_ID" : ConcatenatedRecordIDs, "Response": BLS_Response}
				system.db.runNamedQuery("MII_Ignition_Queries/xMII_Message_Log/XMII_QUEUE_MESSAGE_LOG_UPDATE_MSG_RESPONSE", Update_Response_Parameters)
				
				
				#if BLS_Response == 'Posted Completed':
				if BLS_Status == 'P':
					
					Update_Query_Parameters = {"database": Database, "SAPClient":SAPClient, "SAPPlant":SAPPlant, "Message_ID" : ConcatenatedRecordIDs}
					system.db.runNamedQuery("MII_Ignition_Queries/xMII_Message_Log/XMII_QUEUE_MESSAGE_LOG_UPDATE_UNPROCESSED_MSG", Update_Query_Parameters)	