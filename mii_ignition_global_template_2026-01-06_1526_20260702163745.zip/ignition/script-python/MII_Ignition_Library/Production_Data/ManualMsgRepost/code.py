def RepostMessage(API_Protocol, API_Server, SAP_Status, MII_Status, DB_Status, Database, Client, Plant, ID, PO, XML, MessageType):
	import json
	import xml.etree.ElementTree as QR
	from datetime import datetime
	try:
		
		#Validate if Database Connection is Online
		if DB_Status == 1: #Database is Online
			
			# API URL Web Service
			API_URL = str(API_Protocol) + "://" + str(API_Server) + "/PR-CID/ShopFloor/MII_Data_Collection_Messages/api/MIIDataCollectionMessages/POST_PAWebApiWrapper"
			
			#Validate if SAP and MII Services are Online
			if SAP_Status == 1 and MII_Status == 1: #SAP and MII Services are Online 
				#Verify if Good Issue, to perform consumption validation before posting
				if MessageType == 'Good Issues':
					GI_Validation_Response = MII_Ignition_Library.Production_Data.Good_Issues.Check_Single_Consumption_Validation_XML(API_Protocol, API_Server, Client, Plant, XML)
					if GI_Validation_Response['status'] == '0':  #Consumption Validation Failed
						return GI_Validation_Response['message']
				
				### Wrapper XML Base ###
				Wrapper_XML = "<PaWebApiWrapper><SAP_CLIENT>" + str(Client) + "</SAP_CLIENT><SAP_PLANT>" + str(Plant) + "</SAP_PLANT><DOC_TYPE/><ID/><RETRY_LIMIT/><MESSAGENAME/><RECEIVED_DATE_START/><RECEIVED_TIME_START/><RECEIVED_DATE_END/><RECEIVED_TIME_END/><IDENTIFIER/><CATEGORY/><STATUS/><MESSAGEUID/><PROCESS_ORDER/><SAP_PO_STATUS/><NODE_NAME/><NODE_TYPE/><PHASE/><PHASE_STATUS/><Enable_Doc_Batch_PO_Header_XML/><Enable_Doc_Batch_BOM_XML/><Enable_Doc_Batch_Recipe_Header_XML/><Enable_Doc_Batch_Recipe_Steps_XML/><SAP_RESOURCE/><ROW_COUNT/><json>true</json><Body><MII_Update_File_Content><row><xml_File><ProcessProductionDocuments><ProductionMessage>" + str(XML) + "</ProductionMessage></ProcessProductionDocuments></xml_File></row></MII_Update_File_Content></Body><BlsName>BLS_ProcessProductionDocuments</BlsName></PaWebApiWrapper>"
				
				# Send HTTP Post Request
				connectTimeout = 5000
				readTimeout = (int(system.tag.readBlocking('[Shop_Floor]Coca-Cola/CPS/Site_Settings/General_Configuration/apiTimeoutDuration')[0].value)*60000)
				Response = system.net.httpPost(API_URL,"text/xml",Wrapper_XML,connectTimeout,readTimeout)
				
				# Convert HTTP Json response into dict
				Response_Dict = system.util.jsonDecode(Response) 
				Response_StatusText = Response_Dict['Rowset']['Row'][0]['STATUSTEXT']
				Response_Status = Response_Dict['Rowset']['Row'][0]['STATUS']
				
				if MessageType == '<SINGLE_RESULTS>' or MessageType == '<CHAR_RESULTS>' or MessageType == '<QUALITY_RESULTS>':
					# API URL Web Service
					url = str(API_Protocol) + "://" + str(API_Server) + "/PR-CID/ShopFloor/MII_Data_Collection_Messages/api/MIIDataCollectionMessages/Post_Quality_Inspection_Record_Results_IGN_SAP"
				   	
					# HTTP Post Request
					res = system.net.httpPost(url,"text/xml",XML)
					
					#MII Messge
					root = QR.fromstring(res)
					Response_Status = root[0][0][0][0][0].text
					Response_StatusText = root[0][0][0][0][1].text
					return Response_StatusText, Response_Status
					
				#Verify if HTTP Post succeded or failed
				if Response_Status == "1":
					#Dictionary for the table QUEUE MESSAGE LOG
					SQL_Parameters = {"database": Database, "ID": ID, "PO": PO, "Message": XML, "Processed":Response_Status, "Response":Response_StatusText}
					if MessageType == 'Good Issues':
						queryName="Monitoring/PostMessageTracking/UpdateGIMessageByPO"
					else:
						queryName="Monitoring/PostMessageTracking/UpdateMessageByPO"
					#Query to update table QUEUE MESSAGE LOG
					system.db.runNamedQuery(queryName, SQL_Parameters)
					return Response_StatusText, Response_Status #"Success."
					
				else: #Post Failed
					MII_Ignition_Library.Logger.Insert_Log.Insert_Error_Log(Client + "_" + Plant + "_" + "Manual_Message_Repost_XML", Response_StatusText)
					return Response_StatusText, Response_Status
			else: #Services are offline
				MII_Ignition_Library.Logger.Insert_Log.Insert_Error_Log(Client + "_" + Plant + "_" + "Manual_Message_Repost", "Error: SAP/MII Connection is Offline. Contact Automation Team for Support.")
				return "Error: SAP/MII Connection is Offline. Contact Automation Team for Support."
		else: #Database is Offline
			MII_Ignition_Library.Logger.Insert_Log.Insert_Error_Log(Client + "_" + Plant + "_" + "Manual_Message_Repost", "Error: Database Connection is Offline. Contact Automation Team for Support.")
			return "Error: Database Connection is Offline. Contact Automation Team for Support."	
	except:
		MII_Ignition_Library.Logger.Insert_Log.Insert_Error_Log(Client + "_" + Plant + "_" + "Manual_Message_Repost",  str(sys.exc_info()))
		return  str(sys.exc_info())