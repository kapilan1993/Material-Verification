def Post_Downtime(API_Protocol, API_Server, SAP_Status, MII_Status, DB_Status, Database, Messages_In_Queue_Flag, Client, Plant, PO, Work_Center, SAP_Resource_Name, Phase, Operation, Machine_Status, Reason_ID, Comment, User_ID, Event_Time, Area):
	import xml.etree.ElementTree as ET
	import json

	try: 
		
		#Validate if Database Connection is Online
		if DB_Status == 1: #Database is Online
						
												
			# API URL Web Service
			API_URL = str(API_Protocol) + "://" + str(API_Server) + "/PR-CID/ShopFloor/MII_Data_Collection_Messages/api/MIIDataCollectionMessages/POST_PAWebApiWrapper"
					
					
			### Create Machine Status XML ### 
				
			# Create the root element
			root = ET.Element("Machine_Status")
				
			# Create the 'row' element
			row = ET.SubElement(root, "row")
				
			# Create and fill the child elements
			sap_client_element = ET.SubElement(row, "SAPClient")
			sap_client_element.text = Client
				
			sap_plant_element = ET.SubElement(row, "SAPPlant")
			sap_plant_element.text = Plant
				
			sap_resource_name_element = ET.SubElement(row, "SAPResourceName")
			sap_resource_name_element.text = SAP_Resource_Name
				
			sap_machine_status_element = ET.SubElement(row, "MachineStatus")
			sap_machine_status_element.text = Machine_Status
				
			order_element = ET.SubElement(row, "Order")
			order_element.text = PO
				
			phase_element = ET.SubElement(row, "Phase")
			phase_element.text = Phase
				
			reason_id_element = ET.SubElement(row, "ReasonID")
			reason_id_element.text = Reason_ID
				
			event_time_element = ET.SubElement(row, "EventTime")
			event_time_element.text = Event_Time
				
			comment_element = ET.SubElement(row, "Comment")
			comment_element.text = Comment
				
			user_element = ET.SubElement(row, "User")
			user_element.text = User_ID
				
				
			# Create the XML string
			Machine_Status_XML = ET.tostring(root, encoding="utf-8", method="xml")
					
			# Convert bytes to string
			Machine_Status_XML = Machine_Status_XML.decode("utf-8")
		
		
			#Validate if SAP and MII Services are Online
			if SAP_Status == 1 and MII_Status == 1 and Messages_In_Queue_Flag == False: #SAP and MII Services are Online / No Pending Messages in Queue
		
				### Wrapper XML Base ###
				Machine_Status_Wrapper_XML = "<PaWebApiWrapper><SAP_CLIENT>" + str(Client) + "</SAP_CLIENT><SAP_PLANT>" + str(Plant) + "</SAP_PLANT><DOC_TYPE/><ID/><RETRY_LIMIT/><MESSAGENAME/><RECEIVED_DATE_START/><RECEIVED_TIME_START/><RECEIVED_DATE_END/><RECEIVED_TIME_END/><IDENTIFIER/><CATEGORY/><STATUS/><MESSAGEUID/><PROCESS_ORDER/><SAP_PO_STATUS/><NODE_NAME/><NODE_TYPE/><PHASE/><PHASE_STATUS/><Enable_Doc_Batch_PO_Header_XML/><Enable_Doc_Batch_BOM_XML/><Enable_Doc_Batch_Recipe_Header_XML/><Enable_Doc_Batch_Recipe_Steps_XML/><SAP_RESOURCE/><ROW_COUNT/><json>true</json><Body><MII_Update_File_Content><row><xml_File><ProcessProductionDocuments><ProductionMessage>" + str(Machine_Status_XML) + "</ProductionMessage></ProcessProductionDocuments></xml_File></row></MII_Update_File_Content></Body><BlsName>BLS_ProcessProductionDocuments</BlsName></PaWebApiWrapper>"
			
				# Send HTTP Post Request
				Machine_Status_Response = system.net.httpPost(API_URL,"text/xml",Machine_Status_Wrapper_XML)
				
				# Convert HTTP Json response into dict
				Machine_Status_Response_Dict = system.util.jsonDecode(Machine_Status_Response) 
				Machine_Status_Response_StatusText = Machine_Status_Response_Dict['Rowset']['Row'][0]['STATUSTEXT']
				Machine_Status_Response_Status = Machine_Status_Response_Dict['Rowset']['Row'][0]['STATUS']
				
				
				#Verify if HTTP Post succeded or failed
				if Machine_Status_Response_Status == "1":
					
					#Dictionary for the table QUEUE MESSAGE LOG
					SQL_Parameters = {"database": Database, "SAPClient": Client, "SAPPlant": Plant, "Work_Center":Work_Center, "SAPResourceName": SAP_Resource_Name, "ProcessOrder": PO , "Operation": Operation, "Phase": Phase, "Message": Machine_Status_XML, "Response" : Machine_Status_Response_StatusText, "EventTime" : Event_Time,  "MessageType": "Machine_Status", "Processed":Machine_Status_Response_Status, "INSPCHAR": "","Area":Area,"UpdatedBy":User_ID}
													
					#Query to update table QUEUE MESSAGE LOG
					system.db.runNamedQuery("MII_Ignition_Queries/xMII_Message_Log/XMII_QUEUE_MESSAGE_LOG_INSERT", SQL_Parameters)
					
					return "Success."
					
				else: #Post Failed
					
					MII_Ignition_Library.Logger.Insert_Log.Insert_Error_Log(Client + "_" + Plant + "_" + "Post_Downtime", "PO: " + PO + " Resource: " + SAP_Resource_Name + " " +  Machine_Status_Response_StatusText)
					return Machine_Status_Response_StatusText


			else: #Post directly into Database due to SAP or MII Service Offline / Pending Messages in Queue
				### Insert into Database ###
				
				#Dictionary for the table QUEUE MESSAGE LOG
				SQL_Parameters = {"database": Database ,"SAPClient":Client, "SAPPlant":Plant, "Work_Center":Work_Center, "SAPResourceName": SAP_Resource_Name, "ProcessOrder": PO , "Operation": Operation, "Phase": Phase, "Message":  Machine_Status_XML,  "Response" : "", "EventTime" : Event_Time, "MessageType": "Machine_Status",  "Processed": "0", "INSPCHAR": "","Area":Area,"UpdatedBy":User_ID}
			
				#Query to update table QUEUE MESSAGE LOG
				system.db.runNamedQuery("MII_Ignition_Queries/xMII_Message_Log/XMII_QUEUE_MESSAGE_LOG_INSERT", SQL_Parameters)
				
				return "Success."


		else: #Database is Offline
			return "Error: Database Connection is Offline. Contact Automation Team for Support."	
	
	
	except:
		MII_Ignition_Library.Logger.Insert_Log.Insert_Error_Log(str(Client) + "_" + str(Plant) + "_" + "Post_Downtime", "Error: MII_Ignition_Library.Production_Data.Downtime.Post_Downtime has failed. Check logger for details. PO: " + PO + " , Resource: " + SAP_Resource_Name)
		return "Error: MII_Ignition_Library.Production_Data.Downtime.Post_Downtime has failed. Check logger for details."




def Create_Downtime_XML(Client, Plant, PO, SAP_Resource_Name, Phase, Operation, Machine_Status, Reason_ID, Comment, User_ID, Event_Time):
	import xml.etree.ElementTree as ET
	
	try:
	
		### Create Machine Status XML ### 
						
		# Create the root element
		root = ET.Element("Machine_Status")
			
		# Create the 'row' element
		row = ET.SubElement(root, "row")
			
		# Create and fill the child elements
		sap_client_element = ET.SubElement(row, "SAPClient")
		sap_client_element.text = Client
			
		sap_plant_element = ET.SubElement(row, "SAPPlant")
		sap_plant_element.text = Plant
			
		sap_resource_name_element = ET.SubElement(row, "SAPResourceName")
		sap_resource_name_element.text = SAP_Resource_Name
			
		sap_machine_status_element = ET.SubElement(row, "MachineStatus")
		sap_machine_status_element.text = Machine_Status
			
		order_element = ET.SubElement(row, "Order")
		order_element.text = PO
			
		phase_element = ET.SubElement(row, "Phase")
		phase_element.text = Phase
			
		reason_id_element = ET.SubElement(row, "ReasonID")
		reason_id_element.text = Reason_ID
			
		event_time_element = ET.SubElement(row, "EventTime")
		event_time_element.text = Event_Time
			
		comment_element = ET.SubElement(row, "Comment")
		comment_element.text = Comment
			
		user_element = ET.SubElement(row, "User")
		user_element.text = User_ID
			
			
		# Create the XML string
		Machine_Status_XML = ET.tostring(root, encoding="utf-8", method="xml")
				
		# Convert bytes to string
		xml_str = Machine_Status_XML.decode("utf-8")
		
		return xml_str
	
	except:
		MII_Ignition_Library.Logger.Insert_Log.Insert_Error_Log(str(Client) + "_" + str(Plant) + "_" + "Create_Phase_Status_XML", "Error: MII_Ignition_Library.Downtime.Create_Downtime_XML has failed. Check logger for details.")
		return "Error: MII_Ignition_Library.Downtime.Create_Downtime_XML has failed. Check logger for details."	
		
		
		
		
		



def Post_Auto_Downtime(API_Protocol, API_Server, SAP_Status, MII_Status, DB_Status, Database, Messages_In_Queue_Flag, Client, Plant, PO, Work_Center, SAP_Resource_Name, Phase, Operation, Machine_Status_1, Machine_Status_2, Reason_ID, Comment, Start_Event_Time, End_Event_Time, User_ID, Area):
	try:
		#Send UNSCHEDDOWN															
		UNSCHEDDOWN_Response = MII_Ignition_Library.Production_Data.Downtime.Post_Downtime(API_Protocol, API_Server, SAP_Status, MII_Status, DB_Status, Database, Messages_In_Queue_Flag, Client, Plant, PO, Work_Center, SAP_Resource_Name, Phase, Operation, Machine_Status_1, Reason_ID, Comment, User_ID, Start_Event_Time, Area)
		
		#Send UPTIME
		UPTIME_Response = MII_Ignition_Library.Production_Data.Downtime.Post_Downtime(API_Protocol, API_Server, SAP_Status, MII_Status, DB_Status, Database, Messages_In_Queue_Flag, Client, Plant, PO, Work_Center, SAP_Resource_Name, Phase, Operation, Machine_Status_2, Reason_ID, Comment, User_ID, End_Event_Time, Area)
		
		
		if UNSCHEDDOWN_Response != "Success.":
			MII_Ignition_Library.Logger.Insert_Log.Insert_Error_Log(Client + "_" + Plant + "_" + "Post_Auto_Downtime", "PO: " + PO + " Resource: " + SAP_Resource_Name + " " +  UNSCHEDDOWN_Response)
		
		if UPTIME_Response != "Success.":
			MII_Ignition_Library.Logger.Insert_Log.Insert_Error_Log(Client + "_" + Plant + "_" + "Post_Auto_Downtime", "PO: " + PO + " Resource: " + SAP_Resource_Name + " " +  UPTIME_Response)
		
		return "Success."
		
	#except:
		#MII_Ignition_Library.Logger.Insert_Log.Insert_Error_Log(Client + "_" + Plant + "_" + "Post_Auto_Downtime", "Error: MII_Ignition_Library.Production_Data.Downtime.Post_Auto_Downtime has failed. Check logger for details. PO: " + PO + " , Resource: " + SAP_Resource_Name)
		#return "Error: MII_Ignition_Library.Production_Data.Downtime.Post_Auto_Downtime has failed. Check logger for details."	
	except Exception as e:
		Status = e
		return Status
		MII_Ignition_Library.Logger.Insert_Log.Insert_Error_Log(str(Client) + "_" + str(Plant) + "_" + "Post_Auto_Downtime", Status)		
		
		
def Search_Downtime_ID(MII_Download_XML, Description):
	try:
		#Variables
		Json_Data = MII_Download_XML
		
		#Searching for RC_ID where DESCRIPTION is 'SETUP & ADJUSTMENTS'
		reasonID = None
		rows = Json_Data['DOWNLOAD_RECIPE']['DOWNTIME_CODES_LIST']['Rowsets']['Rowset']['Row']
		
		for row in rows:
		    if row['DESCRIPTION'] == str(Description):
		        reasonID = row['RC_ID']
		        break
		return str(reasonID) 
		
	except:
		MII_Ignition_Library.Logger.Insert_Log.Insert_Error_Log(str(Client) + "_" + str(Plant) + "_" + "Search_Downtime_ID", "Error: MII_Ignition_Library.Production_Data.Downtime.Search_Downtime_ID has failed. Check logger for details.")
		return "Error: MII_Ignition_Library.Production_Data.Downtime.Search_Downtime_ID has failed. Check logger for details."
		
			
				
		
def Search_Downtime_Description(MII_Download_XML, RC_ID):
	try:
		#Variables
		Json_Data = MII_Download_XML
		
		#Searching for RC_ID where DESCRIPTION is 'SETUP & ADJUSTMENTS'
		reasonID = None
		rows = Json_Data['DOWNLOAD_RECIPE']['DOWNTIME_CODES_LIST']['Rowsets']['Rowset']['Row']
		
		for row in rows:
			if row['RC_ID'] == str(RC_ID):
				Description = row['DESCRIPTION']
				break
		return str(Description) 
		
	except:
		MII_Ignition_Library.Logger.Insert_Log.Insert_Error_Log(str(Client) + "_" + str(Plant) + "_" + "Search_Downtime_Description", "Error: MII_Ignition_Library.Production_Data.Downtime.Search_Downtime_Description has failed. Check logger for details.")
		return "Error: MII_Ignition_Library.Production_Data.Downtime.Search_Downtime_Description has failed. Check logger for details."							
		
		
		
		
def GetResourceLastMachineStatusEventTime(Database, Client, Plant, Order, SAPResourceName):
	try:
	
		Query_Parameters = {"database": Database, "Client": Client, "Plant":Plant, "Order": Order, "SAPResourceName": SAPResourceName}
		Query_Result = system.db.runNamedQuery("MII_Ignition_Queries/Machine_Status/GetMachineStatusLastByResource", Query_Parameters)
		
		if len(Query_Result) == 1: 
		    LatestDowntimeEvent = Query_Result.getValueAt(0, "Event_Time")
		else:
		    LatestDowntimeEvent = None
		    
		return LatestDowntimeEvent
		
	except Exception as e:
		Status = e
		return Status
		MII_Ignition_Library.Logger.Insert_Log.Insert_Error_Log(str(Client) + "_" + str(Plant) + "_" + "GetResourceLastMachineStatusEventTime", Status)	
	
		
			
					
def GetResourceLastMachineStatusReasonCode(Database, Client, Plant, Order, SAPResourceName):
	try:
	
		Query_Parameters = {"database": Database, "Client": Client, "Plant":Plant, "Order": Order, "SAPResourceName": SAPResourceName}
		Query_Result = system.db.runNamedQuery("MII_Ignition_Queries/Machine_Status/GetMachineStatusLastByResource", Query_Parameters)
		
		if len(Query_Result) == 1: 
		    downtimeReasonCode = Query_Result.getValueAt(0, "Reason_ID")
		else:
		    downtimeReasonCode = -1
		    
		return downtimeReasonCode
		
	except Exception as e:
		Status = e
		return Status
		MII_Ignition_Library.Logger.Insert_Log.Insert_Error_Log(str(Client) + "_" + str(Plant) + "_" + "GetResourceLastMachineStatusReasonCode", Status)