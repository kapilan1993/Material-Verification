def BLS_ProcessProductionDocuments(API_Protocol, API_Server, SAP_Status, MII_Status, DB_Status, Database, Client, Plant, XML, MessageType):
	#BLS USED TO POST:
	# Phase Status
	# Good Issues
	# Production Report
	# Machine Status
		
	import json

	try: 
		
		#Validate if Database Connection is Online
		if DB_Status == 1: #Database is Online
						
												
			# API URL Web Service
			API_URL = str(API_Protocol) + "://" + str(API_Server) + "/PR-CID/ShopFloor/MII_Data_Collection_Messages/api/MIIDataCollectionMessages/POST_PAWebApiWrapper"
					
					
			#Validate if SAP and MII Services are Online
			if SAP_Status == 1 and MII_Status == 1: #SAP and MII Services are Online 
		
		
				#Verify if Good Issue, to perform consumption validation before posting
				if MessageType == 'Good Issues':
					GI_Validation_Response = MII_Ignition_Library.Production_Data.Good_Issues.Check_Single_Consumption_Validation_XML(API_Protocol, API_Server, Client, Plant, XML)
					#MII_Ignition_Library.Logger.Insert_Log.Insert_Error_Log('Auto GI BLS', "gi validation : "+str(GI_Validation_Response))
					if GI_Validation_Response['status'] == '0':  #Consumption Validation Failed
						return GI_Validation_Response['message']
		
		
		
				### Wrapper XML Base ###
				Wrapper_XML = "<PaWebApiWrapper><SAP_CLIENT>" + str(Client) + "</SAP_CLIENT><SAP_PLANT>" + str(Plant) + "</SAP_PLANT><DOC_TYPE/><ID/><RETRY_LIMIT/><MESSAGENAME/><RECEIVED_DATE_START/><RECEIVED_TIME_START/><RECEIVED_DATE_END/><RECEIVED_TIME_END/><IDENTIFIER/><CATEGORY/><STATUS/><MESSAGEUID/><PROCESS_ORDER/><SAP_PO_STATUS/><NODE_NAME/><NODE_TYPE/><PHASE/><PHASE_STATUS/><Enable_Doc_Batch_PO_Header_XML/><Enable_Doc_Batch_BOM_XML/><Enable_Doc_Batch_Recipe_Header_XML/><Enable_Doc_Batch_Recipe_Steps_XML/><SAP_RESOURCE/><ROW_COUNT/><json>true</json><Body><MII_Update_File_Content><row><xml_File><ProcessProductionDocuments><ProductionMessage>" + str(XML) + "</ProductionMessage></ProcessProductionDocuments></xml_File></row></MII_Update_File_Content></Body><BlsName>BLS_ProcessProductionDocuments</BlsName></PaWebApiWrapper>"
			
				# Send HTTP Post Request
				connectTimeout = 5000
				readTimeout = (int(system.tag.readBlocking('[Shop_Floor]Coca-Cola/CPS/Site_Settings/General_Configuration/apiTimeoutDuration')[0].value)*60000)
				Response = system.net.httpPost(API_URL,"text/xml",Wrapper_XML,connectTimeout,readTimeout)
				
				# Convert HTTP Json response into dict
				Response_Dict = system.util.jsonDecode(Response) 
				Response_StatusText = Response_Dict['Rowset']['Row'][0]['STATUSTEXT']
				Response_Status = Response_Dict['Rowset']['Row'][0]['STATUS']
				
				#MII_Ignition_Library.Logger.Insert_Log.Insert_Error_Log('Auto GI BLS', "msg resp sts : "+str(Response_StatusText)+"----"+str(Response_Status))
				#Verify if HTTP Post succeded or failed
				if Response_Status == "1":
					
					#Dictionary for the table QUEUE MESSAGE LOG
					#SQL_Parameters = {"database": Database, "SAPClient": Client, "SAPPlant": Plant, "SAPResourceName": SAP_Resource_Name, "ProcessOrder": PO , "Operation": Operation, "Phase": Phase, "Message": Machine_Status_XML,"EventTime" : Event_Time,  "MessageType": "Machine_Status", "Processed":Machine_Status_Response_Status, "INSPCHAR": ""}
													
					#Query to update table QUEUE MESSAGE LOG
					#system.db.runNamedQuery("MII_Ignition_Queries/xMII_Message_Log/XMII_QUEUE_MESSAGE_LOG_INSERT", SQL_Parameters)
					MII_Ignition_Library.Logger.Insert_Log.Insert_Error_Log('Auto GI BLS', "msg resp sts : "+str(Response_StatusText)+"----"+str(Response_Status))
					return Response_StatusText, Response_Status #"Success."
					
				else: #Post Failed
					
					MII_Ignition_Library.Logger.Insert_Log.Insert_Error_Log(Client + "_" + Plant + "_" + "Post_XML", Response_StatusText)
					return Response_StatusText, Response_Status


			else: #Services are offline
				None


		else: #Database is Offline
			return "Error: Database Connection is Offline. Contact Automation Team for Support."	
	
	
	except:
		MII_Ignition_Library.Logger.Insert_Log.Insert_Error_Log(Client + "_" + Plant + "_" + "BLS_ProcessProductionDocuments", "Error: MII_Ignition_Library.Production_Data.BLS.BLS_ProcessProductionDocuments has failed. Check logger for details.")
		return "Error: MII_Ignition_Library.Production_Data.BLS.BLS_ProcessProductionDocuments has failed. Check logger for details."
		
	
		
				

def Post_Quality_Inspection_Record_Results_IGN_SAP(API_Protocol, API_Server, SAP_Status, MII_Status, DB_Status, Database, Client, Plant, XML):
	import xml.etree.ElementTree as QR
	try:
	
		#Validate if Database Connection is Online
		if DB_Status == 1: #Database is Online
		

			#Validate if SAP and MII Services are Online
			if SAP_Status == 1 and MII_Status == 1: #SAP and MII Services are Online 
			
				#Submit Quality Inspection
				
				# API URL Web Service
				url = str(API_Protocol) + "://" + str(API_Server) + "/PR-CID/ShopFloor/MII_Data_Collection_Messages/api/MIIDataCollectionMessages/Post_Quality_Inspection_Record_Results_IGN_SAP"
			   	
			   	
				# HTTP Post Request
				res = system.net.httpPost(url,"text/xml",XML)
				
			
				#MII Messge
				root = QR.fromstring(res)
				MII_Status = root[0][0][0][0][0].text
				MII_Message = root[0][0][0][0][1].text
				
				if MII_Status == 'P':
					MII_Message = 'Posted Completed' 
					Processed_Status = '1'
				else:
					Processed_Status = '0'
					
				
				
				#Dictionary for the table QUEUE MESSAGE LOG
				#parameters_Quality = {"database": Database,"SAPClient":Client, "SAPPlant":Plant, "SAPResourceName":SAP_Resource_Name, "ProcessOrder":PO , "Operation": Operation, "Phase": Phase, "Message": QCParameters_XML, "EventTime" : Event_Time , "MessageType": "<QUALITY_RESULTS>","Processed":Processed_Status,  "INSPCHAR": ""}
				
				#Query to update table QUEUE MESSAGE LOG
				#system.db.runNamedQuery("MII_Ignition_Queries/xMII_Message_Log/XMII_QUEUE_MESSAGE_LOG_INSERT", parameters_Quality)
				
				return MII_Message,MII_Status
				
					
					
					
					
			else: #SAP or MII Service Offline
				None
		
		
		else: #Database is Offline
			return "Error: Database Connection is Offline. Contact Automation Team for Support."	
	
	
		
	except:
		MII_Ignition_Library.Logger.Insert_Log.Insert_Error_Log(Client + "_" + Plant + "_" + "Post_Quality_Inspection_Record_Results_IGN_SAP", "Error: MII_Ignition_Library.Production_Data.BLS.Post_Quality_Inspection_Record_Results_IGN_SAP has failed. Check logger for details.")
		return "Error: MII_Ignition_Library.Production_Data.BLS.Post_Quality_Inspection_Record_Results_IGN_SAP has failed. Check logger for details."	
			