def Post_GoodIssue(Tag_Provider, API_Protocol, API_Server, SAP_Status, MII_Status, DB_Status, Database, Messages_In_Queue_Flag, Client, Plant, Work_Center, SAP_Resource_Name, Nodename, Node_ID, PO, Phase, Operation, EventTime, User_ID, Material, Quantity, UOM, Batch_Number, Storage_Location, Reason_For_Movement, Movement_Type, Final_Issue, Resb_Pos, Area):
	import xml.etree.ElementTree as ET
	import json
	Json = "True"
	
	try:
	
		#Validate if Database Connection is Online
		if DB_Status == 1: #Database is Online
		
		
		
			### Starting the development of the XML  ###
								
			# Create the root element
			root = ET.Element("Goods_Issue")
			
			# Create the 'row' element
			row = ET.SubElement(root, "row")
			
			# Create and fill the child elements
			sap_client_element = ET.SubElement(row, "SAPClient")
			sap_client_element.text = Client
			
			sap_plant_element = ET.SubElement(row, "SAPPlant")
			sap_plant_element.text = Plant
			
			sap_resource_name_element = ET.SubElement(row, "SAPResourceName")
			sap_resource_name_element.text = SAP_Resource_Name
			
			sap_node_name_element = ET.SubElement(row, "NodeName")
			sap_node_name_element.text = Nodename
			
			sap_node_id_element = ET.SubElement(row, "NodeID")
			sap_node_id_element.text = Node_ID
			
			order_element = ET.SubElement(row, "Order")
			order_element.text = PO
			
			phase_element = ET.SubElement(row, "Phase")
			phase_element.text = Phase
			
			event_time_element = ET.SubElement(row, "EventTime")
			event_time_element.text = EventTime
			
			user_element = ET.SubElement(row, "User")
			user_element.text = User_ID
			
			
			items_element = ET.SubElement(row, "Items")
			
			item1_element = ET.SubElement(items_element, "Item")
			
			
			
			matnr_element = ET.SubElement(item1_element, "Matnr")
			matnr_element.text = Material
			
			quantity_element = ET.SubElement(item1_element, "Quantity")
			quantity_element.text = Quantity
			
			uom_element = ET.SubElement(item1_element, "UOM")
			uom_element.text = UOM
			
			batchnr_element  = ET.SubElement(item1_element, "Batchnr")
			batchnr_element.text = Batch_Number
			
			storage_loc_element = ET.SubElement(item1_element, "StorageLocation")
			storage_loc_element.text = Storage_Location
			
			reason_for_move_element = ET.SubElement(item1_element, "ReasonForMove")
			reason_for_move_element.text = Reason_For_Movement
			
			movement_type_element = ET.SubElement(item1_element, "MovementType")
			movement_type_element.text = Movement_Type
			
			final_issue_element = ET.SubElement(item1_element, "FinalIssue")
			final_issue_element.text = Final_Issue
			
			resb_pos_element = ET.SubElement(item1_element, "Resb_Pos")
			resb_pos_element.text = Resb_Pos
			
			
			# Create the XML string
			xml_str = ET.tostring(root, encoding="utf-8", method="xml")
				
			# Convert bytes to string
			xml_str = xml_str.decode("utf-8")
		
		
		
		
			#Validate if SAP and MII Services are Online
			if SAP_Status == 1 and MII_Status == 1 and Messages_In_Queue_Flag == False: #SAP and MII Services are Online / No Pending Messages in Queue
			
				#Check Consumption Validation
				Validation_Response = MII_Ignition_Library.Production_Data.Good_Issues.Check_Single_Consumption_Validation(API_Server, Client, Plant, PO, SAP_Resource_Name, Node_ID, Nodename, Phase, EventTime, Material, Quantity, UOM, Batch_Number, Storage_Location, Reason_For_Movement, Movement_Type, Final_Issue, Resb_Pos, Json)
				message = Validation_Response['message']
				
				#Verify if Consumption Validation Passed of Failed
				if Validation_Response['status'] == '1':  #Passed
					
					
					### Submit Good Issue ###
					
					# API URL Web Service
					url = str(API_Protocol) + "://" + str(API_Server) + "/PR-CID/ShopFloor/MII_Data_Collection_Messages/api/MIIDataCollectionMessages/POST_PAWebApiWrapper"
					
					Wrapper_XML_Message = "<PaWebApiWrapper><SAP_CLIENT>" + str(Client) + "</SAP_CLIENT><SAP_PLANT>" + str(Plant) + "</SAP_PLANT><DOC_TYPE/><ID/><RETRY_LIMIT/><MESSAGENAME/><RECEIVED_DATE_START/><RECEIVED_TIME_START/><RECEIVED_DATE_END/><RECEIVED_TIME_END/><IDENTIFIER/><CATEGORY/><STATUS/><MESSAGEUID/><PROCESS_ORDER/><SAP_PO_STATUS/><NODE_NAME/><NODE_TYPE/><PHASE/><PHASE_STATUS/><Enable_Doc_Batch_PO_Header_XML/><Enable_Doc_Batch_BOM_XML/><Enable_Doc_Batch_Recipe_Header_XML/><Enable_Doc_Batch_Recipe_Steps_XML/><SAP_RESOURCE/><ROW_COUNT/><json>true</json><Body><MII_Update_File_Content><row><xml_File><ProcessProductionDocuments><ProductionMessage>" + xml_str + "</ProductionMessage></ProcessProductionDocuments></xml_File></row></MII_Update_File_Content></Body><BlsName>BLS_ProcessProductionDocuments</BlsName></PaWebApiWrapper>"    
							
					# HTTP Post Request
					res = system.net.httpPost(url,"text/xml", Wrapper_XML_Message)
					 
					#Place the result in a custom property
					Good_Issue_Response = system.util.jsonDecode(res)
				
					rowset = Good_Issue_Response['Rowset']
					row = rowset['Row'][0]  
					
					#MII Messge
					MII_Message = row['STATUSTEXT'] 
					
					#The status of the MII post will be used as parameter for the SQL insert
					MII_Status = row['STATUS'] 
				
					
					if MII_Status == "1":
						### Insert into Database ###
						
						#Dictionary for the table QUEUE MESSAGE LOG
						SQL_Parameters = {"database": Database ,"SAPClient":Client, "SAPPlant":Plant, "Work_Center":Work_Center, "SAPResourceName": SAP_Resource_Name, "ProcessOrder": PO , "Operation": Operation, "Phase": Phase, "Message":  xml_str, "Response" : MII_Message, "EventTime" : EventTime, "Processed": MII_Status, "MessageType": "Good Issues", "INSPCHAR": "","Area":Area,"UpdatedBy":User_ID}
										 
					
						#Query to update table QUEUE MESSAGE LOG
						system.db.runNamedQuery("MII_Ignition_Queries/xMII_Message_Log/XMII_QUEUE_MESSAGE_LOG_INSERT_AUTO_GI", SQL_Parameters)
						
						#Dictionary for the table QUEUE MESSAGE HISTORY

						SQL_Parameters1 = {"database": Database ,"SAPClient":Client, "SAPPlant":Plant, "Work_Center":Work_Center, "SAPResourceName": SAP_Resource_Name, "ProcessOrder": PO , "Operation": Operation, "Phase": Phase, "Message":  xml_str, "Response" : MII_Message, "EventTime" : EventTime, "Processed": MII_Status, "MessageType": "Good Issues", "INSPCHAR": "","Area":Area, "API_Response_Message":message, "Updated_By":User_ID}
											
						#Query to update table QUEUE MESSAGE HISTORY
						system.db.runNamedQuery("MII_Ignition_Queries/xMII_Message_Log/XMII_QUEUE_MESSAGE_LOG_INSERT_HISTORY", SQL_Parameters1)
						
						#Update MII_Posting UDT 	
						MII_Ignition_Library.Production_Data.Populate_MII_Posting.GoodIssuePosting(Tag_Provider, Client, Plant, Work_Center, Area, xml_str)		
													
													
					return MII_Message
					
				
				
				
				else: #Consumption Validation Failed
				
					#Dictionary for the table QUEUE MESSAGE HISTORY
	
					SQL_Parameters1 = {"database": Database ,"SAPClient":Client, "SAPPlant":Plant, "Work_Center":Work_Center, "SAPResourceName": SAP_Resource_Name, "ProcessOrder": PO , "Operation": Operation, "Phase": Phase, "Message":  xml_str, "Response" : "Failed!", "EventTime" : EventTime, "Processed": MII_Status, "MessageType": "Good Issues", "INSPCHAR": "","Area":Area, "API_Response_Message":message, "Updated_By":User_ID}
										
					#Query to update table QUEUE MESSAGE HISTORY
					system.db.runNamedQuery("MII_Ignition_Queries/xMII_Message_Log/XMII_QUEUE_MESSAGE_LOG_INSERT_HISTORY", SQL_Parameters1)
										
					return "Consumption Validation Failed: " + Validation_Response["message"]
					
					
					
					
			else: #Post directly into Database due to SAP or MII Service Offline / Pending Messages in Queue
				### Insert into Database ###
				
				#Dictionary for the table QUEUE MESSAGE LOG
				SQL_Parameters = {"database": Database ,"SAPClient":Client, "SAPPlant":Plant, "Work_Center":Work_Center, "SAPResourceName": SAP_Resource_Name, "ProcessOrder": PO , "Operation": Operation, "Phase": Phase, "Message":  xml_str, "Response" : "Failed!", "EventTime" : EventTime, "Processed": "0", "MessageType": "Good Issues", "INSPCHAR": "","Area":Area,"UpdatedBy":User_ID}
			
				#Query to update table QUEUE MESSAGE LOG
				system.db.runNamedQuery("MII_Ignition_Queries/xMII_Message_Log/XMII_QUEUE_MESSAGE_LOG_INSERT_AUTO_GI", SQL_Parameters)
				
				#Dictionary for the table QUEUE MESSAGE HISTORY
				
				SQL_Parameters1 = {"database": Database ,"SAPClient":Client, "SAPPlant":Plant, "Work_Center":Work_Center, "SAPResourceName": SAP_Resource_Name, "ProcessOrder": PO , "Operation": Operation, "Phase": Phase, "Message":  xml_str, "Response" : "Failed!", "EventTime" : EventTime, "Processed": "0", "MessageType": "Good Issues", "INSPCHAR": "","Area":Area, "API_Response_Message":"SAP/MII is offline", "Updated_By":User_ID}
									
				#Query to update table QUEUE MESSAGE HISTORY
				system.db.runNamedQuery("MII_Ignition_Queries/xMII_Message_Log/XMII_QUEUE_MESSAGE_LOG_INSERT_HISTORY", SQL_Parameters1)
				
				return "Success."
		
		
		else: #Database is Offline
			return "Error: Database Connection is Offline. Contact Automation Team for Support."	
	
	
	except:
		MII_Ignition_Library.Logger.Insert_Log.Insert_Error_Log(Client + "_" + Plant + "_" + "Post_GoodIssue", "Error: MII_Ignition_Library.Production_Data.Good_Issues.Post_GoodIssue has failed. Check logger for details."+str(sys.exc_info()))
		return "Error: MII_Ignition_Library.Production_Data.Good_Issues.Post_GoodIssue has failed. Check logger for details."	
	
	
	
	
def Create_Good_Issue_XML(Client, Plant, SAP_Resource_Name, Nodename, Node_ID, PO, Phase, Operation, EventTime, User_ID, Material, Quantity, UOM, Batch_Number, Storage_Location, Reason_For_Movement, Movement_Type, Final_Issue, Resb_Pos):
	import xml.etree.ElementTree as ET
	
	try:
	
		### Starting the development of the XML  ###
									
		# Create the root element
		root = ET.Element("Goods_Issue")
		
		# Create the 'row' element
		row = ET.SubElement(root, "row")
		
		# Create and fill the child elements
		sap_client_element = ET.SubElement(row, "SAPClient")
		sap_client_element.text = Client
		
		sap_plant_element = ET.SubElement(row, "SAPPlant")
		sap_plant_element.text = Plant
		
		sap_resource_name_element = ET.SubElement(row, "SAPResourceName")
		sap_resource_name_element.text = SAP_Resource_Name
		
		sap_node_name_element = ET.SubElement(row, "NodeName")
		sap_node_name_element.text = Nodename
		
		sap_node_id_element = ET.SubElement(row, "NodeID")
		sap_node_id_element.text = Node_ID
		
		order_element = ET.SubElement(row, "Order")
		order_element.text = PO
		
		phase_element = ET.SubElement(row, "Phase")
		phase_element.text = Phase
		
		event_time_element = ET.SubElement(row, "EventTime")
		event_time_element.text = EventTime
		
		user_element = ET.SubElement(row, "User")
		user_element.text = User_ID
		
		
		items_element = ET.SubElement(row, "Items")
		
		item1_element = ET.SubElement(items_element, "Item")
		
		
		
		matnr_element = ET.SubElement(item1_element, "Matnr")
		matnr_element.text = Material
		
		quantity_element = ET.SubElement(item1_element, "Quantity")
		quantity_element.text = Quantity
		
		uom_element = ET.SubElement(item1_element, "UOM")
		uom_element.text = UOM
		
		batchnr_element  = ET.SubElement(item1_element, "Batchnr")
		batchnr_element.text = Batch_Number
		
		storage_loc_element = ET.SubElement(item1_element, "StorageLocation")
		storage_loc_element.text = Storage_Location
		
		reason_for_move_element = ET.SubElement(item1_element, "ReasonForMove")
		reason_for_move_element.text = Reason_For_Movement
		
		movement_type_element = ET.SubElement(item1_element, "MovementType")
		movement_type_element.text = Movement_Type
		
		final_issue_element = ET.SubElement(item1_element, "FinalIssue")
		final_issue_element.text = Final_Issue
		
		resb_pos_element = ET.SubElement(item1_element, "Resb_Pos")
		resb_pos_element.text = Resb_Pos
		
		
		# Create the XML string
		xml_str = ET.tostring(root, encoding="utf-8", method="xml")
			
		# Convert bytes to string
		xml_str = xml_str.decode("utf-8")
		
		return xml_str
	
	except:
		MII_Ignition_Library.Logger.Insert_Log.Insert_Error_Log(Client + "_" + Plant + "_" + "Create_Phase_Status_XML", "Error: MII_Ignition_Library.Production_Data.Good_Issues.Create_Good_Issue_XML has failed. Check logger for details.")
		return "Error: MII_Ignition_Library.Good_Issues.Create_Good_Issue_XML has failed. Check logger for details."		
	
	
	
	
	
def Check_Single_Consumption_Validation( API_Server, Client, Plant, PO, SAP_Resource_Name, Node_ID, Nodename, Phase, EventTime, Material, Quantity, UOM, Batch_Number, Storage_Location, Reason_For_Movement, Movement_Type, Final_Issue, Resb_Pos, Json):

	try:
	
		url = "http://" + API_Server + "/PR-CID/ShopFloor/MII_Data_Collection_Messages/api/MIIDataCollectionMessages/GET_SAP_MII_MPM_CPS_BLS_CheckConsumptionValid?SAP_CLIENT="+ Client +"&SAP_PLANT="+ Plant +"&PROCESS_ORDER="+ PO +"&SAPResourceName=" + SAP_Resource_Name + "&NodeID=" + Node_ID + "&NODE_NAME=" + Nodename + "&PHASE="+ Phase +"&EventTime="+ EventTime +"&Matnr="+ Material +"&Quantity="+ Quantity +"&UOM="+ UOM +"&Batchnr="+ Batch_Number +"&StorageLocation="+ Storage_Location +"&ReasonForMov="+ Reason_For_Movement +"&MovementType="+ Movement_Type +"&FinalIssue=" + Final_Issue + "&Resb_Pos="+ Resb_Pos +"&jSon=" + Json
			
		#Execute the the HTTP method of GET  
		res = system.net.httpGet(url)
		
		#Capture json decode result
		result = system.util.jsonDecode(res)
		
		rowset = result['Rowset']
		row = rowset['Row'][0]  
		
		message = row['Message'] 
		status = row['status'] 
		
		#Return validation boolean status: 0= Not passed  1= Pass 
		#Return validation message
		return {'status': status, 'message': message}

		
	except:
		MII_Ignition_Library.Logger.Insert_Log.Insert_Error_Log(Client + "_" + Plant + "_" + "Check_Single_Consumption_Validation", "Error: MII_Ignition_Library.Production_Data.Good_Issues.Check_Single_Consumption_Validation has failed. Check logger for details.")
		return "Error: MII_Ignition_Library.Production_Data.Good_Issues.Check_Single_Consumption_Validation has failed. Check logger for details."	



def Check_Single_Consumption_Validation_XML(API_Protocol, API_Server, Client, Plant, XML):
	import xml.etree.ElementTree as ET
	import system
	
	try:
	
		url = str(API_Protocol) + "://" + str(API_Server) + "/PR-CID/ShopFloor/MII_Data_Collection_Messages/api/MIIDataCollectionMessages/GET_SAP_MII_MPM_CPS_BLS_CheckConsumptionValid"
			
		#Execute the the HTTP method of GET  
		connectTimeout = 5000
		readTimeout = (int(system.tag.readBlocking('[Shop_Floor]Coca-Cola/CPS/Site_Settings/General_Configuration/apiTimeoutDuration')[0].value)*60000)
		res = system.net.httpPost(url,"text/xml", XML,connectTimeout,readTimeout)
		
		
		# Parse the XML response
		root = ET.fromstring(res)
		
		# Define namespaces 
		namespaces = {
		    'mii': 'http://www.sap.com/xMII'
		}
		
		# Find the Message element within the XML response
		message = root.find(".//mii:Message", namespaces)
		status = root.find(".//mii:status", namespaces)
		
		#Return validation boolean status: 0= Not passed  1= Pass 
		#Return validation message
		return {'status': status.text, 'message': message.text}

		
	except:
		MII_Ignition_Library.Logger.Insert_Log.Insert_Error_Log(Client + "_" + Plant + "_" + "Check_Single_Consumption_Validation", "Error: MII_Ignition_Library.Production_Data.Good_Issues.Check_Single_Consumption_Validation_XML has failed. Check logger for details.")
		return "Error: MII_Ignition_Library.Production_Data.Good_Issues.Check_Single_Consumption_Validation_XML has failed. Check logger for details."	
		
		
def VerifyIfGoodIssuePosted(Database, Client, Plant, Order, Phase, SAPResourceName):
	try:
	
		Query_Parameters = {"database": Database, "client": Client, "plant":Plant, "order": Order, "Phase": Phase, "SAPResourceName": SAPResourceName}
		Query_Result = system.db.runNamedQuery("MII_Ignition_Queries/Good_Issues/VerifyPostedGoodIssuesPerPhase", Query_Parameters)
		
		if Query_Result[0][0] > 0: 
		    VerifyIfGoodIssuePosted = 1
		else:
		    VerifyIfGoodIssuePosted = 0
		    
		return VerifyIfGoodIssuePosted
		
	except Exception as e:
		Status = e
		return Status
		MII_Ignition_Library.Logger.Insert_Log.Insert_Error_Log(str(Client) + "_" + str(Plant) + "_" + "VerifyIfGoodIssuePosted", Status)