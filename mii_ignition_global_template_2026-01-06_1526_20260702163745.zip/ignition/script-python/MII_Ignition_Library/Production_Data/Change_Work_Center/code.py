def Change_Operation_Work_Center(API_Protocol, API_Server, SAP_Status, MII_Status, DB_Status, Database, Messages_In_Queue_Flag, Client, Plant, Process_Order, Operation, Actual_SAP_Resource_Name, Actual_Work_Center, Actual_Node_ID, New_SAP_Resource_Name, New_Work_Center, New_Node_ID, User_ID, Event_Time, Area):

	try:
	
		import xml.etree.ElementTree as ET
		
		
		#Validate if Database Connection is Online
		if DB_Status == 1: #Database is Online
				
				
			#Create Web API Wrapper XML
			
			# Create the root element
			root = ET.Element("PaWebApiWrapper")
			
			# Create and fill the child elements
			sap_client_element = ET.SubElement(root, "SAP_CLIENT")
			sap_client_element.text = str(Client)
			
			sap_plant_element = ET.SubElement(root, "SAP_PLANT")
			sap_plant_element.text = str(Plant)
			
			doc_type_element = ET.SubElement(root, "DOC_TYPE")
			doc_type_element.text = ""
			
			id_element = ET.SubElement(root, "ID")
			id_element.text = ""
			
			retry_limit_element = ET.SubElement(root, "RETRY_LIMIT")
			retry_limit_element.text = ""
			
			messagename_element = ET.SubElement(root, "MESSAGENAME")
			messagename_element.text = ""
			
			received_date_start_element = ET.SubElement(root, "RECEIVED_DATE_START")
			received_date_start_element.text = ""
			
			received_time_start_element = ET.SubElement(root, "RECEIVED_TIME_START")
			received_time_start_element.text = ""
			
			received_date_end_element = ET.SubElement(root, "RECEIVED_DATE_END")
			received_date_end_element.text = ""
			
			received_time_end_element = ET.SubElement(root, "RECEIVED_TIME_END")
			received_time_end_element.text = ""
			
			identifier_element = ET.SubElement(root, "IDENTIFIER")
			identifier_element.text = ""
			
			category_element = ET.SubElement(root, "CATEGORY")
			category_element.text = ""
			
			status_element = ET.SubElement(root, "STATUS")
			status_element.text = ""
			
			messageuid_element = ET.SubElement(root, "MESSAGEUID")
			messageuid_element.text = ""
			
			process_order_element = ET.SubElement(root, "PROCESS_ORDER")
			process_order_element.text = ""
			
			sap_po_status_element = ET.SubElement(root, "SAP_PO_STATUS")
			sap_po_status_element.text = ""
			
			node_name_element = ET.SubElement(root, "NODE_NAME")
			node_name_element.text = ""
			
			node_type_element = ET.SubElement(root, "NODE_TYPE")
			node_type_element.text = ""
			
			phase_element = ET.SubElement(root, "PHASE")
			phase_element.text = ""
			
			phase_status_element = ET.SubElement(root, "PHASE_STATUS")
			phase_status_element.text = ""
			
			enable_doc_batch_po_header_xml_element = ET.SubElement(root, "Enable_Doc_Batch_PO_Header_XML")
			enable_doc_batch_po_header_xml_element.text = "0"
			
			enable_doc_batch_bom_xml_element = ET.SubElement(root, "Enable_Doc_Batch_BOM_XML")
			enable_doc_batch_bom_xml_element.text = "0"
			
			enable_doc_batch_recipe_header_xml_element = ET.SubElement(root, "Enable_Doc_Batch_Recipe_Header_XML")
			enable_doc_batch_recipe_header_xml_element.text = "0"
			
			enable_doc_batch_recipe_steps_xml_element = ET.SubElement(root, "Enable_Doc_Batch_Recipe_Steps_XML")
			enable_doc_batch_recipe_steps_xml_element.text = "1"
			
			sap_resource_element = ET.SubElement(root, "SAP_RESOURCE")
			sap_resource_element.text = ""
			
			row_count_element = ET.SubElement(root, "ROW_COUNT")
			row_count_element.text = "100"
			
			json_element = ET.SubElement(root, "json")
			json_element.text = "true"
			
			body_element = ET.SubElement(root, "Body")
			mii_update_file_content_element = ET.SubElement(body_element, "MII_Update_File_Content")
			change_sap_operation_resource_element = ET.SubElement(mii_update_file_content_element, "ChangeSapOperationResource")
			
			client_element = ET.SubElement(change_sap_operation_resource_element, "Client")
			client_element.text = str(Client)
			
			plant_element = ET.SubElement(change_sap_operation_resource_element, "Plant")
			plant_element.text = str(Plant)
			
			porder_element = ET.SubElement(change_sap_operation_resource_element, "POrder")
			porder_element.text = str(Process_Order)
			
			resource_source_element = ET.SubElement(change_sap_operation_resource_element, "Resource_Source")
			resource_source_element.text = str(Actual_Work_Center)
			
			resource_target_element = ET.SubElement(change_sap_operation_resource_element, "Resource_Target")
			resource_target_element.text = str(New_Work_Center)
			
			operation_element = ET.SubElement(change_sap_operation_resource_element, "Operation")
			operation_element.text = str(Operation)
			
			username_element = ET.SubElement(change_sap_operation_resource_element, "UserName")
			username_element.text = str(User_ID)
			
			eventtime_element = ET.SubElement(change_sap_operation_resource_element, "Eventtime")
			eventtime_element.text = str(Event_Time)
			
			bls_name_element = ET.SubElement(root, "BlsName")
			bls_name_element.text = "ChangeResourceofOperation"
			
			# Create the XML string
			xml_str = ET.tostring(root, encoding="utf-8", method="xml")
			
			# Convert bytes to string
			xml_str = xml_str.decode("utf-8")
			
			
			#Validate if SAP and MII Services are Online
			if SAP_Status == 1 and MII_Status == 1 and Messages_In_Queue_Flag == False: #SAP and MII Services are Online / No Pending Messages in Queue
						
						
				#Perform API Posting
				# API URL Web Service
				url = str(API_Protocol) + "://" + str(API_Server) + "/PR-CID/ShopFloor/MII_Data_Collection_Messages/api/MIIDataCollectionMessages/POST_PAWebApiWrapper"
				
				
				# HTTP Post Request
				res = system.net.httpPost(url,"text/xml", xml_str)
				 
				#Place the result in a custom property
				Change_Work_Center_Response = system.util.jsonDecode(res)
			
				#return Change_Work_Center_Response
				
				rowset = Change_Work_Center_Response['Rowset']
				row = rowset['Row'][0]  
				
				#BLS Message
				BLS_Message = row['BLS_MESSAGE'] 
				
				#The status of the MII post will be used as parameter for the SQL insert
				#MII_Status = row['STATUS'] 
				
				
				### Insert into Database ###
							
				#Dictionary for the table QUEUE MESSAGE LOG
				#SQL_Parameters = {"database": Database ,"SAPClient":Client, "SAPPlant":Plant, "Work_Center":Actual_Work_Center, "SAPResourceName": Actual_SAP_Resource_Name, "ProcessOrder": Process_Order , "Operation": Operation, "Phase": '', "Message":  xml_str, "Response" : "", "EventTime" : Event_Time, "Processed": "1", "MessageType": "<Change_Work_Center>", "INSPCHAR": "","Area":Area}
			
				#Query to update table QUEUE MESSAGE LOG
				#system.db.runNamedQuery("MII_Ignition_Queries/xMII_Message_Log/XMII_QUEUE_MESSAGE_LOG_INSERT", SQL_Parameters)
				
				return BLS_Message
		
		
			else: #Post directly into Database due to SAP or MII Service Offline / Pending Messages in Queue
				
				### Insert into Database ###
				
				#Dictionary for the table QUEUE MESSAGE LOG
				#SQL_Parameters = {"database": Database ,"SAPClient":Client, "SAPPlant":Plant, "Work_Center":Actual_Work_Center, "SAPResourceName": Actual_SAP_Resource_Name, "ProcessOrder": Process_Order , "Operation": Operation, "Phase": '', "Message":  xml_str, "Response" : "", "EventTime" : Event_Time, "Processed": "0", "MessageType": "<Change_Work_Center>", "INSPCHAR": "","Area":Area}
			
				#Query to update table QUEUE MESSAGE LOG
				#system.db.runNamedQuery("MII_Ignition_Queries/xMII_Message_Log/XMII_QUEUE_MESSAGE_LOG_INSERT", SQL_Parameters)
				
				return "Success."

		
		
		
		
		else: #Database is Offline
			return "Error: Database Connection is Offline. Contact Automation Team for Support."	
		
		
	except Exception as e:
		Status = e
		return Status
		MII_Ignition_Library.Logger.Insert_Log.Insert_Error_Log(str(Client) + "_" + str(Plant) + "_" + "Change_Operation_Work_Center", Status)






