def Get_Phase_Control_Key(Database, Client, Plant, PO, Phase):
	
	try:
	
		#Dictionary for the table QUEUE MESSAGE LOG
		SQL_Parameters = {"database": Database ,"Client": Client, "Plant": Plant, "PO": PO, "Phase": Phase}
		
		#Query to update table QUEUE MESSAGE LOG
		res = system.db.runNamedQuery("MII_Ignition_Queries/Process_Order/Verify_Phase_Control_Key", SQL_Parameters)
		
		return res
		
	except Exception as e:
		Status = e
		return Status
		MII_Ignition_Library.Logger.Insert_Log.Insert_Error_Log(str(Client) + "_" + str(Plant) + "_" + "Get_Phase_Control_Key", Status)
		
		