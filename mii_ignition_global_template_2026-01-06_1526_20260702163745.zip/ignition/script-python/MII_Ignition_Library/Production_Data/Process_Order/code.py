def GetLatestActiveOrderByResource(Database, Client, Plant, SAPResourceName):
	try:
	
		Query_Parameters = {"database": Database, "client": Client, "plant":Plant, "SAPResourceName": SAPResourceName}
		Query_Result = system.db.runNamedQuery("MII_Ignition_Queries/Process_Order/GetLatestActiveOrderByResource", Query_Parameters)
		
		if len(Query_Result) == 1: 
		    LatestActivatedPO = Query_Result.getValueAt(0, "order")
		else:
		    LatestActivatedPO = 'N/A'
		    
		return LatestActivatedPO
		
	except Exception as e:
		Status = e
		return Status
		MII_Ignition_Library.Logger.Insert_Log.Insert_Error_Log(str(Client) + "_" + str(Plant) + "_" + "GetLatestActiveOrderByResource", Status)	
		
	
	
def GetProductionActivityCode(Database, Client, Plant, Order, Phase, Work_Center):
	try:
	
		Query_Parameters = {"database": Database, "client": Client, "plant":Plant, "order": Order, "phase": Phase, "resource": Work_Center}
		Query_Result = system.db.runNamedQuery("MII_Ignition_Queries/Process_Order/GetProductionActivityCode", Query_Parameters)
		
		if len(Query_Result) == 1: 
		    ProductionActivityCode = Query_Result.getValueAt(0, "productionActivity")
		else:
		    ProductionActivityCode = None
		
		return ProductionActivityCode
		
	except Exception as e:
		Status = e
		return Status
		MII_Ignition_Library.Logger.Insert_Log.Insert_Error_Log(str(Client) + "_" + str(Plant) + "_" + "GetProductionActivityCode", Status)