def Get_Storage_Location_List(API_Protocol, API_Server, SAP_Status, MII_Status, DB_Status, Database, Client, Plant, Material, RowCount):
	try:
			
		url = str(API_Protocol) + '://' + str(API_Server) + '/PR-CID/ShopFloor/MII_Data_Collection_Messages/api/MIIDataCollectionMessages/GET_SAP_MII_SLOC?SAP_CLIENT=' + str(Client) + '&SAP_PLANT=' + str(Plant) + '&MATERIAL=' + str(Material) + '&RowCount=1000&jSon=true'
				
		json_data = system.net.httpGet(url)
				
		return json_data
	
	except Exception as e:
		Status = e
		return Status
		MII_Ignition_Library.Logger.Insert_Log.Insert_Error_Log(str(Client) + "_" + str(Plant) + "_" + "Get_Storage_Location_List", Status)
		
		



def Change_Storage_Location(API_Protocol, API_Server, SAP_Status, MII_Status, DB_Status, Database, Client, Plant, Process_Order, Storage_Location):
	try:
			
		url = str(API_Protocol) + '://' + str(API_Server) + '/PR-CID/ShopFloor/MII_Data_Collection_Messages/api/MIIDataCollectionMessages/POST_SAP_MII_MPM_CPS_ChangeSLOCWeb?SAP_CLIENT=' + str(Client) + '&SAP_PLANT=' + str(Plant) + '&PROCESS_ORDER=' + str(Process_Order) + '&NewStorageLocation=' + str(Storage_Location) + '&Json=true'
				
		res = system.net.httpPost(url, {}, {})
				
		#Place the result in a custom property
		SLOC_Response = system.util.jsonDecode(res)
		rowset = SLOC_Response['Rowset']
		row = rowset['Row'][0]  
		
		#MII Messge
		MII_Message = row['BLS_MESSAGE'] 
		
		#The status of the MII post will be used as parameter for the SQL insert
		MII_Status = row['BLS_STATUS'] 
		
		return MII_Message, MII_Status
	
	except Exception as e:
		Status = e
		return Status
		MII_Ignition_Library.Logger.Insert_Log.Insert_Error_Log(str(Client) + "_" + str(Plant) + "_" + "Change_Storage_Location", Status)