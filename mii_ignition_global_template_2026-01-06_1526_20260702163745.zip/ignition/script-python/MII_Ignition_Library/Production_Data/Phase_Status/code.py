def Post_Phase_Status(Tag_Provider, API_Protocol, API_Server, SAP_Status, MII_Status, DB_Status, Database, Messages_In_Queue_Flag, Client, Plant, Work_Center, SAP_Resource_Name, PO, Operation, Phase, Phase_Status, SLOC, EventTime, Message_ID, User_ID, Area):
	import xml.etree.ElementTree as ET
	import json
	#Json = "True"
	try:
	    #Validate if Database Connection is Online
		if DB_Status == 1: #Database is Online
			### Starting the development of the XML  ###
			                    
			# Create the root element
			root = ET.Element("Phase_Status")
			
			# Create the 'row' element
			row = ET.SubElement(root, "row")
			
			# Create and fill the child elements
			sap_client_element = ET.SubElement(row, "SAPClient")
			sap_client_element.text = Client
			
			sap_plant_element = ET.SubElement(row, "SAPPlant")
			sap_plant_element.text = Plant
			
			sap_resource_name_element = ET.SubElement(row, "SAPResourceName")
			sap_resource_name_element.text = SAP_Resource_Name
			
			order_element = ET.SubElement(row, "Order")
			order_element.text = PO
			
			phase_element = ET.SubElement(row, "Phase")
			phase_element.text = Phase
			
			phase_status_element = ET.SubElement(row, "PhaseStatus")
			phase_status_element.text = Phase_Status
			
			sloc_element = ET.SubElement(row, "SLOC")
			sloc_element.text = SLOC
			
			event_time_element = ET.SubElement(row, "EventTime")
			event_time_element.text = EventTime
			
			message_id_element = ET.SubElement(row, "MessageID")
			message_id_element.text = Message_ID
			
			user_element = ET.SubElement(row, "User")
			user_element.text = User_ID
			
			# Create the XML string
			xml_str = ET.tostring(root, encoding="utf-8", method="xml")
			
			# Convert bytes to string
			xml_str = xml_str.decode("utf-8")
	    
	    
			#Validate if SAP and MII Services are Online
			if SAP_Status == 1 and MII_Status == 1 and Messages_In_Queue_Flag == False: #SAP and MII Services are Online / No Pending Messages in Queue
				#Submit Phase Status
				    
				# API URL Web Service
				url = str(API_Protocol) + "://" + str(API_Server) + "/PR-CID/ShopFloor/MII_Data_Collection_Messages/api/MIIDataCollectionMessages/POST_PAWebApiWrapper"
				message = "<PaWebApiWrapper><SAP_CLIENT>" + str(Client) + "</SAP_CLIENT><SAP_PLANT>" + str(Plant) + "</SAP_PLANT><DOC_TYPE/><ID/><RETRY_LIMIT/><MESSAGENAME/><RECEIVED_DATE_START/><RECEIVED_TIME_START/><RECEIVED_DATE_END/><RECEIVED_TIME_END/><IDENTIFIER/><CATEGORY/><STATUS/><MESSAGEUID/><PROCESS_ORDER/><SAP_PO_STATUS/><NODE_NAME/><NODE_TYPE/><PHASE/><PHASE_STATUS/><Enable_Doc_Batch_PO_Header_XML/><Enable_Doc_Batch_BOM_XML/><Enable_Doc_Batch_Recipe_Header_XML/><Enable_Doc_Batch_Recipe_Steps_XML/><SAP_RESOURCE/><ROW_COUNT/><json>true</json><Body><MII_Update_File_Content><row><xml_File><ProcessProductionDocuments><ProductionMessage>" + xml_str + "</ProductionMessage></ProcessProductionDocuments></xml_File></row></MII_Update_File_Content></Body><BlsName>BLS_ProcessProductionDocuments</BlsName></PaWebApiWrapper>" 
				        
				#HTTP Post Request
				connectTimeout = 5000
				readTimeout = (int(system.tag.readBlocking('[Shop_Floor]Coca-Cola/CPS/Site_Settings/General_Configuration/apiTimeoutDuration')[0].value)*60000)
				res = system.net.httpPost(url,"text/xml",message,connectTimeout,readTimeout)
				
				#Place the result in a custom property
				Phase_Status_Response = system.util.jsonDecode(res)
				rowset = Phase_Status_Response['Rowset']
				row = rowset['Row'][0]  
				
				#MII Messge
				MII_Message = row['STATUSTEXT'] 
				
				#The status of the MII post will be used as parameter for the SQL insert
				MII_Status = row['STATUS'] 
	            
	            
				if MII_Status == '1':
#					MII_Ignition_Library.Logger.Insert_Log.Insert_Error_Log("poExecutionPhaseStatus","if part")
					### Insert into Database ###
				    #Dictionary for the table QUEUE MESSAGE LOG
					SQL_Parameters = {"database": Database ,"SAPClient": Client, "SAPPlant": Plant, "Work_Center":Work_Center, "SAPResourceName": SAP_Resource_Name, "ProcessOrder": PO , "Operation": Operation, "Phase": Phase, "Message": xml_str, "Response" : MII_Message, "EventTime" : EventTime , "MessageType": "<Phase_Status>", "Processed":MII_Status, "INSPCHAR": "", "Area":Area,"UpdatedBy":User_ID}
					
					#Query to update table QUEUE MESSAGE LOG
					system.db.runNamedQuery("MII_Ignition_Queries/xMII_Message_Log/XMII_QUEUE_MESSAGE_LOG_INSERT", SQL_Parameters)
					
					#Dictionary for the table QUEUE MESSAGE HISTORY
					SQL_Parameters1 = {"database": Database ,"SAPClient": Client, "SAPPlant": Plant, "Work_Center":Work_Center, "SAPResourceName": SAP_Resource_Name, "ProcessOrder": PO , "Operation": Operation, "Phase": Phase, "Message": xml_str, "Response" : MII_Message, "EventTime" : EventTime , "MessageType": "<Phase_Status>", "Processed":MII_Status, "INSPCHAR": "", "Area":Area, "API_Response_Message":MII_Message, "Updated_By":User_ID}
					
					#Query to update table QUEUE MESSAGE HISTORY
					system.db.runNamedQuery("MII_Ignition_Queries/xMII_Message_Log/XMII_QUEUE_MESSAGE_LOG_INSERT_HISTORY", SQL_Parameters1)
					
					#Update MII_Posting UDT 	
					MII_Ignition_Library.Production_Data.Populate_MII_Posting.PhaseStatusPosting(Tag_Provider, Client, Plant, Work_Center, Area, xml_str)		
								
							
				else:
#					MII_Ignition_Library.Logger.Insert_Log.Insert_Error_Log("poExecutionPhaseStatus","else: mii status 0")
					#Dictionary for the table QUEUE MESSAGE HISTORY
					SQL_Parameters1 = {"database": Database ,"SAPClient": Client, "SAPPlant": Plant, "Work_Center":Work_Center, "SAPResourceName": SAP_Resource_Name, "ProcessOrder": PO , "Operation": Operation, "Phase": Phase, "Message": xml_str, "Response" : "Failed!", "EventTime" : EventTime , "MessageType": "<Phase_Status>", "Processed":MII_Status, "INSPCHAR": "", "Area":Area, "API_Response_Message":MII_Message, "Updated_By":User_ID}
					
					#Query to update table QUEUE MESSAGE HISTORY
					system.db.runNamedQuery("MII_Ignition_Queries/xMII_Message_Log/XMII_QUEUE_MESSAGE_LOG_INSERT_HISTORY", SQL_Parameters1)
				
				return MII_Message
	            
	
			else: 
#				MII_Ignition_Library.Logger.Insert_Log.Insert_Error_Log("poExecutionPhaseStatus","else: "+str(Messages_In_Queue_Flag)+"sap"+str(SAP_Status)+"mii"+str(MII_Status))
				#Post directly into Database due to SAP or MII Service Offline / Pending Messages in Queue
				### Insert into Database ###
				#Dictionary for the table QUEUE MESSAGE LOG
				MII_Message = ""
				SQL_Parameters = {"database": Database ,"SAPClient": Client, "SAPPlant": Plant, "Work_Center" : Work_Center, "SAPResourceName": SAP_Resource_Name, "ProcessOrder": PO , "Operation": Operation, "Phase": Phase, "Message": xml_str, "Response" : "", "EventTime" : EventTime , "MessageType": "<Phase_Status>", "Processed":"0", "INSPCHAR": "","Area":Area,"UpdatedBy":User_ID}
				
				#Query to update table QUEUE MESSAGE LOG
				system.db.runNamedQuery("MII_Ignition_Queries/xMII_Message_Log/XMII_QUEUE_MESSAGE_LOG_INSERT", SQL_Parameters)
				
				#Dictionary for the table QUEUE MESSAGE HISTORY
				SQL_Parameters1 = {"database": Database ,"SAPClient": Client, "SAPPlant": Plant, "Work_Center":Work_Center, "SAPResourceName": SAP_Resource_Name, "ProcessOrder": PO , "Operation": Operation, "Phase": Phase, "Message": xml_str, "Response" : "Failed!", "EventTime" : EventTime , "MessageType": "<Phase_Status>", "Processed":"0", "INSPCHAR": "", "Area":Area, "API_Response_Message":"SAP/MII is offline.", "Updated_By":User_ID}
				
				#Query to update table QUEUE MESSAGE HISTORY
				system.db.runNamedQuery("MII_Ignition_Queries/xMII_Message_Log/XMII_QUEUE_MESSAGE_LOG_INSERT_HISTORY", SQL_Parameters1)
				
				return "Success."
	    
	    
		else:
			#Database is Offline
			return "Error: Database Connection is Offline. Contact Automation Team for Support."    
	
	except:
		MII_Ignition_Library.Logger.Insert_Log.Insert_Error_Log("poExecutionPhaseStatus",str(sys.exc_info()))
		MII_Ignition_Library.Logger.Insert_Log.Insert_Error_Log(Client + "_" + Plant + "_" + "Post_Phase_Status", str(sys.exc_info()))
		return "Error: MII_Ignition_Library.Phase_Status.Post_Phase_Status has failed. Check logger for details."
	    
	
	
	
	
def Create_Phase_Status_XML(Client, Plant, SAP_Resource_Name, PO, Phase, Phase_Status, SLOC, EventTime, Message_ID, User_ID):
	import xml.etree.ElementTree as ET
	
	try:
	
	    ### Starting the development of the XML  ###
	                        
	    # Create the root element
	    root = ET.Element("Phase_Status")
	    
	    # Create the 'row' element
	    row = ET.SubElement(root, "row")
	    
	    # Create and fill the child elements
	    sap_client_element = ET.SubElement(row, "SAPClient")
	    sap_client_element.text = Client
	    
	    sap_plant_element = ET.SubElement(row, "SAPPlant")
	    sap_plant_element.text = Plant
	    
	    sap_resource_name_element = ET.SubElement(row, "SAPResourceName")
	    sap_resource_name_element.text = SAP_Resource_Name
	    
	    order_element = ET.SubElement(row, "Order")
	    order_element.text = PO
	    
	    phase_element = ET.SubElement(row, "Phase")
	    phase_element.text = Phase
	    
	    phase_status_element = ET.SubElement(row, "PhaseStatus")
	    phase_status_element.text = Phase_Status
	    
	    sloc_element = ET.SubElement(row, "SLOC")
	    sloc_element.text = SLOC
	    
	    event_time_element = ET.SubElement(row, "EventTime")
	    event_time_element.text = EventTime
	    
	    message_id_element = ET.SubElement(row, "MessageID")
	    message_id_element.text = Message_ID
	    
	    user_element = ET.SubElement(row, "User")
	    user_element.text = User_ID
	    
	    # Create the XML string
	    xml_str = ET.tostring(root, encoding="utf-8", method="xml")
	    
	    # Convert bytes to string
	    xml_str = xml_str.decode("utf-8")
	    
	    return xml_str
	
	except:
	    MII_Ignition_Library.Logger.Insert_Log.Insert_Error_Log(Client + "_" + Plant + "_" + "Create_Phase_Status_XML", str(sys.exc_info()))
	    return "Error: MII_Ignition_Library.Phase_Status.Create_Phase_Status_XML has failed. Check logger for details."  