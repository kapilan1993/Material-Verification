def Populate_Availability(Tag_Provider, Client, Plant, PO, Work_Center, Area_Description, Availability):
     try:
         
        #Local Parameters
        Area = ''                           #Area: Used to determine resource area prefix.
        
                
        #Verify Resource Area Prefix
        '''
        if Work_Center[0:2] == 'LF' or Work_Center[0:2] == 'LA': #Liquid Filling
            Area = 'LF'
            
        elif Work_Center[0:2] == 'DF' or Work_Center[0:2] == 'DA': #Dry Processing
            Area = 'DP'
        
        elif Area_Description == 'LIQ_PROCESS_AREA': #MFG
            Area = 'LP/LP' + str(Work_Center[0:2])
            #return "Success."
        
        else: #Resource Area not Found
            MII_Ignition_Library.Logger.Insert_Log.Insert_Error_Log(Client + "_" + Plant + "_" + "Populate_", "Error: Resource Area Prefix not found. Resource: " + Work_Center)
            return "Error: Resource Area Prefix not found. Resource: " + Work_Center
        '''
        Status,ReturnVal = MII_Ignition_Library.ToolsSet.Tools.GetArea(Client,Plant,Work_Center,Area_Description)
                
        if Status != "Success.":
            return Status
        else:
            Area = ReturnVal

        #Populate MII_PH_Status Tag and validate if tag writing fails in the process 
        Response = MII_Ignition_Library.Tags.Write.Write_Single_Value(Tag_Provider + "Coca-Cola/CPS/" + Plant + "/" + Area + "/" + Work_Center + "/OEE/availability",Availability)
        if str(Response) != 'Good':
            return "Error: There was an error while trying to populate OEE Availability Tag value. Check logger for more information. Resource " + Work_Center    
        
        #Script executed succesffuly
        return "Success."
            
    except:
        MII_Ignition_Library.Logger.Insert_Log.Insert_Error_Log(Client + "_" + Plant + "_" + "Populate_", "Error: MII_Ignition_Library.Production_Data.Populate_Resource_OEE_Tag.Populate_Availability has failed. Check log for details. Resource: " +  Work_Center)
        return "Error: MII_Ignition_Library.Production_Data.Populate_Resource_OEE_Tag.Populate_Availability has failed. Check log for details. Resource: "  + Work_Center        
        
        
        
        
def Populate_Performance(Tag_Provider, Client, Plant, PO, Work_Center, Area_Description, Performance):
     try:
         
        #Local Parameters
        Area = ''                           #Area: Used to determine resource area prefix.
        
                
        #Verify Resource Area Prefix
        '''
        if Work_Center[0:2] == 'LF' or Work_Center[0:2] == 'LA': #Liquid Filling
            Area = 'LF'
            
        elif Work_Center[0:2] == 'DF' or Work_Center[0:2] == 'DA': #Dry Processing
            Area = 'DP'
        
        elif Area_Description == 'LIQ_PROCESS_AREA': #MFG
            Area = 'LP/LP' + str(Work_Center[0:2])
            #return "Success."
        
        else: #Resource Area not Found
            MII_Ignition_Library.Logger.Insert_Log.Insert_Error_Log(Client + "_" + Plant + "_" + "Populate_", "Error: Resource Area Prefix not found. Resource: " + Work_Center)
            return "Error: Resource Area Prefix not found. Resource: " + Work_Center
        '''
        Status,ReturnVal = MII_Ignition_Library.ToolsSet.Tools.GetArea(Client,Plant,Work_Center,Area_Description)
                
        if Status != "Success.":
            return Status
        else:
            Area = ReturnVal


        #Populate MII_PH_Status Tag and validate if tag writing fails in the process 
        Response = MII_Ignition_Library.Tags.Write.Write_Single_Value(Tag_Provider + "Coca-Cola/CPS/" + Plant + "/" + Area + "/" + Work_Center + "/OEE/performance",Performance)
        if str(Response) != 'Good':
            return "Error: There was an error while trying to populate OEE Performance Tag value. Check logger for more information. Resource " + Work_Center    
        
        #Script executed succesffuly
        return "Success."
            
    except:
        MII_Ignition_Library.Logger.Insert_Log.Insert_Error_Log(Client + "_" + Plant + "_" + "Populate_", "Error: MII_Ignition_Library.Production_Data.Populate_Resource_OEE_Tag.Populate_Performance has failed. Check log for details. Resource: " +  Work_Center)
        return "Error: MII_Ignition_Library.Production_Data.Populate_Resource_OEE_Tag.Populate_Performance has failed. Check log for details. Resource: "  + Work_Center        
        
        
        
def Populate_Quality(Tag_Provider, Client, Plant, PO, Work_Center, Area_Description, Quality):
     try:
         
        #Local Parameters
        Area = ''                           #Area: Used to determine resource area prefix.
        
                
        #Verify Resource Area Prefix
        '''
        if Work_Center[0:2] == 'LF' or Work_Center[0:2] == 'LA': #Liquid Filling
            Area = 'LF'
            
        elif Work_Center[0:2] == 'DF' or Work_Center[0:2] == 'DA': #Dry Processing
            Area = 'DP'
        
        elif Area_Description == 'LIQ_PROCESS_AREA': #MFG
            Area = 'LP/LP' + str(Work_Center[0:2])
            #return "Success."
        
        else: #Resource Area not Found
            MII_Ignition_Library.Logger.Insert_Log.Insert_Error_Log(Client + "_" + Plant + "_" + "Populate_", "Error: Resource Area Prefix not found. Resource: " + Work_Center)
            return "Error: Resource Area Prefix not found. Resource: " + Work_Center
        '''
        Status,ReturnVal = MII_Ignition_Library.ToolsSet.Tools.GetArea(Client,Plant,Work_Center,Area_Description)
                
        if Status != "Success.":
            return Status
        else:
            Area = ReturnVal
            

        #Populate MII_PH_Status Tag and validate if tag writing fails in the process 
        Response = MII_Ignition_Library.Tags.Write.Write_Single_Value(Tag_Provider + "Coca-Cola/CPS/" + Plant + "/" + Area + "/" + Work_Center + "/OEE/quality",Quality)
        if str(Response) != 'Good':
            return "Error: There was an error while trying to populate OEE Quality Tag value. Check logger for more information. Resource " + Work_Center    
        
        #Script executed succesffuly
        return "Success."
            
    except:
        MII_Ignition_Library.Logger.Insert_Log.Insert_Error_Log(Client + "_" + Plant + "_" + "Populate_", "Error: MII_Ignition_Library.Production_Data.Populate_Resource_OEE_Tag.Populate_Quality has failed. Check log for details. Resource: " +  Work_Center)
        return "Error: MII_Ignition_Library.Production_Data.Populate_Resource_OEE_Tag.Populate_Quality has failed. Check log for details. Resource: "  + Work_Center        
        
        
        
def Populate_OEE(Tag_Provider, Client, Plant, PO, Work_Center, Area_Description, OEE):
     try:
         
        #Local Parameters
        Area = ''                           #Area: Used to determine resource area prefix.
        
                
        #Verify Resource Area Prefix
        '''
        if Work_Center[0:2] == 'LF' or Work_Center[0:2] == 'LA': #Liquid Filling
            Area = 'LF'
            
        elif Work_Center[0:2] == 'DF' or Work_Center[0:2] == 'DA': #Dry Processing
            Area = 'DP'
        
        elif Area_Description == 'LIQ_PROCESS_AREA': #MFG
            Area = 'LP/LP' + str(Work_Center[0:2])
            #return "Success."
        
        else: #Resource Area not Found
            MII_Ignition_Library.Logger.Insert_Log.Insert_Error_Log(Client + "_" + Plant + "_" + "Populate_", "Error: Resource Area Prefix not found. Resource: " + Work_Center)
            return "Error: Resource Area Prefix not found. Resource: " + Work_Center
        '''
        Status,ReturnVal = MII_Ignition_Library.ToolsSet.Tools.GetArea(Client,Plant,Work_Center,Area_Description)
                
        if Status != "Success.":
            return Status
        else:
            Area = ReturnVal


        #Populate MII_PH_Status Tag and validate if tag writing fails in the process 
        Response = MII_Ignition_Library.Tags.Write.Write_Single_Value(Tag_Provider + "Coca-Cola/CPS/" + Plant + "/" + Area + "/" + Work_Center + "/OEE/currentPOOEE",OEE)
        if str(Response) != 'Good':
            return "Error: There was an error while trying to populate OEE Tag value. Check logger for more information. Resource " + Work_Center    
        
        #Script executed succesffuly
        return "Success."
            
    except:
        MII_Ignition_Library.Logger.Insert_Log.Insert_Error_Log(Client + "_" + Plant + "_" + "Populate_", "Error: MII_Ignition_Library.Production_Data.Populate_Resource_OEE_Tag.Populate_OEE has failed. Check log for details. Resource: " +  Work_Center)
        return "Error: MII_Ignition_Library.Production_Data.Populate_Resource_OEE_Tag.Populate_OEE has failed. Check log for details. Resource: "  + Work_Center