def PhaseStatusPosting(Tag_Provider, Client, Plant, Work_Center, Area_Description, XML):
 	try:
 		
		#Local Parameters
		Area = ''						   #Area: Used to determine resource area prefix.
		
		'''
		#Verify Resource Area Prefix
		if Work_Center[0:2] == 'LF' or Work_Center[0:2] == 'LA': #Liquid Filling
			Area = 'LF'
			
		elif Work_Center[0:2] == 'DF' or Work_Center[0:2] == 'DA': #Dry Processing
			Area = 'DP'
		
		elif Area_Description == 'LIQ_PROCESS_AREA': #MFG
			Area = 'LP/LP' + str(Work_Center[0:2])
			#return "Success."
		
		else: #Resource Area not Found
			MII_Ignition_Library.Logger.Insert_Log.Insert_Error_Log(Client + "_" + Plant + "_" + "Populate_", "Error: Resource Area Prefix not found. Resource: " + Work_Center)
			return "Error: Resource Area Prefix not found. Resource: " + Work_Center
		'''
		
		Status,ReturnVal = MII_Ignition_Library.ToolsSet.Tools.GetArea(Client,Plant,Work_Center,Area_Description)
		
		if Status != "Success.":
			return Status
		else:
			Area = ReturnVal
		
		JSON =  MII_Ignition_Library.Conversion.Convert_XML_to_JSon.XML_to_Json(XML)


		#Populate PhaseStatusPosting Tag and validate if tag writing fails in the process 
		Response = MII_Ignition_Library.Tags.Write.Write_Single_Value(Tag_Provider + "Coca-Cola/CPS/" + Plant + "/" + Area + "/" + Work_Center + "/MII_Posting/PhaseStatusPosting/JSON", JSON)
		if str(Response) != 'Good':
			return "Error: There was an error while trying to populate PhaseStatusPosting JSON Tag value. Check logger for more information. Resource " + Work_Center	
		
		Response = MII_Ignition_Library.Tags.Write.Write_Single_Value(Tag_Provider + "Coca-Cola/CPS/" + Plant + "/" + Area + "/" + Work_Center + "/MII_Posting/PhaseStatusPosting/XML", XML)
		if str(Response) != 'Good':
			return "Error: There was an error while trying to populate PhaseStatusPosting XML Tag value. Check logger for more information. Resource " + Work_Center	
					
		#Script executed succesffuly
		return "Success."
			
	except Exception as e:
		MII_Ignition_Library.Logger.Insert_Log.Insert_Error_Log(Client + "_" + Plant + "_" + "Populate_", "Error: MII_Ignition_Library.Production_Data.Populate_MII_Posting.PhaseStatusPosting has failed. Check log for details. Resource: " +  Work_Center)
		MII_Ignition_Library.Logger.Insert_Log.Insert_Error_Log(Client + "_" + Plant, str(e))
		return "Error: MII_Ignition_Library.Production_Data.Populate_MII_Posting.PhaseStatusPosting has failed. Check log for details. Resource: "  + Work_Center		


def GoodIssuePosting(Tag_Provider, Client, Plant, Work_Center, Area_Description, XML):
 	try:
 		
		#Local Parameters
		Area = ''						   #Area: Used to determine resource area prefix.
		
				
		'''
		#Verify Resource Area Prefix
		if Work_Center[0:2] == 'LF' or Work_Center[0:2] == 'LA': #Liquid Filling
			Area = 'LF'
			
		elif Work_Center[0:2] == 'DF' or Work_Center[0:2] == 'DA': #Dry Processing
			Area = 'DP'
		
		elif Area_Description == 'LIQ_PROCESS_AREA': #MFG
			Area = 'LP/LP' + str(Work_Center[0:2])
			#return "Success."
		
		else: #Resource Area not Found
			MII_Ignition_Library.Logger.Insert_Log.Insert_Error_Log(Client + "_" + Plant + "_" + "Populate_", "Error: Resource Area Prefix not found. Resource: " + Work_Center)
			return "Error: Resource Area Prefix not found. Resource: " + Work_Center
		'''
		
		Status,ReturnVal = MII_Ignition_Library.ToolsSet.Tools.GetArea(Client,Plant,Work_Center,Area_Description)
		
		if Status != "Success.":
			return Status
		else:
			Area = ReturnVal

		JSON =  MII_Ignition_Library.Conversion.Convert_XML_to_JSon.XML_to_Json(XML)



		#Populate PhaseStatusPosting Tag and validate if tag writing fails in the process 
		Response = MII_Ignition_Library.Tags.Write.Write_Single_Value(Tag_Provider + "Coca-Cola/CPS/" + Plant + "/" + Area + "/" + Work_Center + "/MII_Posting/GoodIssuePosting/JSON", JSON)
		if str(Response) != 'Good':
			return "Error: There was an error while trying to populate GoodIssuePosting JSON Tag value. Check logger for more information. Resource " + Work_Center	
			
		Response = MII_Ignition_Library.Tags.Write.Write_Single_Value(Tag_Provider + "Coca-Cola/CPS/" + Plant + "/" + Area + "/" + Work_Center + "/MII_Posting/GoodIssuePosting/XML", XML)
		if str(Response) != 'Good':
			return "Error: There was an error while trying to populate GoodIssuePosting XML Tag value. Check logger for more information. Resource " + Work_Center	
		
		#Script executed succesffuly
		return "Success."
			
	except Exception as e:
		MII_Ignition_Library.Logger.Insert_Log.Insert_Error_Log(Client + "_" + Plant + "_" + "Populate_", "Error: MII_Ignition_Library.Production_Data.Populate_MII_Posting.GoodIssuePosting has failed. Check log for details. Resource: " +  Work_Center)
		MII_Ignition_Library.Logger.Insert_Log.Insert_Error_Log(Client + "_" + Plant, str(e))
		return "Error: MII_Ignition_Library.Production_Data.Populate_MII_Posting.GoodIssuePosting has failed. Check log for details. Resource: "  + Work_Center		
		
		




def MachineStatusPosting(Tag_Provider, Client, Plant, Work_Center, Area_Description, XML):
 	try:
 		import xml.etree.ElementTree as ET
		#Local Parameters
		Area = ''						   #Area: Used to determine resource area prefix.
		
				
		'''
		#Verify Resource Area Prefix
		if Work_Center[0:2] == 'LF' or Work_Center[0:2] == 'LA': #Liquid Filling
			Area = 'LF'
			
		elif Work_Center[0:2] == 'DF' or Work_Center[0:2] == 'DA': #Dry Processing
			Area = 'DP'
		
		elif Area_Description == 'LIQ_PROCESS_AREA': #MFG
			Area = 'LP/LP' + str(Work_Center[0:2])
			#return "Success."
		
		else: #Resource Area not Found
			MII_Ignition_Library.Logger.Insert_Log.Insert_Error_Log(Client + "_" + Plant + "_" + "Populate_", "Error: Resource Area Prefix not found. Resource: " + Work_Center)
			return "Error: Resource Area Prefix not found. Resource: " + Work_Center
		'''
		
		Status,ReturnVal = MII_Ignition_Library.ToolsSet.Tools.GetArea(Client,Plant,Work_Center,Area_Description)
		
		if Status != "Success.":
			return Status
		else:
			Area = ReturnVal

		JSON =  MII_Ignition_Library.Conversion.Convert_XML_to_JSon.XML_to_Json(XML)
		
		
		# Parse the XML
		root = ET.fromstring(XML)
		# Extract the MachineStatus value
		Machine_Status = root.find('.//MachineStatus').text



		#Populate PhaseStatusPosting Tag and validate if tag writing fails in the process 
		Response = MII_Ignition_Library.Tags.Write.Write_Single_Value(Tag_Provider + "Coca-Cola/CPS/" + Plant + "/" + Area + "/" + Work_Center + "/MII_Posting/MachineStatusPosting/JSON", JSON)
		if str(Response) != 'Good':
			return "Error: There was an error while trying to populate MachineStatusPosting JSON Tag value. Check logger for more information. Resource " + Work_Center	
			
		Response = MII_Ignition_Library.Tags.Write.Write_Single_Value(Tag_Provider + "Coca-Cola/CPS/" + Plant + "/" + Area + "/" + Work_Center + "/MII_Posting/MachineStatusPosting/XML", XML)
		if str(Response) != 'Good':
			return "Error: There was an error while trying to populate MachineStatusPosting XML Tag value. Check logger for more information. Resource " + Work_Center	
		
		Response = MII_Ignition_Library.Tags.Write.Write_Single_Value(Tag_Provider + "Coca-Cola/CPS/" + Plant + "/" + Area + "/" + Work_Center + "/MII_Posting/MachineStatusPosting/machineStatus",  Machine_Status)
		if str(Response) != 'Good':
			return "Error: There was an error while trying to populate MachineStatusPosting machineStatus Tag value. Check logger for more information. Resource " + Work_Center	
			
		#Script executed succesffuly
		return "Success."
			
	except Exception as e:
		MII_Ignition_Library.Logger.Insert_Log.Insert_Error_Log(Client + "_" + Plant + "_" + "Populate_", "Error: MII_Ignition_Library.Production_Data.Populate_MII_Posting.MachineStatusPosting has failed. Check log for details. Resource: " +  Work_Center)
		MII_Ignition_Library.Logger.Insert_Log.Insert_Error_Log(Client + "_" + Plant, str(e))
		return "Error: MII_Ignition_Library.Production_Data.Populate_MII_Posting.MachineStatusPosting has failed. Check log for details. Resource: "  + Work_Center		
	
		
			
					
		
def ProductionReportPosting(Tag_Provider, Client, Plant, Work_Center, Area_Description, XML):
 	try:
 		
		#Local Parameters
		Area = ''						   #Area: Used to determine resource area prefix.
		
				
		
		#Verify Resource Area Prefix
		'''
		if Work_Center[0:2] == 'LF' or Work_Center[0:2] == 'LA': #Liquid Filling
			Area = 'LF'
			
		elif Work_Center[0:2] == 'DF' or Work_Center[0:2] == 'DA': #Dry Processing
			Area = 'DP'
		
		elif Area_Description == 'LIQ_PROCESS_AREA': #MFG
			Area = 'LP/LP' + str(Work_Center[0:2])
			#return "Success."
		
		else: #Resource Area not Found
			MII_Ignition_Library.Logger.Insert_Log.Insert_Error_Log(Client + "_" + Plant + "_" + "Populate_", "Error: Resource Area Prefix not found. Resource: " + Work_Center)
			return "Error: Resource Area Prefix not found. Resource: " + Work_Center
		'''
		
		Status,ReturnVal = MII_Ignition_Library.ToolsSet.Tools.GetArea(Client,Plant,Work_Center,Area_Description)
		
		if Status != "Success.":
			return Status
		else:
			Area = ReturnVal

		JSON =  MII_Ignition_Library.Conversion.Convert_XML_to_JSon.XML_to_Json(XML)


		#Populate PhaseStatusPosting Tag and validate if tag writing fails in the process 
		Response = MII_Ignition_Library.Tags.Write.Write_Single_Value(Tag_Provider + "Coca-Cola/CPS/" + Plant + "/" + Area + "/" + Work_Center + "/MII_Posting/ProductionReportPosting/JSON", JSON)
		if str(Response) != 'Good':
			return "Error: There was an error while trying to populate ProductionReportPosting JSON Tag value. Check logger for more information. Resource " + Work_Center	
		
		
		Response = MII_Ignition_Library.Tags.Write.Write_Single_Value(Tag_Provider + "Coca-Cola/CPS/" + Plant + "/" + Area + "/" + Work_Center + "/MII_Posting/ProductionReportPosting/XML", XML)
		if str(Response) != 'Good':
			return "Error: There was an error while trying to populate ProductionReportPosting XML Tag value. Check logger for more information. Resource " + Work_Center	
			
					
		#Script executed succesffuly
		return "Success."
			
	except Exception as e:
		MII_Ignition_Library.Logger.Insert_Log.Insert_Error_Log(Client + "_" + Plant + "_" + "Populate_", "Error: MII_Ignition_Library.Production_Data.Populate_MII_Posting.ProductionReportPosting has failed. Check log for details. Resource: " +  Work_Center)
		MII_Ignition_Library.Logger.Insert_Log.Insert_Error_Log(Client + "_" + Plant, str(e))
		return "Error: MII_Ignition_Library.Production_Data.Populate_MII_Posting.ProductionReportPosting has failed. Check log for details. Resource: "  + Work_Center		
		