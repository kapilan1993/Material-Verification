def Post_Quality_Inspection(API_Protocol, API_Server, SAP_Status, MII_Status, DB_Status, Database, Messages_In_Queue_Flag, Quality_Data, Current_Time, Event_Time, User_ID, Client, Plant, Work_Center, SAP_Resource_Name, PO, Phase, Operation, InspChar, Area):
	import xml.etree.ElementTree as ET
	import xml.etree.ElementTree as QR
	from datetime import datetime
	#Json = "True"
	
	try:
	
		#Validate if Database Connection is Online
		if DB_Status == 1: #Database is Online
		
		
			# Sample data
			data = Quality_Data
			
			insplot = data[0]["PPPI_INSPECTION_LOT"]
			inspoper = data[0]["PPPI_PHASE"]
			
			# Define a mapping between table columns and child elements
			column_to_child_mapping = {
			    "PPPI_INSPECTION_LOT": "INSPLOT",
			    "PPPI_PHASE": "INSPOPER",
			    "PPPI_INSPECTION_CHARACTERISTIC": "INSPCHAR",
			    "EVALUATION":"EVALUATION",
			    "Mean_Value":"MEAN_VALUE",
			    "COMMENT": "REMARK",
			    "Code_1":"CODE1",
			    "Code_Grp1":"CODE_GRP1",
			    # Add more mappings as needed
			}
			
			# Define the list of all child elements
			child_elements = [
				"INSPLOT",
			    "INSPOPER",
			    "INSPCHAR",
			    "CLOSED",
			    "EVALUATED",
			    "CHAR_ATTR",
			    "CHAR_INVAL",
			    "EVALUATION",
			    "ERR_CLASS",
			    "VALID_VALS",
			    "NONCONF",
			    "DEFECTS",
			    "VALS_ABOVE",
			    "VALS_BELOW",
			    "MEAN_VALUE",
			    "VARIANCE",
			    "MAXIMUM",
			    "MINIMUM",
			    "START_DATE",
			    "START_TIME",
			    "END_DATE",
			    "END_TIME",
			    "INSPECTOR",
			    "RES_ORG",
			    "REMARK",
			    "CODE1",
			    "CODE_GRP1",
			    "CODE2",
			    "CODE_GRP2",
			    "CODE3",
			    "CODE_GRP3",
			    "CODE4",
			    "CODE_GRP4",
			    "CODE5",
			    "CODE_GRP5",
			    "ORIGINAL_INPUT",
			    "INPPROC_READY",
			    "DIFF_DEC_PLACES",
			    "ADD_INFO1",
			    "CONDITION_ACTIVE",
			]
			
			# Initialize the XML structure
			root = ET.Element("CHAR_RESULTS")
			
			# Iterate through the data
			for item in data:
				evalua = item["EVALUATION"]
				if evalua != "":
					element = ET.Element("item")
					for child_element in child_elements:
						column = next((column for column, child in column_to_child_mapping.items() if child == child_element), None)
						if column:
							value = item[column]
			        	
						elif child_element == "INSP_DATE":
							value = system.date.format(Current_Time, "yyyy-MM-dd")
						
						elif child_element == "INSP_TIME":
							value = system.date.format(Current_Time, "HH:mm:ss")
						
						elif child_element == "CLOSED":
							value = "X"
							
						elif child_element == "EVALUATED":
							value = "X"	
													 		
						elif child_element == "INSPECTOR":
						 	value = User_ID	
						
						else:
							value = ""
			            
						child = ET.Element(child_element)
						child.text = value
						element.append(child)
					
					root.append(element)
			
			# Create an ElementTree object
			tree = ET.ElementTree(root)
			
			# Serialize the ElementTree to an XML string
			xml_str = ET.tostring(root, encoding="utf-8", method="xml") 
			
			# Convert bytes to string
			xml_str = xml_str.decode("utf-8")
			
			
			
			
			#Dictionary for the table QUEUE MESSAGE LOG delete process
			parameters_delete = {"database": Database,"SAPClient": Client, "SAPPlant": Plant,  "ProcessOrder": PO , "Phase": Phase, "SAPResourceName": SAP_Resource_Name,  "MessageType": "<CHAR_RESULTS>",  "INSPCHAR": InspChar}
			
			#Query to delete table QUEUE MESSAGE LOG
			system.db.runNamedQuery("MIIIgnitionQueries/XMIIMessageLog/XMII_QUEUE_MESSAGE_LOG_DELETE", parameters_delete)
			
			#Dictionary for the table QUEUE MESSAGE LOG
			parameters = {"database": Database,"SAPClient": Client, "SAPPlant": Plant, "SAPResourceName":SAP_Resource_Name, "ProcessOrder":PO , "Operation": Operation, "Phase": Phase, "Message": xml_str, "EventTime" : Event_Time , "MessageType": "<CHAR_RESULTS>","Processed":"1", "Attempts":"1", "Response":"Success.", "Work_Center":SAP_Resource_Name,  "INSPCHAR": InspChar,"UpdatedBy":User_ID}
			
			#Query to update table QUEUE MESSAGE LOG
			system.db.runNamedQuery("MIIIgnitionQueries/XMIIMessageLog/xMiiQueueMessageLogInsert", parameters)
			
			
		
			
			#Get the Char Results string
			params1 = {"database": Database,"SAPClient":Client, "SAPPlant":Plant,  "ProcessOrder":PO , "Phase": Phase, "SAPResourceName" : SAP_Resource_Name, "MessageType": "<CHAR_RESULTS>"}
			char_results = str(system.db.runNamedQuery("MIIIgnitionQueries/XMIIMessageLog/XMII_QUEUE_MESSAGE_LOG_GetPostedQualityXML", params1))	
			
			#Get the Single Results string
			params2 = {"database": Database,"SAPClient":Client, "SAPPlant":Plant,  "ProcessOrder":PO , "Phase": Phase, "SAPResourceName" : SAP_Resource_Name,  "MessageType": "<SINGLE_RESULTS>"}
			single_results = str(system.db.runNamedQuery("MIIIgnitionQueries/XMIIMessageLog/XMII_QUEUE_MESSAGE_LOG_GetPostedQualityXML", params2))
			
			if single_results == "None":
				single_results = ""
				
			
				
			#Message for the quality insert
			QCParameters_XML = "<QCParameters><SAP_CLIENT>" + str(Client) + "</SAP_CLIENT><SAP_PLANT>" + str(Plant) + "</SAP_PLANT><BAPI_INSPOPER_RECORDRESULTS><INPUT><HANDHELD_APPLICATION/><INSPLOT>"+insplot+"</INSPLOT><INSPOPER>"+inspoper+"</INSPOPER><INSPPOINTDATA><INSPLOT>000000000000</INSPLOT><INSPOPER/><INSPPOINT>000000</INSPPOINT><PART_LOT>000000</PART_LOT><QUANTITY/><UNIT/><UNITC/><UNITT/><EQUIPMENT/><FUNCT_LOC/><PHYS_SMPL/><USERC1/><USERC2/><USERN1>0000000000</USERN1><USERN2>000</USERN2><USERD1>0000-00-00</USERD1><USERT1>00:00:00</USERT1><CAT_TYPE/><PSEL_SET/><SEL_SET/><CODE_GRP/><CODE/><REMARK/><MATERIAL/><BATCH/><INSP_DATE>0000-00-00</INSP_DATE><INSP_TIME>00:00:00</INSP_TIME><INSPECTOR/><SCRP_QUANT/><MATERIAL_EXTERNAL/><MATERIAL_GUID/><MATERIAL_VERSION/><REWORK_QUANT/><MATERIAL_LONG/><SHOP_FLOOR_ITEM>0000000000000000000</SHOP_FLOOR_ITEM></INSPPOINTDATA></INPUT><OUTPUT><RETURN><TYPE/><ID/><NUMBER>000</NUMBER><MESSAGE/><LOG_NO/><LOG_MSG_NO>000000</LOG_MSG_NO><MESSAGE_V1/><MESSAGE_V2/><MESSAGE_V3/><MESSAGE_V4/><PARAMETER/><ROW>0</ROW><FIELD/><SYSTEM/></RETURN></OUTPUT><TABLES><CHAR_RESULTS>"+char_results+"</CHAR_RESULTS><RETURNTABLE><item><TYPE/><ID/><NUMBER/><MESSAGE/><LOG_NO/><LOG_MSG_NO/><MESSAGE_V1/><MESSAGE_V2/><MESSAGE_V3/><MESSAGE_V4/><PARAMETER/><ROW/><FIELD/><SYSTEM/></item></RETURNTABLE><SAMPLE_RESULTS><item><INSPLOT/><INSPOPER/><INSPCHAR/><INSPMII_Ignition_Project/><LAST_SMPL/><CLOSED/><EVALUATED/><SMPL_ATTR/><SMPL_INVAL/><EVALUATION/><ERR_CLASS/><VALID_VALS/><NONCONF/><DEFECTS/><VALS_ABOVE/><VALS_BELOW/><MEAN_VALUE/><VARIANCE/><MAXIMUM/><MINIMUM/><START_DATE/><START_TIME/><END_DATE/><END_TIME/><INSPECTOR/><RES_ORG/><REMARK/><CODE1/><CODE_GRP1/><CODE2/><CODE_GRP2/><CODE3/><CODE_GRP3/><CODE4/><CODE_GRP4/><CODE5/><CODE_GRP5/><ORIGINAL_INPUT/><INPPROC_READY/><DIFF_DEC_PLACES/><ADD_INFO1/><ADD_INFO2/><CONDITION_ACTIVE/><CLOSE_SAMPLE_ONLY/></item></SAMPLE_RESULTS><SINGLE_RESULTS>"+single_results+"</SINGLE_RESULTS></TABLES></BAPI_INSPOPER_RECORDRESULTS></QCParameters>"	
			
		
			

			#Validate if SAP and MII Services are Online
			if SAP_Status == 1 and MII_Status == 1 and Messages_In_Queue_Flag == False: #SAP and MII Services are Online 
			
				#Submit Quality Inspection
				
				# API URL Web Service
				url = str(API_Protocol) + "://" + str(API_Server) + "/PR-CID/ShopFloor/MII_Data_Collection_Messages/api/MIIDataCollectionMessages/Post_Quality_Inspection_Record_Results_IGN_SAP"
			   	
			   	
				# HTTP Post Request
				res = system.net.httpPost(url,"text/xml",QCParameters_XML)
				
				system.perspective.print("quality url send1")
				system.perspective.print(url)
				system.perspective.print(QCParameters_XML)
				system.perspective.print("quality url send2")
				#MII_Ignition_Library.Logger.Insert_Log.Insert_Error_Log('Quality', str(res))
				
				#Place the result in a custom property
				#self.custom.MII = system.util.jsonDecode(res)
			
				#MII Messge
				root = QR.fromstring(res)
				MII_Status = root[0][0][0][0][0].text
				MII_Message = root[0][0][0][0][1].text
				
				if MII_Status == 'P':
					MII_Message = 'Posted Completed' 
					Processed_Status = '1'
					Attempts = '1'
					Response = 'Success.'
				else:
					Processed_Status = '0'
					Attempts = '0'
					Response = ''
					#mii_message = mii_message
				
				
				#if Processed_Status == '1':
				#Dictionary for the table QUEUE MESSAGE LOG
				parameters_Quality = {"database": Database,"SAPClient":Client, "SAPPlant":Plant, "SAPResourceName":SAP_Resource_Name, "ProcessOrder":PO , "Operation": Operation, "Phase": Phase, "Message": QCParameters_XML, "EventTime" : Event_Time , "MessageType": "<QUALITY_RESULTS>","Processed":Processed_Status, "Attempts":Attempts, "Response":Response, "Work_Center":SAP_Resource_Name,  "INSPCHAR": "","UpdatedBy":User_ID, "Area":Area}
				
				#Query to update table QUEUE MESSAGE LOG
				system.db.runNamedQuery("MIIIgnitionQueries/XMIIMessageLog/xMiiQueueMessageLogInsert", parameters_Quality)
				
				system.perspective.print(parameters_Quality)
				
				return MII_Message
				
					
					
					
					
			else: #Post directly into Database due to SAP or MII Service Offline
				### Insert into Database ###
				#Dictionary for the table QUEUE MESSAGE LOG
				parameters_Quality = {"database": Database,"SAPClient":Client, "SAPPlant":Plant, "SAPResourceName":SAP_Resource_Name, "ProcessOrder":PO , "Operation": Operation, "Phase": Phase, "Message": QCParameters_XML, "EventTime" : Event_Time , "MessageType": "<QUALITY_RESULTS>","Processed":'0', "Attempts":'0', "Response":'', "Work_Center":SAP_Resource_Name,  "INSPCHAR": "","UpdatedBy":User_ID, "Area":Area}
				
				#Query to update table QUEUE MESSAGE LOG
				system.db.runNamedQuery("MIIIgnitionQueries/XMIIMessageLog/xMiiQueueMessageLogInsert", parameters_Quality)
				
				return "Success."
		
		
		else: #Database is Offline
			return "Error: Database Connection is Offline. Contact Automation Team for Support."	
	
	
		
	except:
		MII_Ignition_Library.Logger.Insert_Log.Insert_Error_Log(Client + "_" + Plant + "_" + "Post_Quality_Inspection", str(sys.exc_info()))
		return "Error: MII_Ignition_Library.Production_Data.Quality_Inspection.Post_Quality_Inspection has failed. Check logger for details."	
	
	
							
def VerifyIfQualityPosted(Database, Client, Plant, Order, Phase, SAPResourceName):
	try:
	
		Query_Parameters = {"database": Database, "client": Client, "plant":Plant, "order": Order, "Phase": Phase, "SAPResourceName": SAPResourceName}
		Query_Result = system.db.runNamedQuery("MII_Ignition_Queries/Quality/VerifyPostedQualityResultsPerPhase", Query_Parameters)
		
		if Query_Result[0][0] > 0: 
		    VerifyIfQualityPosted = 1
		else:
		    VerifyIfQualityPosted = 0
		    
		return VerifyIfQualityPosted
		
	except Exception as e:
		Status = e
		return Status
		MII_Ignition_Library.Logger.Insert_Log.Insert_Error_Log(str(Client) + "_" + str(Plant) + "_" + "VerifyIfQualityPosted", Status)																	
	