'''
def Populate_PO_Tag(Tag_Provider, Client, Plant, PO, Resource, Resource_Description, Material, Material_Description, Batch_Number, Area_Description):

	try:

		#Local Parameters
		Area = ''						   #Area: Used to determine resource area prefix.
		Tag_Write_Error_Flag = False		   #Tag_Write_Error_Flag: Used to determine if a Tag write returned error.
						
		#Verify Resource Area Prefix
		if Resource[0:2] == 'LF' or Resource[0:2] == 'LA': #Liquid Filling
			Area = 'LF'
			
		elif Resource[0:2] == 'DF' or Resource[0:2] == 'DA': #Dry Processing
			Area = 'DP'
		
		elif Area_Description == 'LIQ_PROCESS_AREA': #MFG
			Area = 'LP/LP' + str(Resource[0:2])
			#return "Success."
		
		else: #Resource Area not Found
			MII_Ignition_Library.Logger.Insert_Log.Insert_Error_Log(Client + "_" + Plant + "_" + "Populate_PO_Tag_Module", "Error: Resource Area Prefix not found. Resource: " + Resource_Description)
			return "Error: Resource Area Prefix not found. Resource: " + Resource_Description
		
		
		#Populate PO Tags and validate if any tag writing fails in the process 
		Client_Response = system.tag.writeBlocking(Tag_Provider + "Coca-Cola/CPS/" + Plant + "/" + Area + "/" + Resource + "/PO/client",Client)
		if str(Client_Response[0]) != 'Good':
			Tag_Write_Error_Flag = True
			MII_Ignition_Library.Logger.Insert_Log.Insert_Error_Log(Client + "_" + Plant + "_" + "Populate_PO_Tag_Module", "Error: " + Tag_Provider + "Coca-Cola/CPS/" + Plant + "/" + Area + "/" + Resource + "/PO/client" + " " + str(Client_Response[0]) + " Inserted Client Value: " + Client)
								
								
		Plant_Response = system.tag.writeBlocking(Tag_Provider + "Coca-Cola/CPS/" + Plant + "/" + Area + "/" + Resource + "/PO/plant",Plant)
		if str(Plant_Response[0]) != 'Good':
			Tag_Write_Error_Flag = True
			MII_Ignition_Library.Logger.Insert_Log.Insert_Error_Log(Client + "_" + Plant + "_" + "Populate_PO_Tag_Module", "Error: " + Tag_Provider + "Coca-Cola/CPS/" + Plant + "/" + Area + "/" + Resource + "/PO/plant" + " " + str(Plant_Response[0]) + " Inserted Plant Value: " + Plant)
									
														
		PO_Response = system.tag.writeBlocking(Tag_Provider + "Coca-Cola/CPS/" + Plant + "/" + Area + "/" + Resource + "/PO/poNumber",PO)
		if str(PO_Response[0]) != 'Good':
			Tag_Write_Error_Flag = True
			MII_Ignition_Library.Logger.Insert_Log.Insert_Error_Log(Client + "_" + Plant + "_" + "Populate_PO_Tag_Module", "Error: " + Tag_Provider + "Coca-Cola/CPS/" + Plant + "/" + Area + "/" + Resource + "/PO/poNumber" + " " + str(PO_Response[0]) + " Inserted PO Value: " + PO)
									
															
		Resource_Response = system.tag.writeBlocking(Tag_Provider + "Coca-Cola/CPS/" + Plant + "/" + Area + "/" + Resource + "/PO/actualResource",Resource)
		if str(Resource_Response[0]) != 'Good':
			Tag_Write_Error_Flag = True
			MII_Ignition_Library.Logger.Insert_Log.Insert_Error_Log(Client + "_" + Plant + "_" + "Populate_PO_Tag_Module", "Error: " + Tag_Provider + "Coca-Cola/CPS/" + Plant + "/" + Area + "/" + Resource + "/PO/actualResource" + " " + str(Resource_Response[0]) + " Inserted Resource Value: " + Resource)
									
															
		Resource_Description_Response = system.tag.writeBlocking(Tag_Provider + "Coca-Cola/CPS/" + Plant + "/" + Area + "/" + Resource + "/PO/actualResourceDesc",Resource_Description)
		if str(Resource_Description_Response[0]) != 'Good':
			Tag_Write_Error_Flag = True
			MII_Ignition_Library.Logger.Insert_Log.Insert_Error_Log(Client + "_" + Plant + "_" + "Populate_PO_Tag_Module", "Error: " + Tag_Provider + "Coca-Cola/CPS/" + Plant + "/" + Area + "/" + Resource + "/PO/actualResourceDesc" + " " + str(Resource_Description_Response[0]) + " Inserted Resource_Description Value: " + Resource_Description)
															
								
		Material_Response = system.tag.writeBlocking(Tag_Provider + "Coca-Cola/CPS/" + Plant + "/" + Area + "/" + Resource + "/PO/material",Material)
		if str(Material_Response[0]) != 'Good':
			Tag_Write_Error_Flag = True
			MII_Ignition_Library.Logger.Insert_Log.Insert_Error_Log(Client + "_" + Plant + "_" + "Populate_PO_Tag_Module", "Error: " + Tag_Provider + "Coca-Cola/CPS/" + Plant + "/" + Area + "/" + Resource + "/PO/material" + " " + str(Material_Response[0]) + " Inserted Material Value: " + Material)
																
								
		Material_Description_Response = system.tag.writeBlocking(Tag_Provider + "Coca-Cola/CPS/" + Plant + "/" + Area + "/" + Resource + "/PO/matDesc",Material_Description)
		if str(Material_Description_Response[0]) != 'Good':
			Tag_Write_Error_Flag = True
			MII_Ignition_Library.Logger.Insert_Log.Insert_Error_Log(Client + "_" + Plant + "_" + "Populate_PO_Tag_Module", "Error: " + Tag_Provider + "Coca-Cola/CPS/" + Plant + "/" + Area + "/" + Resource + "/PO/matDesc" + " " + str(Material_Description_Response[0]) + " Inserted Material_Description Value: " + Material_Description)
									
														
		Batch_Number_Response = system.tag.writeBlocking(Tag_Provider + "Coca-Cola/CPS/" + Plant + "/" + Area + "/" + Resource + "/PO/batch",Batch_Number)
		if str(Batch_Number_Response[0]) != 'Good':
			Tag_Write_Error_Flag = True
			MII_Ignition_Library.Logger.Insert_Log.Insert_Error_Log(Client + "_" + Plant + "_" + "Populate_PO_Tag_Module", "Error: " + Tag_Provider + "Coca-Cola/CPS/" + Plant + "/" + Area + "/" + Resource + "/PO/batch" + " " + str(Batch_Number_Response[0]) + " Inserted  Batch_Number Value: " + Batch_Number)
								
					
		#Validate if a PO Tag write returned error
		if Tag_Write_Error_Flag == True:
			MII_Ignition_Library.Logger.Insert_Log.Insert_Error_Log(Client + "_" + Plant + "_" + "Populate_PO_Tag_Module", "Error: There was an error while trying to populate a PO Tag value. Check logger for more information. Resource: " + Resource + " " + Resource_Description)
			return "Error: There was an error while trying to populate a PO Tag value. Check logger for more information. Resource: " + Resource_Description
								
		else:				
			#Script executed succesffuly
			return "Success."
		
	except:
	 	MII_Ignition_Library.Logger.Insert_Log.Insert_Error_Log(Client + "_" + Plant + "_" + "Populate_PO_Tag_Module", "Error: MII_Ignition_Library.Production_Data.Populate_Resource_PO_Tag.Populate_PO_Tag has failed. Check log for details. Resource: " + Resource + " " + Resource_Description)
		return "Error: MII_Ignition_Library.Production_Data.Populate_Resource_PO_Tag.Populate_PO_Tag has failed. Check log for details. Resource: "  + Resource_Description
''' 
 
 
 
def Populate_PO_Header_Tag(Tag_Provider, Client, Plant, PO, Batch_Number, Storage_Location, Material, Material_Description,	PP_Material_Group, PP_Order_Type, Required_Quantity, Required_Quantity_UOM, Inspection_Lot, Collective_Order_Leader, Collective_Order_Dependent, Collective_Order, S4_MII_Status, MII_PO_Status, Resource, Resource_Description, Node_ID, Node_Type, PLNNR, PLNME, PLNAL, PLNTY, PLGRP, Scheduled_Start_Date, Scheduled_Start_Time, Scheduled_End_Date, Scheduled_End_Time, Duration, Duration_UOM,	Order_Type, MSGFN, Language_Key, SAP_Language_Key,	Material_Group, Material_Type, XCHPF, PP_Target, PP_Target_UOM, PP_Target_LL, PP_Target_UL, SP_Target, SP_Target_UOM, SP_Target_LL, SP_Target_UL, Area_Description, BLS_Status, BLS_Message):
	try:
	
		#Local Parameters
		Area = ''						   #Area: Used to determine resource area prefix.
		Tag_Write_Error_Flag = False		   #Tag_Write_Error_Flag: Used to determine if a Tag write returned error.

				
		#Verify Resource Area Prefix
		'''
		if Work_Center[0:2] == 'LF' or Work_Center[0:2] == 'LA': #Liquid Filling
			Area = 'LF'
			
		elif Work_Center[0:2] == 'DF' or Work_Center[0:2] == 'DA': #Dry Processing
			Area = 'DP'
		
		elif Area_Description == 'LIQ_PROCESS_AREA': #MFG
			Area = 'LP/LP' + str(Work_Center[0:2])
			#return "Success."
		
		else: #Resource Area not Found
			MII_Ignition_Library.Logger.Insert_Log.Insert_Error_Log(Client + "_" + Plant + "_" + "Populate_", "Error: Resource Area Prefix not found. Resource: " + Work_Center)
			return "Error: Resource Area Prefix not found. Resource: " + Work_Center
		'''
		Status,ReturnVal = MII_Ignition_Library.ToolsSet.Tools.GetArea(Client,Plant,Resource,Area_Description)
				
		if Status != "Success.":
			return Status
		else:
			Area = ReturnVal



		#Populate PO Header Tags and validate if any tag writing fails in the process 
		Response = MII_Ignition_Library.Tags.Write.Write_Single_Value(Tag_Provider + "Coca-Cola/CPS/" + Plant + "/" + Area + "/" + Resource + "/PO/Header/client", Client)
		if str(Response) != 'Good':
			return "Error: There was an error while trying to populate a PO Tag value. Check logger for more information. Resource: " + Resource_Description
		
		
		Response = MII_Ignition_Library.Tags.Write.Write_Single_Value(Tag_Provider + "Coca-Cola/CPS/" + Plant + "/" + Area + "/" + Resource + "/PO/Header/plant",Plant)
		if str(Response) != 'Good':
			return "Error: There was an error while trying to populate a PO Tag value. Check logger for more information. Resource: " + Resource_Description
				
		
		Response = MII_Ignition_Library.Tags.Write.Write_Single_Value(Tag_Provider + "Coca-Cola/CPS/" + Plant + "/" + Area + "/" + Resource + "/PO/Header/processOrder",PO)
		if str(Response) != 'Good':
			return "Error: There was an error while trying to populate a PO Tag value. Check logger for more information. Resource: " + Resource_Description
		
		
		Response = MII_Ignition_Library.Tags.Write.Write_Single_Value(Tag_Provider + "Coca-Cola/CPS/" + Plant + "/" + Area + "/" + Resource + "/PO/Header/batchNumber",Batch_Number)
		if str(Response) != 'Good':
			return "Error: There was an error while trying to populate a PO Tag value. Check logger for more information. Resource: " + Resource_Description
																																																																																
																																																																																																																																																											
		Response = MII_Ignition_Library.Tags.Write.Write_Single_Value(Tag_Provider + "Coca-Cola/CPS/" + Plant + "/" + Area + "/" + Resource + "/PO/Header/storageLocation",Storage_Location)
		if str(Response) != 'Good':
			return "Error: There was an error while trying to populate a PO Tag value. Check logger for more information. Resource: " + Resource_Description
		
		
		Response = MII_Ignition_Library.Tags.Write.Write_Single_Value(Tag_Provider + "Coca-Cola/CPS/" + Plant + "/" + Area + "/" + Resource + "/PO/Header/materialNumber",Material)
		if str(Response) != 'Good':
			return "Error: There was an error while trying to populate a PO Tag value. Check logger for more information. Resource: " + Resource_Description	
		
		
		Response = MII_Ignition_Library.Tags.Write.Write_Single_Value(Tag_Provider + "Coca-Cola/CPS/" + Plant + "/" + Area + "/" + Resource + "/PO/Header/materialDescription",Material_Description)
		if str(Response) != 'Good':
			return "Error: There was an error while trying to populate a PO Tag value. Check logger for more information. Resource: " + Resource_Description	
		
		
		Response = MII_Ignition_Library.Tags.Write.Write_Single_Value(Tag_Provider + "Coca-Cola/CPS/" + Plant + "/" + Area + "/" + Resource + "/PO/Header/ppMaterialGroup",PP_Material_Group)
		if str(Response) != 'Good':
			return "Error: There was an error while trying to populate a PO Tag value. Check logger for more information. Resource: " + Resource_Description	
		
		
		Response = MII_Ignition_Library.Tags.Write.Write_Single_Value(Tag_Provider + "Coca-Cola/CPS/" + Plant + "/" + Area + "/" + Resource + "/PO/Header/ppOrderType",PP_Order_Type)
		if str(Response) != 'Good':
			return "Error: There was an error while trying to populate a PO Tag value. Check logger for more information. Resource: " + Resource_Description	
		
		
		Response = MII_Ignition_Library.Tags.Write.Write_Single_Value(Tag_Provider + "Coca-Cola/CPS/" + Plant + "/" + Area + "/" + Resource + "/PO/Header/requiredQuantity",Required_Quantity)
		if str(Response) != 'Good':
			return "Error: There was an error while trying to populate a PO Tag value. Check logger for more information. Resource: " + Resource_Description	
			
			
		Response = MII_Ignition_Library.Tags.Write.Write_Single_Value(Tag_Provider + "Coca-Cola/CPS/" + Plant + "/" + Area + "/" + Resource + "/PO/Header/requiredQuantityUom",Required_Quantity_UOM)
		if str(Response) != 'Good':
			return "Error: There was an error while trying to populate a PO Tag value. Check logger for more information. Resource: " + Resource_Description
		
		
		Response = MII_Ignition_Library.Tags.Write.Write_Single_Value(Tag_Provider + "Coca-Cola/CPS/" + Plant + "/" + Area + "/" + Resource + "/PO/Header/inspectionLot",Inspection_Lot)
		if str(Response) != 'Good':
			return "Error: There was an error while trying to populate a PO Tag value. Check logger for more information. Resource: " + Resource_Description	
		
		
		Response = MII_Ignition_Library.Tags.Write.Write_Single_Value(Tag_Provider + "Coca-Cola/CPS/" + Plant + "/" + Area + "/" + Resource + "/PO/Header/collectiveOrderLeader",Collective_Order_Leader)
		if str(Response) != 'Good':
			return "Error: There was an error while trying to populate a PO Tag value. Check logger for more information. Resource: " + Resource_Description	
		
		
		Response = MII_Ignition_Library.Tags.Write.Write_Single_Value(Tag_Provider + "Coca-Cola/CPS/" + Plant + "/" + Area + "/" + Resource + "/PO/Header/collectiveOrderDependent",Collective_Order_Dependent)
		if str(Response) != 'Good':
			return "Error: There was an error while trying to populate a PO Tag value. Check logger for more information. Resource: " + Resource_Description	
		
		
		Response = MII_Ignition_Library.Tags.Write.Write_Single_Value(Tag_Provider + "Coca-Cola/CPS/" + Plant + "/" + Area + "/" + Resource + "/PO/Header/collectiveOrder",Collective_Order)
		if str(Response) != 'Good':
			return "Error: There was an error while trying to populate a PO Tag value. Check logger for more information. Resource: " + Resource_Description	
		
		''' 2024-06-23- : PO Status and S4 MII Status are being populated depending on PO Execution Logic, instead of XML Download
		
		Response = MII_Ignition_Library.Tags.Write.Write_Single_Value(Tag_Provider + "Coca-Cola/CPS/" + Plant + "/" + Area + "/" + Resource + "/PO/Header/s4MIIStatus",S4_MII_Status)
		if str(Response) != 'Good':
			return "Error: There was an error while trying to populate a PO Tag value. Check logger for more information. Resource: " + Resource_Description	
	
			
		Response = MII_Ignition_Library.Tags.Write.Write_Single_Value(Tag_Provider + "Coca-Cola/CPS/" + Plant + "/" + Area + "/" + Resource + "/PO/Header/miiPoStatus",MII_PO_Status)
		if str(Response) != 'Good':
			return "Error: There was an error while trying to populate a PO Tag value. Check logger for more information. Resource: " + Resource_Description
		'''
			
		Response = MII_Ignition_Library.Tags.Write.Write_Single_Value(Tag_Provider + "Coca-Cola/CPS/" + Plant + "/" + Area + "/" + Resource + "/PO/Header/taskListGroupKey",PLNNR)
		if str(Response) != 'Good':
			return "Error: There was an error while trying to populate a PO Tag value. Check logger for more information. Resource: " + Resource_Description	
											
		Response = MII_Ignition_Library.Tags.Write.Write_Single_Value(Tag_Provider + "Coca-Cola/CPS/" + Plant + "/" + Area + "/" + Resource + "/PO/Header/taskListUom",PLNME)
		if str(Response) != 'Good':
			return "Error: There was an error while trying to populate a PO Tag value. Check logger for more information. Resource: " + Resource_Description
		
		
		Response = MII_Ignition_Library.Tags.Write.Write_Single_Value(Tag_Provider + "Coca-Cola/CPS/" + Plant + "/" + Area + "/" + Resource + "/PO/Header/groupCounter",PLNAL)
		if str(Response) != 'Good':
			return "Error: There was an error while trying to populate a PO Tag value. Check logger for more information. Resource: " + Resource_Description	
		
		
		Response = MII_Ignition_Library.Tags.Write.Write_Single_Value(Tag_Provider + "Coca-Cola/CPS/" + Plant + "/" + Area + "/" + Resource + "/PO/Header/taskListType",PLNTY)
		if str(Response) != 'Good':
			return "Error: There was an error while trying to populate a PO Tag value. Check logger for more information. Resource: " + Resource_Description	
		
		
		Response = MII_Ignition_Library.Tags.Write.Write_Single_Value(Tag_Provider + "Coca-Cola/CPS/" + Plant + "/" + Area + "/" + Resource + "/PO/Header/responsiblePlannerGroup",PLGRP)
		if str(Response) != 'Good':
			return "Error: There was an error while trying to populate a PO Tag value. Check logger for more information. Resource: " + Resource_Description	
		
		
		Response = MII_Ignition_Library.Tags.Write.Write_Single_Value(Tag_Provider + "Coca-Cola/CPS/" + Plant + "/" + Area + "/" + Resource + "/PO/Header/scheduledStartDate",Scheduled_Start_Date)
		if str(Response) != 'Good':
			return "Error: There was an error while trying to populate a PO Tag value. Check logger for more information. Resource: " + Resource_Description	
		
		
		Response = MII_Ignition_Library.Tags.Write.Write_Single_Value(Tag_Provider + "Coca-Cola/CPS/" + Plant + "/" + Area + "/" + Resource + "/PO/Header/scheduledStartTime",Scheduled_Start_Time)
		if str(Response) != 'Good':
			return "Error: There was an error while trying to populate a PO Tag value. Check logger for more information. Resource: " + Resource_Description	
															
									
									
		Response = MII_Ignition_Library.Tags.Write.Write_Single_Value(Tag_Provider + "Coca-Cola/CPS/" + Plant + "/" + Area + "/" + Resource + "/PO/Header/scheduledEndDate",Scheduled_End_Date)
		if str(Response) != 'Good':
			return "Error: There was an error while trying to populate a PO Tag value. Check logger for more information. Resource: " + Resource_Description
		
		
		Response = MII_Ignition_Library.Tags.Write.Write_Single_Value(Tag_Provider + "Coca-Cola/CPS/" + Plant + "/" + Area + "/" + Resource + "/PO/Header/scheduledEndTime",Scheduled_End_Time)
		if str(Response) != 'Good':
			return "Error: There was an error while trying to populate a PO Tag value. Check logger for more information. Resource: " + Resource_Description	
		
		
		Response = MII_Ignition_Library.Tags.Write.Write_Single_Value(Tag_Provider + "Coca-Cola/CPS/" + Plant + "/" + Area + "/" + Resource + "/PO/Header/duration",Duration)
		if str(Response) != 'Good':
			return "Error: There was an error while trying to populate a PO Tag value. Check logger for more information. Resource: " + Resource_Description	
		
		
		Response = MII_Ignition_Library.Tags.Write.Write_Single_Value(Tag_Provider + "Coca-Cola/CPS/" + Plant + "/" + Area + "/" + Resource + "/PO/Header/durationUom",Duration_UOM)
		if str(Response) != 'Good':
			return "Error: There was an error while trying to populate a PO Tag value. Check logger for more information. Resource: " + Resource_Description	
		
		
		Response = MII_Ignition_Library.Tags.Write.Write_Single_Value(Tag_Provider + "Coca-Cola/CPS/" + Plant + "/" + Area + "/" + Resource + "/PO/Header/orderType",Order_Type)
		if str(Response) != 'Good':
			return "Error: There was an error while trying to populate a PO Tag value. Check logger for more information. Resource: " + Resource_Description	
		
		
		Response = MII_Ignition_Library.Tags.Write.Write_Single_Value(Tag_Provider + "Coca-Cola/CPS/" + Plant + "/" + Area + "/" + Resource + "/PO/Header/msgFunctionCode",MSGFN)
		if str(Response) != 'Good':
			return "Error: There was an error while trying to populate a PO Tag value. Check logger for more information. Resource: " + Resource_Description	
																			
									
									
		Response = MII_Ignition_Library.Tags.Write.Write_Single_Value(Tag_Provider + "Coca-Cola/CPS/" + Plant + "/" + Area + "/" + Resource + "/PO/Header/languageKey",Language_Key)
		if str(Response) != 'Good':
			return "Error: There was an error while trying to populate a PO Tag value. Check logger for more information. Resource: " + Resource_Description
		
		
		Response = MII_Ignition_Library.Tags.Write.Write_Single_Value(Tag_Provider + "Coca-Cola/CPS/" + Plant + "/" + Area + "/" + Resource + "/PO/Header/sapLanguageKey",SAP_Language_Key)
		if str(Response) != 'Good':
			return "Error: There was an error while trying to populate a PO Tag value. Check logger for more information. Resource: " + Resource_Description	
		
		
		Response = MII_Ignition_Library.Tags.Write.Write_Single_Value(Tag_Provider + "Coca-Cola/CPS/" + Plant + "/" + Area + "/" + Resource + "/PO/Header/materialGroup",Material_Group)
		if str(Response) != 'Good':
			return "Error: There was an error while trying to populate a PO Tag value. Check logger for more information. Resource: " + Resource_Description	
		
		
		Response = MII_Ignition_Library.Tags.Write.Write_Single_Value(Tag_Provider + "Coca-Cola/CPS/" + Plant + "/" + Area + "/" + Resource + "/PO/Header/materialType",Material_Type)
		if str(Response) != 'Good':
			return "Error: There was an error while trying to populate a PO Tag value. Check logger for more information. Resource: " + Resource_Description	
		
		
		Response = MII_Ignition_Library.Tags.Write.Write_Single_Value(Tag_Provider + "Coca-Cola/CPS/" + Plant + "/" + Area + "/" + Resource + "/PO/Header/batchMgmtReqInd",XCHPF)
		if str(Response) != 'Good':
			return "Error: There was an error while trying to populate a PO Tag value. Check logger for more information. Resource: " + Resource_Description	
		
				
		Response = MII_Ignition_Library.Tags.Write.Write_Single_Value(Tag_Provider + "Coca-Cola/CPS/" + Plant + "/" + Area + "/" + Resource + "/PO/Header/spTarget",SP_Target)
		if str(Response) != 'Good':
			return "Error: There was an error while trying to populate a PO Tag value. Check logger for more information. Resource: " + Resource_Description	
		
		
		Response = MII_Ignition_Library.Tags.Write.Write_Single_Value(Tag_Provider + "Coca-Cola/CPS/" + Plant + "/" + Area + "/" + Resource + "/PO/Header/spTargetUom",SP_Target_UOM)
		if str(Response) != 'Good':
			return "Error: There was an error while trying to populate a PO Tag value. Check logger for more information. Resource: " + Resource_Description	
		
		
		Response = MII_Ignition_Library.Tags.Write.Write_Single_Value(Tag_Provider + "Coca-Cola/CPS/" + Plant + "/" + Area + "/" + Resource + "/PO/Header/spTargetLL",SP_Target_LL)
		if str(Response) != 'Good':
			return "Error: There was an error while trying to populate a PO Tag value. Check logger for more information. Resource: " + Resource_Description	
																			
									
		Response = MII_Ignition_Library.Tags.Write.Write_Single_Value(Tag_Provider + "Coca-Cola/CPS/" + Plant + "/" + Area + "/" + Resource + "/PO/Header/spTargetUL",SP_Target_UL)
		if str(Response) != 'Good':
			return "Error: There was an error while trying to populate a PO Tag value. Check logger for more information. Resource: " + Resource_Description	
		
		
		Response = MII_Ignition_Library.Tags.Write.Write_Single_Value(Tag_Provider + "Coca-Cola/CPS/" + Plant + "/" + Area + "/" + Resource + "/PO/Header/area",Area_Description)
		if str(Response) != 'Good':
			return "Error: There was an error while trying to populate a PO Tag value. Check logger for more information. Resource: " + Resource_Description	
		
		
		Response = MII_Ignition_Library.Tags.Write.Write_Single_Value(Tag_Provider + "Coca-Cola/CPS/" + Plant + "/" + Area + "/" + Resource + "/PO/Header/blsStatus",BLS_Status)
		if str(Response) != 'Good':
			return "Error: There was an error while trying to populate a PO Tag value. Check logger for more information. Resource: " + Resource_Description	
		
		
		Response = MII_Ignition_Library.Tags.Write.Write_Single_Value(Tag_Provider + "Coca-Cola/CPS/" + Plant + "/" + Area + "/" + Resource + "/PO/Header/blsMessage",BLS_Message)
		if str(Response) != 'Good':
			return "Error: There was an error while trying to populate a PO Tag value. Check logger for more information. Resource: " + Resource_Description								
			
											
		#Script executed succesffuly
		return "Success."
	
	except Exception as e:
		Status = e
		return Status
		MII_Ignition_Library.Logger.Insert_Log.Insert_Error_Log(Status)	
	#except:
		#MII_Ignition_Library.Logger.Insert_Log.Insert_Error_Log(Client + "_" + Plant + "_" + "Populate_PO_Tag_Module", "Error: MII_Ignition_Library.Production_Data.Populate_Resource_PO_Tag.Populate_PO_Header has failed. Check log for details. Resource: " + Resource + " " + Resource_Description)
		#return "Error: MII_Ignition_Library.Production_Data.Populate_Resource_PO_Tag.Populate_PO_Header has failed. Check log for details. Resource: "  + Resource_Description








def Populate_PO_Header_Phases_Tag(Tag_Provider,PH_Client, PH_Process_Order, PH_Plant, PH_Batch_Number, PH_Storage_Location, PH_S4_MII_Status, PH_MII_PO_Status, PH_Material, PH_Material_Description, PH_Required_Quantity, PH_Required_Quantity_UOM, PH_Scheduled_Start_Date, PH_Scheduled_Start_Time, PH_Scheduled_Finish_Date , PH_Scheduled_Finish_Time, PH_Order_Type, PH_PLNNR, PH_PLNME, PH_PLNAL, PH_PLNTY, PH_PLGRP, PH_Work_Center, PH_Description, PH_Node_ID, PH_Nodename, PH_Operation_Quantity, PH_Operation_Quantity_UOM, PH_Operation, PH_Phase, PH_Control_Key, PH_Operation_Description , PH_MII_PH_Status , PH_Reserved_Material, PH_Reserved_Material_Description, PH_Requirements_Quantity, PH_Requirements_Quantity_UOM , PH_ERP_Send_Time, PH_OEE_Relevant,     PH_Base_Quantity, PH_Base_UOM_For_Material, PH_Breaktime, PH_Breaktime_UOM, PH_BEARZ,PH_BEAZE,    PH_SBMNG, PH_VGW01, PH_VGE01, PH_VGW02, PH_VGE02, PH_VGW03, PH_VGE03, PH_VGW04, PH_VGE04, PH_VGW05, PH_VGE05, PH_VGW06, PH_VGE06, PH_Latest_Scheduled_Start_Date, PH_Latest_Scheduled_Start_Time, PH_Latest_Scheduled_Finish_Date, PH_Latest_Scheduled_Finish_Time, PH_Ddiff_Duration, PH_Ddiff_Duration_UOM, PH_STDVAL_Duration, PH_STDVAL_Duration_UOM, PH_BLS_Status, PH_BLS_Message, PH_MSGFN, PH_Language_Key, PH_SAP_Language_Key, PH_Material_Group, PH_Material_Type, PH_XCHPF, PH_RESB_MSGFN, PH_Reserved_Language_Key, PH_Reserved_SAP_Language_Key, PH_Reserved_Material_Group, PH_Reserved_Material_Type, PH_RESB_XCHPF, PH_Record_Found_Qty, PH_Inspection_Lot, PH_Ph_Execution_Start_Date, PH_Ph_Execution_Start_Time, PH_Ph_Execution_End_Date, PH_Ph_Execution_End_Time, PH_Area):
 	try:
 		
		#Local Parameters
		Area = ''						   #Area: Used to determine resource area prefix.
		
			
		#Verify Resource Area Prefix
		'''
		if PH_Work_Center[0:2] == 'LF' or PH_Work_Center[0:2] == 'LA': #Liquid Filling
			Area = 'LF'
			
		elif PH_Work_Center[0:2] == 'DF' or PH_Work_Center[0:2] == 'DA': #Dry Processing
			Area = 'DP'
		
		elif PH_Area == 'LIQ_PROCESS_AREA': #MFG
			Area = 'LP/LP' + str(PH_Work_Center[0:2])
			#return "Success."
		
		else: #Resource Area not Found
			MII_Ignition_Library.Logger.Insert_Log.Insert_Error_Log(PH_Client + "_" + PH_Plant + "_" + "Populate_PO_Header_Phases", "Error: Resource Area Prefix not found. Resource: " + PH_Nodename)
			return "Error: Resource Area Prefix not found. Resource: " + PH_Nodename
		'''
		
		Status,ReturnVal = MII_Ignition_Library.ToolsSet.Tools.GetArea(PH_Client,PH_Plant,PH_Work_Center,PH_Area)
				
		if Status != "Success.":
			return Status
		else:
			Area = ReturnVal


		#Populate PO Header Phases Tags and validate if any tag writing fails in the process 
		Response = MII_Ignition_Library.Tags.Write.Write_Single_Value(Tag_Provider + "Coca-Cola/CPS/" + PH_Plant + "/" + Area + "/" + PH_Work_Center + "/PO/Phase/pClient",PH_Client)
		if str(Response) != 'Good':
			return "Error: There was an error while trying to populate a PO Tag value. Check logger for more information. Resource: " + PH_Nodename
			
		Response = MII_Ignition_Library.Tags.Write.Write_Single_Value(Tag_Provider + "Coca-Cola/CPS/" + PH_Plant + "/" + Area + "/" + PH_Work_Center + "/PO/Phase/pProcessOrder",PH_Process_Order)
		if str(Response) != 'Good':
			return "Error: There was an error while trying to populate a PO Tag value. Check logger for more information. Resource " + PH_Nodename	
			
			
		Response = MII_Ignition_Library.Tags.Write.Write_Single_Value(Tag_Provider + "Coca-Cola/CPS/" + PH_Plant + "/" + Area + "/" + PH_Work_Center + "/PO/Phase/pPlant",PH_Plant)
		if str(Response) != 'Good':
			return "Error: There was an error while trying to populate a PO Tag value. Check logger for more information. Resource " + PH_Nodename
			
			
		Response = MII_Ignition_Library.Tags.Write.Write_Single_Value(Tag_Provider + "Coca-Cola/CPS/" + PH_Plant + "/" + Area + "/" + PH_Work_Center + "/PO/Phase/pBatchNumber",PH_Batch_Number)
		if str(Response) != 'Good':
			return "Error: There was an error while trying to populate a PO Tag value. Check logger for more information. Resource " + PH_Nodename	
		
			
		Response = MII_Ignition_Library.Tags.Write.Write_Single_Value(Tag_Provider + "Coca-Cola/CPS/" + PH_Plant + "/" + Area + "/" + PH_Work_Center + "/PO/Phase/pStorageLocation",PH_Storage_Location)
		if str(Response) != 'Good':
			return "Error: There was an error while trying to populate a PO Tag value. Check logger for more information. Resource " + PH_Nodename
			
		''' 2024-06-23- : PO Status and S4 MII Status are being populated referencing PO Header
		Response = MII_Ignition_Library.Tags.Write.Write_Single_Value(Tag_Provider + "Coca-Cola/CPS/" + PH_Plant + "/" + Area + "/" + PH_Work_Center + "/PO/Phase/pS4MIIStatus",PH_S4_MII_Status)
		if str(Response) != 'Good':
			return "Error: There was an error while trying to populate a PO Tag value. Check logger for more information. Resource " + PH_Nodename	
			
		
		Response = MII_Ignition_Library.Tags.Write.Write_Single_Value(Tag_Provider + "Coca-Cola/CPS/" + PH_Plant + "/" + Area + "/" + PH_Work_Center + "/PO/Phase/pMIIPOStatus",PH_MII_PO_Status)
		if str(Response) != 'Good':
			return "Error: There was an error while trying to populate a PO Tag value. Check logger for more information. Resource " + PH_Nodename
		'''	
			
		Response = MII_Ignition_Library.Tags.Write.Write_Single_Value(Tag_Provider + "Coca-Cola/CPS/" + PH_Plant + "/" + Area + "/" + PH_Work_Center + "/PO/Phase/pMaterialNumber",PH_Material)
		if str(Response) != 'Good':
			return "Error: There was an error while trying to populate a PO Tag value. Check logger for more information. Resource " + PH_Nodename		
			
			
		Response = MII_Ignition_Library.Tags.Write.Write_Single_Value(Tag_Provider + "Coca-Cola/CPS/" + PH_Plant + "/" + Area + "/" + PH_Work_Center + "/PO/Phase/pMaterialDescription",PH_Material_Description)
		if str(Response) != 'Good':
			return "Error: There was an error while trying to populate a PO Tag value. Check logger for more information. Resource " + PH_Nodename
			
			
		Response = MII_Ignition_Library.Tags.Write.Write_Single_Value(Tag_Provider + "Coca-Cola/CPS/" + PH_Plant + "/" + Area + "/" + PH_Work_Center + "/PO/Phase/pRequiredQuantity",PH_Required_Quantity)
		if str(Response) != 'Good':
			return "Error: There was an error while trying to populate a PO Tag value. Check logger for more information. Resource " + PH_Nodename		
			
			
		Response = MII_Ignition_Library.Tags.Write.Write_Single_Value(Tag_Provider + "Coca-Cola/CPS/" + PH_Plant + "/" + Area + "/" + PH_Work_Center + "/PO/Phase/pRequiredQuantityUom",PH_Required_Quantity_UOM)
		if str(Response) != 'Good':
			return "Error: There was an error while trying to populate a PO Tag value. Check logger for more information. Resource " + PH_Nodename
			
			
		Response = MII_Ignition_Library.Tags.Write.Write_Single_Value(Tag_Provider + "Coca-Cola/CPS/" + PH_Plant + "/" + Area + "/" + PH_Work_Center + "/PO/Phase/pScheduledStartDate",PH_Scheduled_Start_Date)
		if str(Response) != 'Good':
			return "Error: There was an error while trying to populate a PO Tag value. Check logger for more information. Resource " + PH_Nodename	
			
			
		Response = MII_Ignition_Library.Tags.Write.Write_Single_Value(Tag_Provider + "Coca-Cola/CPS/" + PH_Plant + "/" + Area + "/" + PH_Work_Center + "/PO/Phase/pScheduledStartTime",PH_Scheduled_Start_Time)
		if str(Response) != 'Good':
			return "Error: There was an error while trying to populate a PO Tag value. Check logger for more information. Resource " + PH_Nodename
			
			
		Response = MII_Ignition_Library.Tags.Write.Write_Single_Value(Tag_Provider + "Coca-Cola/CPS/" + PH_Plant + "/" + Area + "/" + PH_Work_Center + "/PO/Phase/pScheduledFinishDate",PH_Scheduled_Finish_Date)
		if str(Response) != 'Good':
			return "Error: There was an error while trying to populate a PO Tag value. Check logger for more information. Resource " + PH_Nodename	
		
			
		Response = MII_Ignition_Library.Tags.Write.Write_Single_Value(Tag_Provider + "Coca-Cola/CPS/" + PH_Plant + "/" + Area + "/" + PH_Work_Center + "/PO/Phase/pScheduledFinishTime",PH_Scheduled_Finish_Time)
		if str(Response) != 'Good':
			return "Error: There was an error while trying to populate a PO Tag value. Check logger for more information. Resource " + PH_Nodename
			
			
		Response = MII_Ignition_Library.Tags.Write.Write_Single_Value(Tag_Provider + "Coca-Cola/CPS/" + PH_Plant + "/" + Area + "/" + PH_Work_Center + "/PO/Phase/pOrderType",PH_Order_Type)
		if str(Response) != 'Good':
			return "Error: There was an error while trying to populate a PO Tag value. Check logger for more information. Resource " + PH_Nodename	
			
			
		Response = MII_Ignition_Library.Tags.Write.Write_Single_Value(Tag_Provider + "Coca-Cola/CPS/" + PH_Plant + "/" + Area + "/" + PH_Work_Center + "/PO/Phase/pTaskListGroupKey",PH_PLNNR)
		if str(Response) != 'Good':
			return "Error: There was an error while trying to populate a PO Tag value. Check logger for more information. Resource " + PH_Nodename
			
			
		Response = MII_Ignition_Library.Tags.Write.Write_Single_Value(Tag_Provider + "Coca-Cola/CPS/" + PH_Plant + "/" + Area + "/" + PH_Work_Center + "/PO/Phase/pTaskListUom",PH_PLNME)
		if str(Response) != 'Good':
			return "Error: There was an error while trying to populate a PO Tag value. Check logger for more information. Resource " + PH_Nodename		
			
			
		Response = MII_Ignition_Library.Tags.Write.Write_Single_Value(Tag_Provider + "Coca-Cola/CPS/" + PH_Plant + "/" + Area + "/" + PH_Work_Center + "/PO/Phase/pGroupCounter",PH_PLNAL)
		if str(Response) != 'Good':
			return "Error: There was an error while trying to populate a PO Tag value. Check logger for more information. Resource " + PH_Nodename
			
			
		Response = MII_Ignition_Library.Tags.Write.Write_Single_Value(Tag_Provider + "Coca-Cola/CPS/" + PH_Plant + "/" + Area + "/" + PH_Work_Center + "/PO/Phase/pTaskListType",PH_PLNTY)
		if str(Response) != 'Good':
			return "Error: There was an error while trying to populate a PO Tag value. Check logger for more information. Resource " + PH_Nodename		
			
		
		Response = MII_Ignition_Library.Tags.Write.Write_Single_Value(Tag_Provider + "Coca-Cola/CPS/" + PH_Plant + "/" + Area + "/" + PH_Work_Center + "/PO/Phase/pResponsiblePlannerGroup",PH_PLGRP)
		if str(Response) != 'Good':
			return "Error: There was an error while trying to populate a PO Tag value. Check logger for more information. Resource " + PH_Nodename
			
			
		Response = MII_Ignition_Library.Tags.Write.Write_Single_Value(Tag_Provider + "Coca-Cola/CPS/" + PH_Plant + "/" + Area + "/" + PH_Work_Center + "/PO/Phase/pWorkCenter",PH_Work_Center)
		if str(Response) != 'Good':
			return "Error: There was an error while trying to populate a PO Tag value. Check logger for more information. Resource " + PH_Nodename	
			
			
		Response = MII_Ignition_Library.Tags.Write.Write_Single_Value(Tag_Provider + "Coca-Cola/CPS/" + PH_Plant + "/" + Area + "/" + PH_Work_Center + "/PO/Phase/pWorkCenterDescription",PH_Description)
		if str(Response) != 'Good':
			return "Error: There was an error while trying to populate a PO Tag value. Check logger for more information. Resource " + PH_Nodename
			
			
		Response = MII_Ignition_Library.Tags.Write.Write_Single_Value(Tag_Provider + "Coca-Cola/CPS/" + PH_Plant + "/" + Area + "/" + PH_Work_Center + "/PO/Phase/pNodeID",PH_Node_ID)
		if str(Response) != 'Good':
			return "Error: There was an error while trying to populate a PO Tag value. Check logger for more information. Resource " + PH_Nodename	
		
			
		Response = MII_Ignition_Library.Tags.Write.Write_Single_Value(Tag_Provider + "Coca-Cola/CPS/" + PH_Plant + "/" + Area + "/" + PH_Work_Center + "/PO/Phase/pNodeName",PH_Nodename)
		if str(Response) != 'Good':
			return "Error: There was an error while trying to populate a PO Tag value. Check logger for more information. Resource " + PH_Nodename
			
			
		Response = MII_Ignition_Library.Tags.Write.Write_Single_Value(Tag_Provider + "Coca-Cola/CPS/" + PH_Plant + "/" + Area + "/" + PH_Work_Center + "/PO/Phase/pPhaseQuantity",PH_Operation_Quantity)
		if str(Response) != 'Good':
			return "Error: There was an error while trying to populate a PO Tag value. Check logger for more information. Resource " + PH_Nodename	
			
			
		Response = MII_Ignition_Library.Tags.Write.Write_Single_Value(Tag_Provider + "Coca-Cola/CPS/" + PH_Plant + "/" + Area + "/" + PH_Work_Center + "/PO/Phase/pPhaseUom",PH_Operation_Quantity_UOM)
		if str(Response) != 'Good':
			return "Error: There was an error while trying to populate a PO Tag value. Check logger for more information. Resource " + PH_Nodename
			
			
		Response = MII_Ignition_Library.Tags.Write.Write_Single_Value(Tag_Provider + "Coca-Cola/CPS/" + PH_Plant + "/" + Area + "/" + PH_Work_Center + "/PO/Phase/pOperation",PH_Operation)
		if str(Response) != 'Good':
			return "Error: There was an error while trying to populate a PO Tag value. Check logger for more information. Resource " + PH_Nodename		
			
			
		Response = MII_Ignition_Library.Tags.Write.Write_Single_Value(Tag_Provider + "Coca-Cola/CPS/" + PH_Plant + "/" + Area + "/" + PH_Work_Center + "/PO/Phase/pPhase",PH_Phase)
		if str(Response) != 'Good':
			return "Error: There was an error while trying to populate a PO Tag value. Check logger for more information. Resource " + PH_Nodename
			
			
		Response = MII_Ignition_Library.Tags.Write.Write_Single_Value(Tag_Provider + "Coca-Cola/CPS/" + PH_Plant + "/" + Area + "/" + PH_Work_Center + "/PO/Phase/pControlKey",PH_Control_Key)
		if str(Response) != 'Good':
			return "Error: There was an error while trying to populate a PO Tag value. Check logger for more information. Resource " + PH_Nodename		
			
			
		Response = MII_Ignition_Library.Tags.Write.Write_Single_Value(Tag_Provider + "Coca-Cola/CPS/" + PH_Plant + "/" + Area + "/" + PH_Work_Center + "/PO/Phase/pPhaseShortText",PH_Operation_Description)
		if str(Response) != 'Good':
			return "Error: There was an error while trying to populate a PO Tag value. Check logger for more information. Resource " + PH_Nodename
			
		''' 2024-06-23- : PO Phase Status is being updated depending on PO Execution
		Response = MII_Ignition_Library.Tags.Write.Write_Single_Value(Tag_Provider + "Coca-Cola/CPS/" + PH_Plant + "/" + Area + "/" + PH_Work_Center + "/PO/Phase/pMIIPHStatus",PH_MII_PH_Status)
		if str(Response) != 'Good':
			return "Error: There was an error while trying to populate a PO Tag value. Check logger for more information. Resource " + PH_Nodename	
		'''	
			
		Response = MII_Ignition_Library.Tags.Write.Write_Single_Value(Tag_Provider + "Coca-Cola/CPS/" + PH_Plant + "/" + Area + "/" + PH_Work_Center + "/PO/Phase/pReservedMaterial",PH_Reserved_Material)
		if str(Response) != 'Good':
			return "Error: There was an error while trying to populate a PO Tag value. Check logger for more information. Resource " + PH_Nodename
			
			
		Response = MII_Ignition_Library.Tags.Write.Write_Single_Value(Tag_Provider + "Coca-Cola/CPS/" + PH_Plant + "/" + Area + "/" + PH_Work_Center + "/PO/Phase/pReservedMaterialDescription",PH_Reserved_Material_Description)
		if str(Response) != 'Good':
			return "Error: There was an error while trying to populate a PO Tag value. Check logger for more information. Resource " + PH_Nodename	
		
			
		Response = MII_Ignition_Library.Tags.Write.Write_Single_Value(Tag_Provider + "Coca-Cola/CPS/" + PH_Plant + "/" + Area + "/" + PH_Work_Center + "/PO/Phase/pRequirementQuantity",PH_Requirements_Quantity)
		if str(Response) != 'Good':
			return "Error: There was an error while trying to populate a PO Tag value. Check logger for more information. Resource " + PH_Nodename
		
		Response = MII_Ignition_Library.Tags.Write.Write_Single_Value(Tag_Provider + "Coca-Cola/CPS/" + PH_Plant + "/" + Area + "/" + PH_Work_Center + "/PO/Phase/pBaseUOM",PH_Requirements_Quantity_UOM)
		if str(Response) != 'Good':
			return "Error: There was an error while trying to populate a PO Tag value. Check logger for more information. Resource " + PH_Nodename	
					
			
		Response = MII_Ignition_Library.Tags.Write.Write_Single_Value(Tag_Provider + "Coca-Cola/CPS/" + PH_Plant + "/" + Area + "/" + PH_Work_Center + "/PO/Phase/pRequiredQuantityUom",PH_Required_Quantity_UOM)
		if str(Response) != 'Good':
			return "Error: There was an error while trying to populate a PO Tag value. Check logger for more information. Resource " + PH_Nodename	
			
			
		Response = MII_Ignition_Library.Tags.Write.Write_Single_Value(Tag_Provider + "Coca-Cola/CPS/" + PH_Plant + "/" + Area + "/" + PH_Work_Center + "/PO/Phase/pErpSendTime",PH_ERP_Send_Time)
		if str(Response) != 'Good':
			return "Error: There was an error while trying to populate a PO Tag value. Check logger for more information. Resource " + PH_Nodename
			
			
		Response = MII_Ignition_Library.Tags.Write.Write_Single_Value(Tag_Provider + "Coca-Cola/CPS/" + PH_Plant + "/" + Area + "/" + PH_Work_Center + "/PO/Phase/pOEERelevant",PH_OEE_Relevant)
		if str(Response) != 'Good':
			return "Error: There was an error while trying to populate a PO Tag value. Check logger for more information. Resource " + PH_Nodename		
		
			
		Response = MII_Ignition_Library.Tags.Write.Write_Single_Value(Tag_Provider + "Coca-Cola/CPS/" + PH_Plant + "/" + Area + "/" + PH_Work_Center + "/PO/Phase/pBaseQuantity",PH_Base_Quantity)
		if str(Response) != 'Good':
			return "Error: There was an error while trying to populate a PO Tag value. Check logger for more information. Resource " + PH_Nodename				
			
							
		Response = MII_Ignition_Library.Tags.Write.Write_Single_Value(Tag_Provider + "Coca-Cola/CPS/" + PH_Plant + "/" + Area + "/" + PH_Work_Center + "/PO/Phase/pBaseUOMForMaterial",PH_Base_UOM_For_Material)
		if str(Response) != 'Good':
			return "Error: There was an error while trying to populate a PO Tag value. Check logger for more information. Resource " + PH_Nodename						
			
											
		Response = MII_Ignition_Library.Tags.Write.Write_Single_Value(Tag_Provider + "Coca-Cola/CPS/" + PH_Plant + "/" + Area + "/" + PH_Work_Center + "/PO/Phase/pBreakTime",PH_Breaktime)
		if str(Response) != 'Good':
			return "Error: There was an error while trying to populate a PO Tag value. Check logger for more information. Resource " + PH_Nodename								
											
											
		Response = MII_Ignition_Library.Tags.Write.Write_Single_Value(Tag_Provider + "Coca-Cola/CPS/" + PH_Plant + "/" + Area + "/" + PH_Work_Center + "/PO/Phase/pBreakTimeUom",PH_Breaktime_UOM)
		if str(Response) != 'Good':
			return "Error: There was an error while trying to populate a PO Tag value. Check logger for more information. Resource " + PH_Nodename										
			
																																			
		Response = MII_Ignition_Library.Tags.Write.Write_Single_Value(Tag_Provider + "Coca-Cola/CPS/" + PH_Plant + "/" + Area + "/" + PH_Work_Center + "/PO/Phase/pProcessingTime",PH_BEARZ)
		if str(Response) != 'Good':
			return "Error: There was an error while trying to populate a PO Tag value. Check logger for more information. Resource " + PH_Nodename												
						
																						
		Response = MII_Ignition_Library.Tags.Write.Write_Single_Value(Tag_Provider + "Coca-Cola/CPS/" + PH_Plant + "/" + Area + "/" + PH_Work_Center + "/PO/Phase/pProcessingTimeUOM",PH_BEAZE)
		if str(Response) != 'Good':
			return "Error: There was an error while trying to populate a PO Tag value. Check logger for more information. Resource " + PH_Nodename		
			
							
								
									
											
		Response = MII_Ignition_Library.Tags.Write.Write_Single_Value(Tag_Provider + "Coca-Cola/CPS/" + PH_Plant + "/" + Area + "/" + PH_Work_Center + "/PO/Phase/pBaseQuantityForMaterial",PH_SBMNG)
		if str(Response) != 'Good':
			return "Error: There was an error while trying to populate a PO Tag value. Check logger for more information. Resource " + PH_Nodename
			
			
		Response = MII_Ignition_Library.Tags.Write.Write_Single_Value(Tag_Provider + "Coca-Cola/CPS/" + PH_Plant + "/" + Area + "/" + PH_Work_Center + "/PO/Phase/pStandardValue01",PH_VGW01)
		if str(Response) != 'Good':
			return "Error: There was an error while trying to populate a PO Tag value. Check logger for more information. Resource " + PH_Nodename		
				
						
		Response = MII_Ignition_Library.Tags.Write.Write_Single_Value(Tag_Provider + "Coca-Cola/CPS/" + PH_Plant + "/" + Area + "/" + PH_Work_Center + "/PO/Phase/pStandardValueUom01",PH_VGE01)
		if str(Response) != 'Good':
			return "Error: There was an error while trying to populate a PO Tag value. Check logger for more information. Resource " + PH_Nodename
			
			
		Response = MII_Ignition_Library.Tags.Write.Write_Single_Value(Tag_Provider + "Coca-Cola/CPS/" + PH_Plant + "/" + Area + "/" + PH_Work_Center + "/PO/Phase/pStandardValue02",PH_VGW02)
		if str(Response) != 'Good':
			return "Error: There was an error while trying to populate a PO Tag value. Check logger for more information. Resource " + PH_Nodename	
			
			
		Response = MII_Ignition_Library.Tags.Write.Write_Single_Value(Tag_Provider + "Coca-Cola/CPS/" + PH_Plant + "/" + Area + "/" + PH_Work_Center + "/PO/Phase/pStandardValueUom02",PH_VGE02)
		if str(Response) != 'Good':
			return "Error: There was an error while trying to populate a PO Tag value. Check logger for more information. Resource " + PH_Nodename
			
			
		Response = MII_Ignition_Library.Tags.Write.Write_Single_Value(Tag_Provider + "Coca-Cola/CPS/" + PH_Plant + "/" + Area + "/" + PH_Work_Center + "/PO/Phase/pStandardValue03",PH_VGW03)
		if str(Response) != 'Good':
			return "Error: There was an error while trying to populate a PO Tag value. Check logger for more information. Resource " + PH_Nodename	
		
			
		Response = MII_Ignition_Library.Tags.Write.Write_Single_Value(Tag_Provider + "Coca-Cola/CPS/" + PH_Plant + "/" + Area + "/" + PH_Work_Center + "/PO/Phase/pStandardValueUom03",PH_VGE03)
		if str(Response) != 'Good':
			return "Error: There was an error while trying to populate a PO Tag value. Check logger for more information. Resource " + PH_Nodename
			
			
		Response = MII_Ignition_Library.Tags.Write.Write_Single_Value(Tag_Provider + "Coca-Cola/CPS/" + PH_Plant + "/" + Area + "/" + PH_Work_Center + "/PO/Phase/pStandardValue04",PH_VGW04)
		if str(Response) != 'Good':
			return "Error: There was an error while trying to populate a PO Tag value. Check logger for more information. Resource " + PH_Nodename	
			
			
		Response = MII_Ignition_Library.Tags.Write.Write_Single_Value(Tag_Provider + "Coca-Cola/CPS/" + PH_Plant + "/" + Area + "/" + PH_Work_Center + "/PO/Phase/pStandardValueUom04",PH_VGE04)
		if str(Response) != 'Good':
			return "Error: There was an error while trying to populate a PO Tag value. Check logger for more information. Resource " + PH_Nodename
			
			
		Response = MII_Ignition_Library.Tags.Write.Write_Single_Value(Tag_Provider + "Coca-Cola/CPS/" + PH_Plant + "/" + Area + "/" + PH_Work_Center + "/PO/Phase/pStandardValue05",PH_VGW05)
		if str(Response) != 'Good':
			return "Error: There was an error while trying to populate a PO Tag value. Check logger for more information. Resource " + PH_Nodename		
			
			
		Response = MII_Ignition_Library.Tags.Write.Write_Single_Value(Tag_Provider + "Coca-Cola/CPS/" + PH_Plant + "/" + Area + "/" + PH_Work_Center + "/PO/Phase/pStandardValueUom05",PH_VGE05)
		if str(Response) != 'Good':
			return "Error: There was an error while trying to populate a PO Tag value. Check logger for more information. Resource " + PH_Nodename
			
			
		Response = MII_Ignition_Library.Tags.Write.Write_Single_Value(Tag_Provider + "Coca-Cola/CPS/" + PH_Plant + "/" + Area + "/" + PH_Work_Center + "/PO/Phase/pStandardValue06",PH_VGW06)
		if str(Response) != 'Good':
			return "Error: There was an error while trying to populate a PO Tag value. Check logger for more information. Resource " + PH_Nodename		
			
			
		Response = MII_Ignition_Library.Tags.Write.Write_Single_Value(Tag_Provider + "Coca-Cola/CPS/" + PH_Plant + "/" + Area + "/" + PH_Work_Center + "/PO/Phase/pStandardValueUom06",PH_VGE06)
		if str(Response) != 'Good':
			return "Error: There was an error while trying to populate a PO Tag value. Check logger for more information. Resource " + PH_Nodename
			
			
		Response = MII_Ignition_Library.Tags.Write.Write_Single_Value(Tag_Provider + "Coca-Cola/CPS/" + PH_Plant + "/" + Area + "/" + PH_Work_Center + "/PO/Phase/pLatestScheduledStartDate",PH_Latest_Scheduled_Start_Date)
		if str(Response) != 'Good':
			return "Error: There was an error while trying to populate a PO Tag value. Check logger for more information. Resource " + PH_Nodename	
			
			
		Response = MII_Ignition_Library.Tags.Write.Write_Single_Value(Tag_Provider + "Coca-Cola/CPS/" + PH_Plant + "/" + Area + "/" + PH_Work_Center + "/PO/Phase/pLatestScheduledStartTime",PH_Latest_Scheduled_Start_Time)
		if str(Response) != 'Good':
			return "Error: There was an error while trying to populate a PO Tag value. Check logger for more information. Resource " + PH_Nodename
			
			
		Response = MII_Ignition_Library.Tags.Write.Write_Single_Value(Tag_Provider + "Coca-Cola/CPS/" + PH_Plant + "/" + Area + "/" + PH_Work_Center + "/PO/Phase/pLatestScheduledFinishDate",PH_Latest_Scheduled_Finish_Date)
		if str(Response) != 'Good':
			return "Error: There was an error while trying to populate a PO Tag value. Check logger for more information. Resource " + PH_Nodename	
		
			
		Response = MII_Ignition_Library.Tags.Write.Write_Single_Value(Tag_Provider + "Coca-Cola/CPS/" + PH_Plant + "/" + Area + "/" + PH_Work_Center + "/PO/Phase/pLatestScheduledFinishTime",PH_Latest_Scheduled_Finish_Time)
		if str(Response) != 'Good':
			return "Error: There was an error while trying to populate a PO Tag value. Check logger for more information. Resource " + PH_Nodename
			
			
		Response = MII_Ignition_Library.Tags.Write.Write_Single_Value(Tag_Provider + "Coca-Cola/CPS/" + PH_Plant + "/" + Area + "/" + PH_Work_Center + "/PO/Phase/pDdiffDuration",PH_Ddiff_Duration)
		if str(Response) != 'Good':
			return "Error: There was an error while trying to populate a PO Tag value. Check logger for more information. Resource " + PH_Nodename	
			
			
		Response = MII_Ignition_Library.Tags.Write.Write_Single_Value(Tag_Provider + "Coca-Cola/CPS/" + PH_Plant + "/" + Area + "/" + PH_Work_Center + "/PO/Phase/pDdiffDurationUom",PH_Ddiff_Duration_UOM)
		if str(Response) != 'Good':
			return "Error: There was an error while trying to populate a PO Tag value. Check logger for more information. Resource " + PH_Nodename
			
			
		Response = MII_Ignition_Library.Tags.Write.Write_Single_Value(Tag_Provider + "Coca-Cola/CPS/" + PH_Plant + "/" + Area + "/" + PH_Work_Center + "/PO/Phase/pStdValDuration",PH_STDVAL_Duration)
		if str(Response) != 'Good':
			return "Error: There was an error while trying to populate a PO Tag value. Check logger for more information. Resource " + PH_Nodename		
			
			
		Response = MII_Ignition_Library.Tags.Write.Write_Single_Value(Tag_Provider + "Coca-Cola/CPS/" + PH_Plant + "/" + Area + "/" + PH_Work_Center + "/PO/Phase/pStdValDurationUom",PH_STDVAL_Duration_UOM)
		if str(Response) != 'Good':
			return "Error: There was an error while trying to populate a PO Tag value. Check logger for more information. Resource " + PH_Nodename
			
			
		Response = MII_Ignition_Library.Tags.Write.Write_Single_Value(Tag_Provider + "Coca-Cola/CPS/" + PH_Plant + "/" + Area + "/" + PH_Work_Center + "/PO/Phase/pBlsStatus",PH_BLS_Status)
		if str(Response) != 'Good':
			return "Error: There was an error while trying to populate a PO Tag value. Check logger for more information. Resource " + PH_Nodename		
	
		
		Response = MII_Ignition_Library.Tags.Write.Write_Single_Value(Tag_Provider + "Coca-Cola/CPS/" + PH_Plant + "/" + Area + "/" + PH_Work_Center + "/PO/Phase/pBlsMessage",PH_BLS_Message)
		if str(Response) != 'Good':
			return "Error: There was an error while trying to populate a PO Tag value. Check logger for more information. Resource " + PH_Nodename
			
			
		Response = MII_Ignition_Library.Tags.Write.Write_Single_Value(Tag_Provider + "Coca-Cola/CPS/" + PH_Plant + "/" + Area + "/" + PH_Work_Center + "/PO/Phase/pMsgFunctionCode",PH_MSGFN)
		if str(Response) != 'Good':
			return "Error: There was an error while trying to populate a PO Tag value. Check logger for more information. Resource " + PH_Nodename	
			
			
		Response = MII_Ignition_Library.Tags.Write.Write_Single_Value(Tag_Provider + "Coca-Cola/CPS/" + PH_Plant + "/" + Area + "/" + PH_Work_Center + "/PO/Phase/pLanguageKey",PH_Language_Key)
		if str(Response) != 'Good':
			return "Error: There was an error while trying to populate a PO Tag value. Check logger for more information. Resource " + PH_Nodename
			
			
		Response = MII_Ignition_Library.Tags.Write.Write_Single_Value(Tag_Provider + "Coca-Cola/CPS/" + PH_Plant + "/" + Area + "/" + PH_Work_Center + "/PO/Phase/pSAPLanguageKey",PH_SAP_Language_Key)
		if str(Response) != 'Good':
			return "Error: There was an error while trying to populate a PO Tag value. Check logger for more information. Resource " + PH_Nodename	
		
			
		Response = MII_Ignition_Library.Tags.Write.Write_Single_Value(Tag_Provider + "Coca-Cola/CPS/" + PH_Plant + "/" + Area + "/" + PH_Work_Center + "/PO/Phase/pMaterialGroup",PH_Material_Group)
		if str(Response) != 'Good':
			return "Error: There was an error while trying to populate a PO Tag value. Check logger for more information. Resource " + PH_Nodename
			
			
		Response = MII_Ignition_Library.Tags.Write.Write_Single_Value(Tag_Provider + "Coca-Cola/CPS/" + PH_Plant + "/" + Area + "/" + PH_Work_Center + "/PO/Phase/pMaterialType",PH_Material_Type)
		if str(Response) != 'Good':
			return "Error: There was an error while trying to populate a PO Tag value. Check logger for more information. Resource " + PH_Nodename	
			
			
		Response = MII_Ignition_Library.Tags.Write.Write_Single_Value(Tag_Provider + "Coca-Cola/CPS/" + PH_Plant + "/" + Area + "/" + PH_Work_Center + "/PO/Phase/pBatchMgmtReqInd",PH_XCHPF)
		if str(Response) != 'Good':
			return "Error: There was an error while trying to populate a PO Tag value. Check logger for more information. Resource " + PH_Nodename
			
			
		Response = MII_Ignition_Library.Tags.Write.Write_Single_Value(Tag_Provider + "Coca-Cola/CPS/" + PH_Plant + "/" + Area + "/" + PH_Work_Center + "/PO/Phase/pResbMsgFunctionCode",PH_RESB_MSGFN)
		if str(Response) != 'Good':
			return "Error: There was an error while trying to populate a PO Tag value. Check logger for more information. Resource " + PH_Nodename		
			
			
		Response = MII_Ignition_Library.Tags.Write.Write_Single_Value(Tag_Provider + "Coca-Cola/CPS/" + PH_Plant + "/" + Area + "/" + PH_Work_Center + "/PO/Phase/pReservedLanguageKey",PH_Reserved_Language_Key)
		if str(Response) != 'Good':
			return "Error: There was an error while trying to populate a PO Tag value. Check logger for more information. Resource " + PH_Nodename
			
			
		Response = MII_Ignition_Library.Tags.Write.Write_Single_Value(Tag_Provider + "Coca-Cola/CPS/" + PH_Plant + "/" + Area + "/" + PH_Work_Center + "/PO/Phase/pReservedSAPLanguageKey",PH_Reserved_SAP_Language_Key)
		if str(Response) != 'Good':
			return "Error: There was an error while trying to populate a PO Tag value. Check logger for more information. Resource " + PH_Nodename		
			
			
		Response = MII_Ignition_Library.Tags.Write.Write_Single_Value(Tag_Provider + "Coca-Cola/CPS/" + PH_Plant + "/" + Area + "/" + PH_Work_Center + "/PO/Phase/pReservedMaterialGroup",PH_Reserved_Material_Group)
		if str(Response) != 'Good':
			return "Error: There was an error while trying to populate a PO Tag value. Check logger for more information. Resource " + PH_Nodename
			
			
		Response = MII_Ignition_Library.Tags.Write.Write_Single_Value(Tag_Provider + "Coca-Cola/CPS/" + PH_Plant + "/" + Area + "/" + PH_Work_Center + "/PO/Phase/pReservedMaterialType",PH_Reserved_Material_Type)
		if str(Response) != 'Good':
			return "Error: There was an error while trying to populate a PO Tag value. Check logger for more information. Resource " + PH_Nodename	
			
			
		Response = MII_Ignition_Library.Tags.Write.Write_Single_Value(Tag_Provider + "Coca-Cola/CPS/" + PH_Plant + "/" + Area + "/" + PH_Work_Center + "/PO/Phase/pResbBatchMgmtReqInd",PH_RESB_XCHPF)
		if str(Response) != 'Good':
			return "Error: There was an error while trying to populate a PO Tag value. Check logger for more information. Resource " + PH_Nodename
			
			
		Response = MII_Ignition_Library.Tags.Write.Write_Single_Value(Tag_Provider + "Coca-Cola/CPS/" + PH_Plant + "/" + Area + "/" + PH_Work_Center + "/PO/Phase/pRecordFoundQty",PH_Record_Found_Qty)
		if str(Response) != 'Good':
			return "Error: There was an error while trying to populate a PO Tag value. Check logger for more information. Resource " + PH_Nodename	
		
			
		Response = MII_Ignition_Library.Tags.Write.Write_Single_Value(Tag_Provider + "Coca-Cola/CPS/" + PH_Plant + "/" + Area + "/" + PH_Work_Center + "/PO/Phase/pInspectionLot",PH_Inspection_Lot)
		if str(Response) != 'Good':
			return "Error: There was an error while trying to populate a PO Tag value. Check logger for more information. Resource " + PH_Nodename
						
			
		Response = MII_Ignition_Library.Tags.Write.Write_Single_Value(Tag_Provider + "Coca-Cola/CPS/" + PH_Plant + "/" + Area + "/" + PH_Work_Center + "/PO/Phase/pArea",PH_Area)
		if str(Response) != 'Good':
			return "Error: There was an error while trying to populate a PO Tag value. Check logger for more information. Resource " + PH_Nodename		
			
			
		
		#Script executed succesffuly
		return "Success."
	
	except Exception as e:
		Status = e
		return Status
		MII_Ignition_Library.Logger.Insert_Log.Insert_Error_Log(Status)	
	#except:
		#MII_Ignition_Library.Logger.Insert_Log.Insert_Error_Log(PH_Client + "_" + PH_Plant + "_" + "Populate_PO_Tag_Module", "Error: MII_Ignition_Library.Production_Data.Populate_Resource_PO_Tag.Populate_PO_Header_Phases has failed. Check log for details. Resource: " +  PH_Nodename)
		#return "Error: MII_Ignition_Library.Production_Data.Populate_Resource_PO_Tag.Populate_PO_Header_Phases has failed. Check log for details. Resource: "  + PH_Nodename	
		
		
def Populate_PO_Header_Phase(Database, Tag_Provider, Client, Plant, PO, Work_Center, SAPResourceName, Area_Description):
 	try:
 	
		#Local Parameters
		Area = ''						   #Area: Used to determine resource area prefix.
		
				
		#Verify Resource Area Prefix
		'''
		if Work_Center[0:2] == 'LF' or Work_Center[0:2] == 'LA': #Liquid Filling
			Area = 'LF'
			
		elif Work_Center[0:2] == 'DF' or Work_Center[0:2] == 'DA': #Dry Processing
			Area = 'DP'
		
		elif Area_Description == 'LIQ_PROCESS_AREA': #MFG
			Area = 'LP/LP' + str(Work_Center[0:2])
			#return "Success."
		
		else: #Resource Area not Found
			MII_Ignition_Library.Logger.Insert_Log.Insert_Error_Log(Client + "_" + Plant + "_" + "Populate_", "Error: Resource Area Prefix not found. Resource: " + Work_Center)
			return "Error: Resource Area Prefix not found. Resource: " + Work_Center
		'''
		Status,ReturnVal = MII_Ignition_Library.ToolsSet.Tools.GetArea(Client,Plant,Work_Center,Area_Description)
				
		if Status != "Success.":
			return Status
		else:
			Area = ReturnVal
		
		
		
		
		#Get S4 MII Status
		MII_DB_Query_Parameters = {"database" : Database,
		"Client" : Client,
		"Plant" : Plant,
		"PO" : PO,
		"Message_Type" : '<Phase_Status>',
		"SAPResourceName" : SAPResourceName}

		MII_DB_Response = system.db.runNamedQuery("MII_Ignition_Queries/Process_Order/Get_Latest_Status", MII_DB_Query_Parameters)
		Phase = str(MII_DB_Response.getValueAt(0, "Phase"))
		

		#Populate PO Header S4 MII Status Tag and validate i tag writing fails in the process 
		Response = MII_Ignition_Library.Tags.Write.Write_Single_Value(Tag_Provider + "Coca-Cola/CPS/" + Plant + "/" + Area + "/" + Work_Center + "/PO/Header/s4MIIStatus",Phase)
		#Response = 1
		if str(Response) != 'Good':
			return "Error: There was an error while trying to populate PO Header S4 MII Status Tag. Check logger for more information. Resource " + Work_Center	
		
		
		#Script executed succesffuly
		return "Success."
	
	except Exception as e:
		Status = e
		return Status
		MII_Ignition_Library.Logger.Insert_Log.Insert_Error_Log(Status)		
	#except:
		#MII_Ignition_Library.Logger.Insert_Log.Insert_Error_Log(Client + "_" + Plant + "_" + "Populate_", "Error: MII_Ignition_Library.Production_Data.Populate_Resource_PO_Tag.Populate_ has failed. Check log for details. Resource: " +  Work_Center)
		#return "Error: MII_Ignition_Library.Production_Data.Populate_Resource_PO_Tag.Populate_PO_Header_S4_MII_Status has failed. Check log for details. Resource: "  + Work_Center
		
	
def Populate_PO_Header_S4_MII_Status(Database, Tag_Provider, Client, Plant, PO, Work_Center, SAPResourceName, Area_Description):
 	try:
 	
		#Local Parameters
		Area = ''						   #Area: Used to determine resource area prefix.
		
				
		#Verify Resource Area Prefix
		'''
		if Work_Center[0:2] == 'LF' or Work_Center[0:2] == 'LA': #Liquid Filling
			Area = 'LF'
			
		elif Work_Center[0:2] == 'DF' or Work_Center[0:2] == 'DA': #Dry Processing
			Area = 'DP'
		
		elif Area_Description == 'LIQ_PROCESS_AREA': #MFG
			Area = 'LP/LP' + str(Work_Center[0:2])
			#return "Success."
		
		else: #Resource Area not Found
			MII_Ignition_Library.Logger.Insert_Log.Insert_Error_Log(Client + "_" + Plant + "_" + "Populate_", "Error: Resource Area Prefix not found. Resource: " + Work_Center)
			return "Error: Resource Area Prefix not found. Resource: " + Work_Center
		'''
		Status,ReturnVal = MII_Ignition_Library.ToolsSet.Tools.GetArea(Client,Plant,Work_Center,Area_Description)
				
		if Status != "Success.":
			return Status
		else:
			Area = ReturnVal
		
		
		
		
		#Get S4 MII Status
		MII_DB_Query_Parameters = {"database" : Database,
		"Client" : Client,
		"Plant" : Plant,
		"PO" : PO,
		"Message_Type" : '<Phase_Status>',
		"SAPResourceName" : SAPResourceName}

		MII_DB_Response = system.db.runNamedQuery("MII_Ignition_Queries/Process_Order/Get_Latest_Status", MII_DB_Query_Parameters)
		S4_MII_Status = str(MII_DB_Response.getValueAt(0, "S4_MII_Status"))
		

		#Populate PO Header S4 MII Status Tag and validate i tag writing fails in the process 
		Response = MII_Ignition_Library.Tags.Write.Write_Single_Value(Tag_Provider + "Coca-Cola/CPS/" + Plant + "/" + Area + "/" + Work_Center + "/PO/Header/s4MIIStatus",S4_MII_Status)
		#Response = 1
		if str(Response) != 'Good':
			return "Error: There was an error while trying to populate PO Header S4 MII Status Tag. Check logger for more information. Resource " + Work_Center	
		
		
		#Script executed succesffuly
		return "Success."
	
	except Exception as e:
		Status = e
		return Status
		MII_Ignition_Library.Logger.Insert_Log.Insert_Error_Log(Status)		
	#except:
		#MII_Ignition_Library.Logger.Insert_Log.Insert_Error_Log(Client + "_" + Plant + "_" + "Populate_", "Error: MII_Ignition_Library.Production_Data.Populate_Resource_PO_Tag.Populate_ has failed. Check log for details. Resource: " +  Work_Center)
		#return "Error: MII_Ignition_Library.Production_Data.Populate_Resource_PO_Tag.Populate_PO_Header_S4_MII_Status has failed. Check log for details. Resource: "  + Work_Center
		
	
			
def Populate_PO_Header_MII_PO_Status(Database, Tag_Provider, Client, Plant, PO, Work_Center, SAPResourceName, Area_Description):
 	try:
 		
		#Local Parameters
		Area = ''						   #Area: Used to determine resource area prefix.
		
				
		#Verify Resource Area Prefix
		'''
		if Work_Center[0:2] == 'LF' or Work_Center[0:2] == 'LA': #Liquid Filling
			Area = 'LF'
			
		elif Work_Center[0:2] == 'DF' or Work_Center[0:2] == 'DA': #Dry Processing
			Area = 'DP'
		
		elif Area_Description == 'LIQ_PROCESS_AREA': #MFG
			Area = 'LP/LP' + str(Work_Center[0:2])
			#return "Success."
		
		else: #Resource Area not Found
			MII_Ignition_Library.Logger.Insert_Log.Insert_Error_Log(Client + "_" + Plant + "_" + "Populate_", "Error: Resource Area Prefix not found. Resource: " + Work_Center)
			return "Error: Resource Area Prefix not found. Resource: " + Work_Center
		'''
		Status,ReturnVal = MII_Ignition_Library.ToolsSet.Tools.GetArea(Client,Plant,Work_Center,Area_Description)
				
		if Status != "Success.":
			return Status
		else:
			Area = ReturnVal



		#Get MII PO Status
		MII_DB_Query_Parameters = {"database" : Database,
		"Client" : Client,
		"Plant" : Plant,
		"PO" : PO,
		"Message_Type" : '<Phase_Status>',
		"SAPResourceName" : ''}  #SAPResourceName
		
		MII_DB_Response = system.db.runNamedQuery("MII_Ignition_Queries/Process_Order/Get_Latest_Status", MII_DB_Query_Parameters)
		MII_PO_Status = MII_DB_Response.getValueAt(0, "MII_PO_Status")


		#Populate MII_PO_Status and validate if  tag writing fails in the process 
		Response = MII_Ignition_Library.Tags.Write.Write_Single_Value(Tag_Provider + "Coca-Cola/CPS/" + Plant + "/" + Area + "/" + Work_Center + "/PO/Header/miiPoStatus",MII_PO_Status)
		if str(Response) != 'Good':
			return "Error: There was an error while trying to populate MII_PO_Status Tag value. Check logger for more information. Resource " + Work_Center
		
		
		#Script executed succesffuly
		return "Success."
	
	except Exception as e:
		Status = e
		return Status
		MII_Ignition_Library.Logger.Insert_Log.Insert_Error_Log(Status)		
	#except:
		#MII_Ignition_Library.Logger.Insert_Log.Insert_Error_Log(Client + "_" + Plant + "_" + "Populate_", "Error: MII_Ignition_Library.Production_Data.Populate_Resource_PO_Tag.Populate_ has failed. Check log for details. Resource: " +  Work_Center)
		#return "Error: MII_Ignition_Library.Production_Data.Populate_Resource_PO_Tag.Populate_PO_Header_MII_PO_Status has failed. Check log for details. Resource: "  + Work_Center	
				
					
					
					
					
					
def Populate_PO_Header_MII_PH_Status(Database, Tag_Provider, Client, Plant, PO, Work_Center, SAPResourceName, Area_Description):
 	try:
 		
		#Local Parameters
		Area = ''						   #Area: Used to determine resource area prefix.
		
				
		#Verify Resource Area Prefix
		'''
		if Work_Center[0:2] == 'LF' or Work_Center[0:2] == 'LA': #Liquid Filling
			Area = 'LF'
			
		elif Work_Center[0:2] == 'DF' or Work_Center[0:2] == 'DA': #Dry Processing
			Area = 'DP'
		
		elif Area_Description == 'LIQ_PROCESS_AREA': #MFG
			Area = 'LP/LP' + str(Work_Center[0:2])
			#return "Success."
		
		else: #Resource Area not Found
			MII_Ignition_Library.Logger.Insert_Log.Insert_Error_Log(Client + "_" + Plant + "_" + "Populate_", "Error: Resource Area Prefix not found. Resource: " + Work_Center)
			return "Error: Resource Area Prefix not found. Resource: " + Work_Center
		'''
		Status,ReturnVal = MII_Ignition_Library.ToolsSet.Tools.GetArea(Client,Plant,Work_Center,Area_Description)
				
		if Status != "Success.":
			return Status
		else:
			Area = ReturnVal
		
		
		#Get MII PH Status
		MII_DB_Query_Parameters = {"database" : Database,
		"Client" : Client,
		"Plant" : Plant,
		"PO" : PO,
		"Message_Type" : '<Phase_Status>',
		"SAPResourceName" : SAPResourceName}
		
		MII_DB_Response = system.db.runNamedQuery("MII_Ignition_Queries/Process_Order/Get_Latest_Status", MII_DB_Query_Parameters)
		#MII_PH_Status = MII_DB_Response.getValueAt(0, "Phase_Status")
		if MII_DB_Response.getValueAt(0, "Phase_Status") == "ACT" and MII_DB_Response.getValueAt(0, "S4_MII_STATUS") == "COMPLETED":
			MII_PH_Status = MII_DB_Response.getValueAt(0, "Phase_Status_Requested")
		else:
			MII_PH_Status = MII_DB_Response.getValueAt(0, "Phase_Status")
			
		#Populate MII_PH_Status Tag and validate if tag writing fails in the process 
		Response = MII_Ignition_Library.Tags.Write.Write_Single_Value(Tag_Provider + "Coca-Cola/CPS/" + Plant + "/" + Area + "/" + Work_Center + "/PO/Phase/pMIIPHStatus",MII_PH_Status)
		if str(Response) != 'Good':
			return "Error: There was an error while trying to populate MII_PH_Status Tag value. Check logger for more information. Resource " + Work_Center	
		
		#Script executed succesffuly
		return "Success."
	
	except Exception as e:
		Status = e
		return Status
		MII_Ignition_Library.Logger.Insert_Log.Insert_Error_Log(Status)		
	#except:
		#MII_Ignition_Library.Logger.Insert_Log.Insert_Error_Log(Client + "_" + Plant + "_" + "Populate_", "Error: MII_Ignition_Library.Production_Data.Populate_Resource_PO_Tag.Populate_ has failed. Check log for details. Resource: " +  Work_Center)
		#return "Error: MII_Ignition_Library.Production_Data.Populate_Resource_PO_Tag.Populate_PO_Header_MII_PH_Status has failed. Check log for details. Resource: "  + Work_Center		
		

		
				
								
		
def Populate_PO_Phase_Execution_Time(Database, Tag_Provider, Client, Plant, PO, Phase, Work_Center, SAPResourceName, Area_Description):
 	try:
 		
		#Local Parameters
		Area = ''						   #Area: Used to determine resource area prefix.
		
				
		#Verify Resource Area Prefix
		'''
		if Work_Center[0:2] == 'LF' or Work_Center[0:2] == 'LA': #Liquid Filling
			Area = 'LF'
			
		elif Work_Center[0:2] == 'DF' or Work_Center[0:2] == 'DA': #Dry Processing
			Area = 'DP'
		
		elif Area_Description == 'LIQ_PROCESS_AREA': #MFG
			Area = 'LP/LP' + str(Work_Center[0:2])
			#return "Success."
		
		else: #Resource Area not Found
			MII_Ignition_Library.Logger.Insert_Log.Insert_Error_Log(Client + "_" + Plant + "_" + "Populate_", "Error: Resource Area Prefix not found. Resource: " + Work_Center)
			return "Error: Resource Area Prefix not found. Resource: " + Work_Center
		'''
		Status,ReturnVal = MII_Ignition_Library.ToolsSet.Tools.GetArea(Client,Plant,Work_Center,Area_Description)
				
		if Status != "Success.":
			return Status
		else:
			Area = ReturnVal

		
		#Get MII PH Status
		MII_DB_Query_Parameters = {"database" : Database,
		"Client" : Client,
		"Plant" : Plant,
		"PO" : PO,
		"Message_Type" : '<Phase_Status>',
		"SAPResourceName" : SAPResourceName}
		
		MII_DB_Response = system.db.runNamedQuery("MII_Ignition_Queries/Process_Order/GetCompletionDatePerPhase", MII_DB_Query_Parameters)
		
		
		# Retrieve column indexes based on column names
		Phase_Index = MII_DB_Response.getColumnIndex("Phase")
		PhaseStatus_Index = MII_DB_Response.getColumnIndex("PhaseStatus")
		EventTime_Index = MII_DB_Response.getColumnIndex("EventTime")
		
		Execution_StartDateTime = None
		Execution_EndDateTime = None
		
		# Iterate over the rows
		for row in range(MII_DB_Response.getRowCount()):
		    if MII_DB_Response.getValueAt(row, Phase_Index) == Phase and MII_DB_Response.getValueAt(row, PhaseStatus_Index) == 'ACT':
		        Execution_StartDateTime = (MII_DB_Response.getValueAt(row, EventTime_Index)).replace("T"," ")
		     
		    if MII_DB_Response.getValueAt(row, Phase_Index) == Phase and MII_DB_Response.getValueAt(row, PhaseStatus_Index) == 'CMPL':
		        Execution_EndDateTime = MII_DB_Response.getValueAt(row, EventTime_Index).replace("T"," ")
		        
		           
		#Populate Execution Time Tag and validate if tag writing fails in the process 
		Response = MII_Ignition_Library.Tags.Write.Write_Single_Value(Tag_Provider + "Coca-Cola/CPS/" + Plant + "/" + Area + "/" + Work_Center + "/PO/Phase/pPhExecutionStartDateTime",Execution_StartDateTime)
		if str(Response) != 'Good':
			return "Error: There was an error while trying to populate PO Phase Execution Start Date Time Tag value. Check logger for more information. Resource " + Work_Center	
		
		
		Response = MII_Ignition_Library.Tags.Write.Write_Single_Value(Tag_Provider + "Coca-Cola/CPS/" + Plant + "/" + Area + "/" + Work_Center + "/PO/Phase/pPhExecutionEndDateTime",Execution_EndDateTime)
		if str(Response) != 'Good':
			return "Error: There was an error while trying to populate PO Phase Execution End Date Time Tag value. Check logger for more information. Resource " + Work_Center	
				
				
		#Script executed succesffuly
		return "Success."
	
	except Exception as e:
		Status = e
		return Status
		MII_Ignition_Library.Logger.Insert_Log.Insert_Error_Log(Status)		
	#except:
	#	MII_Ignition_Library.Logger.Insert_Log.Insert_Error_Log(Client + "_" + Plant + "_" + "Populate_", "Error: MII_Ignition_Library.Production_Data.Populate_PO_Phase_Execution_Time has failed. Check log for details. Resource: " +  Work_Center)
		#return "Error: MII_Ignition_Library.Production_Data.Populate_Resource_PO_Tag.Populate_PO_Phase_Execution_Time has failed. Check log for details. Resource: "  + Work_Center		

def Clear_PO_Header_Tag(Tag_Provider, Client, Plant, Resource, Area_Description):
	try:
		#Verify Resource Area Prefix
		Status,ReturnVal = MII_Ignition_Library.ToolsSet.Tools.GetArea(Client,Plant,Resource,Area_Description)
		if Status != "Success.":
			return Status
		else:
			Area = ReturnVal
		
		#Getting tag paths
		tagPath = (Tag_Provider + "Coca-Cola/CPS/" + Plant + "/" + Area + "/" + Resource + "/PO/Header/processOrder")
		tagValue = ""
		system.tag.writeBlocking(tagPath, tagValue)
	except:
		return 'error'
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		