def Post_Production_Report(Tag_Provider, API_Protocol, API_Server, SAP_Status, MII_Status, DB_Status, Database, Messages_In_Queue_Flag, Client, Plant, Work_Center, SAP_Resource_Name, PO, Phase, Operation, EventTime, Material, UOM, User_ID, Yield_Quantity, Yield_Quantity_Type, Yield_Reason_Code, Scrap_Quantity, Scrap_Quantity_Type, Scrap_Reason_Code, Area):
    import xml.etree.ElementTree as ET
    import json
    #Json = "True"
    
    try:
    
        #Validate if Database Connection is Online
        if DB_Status == 1: #Database is Online
        
        
        
            ### Starting the development of the XML  ###
                                
            # Create the root element
            root = ET.Element("Production_Report")
            
            # Create the 'row' element
            row = ET.SubElement(root, "row")
            
            # Create and fill the child elements
            sap_client_element = ET.SubElement(row, "SAPClient")
            sap_client_element.text = Client
            
            sap_plant_element = ET.SubElement(row, "SAPPlant")
            sap_plant_element.text = Plant
            
            sap_resource_name_element = ET.SubElement(row, "SAPResourceName")
            sap_resource_name_element.text = SAP_Resource_Name
            
            order_element = ET.SubElement(row, "Order")
            order_element.text = PO
            
            phase_element = ET.SubElement(row, "Phase")
            phase_element.text = Phase
            
            event_time_element = ET.SubElement(row, "EventTime")
            event_time_element.text = EventTime
            
            matnr_element = ET.SubElement(row, "Matnr")
            matnr_element.text = Material
            
            uom_element = ET.SubElement(row, "UOM")
            uom_element.text = UOM
            
            user_element = ET.SubElement(row, "User")
            user_element.text = User_ID
                
            items_element = ET.SubElement(row, "Items")
            
            item1_element = ET.SubElement(items_element, "Item")
            quantity1_element = ET.SubElement(item1_element, "Quantity")
            quantity1_element.text = Yield_Quantity
            quantity_type1_element = ET.SubElement(item1_element, "Quantity_Type")
            quantity_type1_element.text = Yield_Quantity_Type
            reason_code1_element = ET.SubElement(item1_element, "ReasonCode")
            reason_code1_element.text = Yield_Reason_Code
            
            item2_element = ET.SubElement(items_element, "Item")
            quantity2_element = ET.SubElement(item2_element, "Quantity")
            quantity2_element.text = Scrap_Quantity
            quantity_type2_element = ET.SubElement(item2_element, "Quantity_Type")
            quantity_type2_element.text = Scrap_Quantity_Type
            reason_code2_element = ET.SubElement(item2_element, "ReasonCode")
            reason_code2_element.text = Scrap_Reason_Code
            
            # Create the XML string
            xml_str = ET.tostring(root, encoding="utf-8", method="xml")
            
            # Convert bytes to string
            xml_str = xml_str.decode("utf-8")
        
        
        
        
            #Validate if SAP and MII Services are Online
            if SAP_Status == 1 and MII_Status == 1 and Messages_In_Queue_Flag == False: #SAP and MII Services are Online / No Pending Messages in Queue
            
                #Submit Production Report
                    
                # API URL Web Service
                url = str(API_Protocol) + "://" + str(API_Server) + "/PR-CID/ShopFloor/MII_Data_Collection_Messages/api/MIIDataCollectionMessages/POST_PAWebApiWrapper"
                message = "<PaWebApiWrapper><SAP_CLIENT>" + str(Client) + "</SAP_CLIENT><SAP_PLANT>" + str(Plant) + "</SAP_PLANT><DOC_TYPE/><ID/><RETRY_LIMIT/><MESSAGENAME/><RECEIVED_DATE_START/><RECEIVED_TIME_START/><RECEIVED_DATE_END/><RECEIVED_TIME_END/><IDENTIFIER/><CATEGORY/><STATUS/><MESSAGEUID/><PROCESS_ORDER/><SAP_PO_STATUS/><NODE_NAME/><NODE_TYPE/><PHASE/><PHASE_STATUS/><Enable_Doc_Batch_PO_Header_XML/><Enable_Doc_Batch_BOM_XML/><Enable_Doc_Batch_Recipe_Header_XML/><Enable_Doc_Batch_Recipe_Steps_XML/><SAP_RESOURCE/><ROW_COUNT/><json>true</json><Body><MII_Update_File_Content><row><xml_File><ProcessProductionDocuments><ProductionMessage>" + xml_str + "</ProductionMessage></ProcessProductionDocuments></xml_File></row></MII_Update_File_Content></Body><BlsName>BLS_ProcessProductionDocuments</BlsName></PaWebApiWrapper>" 
                        
                #HTTP Post Request
                connectTimeout = 5000
                readTimeout = (int(system.tag.readBlocking('[Shop_Floor]Coca-Cola/CPS/Site_Settings/General_Configuration/apiTimeoutDuration')[0].value)*60000)
                res = system.net.httpPost(url,"text/xml",message,connectTimeout,readTimeout)
                 
                #Place the result in a custom property
                Production_Report_Response = system.util.jsonDecode(res)
            
                rowset = Production_Report_Response['Rowset']
                row = rowset['Row'][0]  
                
                #MII Messge
                MII_Message = row['STATUSTEXT'] 
                
                #The status of the MII post will be used as parameter for the SQL insert
                MII_Status = row['STATUS'] 
            
                if MII_Status == "1":
					### Insert into Database ###
					
					#Dictionary for the table QUEUE MESSAGE LOG
					SQL_Parameters = {"database": Database ,"SAPClient": Client, "SAPPlant": Plant, "Work_Center":Work_Center, "SAPResourceName": SAP_Resource_Name, "ProcessOrder": PO , "Operation": Operation, "Phase": Phase, "Message": xml_str, "Response" : MII_Message, "EventTime" : EventTime , "MessageType": "Production Report", "Processed":MII_Status, "INSPCHAR": "","Area":Area,"UpdatedBy":User_ID}
					
					#Query to update table QUEUE MESSAGE LOG
					system.db.runNamedQuery("MII_Ignition_Queries/xMII_Message_Log/XMII_QUEUE_MESSAGE_LOG_INSERT", SQL_Parameters)
					
					#Dictionary for the table QUEUE MESSAGE HISTORY
					SQL_Parameters1 = {"database": Database ,"SAPClient": Client, "SAPPlant": Plant, "Work_Center":Work_Center, "SAPResourceName": SAP_Resource_Name, "ProcessOrder": PO , "Operation": Operation, "Phase": Phase, "Message": xml_str, "Response" : MII_Message, "EventTime" : EventTime , "MessageType": "Production Report", "Processed":MII_Status, "INSPCHAR": "","Area":Area, "API_Response_Message":MII_Message, "Updated_By":User_ID}
					#Query to update table QUEUE MESSAGE HISTORY
					system.db.runNamedQuery("MII_Ignition_Queries/xMII_Message_Log/XMII_QUEUE_MESSAGE_LOG_INSERT_HISTORY", SQL_Parameters1)
                    
					#Update MII_Posting UDT 	
					MII_Ignition_Library.Production_Data.Populate_MII_Posting.ProductionReportPosting(Tag_Provider, Client, Plant, Work_Center, Area, xml_str)		
				    								
                    										
                    
                else:
                	#Dictionary for the table QUEUE MESSAGE HISTORY
                	SQL_Parameters1 = {"database": Database ,"SAPClient": Client, "SAPPlant": Plant, "Work_Center":Work_Center, "SAPResourceName": SAP_Resource_Name, "ProcessOrder": PO , "Operation": Operation, "Phase": Phase, "Message": xml_str, "Response" : "MII_Message", "EventTime" : EventTime , "MessageType": "Production Report", "Processed":MII_Status, "INSPCHAR": "","Area":Area, "API_Response_Message":"MII_Message", "Updated_By":User_ID}
                	#Query to update table QUEUE MESSAGE HISTORY
                	system.db.runNamedQuery("MII_Ignition_Queries/xMII_Message_Log/XMII_QUEUE_MESSAGE_LOG_INSERT_HISTORY", SQL_Parameters1)
                   	
                
                return MII_Message
                
                    
                    
                    
                    
            else: #Post directly into Database due to SAP or MII Service Offline / Pending Messages in Queue
                ### Insert into Database ###
                #Dictionary for the table QUEUE MESSAGE LOG
                SQL_Parameters = {"database": Database ,"SAPClient": Client, "SAPPlant": Plant,"Work_Center":Work_Center, "SAPResourceName": SAP_Resource_Name, "ProcessOrder": PO , "Operation": Operation, "Phase": Phase, "Message": xml_str, "Response" : "", "EventTime" : EventTime , "MessageType": "Production Report", "Processed":"0", "INSPCHAR": "","Area":Area,"UpdatedBy":User_ID}
                
                #Query to update table QUEUE MESSAGE LOG
                system.db.runNamedQuery("MII_Ignition_Queries/xMII_Message_Log/XMII_QUEUE_MESSAGE_LOG_INSERT", SQL_Parameters)
                
                #Dictionary for the table QUEUE MESSAGE HISTORY
                SQL_Parameters1 = {"database": Database ,"SAPClient": Client, "SAPPlant": Plant, "Work_Center":Work_Center, "SAPResourceName": SAP_Resource_Name, "ProcessOrder": PO , "Operation": Operation, "Phase": Phase, "Message": xml_str, "Response" : "", "EventTime" : EventTime , "MessageType": "Production Report", "Processed":"0", "INSPCHAR": "","Area":Area, "API_Response_Message":"SAP/MII is offline.", "Updated_By":User_ID}
                #Query to update table QUEUE MESSAGE HISTORY
                system.db.runNamedQuery("MII_Ignition_Queries/xMII_Message_Log/XMII_QUEUE_MESSAGE_LOG_INSERT_HISTORY", SQL_Parameters1)
                
                return "Success."
        
        
        else: #Database is Offline
            return "Error: Database Connection is Offline. Contact Automation Team for Support."    
    
    
        
    except:
        MII_Ignition_Library.Logger.Insert_Log.Insert_Error_Log(Client + "_" + Plant + "_" + "Post_Production_Report", str(sys.exc_info()))
        return "Error: MII_Ignition_Library.Production_Data.Production_Report.Post_Production_Report has failed. Check logger for details."    
            
    
        
def Create_Production_Report_XML(Client, Plant, SAP_Resource_Name, PO, Phase, Operation, EventTime, Material, UOM, User_ID, Yield_Quantity, Yield_Quantity_Type, Yield_Reason_Code, Scrap_Quantity, Scrap_Quantity_Type, Scrap_Reason_Code):
    import xml.etree.ElementTree as ET
    
    try:
    
        ### Starting the development of the XML  ##
                                        
        # Create the root element
        root = ET.Element("Production_Report")
        
        # Create the 'row' element
        row = ET.SubElement(root, "row")
        
        # Create and fill the child elements
        sap_client_element = ET.SubElement(row, "SAPClient")
        sap_client_element.text = Client
        
        sap_plant_element = ET.SubElement(row, "SAPPlant")
        sap_plant_element.text = Plant
        
        sap_resource_name_element = ET.SubElement(row, "SAPResourceName")
        sap_resource_name_element.text = SAP_Resource_Name
        
        order_element = ET.SubElement(row, "Order")
        order_element.text = PO
        
        phase_element = ET.SubElement(row, "Phase")
        phase_element.text = Phase
        
        event_time_element = ET.SubElement(row, "EventTime")
        event_time_element.text = EventTime
        
        matnr_element = ET.SubElement(row, "Matnr")
        matnr_element.text = Material
        
        uom_element = ET.SubElement(row, "UOM")
        uom_element.text = UOM
        
        user_element = ET.SubElement(row, "User")
        user_element.text = User_ID
            
        items_element = ET.SubElement(row, "Items")
        
        item1_element = ET.SubElement(items_element, "Item")
        quantity1_element = ET.SubElement(item1_element, "Quantity")
        quantity1_element.text = Yield_Quantity
        quantity_type1_element = ET.SubElement(item1_element, "Quantity_Type")
        quantity_type1_element.text = Yield_Quantity_Type
        reason_code1_element = ET.SubElement(item1_element, "ReasonCode")
        reason_code1_element.text = Yield_Reason_Code
        
        item2_element = ET.SubElement(items_element, "Item")
        quantity2_element = ET.SubElement(item2_element, "Quantity")
        quantity2_element.text = Scrap_Quantity
        quantity_type2_element = ET.SubElement(item2_element, "Quantity_Type")
        quantity_type2_element.text = Scrap_Quantity_Type
        reason_code2_element = ET.SubElement(item2_element, "ReasonCode")
        reason_code2_element.text = Scrap_Reason_Code
        
        # Create the XML string
        xml_str = ET.tostring(root, encoding="utf-8", method="xml")
        
        # Convert bytes to string
        xml_str = xml_str.decode("utf-8")
        
        return xml_str
    
    except:
        MII_Ignition_Library.Logger.Insert_Log.Insert_Error_Log(Client + "_" + Plant + "_" + "Create_Phase_Status_XML", "Error: MII_Ignition_Library.Production_Data.Production_Report.Create_Production_Report_XML has failed. Check logger for details.")
        return "Error: MII_Ignition_Library.Production_Data.Production_Report.Create_Production_Report_XML has failed. Check logger for details." 
        
        
        


def VerifyIfProductionReportPosted(Database, Client, Plant, Order, Phase, SAPResourceName):
	try:
	
		Query_Parameters = {"database": Database, "client": Client, "plant":Plant, "order": Order, "Phase": Phase, "SAPResourceName": SAPResourceName}
		Query_Result = system.db.runNamedQuery("MII_Ignition_Queries/Production_Report/VerifyPostedProductionReportPerPhase", Query_Parameters)
		
		if Query_Result[0][0] > 0: 
		    VerifyIfProductionReportPosted = 1
		else:
		    VerifyIfProductionReportPosted = 0
		    
		return VerifyIfProductionReportPosted
		
	except Exception as e:
		Status = e
		return Status
		MII_Ignition_Library.Logger.Insert_Log.Insert_Error_Log(str(Client) + "_" + str(Plant) + "_" + "VerifyIfProductionReportPosted", Status)