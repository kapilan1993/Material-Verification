def Write_Single_Value(Tag_Path, Tag_Value):

	Response = system.tag.writeBlocking(Tag_Path , Tag_Value)
	
	if str(Response[0]) != 'Good':
		MII_Ignition_Library.Logger.Insert_Log.Insert_Error_Log("Write_Single_Value", "Error Writing into Tag: " + str(Tag_Path) + " " + str(Response[0]) + " Inserted Tag Value: " + str(Tag_Value))
		
	return Response[0]							
						