def Read_Single_Value(Tag_Path):

	Response = system.tag.readBlocking([Tag_Path])[0]
	
	if str(Response.value) ==  None:
		#MII_Ignition_Library.Logger.Insert_Log.Insert_Error_Log("Read_Single_Value", "Error Reading Tag: " + str(Tag_Path) + " " + str(Response.value))
		return
			
	return Response.value		