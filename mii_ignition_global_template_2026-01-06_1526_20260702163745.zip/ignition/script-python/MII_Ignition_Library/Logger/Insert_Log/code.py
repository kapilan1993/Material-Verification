def Insert_Error_Log(Logger_Title, Message):
	logger = system.util.getLogger(Logger_Title)
	logger.error(Message)


def Insert_Warn_Log(Logger_Title, Message):
	logger = system.util.getLogger(Logger_Title)
	logger.warn(Message)


def Insert_Info_Log(Logger_Title, Message):
	logger = system.util.getLogger(Logger_Title)
	logger.info(Message)
	