#Declare Parameters
API_Protocol = 'http'
API_Server = 'prcidt32'

Database = 'xMII_prcidT55'
Client = '010'
Plant = '0047'


#Get MII Status
try:
	MII_Status_Response = system.net.httpGet(str(API_Protocol) + "://" + str(API_Server) + "/PR-CID/ShopFloor/MII_Data_Collection_Messages/api/MIIDataCollectionMessages/Get_BLS_DateTimePlant?SAP_CLIENT=" + str(Client) + "&SAP_PLANT=" + str(Plant))

	if len(MII_Status_Response) > 0:
		MII_Status = 1
	else:
		MII_Status = 0
except:
	MII_Status = 0
	
#Get SAP Status	
try:
	SAP_Status_Response = system.net.httpGet(str(API_Protocol) + "://" + str(API_Server) + "/PR-CID/ShopFloor/MII_Data_Collection_Messages/api/MIIDataCollectionMessages/GET_SAP_MII_MPM_CPS_BLS_YPP_MII_GET_BIN_FOR_PSA?SAP_CLIENT=" + str(Client) + "&IV_LGNUM_wHouseNo=x&IV_MATNR=x&IV_PLANT=" + str(Plant) + "&IV_PRVBE_psaSupplyArea=x&jSon=true")

	if len(SAP_Status_Response) > 0:
		SAP_Status = 1
	else:
		SAP_Status = 0
except:
	SAP_Status = 0	
	
#Get MII Database Status
try:
	MII_DB_Query_Parameters = {"database": Database}
	MII_DB_Response = system.db.runNamedQuery("MII_Ignition_Queries/Database_Status/Get_xMII_DB_Status", MII_DB_Query_Parameters)
	
	if MII_DB_Response:
		MII_DB_Status = 1
	else:
		MII_DB_Status = 0
except:
	MII_DB_Status = 0	




if MII_Status == 1 and SAP_Status == 1 and MII_DB_Status == 1:

	Query_Parameters = {"database": Database, "SAPClient":Client, "SAPPlant":Plant}
	
	Query_Result = system.db.runNamedQuery("MII_Ignition_Queries/xMII_Message_Log/XMII_QUEUE_MESSAGE_LOG_GET_UNPROCESSED_MSG", Query_Parameters)
	
	#len(Query_Result) == 1 Record Found
	#len(Query_Result) == 0 Record Not Found
	if len(Query_Result) == 1: 
	
		Message_Type = Query_Result.getValueAt(0, "MessageType")
		
		ID = Query_Result.getValueAt(0, "ID")
		SAPClient = Query_Result.getValueAt(0, "SAPClient")
		SAPPlant = Query_Result.getValueAt(0, "SAPPlant")
		XML = Query_Result.getValueAt(0, "Message")
		
		#Increase Attempt Counter
		Attempt_Query_Parameters = {"database": Database, "SAPClient":SAPClient, "SAPPlant":SAPPlant, "Message_ID" : ID}
		system.db.runNamedQuery("MII_Ignition_Queries/xMII_Message_Log/XMII_QUEUE_MESSAGE_LOG_INCREASE_ATTEMPT_COUNT", Attempt_Query_Parameters)
		
		
		#Execute XML Posting BLS Depending on MessageType
		if Message_Type == '<Phase_Status>' or Message_Type == 'Good Issues' or Message_Type == 'Production Report' or Message_Type == 'Machine_Status':
			
			BLS_Response = MII_Ignition_Library.Production_Data.BLS.BLS_ProcessProductionDocuments(API_Protocol, API_Server, SAP_Status, MII_Status, MII_DB_Status, Database, SAPClient, SAPPlant, XML)
			
			if BLS_Response == 'Success.':
				
				Update_Query_Parameters = {"database": Database, "SAPClient":SAPClient, "SAPPlant":SAPPlant, "Message_ID" : ID}
				system.db.runNamedQuery("MII_Ignition_Queries/xMII_Message_Log/XMII_QUEUE_MESSAGE_LOG_UPDATE_UNPROCESSED_MSG", Update_Query_Parameters)
			
		
		elif Message_Type == '<QUALITY_RESULTS>':
		
			BLS_Response = MII_Ignition_Library.Production_Data.BLS.Post_Quality_Inspection_Record_Results_IGN_SAP(API_Protocol, API_Server, SAP_Status, MII_Status, MII_DB_Status, Database,  SAPClient, SAPPlant, XML)
			
			if BLS_Response == 'Posted Completed':
				
				Update_Query_Parameters = {"database": Database, "SAPClient":SAPClient, "SAPPlant":SAPPlant, "Message_ID" : ID}
				system.db.runNamedQuery("MII_Ignition_Queries/xMII_Message_Log/XMII_QUEUE_MESSAGE_LOG_UPDATE_UNPROCESSED_MSG", Update_Query_Parameters)
			