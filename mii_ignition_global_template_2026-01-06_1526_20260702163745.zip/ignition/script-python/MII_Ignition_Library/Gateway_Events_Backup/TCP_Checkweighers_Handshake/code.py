#Time: 60,000 ms

import time

#Capture required values
Tag_Provider = "[Shop_Floor]"
Named_Query_Path = "MII_Ignition_Queries/Monitoring/Delete_xMII_Test_Heartbeat"
Database_Test = "xMII_prcidT55"
Database_Prod = "xMII_prcidB55"
Client = "010"
Plant = "0047"


# Device definitions
devices = [
{'Area': 'LF', 'Resource': 'LF14', 'Device_name': 'Checkweigher_LF14_PET', 'Checkweigher_Type' : 'Checkweigher_PP', 'Port' : '23'},
{'Area': 'LF', 'Resource': 'LF14', 'Device_name': 'Checkweigher_LF14_Box', 'Checkweigher_Type' : 'Checkweigher_SP', 'Port' : '23'},
{'Area': 'LF', 'Resource': 'LF15', 'Device_name': 'Checkweigher_LF15'	   , 'Checkweigher_Type' : 'Checkweigher_PP', 'Port' : '23'},
{'Area': 'LF', 'Resource': 'LF16', 'Device_name': 'Checkweigher_LF16'	   , 'Checkweigher_Type' : 'Checkweigher_PP', 'Port' : '23'},
{'Area': 'LF', 'Resource': 'LF40', 'Device_name': 'Checkweigher_LF40'	   , 'Checkweigher_Type' : 'Checkweigher_PP', 'Port' : '2305'},
{'Area': 'DP', 'Resource': 'DF22', 'Device_name': 'Checkweigher_DF22'	   , 'Checkweigher_Type' : 'Checkweigher_PP', 'Port' : '23'},
{'Area': 'DP', 'Resource': 'DF23', 'Device_name': 'Checkweigher_DF23'	   , 'Checkweigher_Type' : 'Checkweigher_PP', 'Port' : '23'},
{'Area': 'DP', 'Resource': 'DF24', 'Device_name': 'Checkweigher_DF24'	   , 'Checkweigher_Type' : 'Checkweigher_PP', 'Port' : '23'},
{'Area': 'DP', 'Resource': 'DF26', 'Device_name': 'Checkweigher_DF26'	   , 'Checkweigher_Type' : 'Checkweigher_PP', 'Port' : '23'}
]
	
	
# Iterate over each device configuration
for device in devices:
	Area = device['Area']
	Resource = device['Resource']
	Device_Name = device['Device_name']
	Checkweigher_Type = device['Checkweigher_Type']
	Port = device['Port']
	
	if system.tag.read(Tag_Provider + "Coca-Cola/CPS/" + Plant + "/" + Area + "/" + Resource + "/Gateway_Devices/Checkweigher/" + Checkweigher_Type + "/_Diagnostics_/Is Connected").value == True:
		
		#MII_Ignition_Library.Logger.Insert_Log.Insert_Info_Log("Checkweigher_Gateway_Script", "Entered: " + Area + " " + Resource + " " + Device_Name + " " + Checkweigher_Type + " " + Port)
		
		#Capture if PO IsRunning for Resource
		
		#Capture Checkweigher Current Latest Received Date Tag Value
		Current_Latest_Received_Date = system.tag.read(Tag_Provider + "Coca-Cola/CPS/" + Plant + "/" + Area + "/" + Resource + "/Gateway_Devices/Checkweigher/" + Checkweigher_Type + "/" + Port + "/Last Receive Time").value
		
		#Send WD_Test Message
		system.tag.write(Tag_Provider + "Coca-Cola/CPS/" + Plant + "/" + Area + "/" + Resource + "/Gateway_Devices/Checkweigher/" + Checkweigher_Type + "/" + Port + "/Writable","WD_TEST\r\n")
		
		#Sleep
		time.sleep(1)
		
		#Capture New Latest Received Date Tag Value
		New_Latest_Received_Date = system.tag.read(Tag_Provider + "Coca-Cola/CPS/" + Plant + "/" + Area + "/" + Resource + "/Gateway_Devices/Checkweigher/" + Checkweigher_Type + "/" + Port + "/Last Receive Time").value
		
		
		#Validate if Latest Received Date Tag Value Changed
		if str(Current_Latest_Received_Date) != str(New_Latest_Received_Date): #Value changed, TCP connection is active
			
			#MII_Ignition_Library.Logger.Insert_Log.Insert_Info_Log("Checkweigher_Gateway_Script", "Received Updated Time")
			None
		
			
		else: #Value didn't changed, TCP connection is glitched
		
			#Restart Device
			system.device.setDeviceEnabled(Device_Name, 0)
			time.sleep(2)
			system.device.setDeviceEnabled(Device_Name, 1)
			
			#Notify that device was restarted due to TCP tag freeze glitch
			MII_Ignition_Library.Logger.Insert_Log.Insert_Info_Log("Checkweigher_Gateway_Script", Device_Name +  " Device Restarted!")
			
			time.sleep(1)
			
			#Send Start Command to Checkweigher
			system.tag.write(Tag_Provider + "Coca-Cola/CPS/" + Plant + "/" + Area + "/" + Resource + "/Gateway_Devices/Checkweigher/" + Checkweigher_Type + "/" + Port + "/Writable","WD_START\r\n")
		
	else: #Device is currently Offline
		
		#Restart Device
		system.device.setDeviceEnabled(Device_Name, 0)
		time.sleep(2)
		system.device.setDeviceEnabled(Device_Name, 1)
		

#Delete Test Records is Databse
parameters = {"database": Database_Test}
system.db.runNamedQuery(Named_Query_Path, parameters)

parameters = {"database": Database_Prod}
system.db.runNamedQuery(Named_Query_Path, parameters)
	