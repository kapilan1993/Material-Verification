import xml.etree.ElementTree as ET
import json
from java.net import URLEncoder, URL
from java.io import BufferedReader, InputStreamReader
from system.util import jsonDecode

def Active_Materials(Server, Client, Plant):
	#This Method returns a DataSet with a 'Materials' table containing all active Materials in FLQCMS.
	try:
		url = 'http://' + str(Server) + '/PR-CID/ShopFloorAPI/API_Data_Collection_Messages_Cidra/api/Sanitation/ActiveMaterials?Client=' + str(Client) + '&Plant=' + str(Plant)
				
		json_data = system.net.httpGet(url)
				
		return json_data
	
	except:
		MII_Ignition_Library.Logger.Insert_Log.Insert_Error_Log(Client + "_" + Plant + "_" + "CIP", "Error: MII_Ignition_Library.CIP.Sanitation.Active_Materials has failed. Check log for details.")
		return "Error: MII_Ignition_Library.CIP.Sanitation.Active_Materials has failed. Check log for details."


def Material_Data(Client, Plant, Server, Material):
	#Get required material data to populate Sanitation Function
	try:
		Material_Value = str(Material)
			
		url = 'http://' + str(Server) + '/PR-CID/ShopFloorAPI/API_Data_Collection_Messages_Cidra/api/Sanitation/Material_Data?Client=' + str(Client) + '&Plant=' + str(Plant) +'&Material=' + Material_Value
				
		json_data = system.net.httpGet(url)
				
		return json_data
	
	except:
		MII_Ignition_Library.Logger.Insert_Log.Insert_Error_Log(Client + "_" + Plant + "_" + "CIP", "Error: MII_Ignition_Library.CIP.Sanitation.GetSanTypeDesc has failed. Check log for details. Entered Values: Material: " + str(Material))
		return "Error: MII_Ignition_Library.CIP.Sanitation.Material_Data has failed. Check log for details. Entered Values: Material: " + str(Material)


def GetMatId(Server,Client,Plant,Material):
    # Initialize error state and message
    bln_err = False
    str_err_msg = ""
    int_mat_id = 0
    
    try:
        url = 'http://' + str(Server) + '/PR-CID/ShopFloorAPI/API_Data_Collection_Messages_Cidra/api/Sanitation/Material_Data?Client=' + str(Client) + '&Plant=' + str(Plant) + "&Material=" + str(Material)
       
        res = system.net.httpGet(url)
       	
        # Parse the JSON string into a Python dictionary
        Material_Data_Json = system.util.jsonDecode(res)
        	   
        	        		         		    
        #Check if the "Material" key exists and if it's a non-empty list
        if "Material" in Material_Data_Json and len(Material_Data_Json["Material"]) > 0:
        	        		    
	    	#Access Json value
			Material_ID = Material_Data_Json["Material"][0].get("MATMaterial_IN", None) 
        
			return Material_ID, bln_err, str_err_msg
        
    except Exception as ex:
        bln_err = True
        str_err_msg = "Invalid Material [{}]\n{}".format(Material, ex)




def GetSanTypeDesc(Client, Plant, Server,MatBefId,MatNxtId):

	try:
	
		#prcidb55
		MatBefId_Value = str(MatBefId)
		MatNxtId_Value = str(MatNxtId)
		
		#res = system.net.httpPost("http://" + Server + "/PR-CID/ShopFloor/WebServices/CSharp/WebServicesCS/Sanitation.asmx?op=GetSanTypeDesc", "text/xml",
		#'''<soap12:Envelope xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xsd="http://www.w3.org/2001/XMLSchema" xmlns:soap12="http://www.w3.org/2003/05/soap-envelope">
		#<soap12:Body>
		#<GetSanTypeDesc xmlns="http://cri.ko.com/">
		#<MatBefId>''' + MatBefId_Value + '''</MatBefId>
		#<MatNxtId>''' + MatNxtId_Value + '''</MatNxtId>
		#</GetSanTypeDesc>
		#</soap12:Body>
		#</soap12:Envelope>''')
		#return res
		
		
		url = 'http://' + str(Server) + '/PR-CID/ShopFloorAPI/API_Data_Collection_Messages_Cidra/api/Sanitation/GetSanTypeDesc?Client=' + str(Client) + '&Plant=' + str(Plant) +'&MatBefId=' + MatBefId_Value +'&MatNxtId=' + MatNxtId_Value
				
		json_data = system.net.httpGet(url)
				
		return json_data
	
	except:
		MII_Ignition_Library.Logger.Insert_Log.Insert_Error_Log(Client + "_" + Plant + "_" + "CIP", "Error: MII_Ignition_Library.CIP.Sanitation.GetSanTypeDesc has failed. Check log for details. Entered Values: MatBefId: " + str(MatBefId) + " , MatNxtId: " + str(MatNxtId))
		return "Error: MII_Ignition_Library.CIP.Sanitation.GetSanTypeDesc has failed. Check log for details. Entered Values: MatBefId: " + str(MatBefId) + " , MatNxtId: " + str(MatNxtId)




def SanitationEquipmentMonitor(Server, Client, Plant, Line_ID):
	#This Method returns a DataSet with a 'SanEqMon' table containing the current Sanitation status of all equipments in parm Area.
	try:
		
		url = 'http://' + str(Server) + '/PR-CID/ShopFloorAPI/API_Data_Collection_Messages_Cidra/api/Sanitation/SanitationEquipmentMonitor?Client=' + str(Client) + '&Plant=' + str(Plant) +'&LineId=' + str(Line_ID)
		
		json_data = system.net.httpGet(url)
		
		return json_data
	
	except:
		MII_Ignition_Library.Logger.Insert_Log.Insert_Error_Log(Client + "_" + Plant + "_" + "CIP", "Error: MII_Ignition_Library.CIP.Sanitation.SanitationEquipmentMonitor has failed. Check log for details. Entered Values:Line_ID: " + str(Line_ID))
		return "Error: MII_Ignition_Library.CIP.Sanitation.SanitationEquipmentMonitor has failed. Check log for details. Entered Values: Line_ID: " + str(Line_ID) 
		
		


def LastSanitationForEqName(Server, Client, Plant, Equipment_Name):
	#This Method returns a DataSet from tblSanLogHdr containing the most recent Sanitation for an Equipment Name.
	
	try:
		
		# URL Encode the parameter
		Equipment_Name_Encoded = URLEncoder.encode(str(Equipment_Name), "UTF-8")
		
		url = 'http://' + str(Server) + '/PR-CID/ShopFloorAPI/API_Data_Collection_Messages_Cidra/api/Sanitation/LastSanitationForEqName?Client=' + str(Client) + '&Plant=' + str(Plant) +'&EqName=' + str(Equipment_Name_Encoded)
		
		json_data = system.net.httpGet(url)
		
		return json_data
	
	except:
		MII_Ignition_Library.Logger.Insert_Log.Insert_Error_Log(Client + "_" + Plant + "_" + "CIP", "Error: MII_Ignition_Library.CIP.Sanitation.LastSanitationForEqName has failed. Check log for details. Entered Values:Equipment_Name: " + str(Equipment_Name))
		return "Error: MII_Ignition_Library.CIP.Sanitation.LastSanitationForEqName has failed. Check log for details. Entered Values: Equipment_Name: " + str(Equipment_Name) 
		
		



def AddSanLogHdr(Server, Client, Plant, Equipment_Name, User):
	#This Method creates a new Sanitation in tblSanLogHdr.
	
	try:
		
		# URL Encode the parameter
		#Equipment_Name_Encoded = URLEncoder.encode(str(Equipment_Name), "UTF-8")
		
		# Define HTTP request parameters
		url = "http://" + str(Server) + "/PR-CID/ShopFloorAPI/API_Data_Collection_Messages_Cidra/api/Sanitation/AddSanLogHdr"
		params = {
		        "Client": Client,
		        "Plant": Plant,
		        "EqName": Equipment_Name,
		        "User": User
		    }
		    
		# Create an HTTP client
		httpClient = system.net.httpClient()
		    
		#Make the POST request
		response = httpClient.post(url, params=params)
		
		return response
	
	except:
		MII_Ignition_Library.Logger.Insert_Log.Insert_Error_Log(Client + "_" + Plant + "_" + "CIP", "Error: MII_Ignition_Library.CIP.Sanitation.AddSanLogHdr has failed. Check log for details. Entered Values:Equipment_Name: " + str(Equipment_Name) + ", User: " + str(User))
		return "Error: MII_Ignition_Library.CIP.Sanitation.AddSanLogHdr has failed. Check log for details. Entered Values: Equipment_Name: " + str(Equipment_Name) 
		

	
		
			
def UpdSanLogHdr(Server, Client, Plant,SANHRecId_IN, SANHOrder_VC,
           SANHMfgQty_VC, SANHFiller_SI, SANHRoute_SI,
           SANHBRTRecId_IN, SANHMatBef_IN,SANHMatAft_IN,
           SANHSelSan_TI, IgnoreSelSan_BT,
           SANHStartDt_DT,  SANHEndDt_DT,
           SANHCompleteDt_DT,
           SANHComment_VC,  USRId_IN):
		#This Method updates the Sanitation Log Header file and returns an ErrMsg.
		
		try:
			
			# Define HTTP request parameters
			url = "http://" + Server + "/PR-CID/ShopFloorAPI/API_Data_Collection_Messages_Cidra/api/Sanitation/UpdSanLogHdr"
			params = {
			        "Client": Client,
			        "Plant": Plant,
			        "SANHRecId_IN": SANHRecId_IN,
			        "SANHOrder_VC": SANHOrder_VC,
			        "SANHMfgQty_VC": SANHMfgQty_VC,
			        "SANHFiller_SI": SANHFiller_SI,
			        "SANHRoute_SI": SANHRoute_SI,
			        "SANHBRTRecId_IN": SANHBRTRecId_IN,
			        "SANHMatBef_IN": SANHMatBef_IN,
			        "SANHMatAft_IN": SANHMatAft_IN,
			        "SANHSelSan_TI": SANHSelSan_TI,
			        "IgnoreSelSan_BT": IgnoreSelSan_BT,
			        "SANHStartDt_DT": SANHStartDt_DT,
			        "SANHEndDt_DT": SANHEndDt_DT,
			        "SANHCompleteDt_DT": SANHCompleteDt_DT,
			        "SANHComment_VC": SANHComment_VC,
			        "USRId_IN": USRId_IN
			    }
			    
			#MII_Ignition_Library.Logger.Insert_Log.Insert_Error_Log("CIP APIUpdSanLogHdr After URL", str(url) + " " + str(params))
			 
			# Create an HTTP client
			httpClient = system.net.httpClient()
			    
			#Make the POST request
			response = httpClient.post(url, params=params)
			
			#MII_Ignition_Library.Logger.Insert_Log.Insert_Error_Log("CIP APIUpdSanLogHdr Response", str(response.text))
			
			return response
		
		except:
			MII_Ignition_Library.Logger.Insert_Log.Insert_Error_Log(Client + "_" + Plant + "_" + "CIP", "Error: MII_Ignition_Library.CIP.Sanitation.UpdSanLogHdr has failed. Check log for details.")
			return "Error: MII_Ignition_Library.CIP.Sanitation.UpdSanLogHdr has failed. Check log for details." 	
	
	
	
def SanitationType(Server,Client, Plant):
	#This Method returns a DataSet with a 'SanType' table containing all Sanitation Types in FLQCMS.
	try:
		url = 'http://' + str(Server) + '/PR-CID/ShopFloorAPI/API_Data_Collection_Messages_Cidra/api/Sanitation/SanitationType?Client=' + str(Client) + '&Plant=' + str(Plant)
		json_data = system.net.httpGet(url)
		return json_data
	
	except:
		MII_Ignition_Library.Logger.Insert_Log.Insert_Error_Log(Client + "_" + Plant + "_" + "CIP", "Error: MII_Ignition_Library.CIP.Sanitation.SanitationType has failed. Check log for details.")
		return "Error: MII_Ignition_Library.CIP.Sanitation.SanitationType has failed. Check log for details."
		
		
	
def GetSanLogDtl(Server,Client, Plant, SanH_ID):
	#This Method creates a new Sanitation in tblSanLogHdr.
	try:
		url = 'http://' + str(Server) + '/PR-CID/ShopFloorAPI/API_Data_Collection_Messages_Cidra/api/Sanitation/GetSanLogDtl?Client=' + str(Client) + '&Plant=' + str(Plant) + '&SanH_ID=' + str(SanH_ID)
		json_data = system.net.httpGet(url)
		return json_data
	
	except:
		MII_Ignition_Library.Logger.Insert_Log.Insert_Error_Log(Client + "_" + Plant + "_" + "CIP", "Error: MII_Ignition_Library.CIP.Sanitation.GetSanLogDtl has failed. Check log for details.")
		return "Error: MII_Ignition_Library.CIP.Sanitation.GetSanLogDtl has failed. Check log for details."



def SanTstNotExpired(Server,Client, Plant, SanH_ID):
	#This Method returns a DataSet from tblSanStepsTest of Tests Not Expired.
	try:
		url = 'http://' + str(Server) + '/PR-CID/ShopFloorAPI/API_Data_Collection_Messages_Cidra/api/Sanitation/SanTstNotExpired?Client=' + str(Client) + '&Plant=' + str(Plant) + '&SANHId=' + str(SanH_ID)
		json_data = system.net.httpGet(url)
		return json_data
	
	except:
		MII_Ignition_Library.Logger.Insert_Log.Insert_Error_Log(Client + "_" + Plant + "_" + "CIP", "Error: MII_Ignition_Library.CIP.Sanitation.SanTstNotExpired has failed. Check log for details.")
		return "Error: MII_Ignition_Library.CIP.Sanitation.SanTstNotExpired has failed. Check log for details."



def Insert_SanDtl_SingleTest(Server, Client, Plant, SanHdrId, CrtUsrId, TestId):
	#This Method Inserts a Single Test into tblSanLogDtl.
	
	try:
		
		# URL Encode the parameter
		#Equipment_Name_Encoded = URLEncoder.encode(str(Equipment_Name), "UTF-8")
		
		# Define HTTP request parameters
		url = 'http://' + str(Server) + '/PR-CID/ShopFloorAPI/API_Data_Collection_Messages_Cidra/api/Sanitation/Insert_SanDtl_SingleTest'
		params = {
		        "Client": Client,
		        "Plant": Plant,
		        "SanHdrId": SanHdrId,
		        "CrtUsrId": CrtUsrId,
		        "TestId": TestId
		    }
		    
		# Create an HTTP client
		httpClient = system.net.httpClient()
		    
		#Make the POST request
		response = httpClient.post(url, params=params)
		
		return response
	
	except:
		MII_Ignition_Library.Logger.Insert_Log.Insert_Error_Log(Client + "_" + Plant + "_" + "CIP", "Error: MII_Ignition_Library.CIP.Sanitation.Insert_SanDtl_SingleTest has failed. Check log for details.")
		return "Error: MII_Ignition_Library.CIP.Sanitation.Insert_SanDtl_SingleTest has failed. Check log for details."



def UpdSanLogDtl(Server, Client, Plant, SANDRecId, Answer, ChgUsrId):
	#This Method Inserts a Single Test into tblSanLogDtl.
	
	try:
		
		# Define HTTP request parameters
		url = 'http://' + str(Server) + '/PR-CID/ShopFloorAPI/API_Data_Collection_Messages_Cidra/api/Sanitation/UpdSanLogDtl'
		params = {
		        "Client": Client,
		        "Plant": Plant,
		        "SANDRecId": SANDRecId,
		        "Answer": Answer,
		        "ChgUsrId": ChgUsrId
		    }
		    
		# Create an HTTP client
		httpClient = system.net.httpClient()
		    
		#Make the PUT request
		response = httpClient.put(url, params=params)
		
		return response
	
	except:
		MII_Ignition_Library.Logger.Insert_Log.Insert_Error_Log(Client + "_" + Plant + "_" + "CIP", "Error: MII_Ignition_Library.CIP.Sanitation.UpdSanLogDtl has failed. Check log for details.")
		return "Error: MII_Ignition_Library.CIP.Sanitation.UpdSanLogDtl has failed. Check log for details."
