import xml.etree.ElementTree as ET
import json
import system

def UserID_tblUser(Client, Plant, Server, UserID):
	#This Method returns an integer ID code in tblUser.
	try:
		User = str(UserID)
		
		res = system.net.httpPost("http://" + Server + "/PR-CID/ShopFloor/WebServices/CSharp/WebServicesCS/Common.asmx?op=UserID_tblUser", "text/xml",
		'''<?xml version="1.0" encoding="utf-8"?>
		<soap12:Envelope xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xsd="http://www.w3.org/2001/XMLSchema" xmlns:soap12="http://www.w3.org/2003/05/soap-envelope">
		  <soap12:Body>
		    <UserID_tblUser xmlns="http://cri.ko.com/">
		      <UserID>''' + User + '''</UserID>
		    </UserID_tblUser>
		  </soap12:Body>
		</soap12:Envelope>''')
		
		return res
	
	except:
		MII_Ignition_Library.Logger.Insert_Log.Insert_Error_Log(Client + "_" + Plant + "_" + "CIP", "Error: MII_Ignition_Library.CIP.Common.UserID_tblUser has failed. Check log for details. Entered Values: UserID: " + str(UserID))
		return "Error: MII_Ignition_Library.CIP.Common.UserID_tblUser has failed. Check log for details. Entered Values: UserID: " + str(UserID)
		
		
	

def UserAllowedLines(Client, Plant, Server, UserID_Integer):
	#This Method returns the Lines to which a given User has access.
	try:
		User_Int = str(UserID_Integer)
		
		res = system.net.httpPost("http://" + Server + "/PR-CID/ShopFloor/WebServices/CSharp/WebServicesCS/Common.asmx?op=UserAllowedLines", "text/xml",
		'''<?xml version="1.0" encoding="utf-8"?>
		<soap12:Envelope xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xsd="http://www.w3.org/2001/XMLSchema" xmlns:soap12="http://www.w3.org/2003/05/soap-envelope">
		  <soap12:Body>
		    <UserAllowedLines xmlns="http://cri.ko.com/">
		      <UsrId>''' + User_Int + '''</UsrId>
		    </UserAllowedLines>
		  </soap12:Body>
		</soap12:Envelope>''')
		
		
		# XML string (Assuming this XML is saved in a multi-line string variable named `xml_data`)
		xml_data = res
		
		# Parse the XML string
		root = ET.fromstring(xml_data)
		
		# Define namespaces to search for the target elements
		namespaces = {
		    'soap': 'http://www.w3.org/2003/05/soap-envelope',
		    'diffgr': 'urn:schemas-microsoft-com:xml-diffgram-v1'
		    # Add other namespaces if needed
		}
		
		# Find all Lines elements
		lines_elements = root.findall(".//diffgr:diffgram//NewDataSet//Lines", namespaces)
		
		# List to hold all lines data
		lines_data = []
		
		# Extract relevant information from each Lines element
		for lines_element in lines_elements:
		    line_id = lines_element.find('LineId').text
		    line_dsc = lines_element.find('LineDsc').text
		    read_only = lines_element.find('ReadOnly').text
		    
		    # Create a dictionary for each Lines element and add it to the list
		    line_dict = {
		        'LineId': line_id,
		        'LineDsc': line_dsc,
		        'ReadOnly': read_only == 'true'
		    }
		    lines_data.append(line_dict)
		
		# Convert list of lines data to JSON object
		json_data = json.dumps(lines_data, indent=4)
		
		return json_data
	
	except:
		MII_Ignition_Library.Logger.Insert_Log.Insert_Error_Log(Client + "_" + Plant + "_" + "CIP", "Error: MII_Ignition_Library.CIP.Common.UserID_tblUser has failed. Check log for details. Entered Values: UserID: " + str(UserID))
		return "Error: MII_Ignition_Library.CIP.Common.UserID_tblUser has failed. Check log for details. Entered Values: UserID: " + str(UserID)
		
		


def ActiveMaterials(Server, Client, Plant):
	#This Method returns a DataSet with a 'Materials' table containing all active Materials in FLQCMS.
	try:
		
		url = 'http://' + str(Server) + '/PR-CID/ShopFloorAPI/API_Data_Collection_Messages_Cidra/api/Sanitation/ActiveMaterials?Client=' + str(Client) + '&Plant=' + str(Plant)
		
		json_data = system.net.httpGet(url)
		
		return json_data
	
	except:
		MII_Ignition_Library.Logger.Insert_Log.Insert_Error_Log(Client + "_" + Plant + "_" + "CIP", "Error: MII_Ignition_Library.CIP.Sanitation.ActiveMaterials has failed. Check log for details.")
		return "Error: MII_Ignition_Library.CIP.Sanitation.ActiveMaterials has failed. Check log for details." 