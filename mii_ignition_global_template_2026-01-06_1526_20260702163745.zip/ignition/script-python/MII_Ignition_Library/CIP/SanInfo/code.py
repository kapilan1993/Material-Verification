class SanInfo:
    strEmpty = "<n/a>"
    strCheck = "<chk>"
    strStatusColSubString = "Sts"
    strPastDueColName = "Past Due"
    strWarnColName = "Warning"
    strErrorTableName = "tblError"
    bytSANDRecIdCol = 0
    bytAnsTypeCol = 5
    bytDecCol = 6
    bytLowVal = 7
    bytHighVal = 8
    bytAnsCol = 9
    bytChgDTCol = 12
    bytChgUsrIdCol = 13
    bytChgUsrCol = 15
    bytUsrLineId = 0
    bytUsrLineDsc = 1
    bytUsrLineRO = 2

    Fields = type('Fields', (object,), {
        'SANHRecId': None,
        'SAHHOrder': None,
        'SANHMfgQty': None,
        'SANHMatBef': None,
        'SANHMatAft': None,
        'SANHRecSan': None,
        'SANHSelSan': None,
        'SANHStartDt': None,
        'SANHStartOpr': None,
        'SANHEndDt': None,
        'SANHEndOpr': None,
        'SANHCompleteDt': None,
        'SANHCompleteOpr': None,
        'SANHComment': None
    })

    @staticmethod
    def ForceDecimalPlaces(strValue, intDecPlaces):
        strResult = ''
        if SanInfo.IsStrNum(strValue):
            strResult = str(round(float(strValue), intDecPlaces))
            intDigitsAfterDec = len(strResult.split('.')[1]) if '.' in strResult else 0
            if intDigitsAfterDec < intDecPlaces:
                if '.' not in strResult:
                    strResult += '.'
                strResult += '0' * (intDecPlaces - intDigitsAfterDec)
        return strResult

    @staticmethod
    def IsStrNum(myNumber):
        try:
            float(myNumber)
            return True
        except ValueError:
            return False