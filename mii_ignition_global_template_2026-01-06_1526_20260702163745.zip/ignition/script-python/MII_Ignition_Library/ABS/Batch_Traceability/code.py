def Get_ABS_Batch_Traceability(API_Protocol, API_Server, Client, Plant, Batch):
	try:
			
		url = str(API_Protocol) + '://' + str(API_Server) + '/PR-CID/ShopFloorAPI/API_Data_Collection_Messages_Cidra/api/Batch/ABSBatchTraceability?Client=' + str(Client) + '&Plant=' + str(Plant) + '&Batch=' + str(Batch)
				
		json_data = system.net.httpGet(url)
				
		return json_data
	
	except Exception as e:
		Status = e
		return Status
		MII_Ignition_Library.Logger.Insert_Log.Insert_Error_Log(str(Client) + "_" + str(Plant) + "_" + "Get_ABS_Batch_Traceability", Status)
		
		