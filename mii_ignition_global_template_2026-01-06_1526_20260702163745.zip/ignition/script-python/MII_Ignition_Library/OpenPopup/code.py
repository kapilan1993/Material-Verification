def openErrorPopup(params):
	system.perspective.openPopup("alertPopup",'Popup/SuccessMsgPopup', params, showCloseIcon = False, resizable = False, modal = True, overlayDismiss = True)
#	params = {'source':'/system/images/Icons/Alert.svg','text':'Error while adding device tags!'}