def Is_Valid_Number(Text):
#Verify if Text is a valid Number
    try:
        float(Text)
        return True
    except:
        return False