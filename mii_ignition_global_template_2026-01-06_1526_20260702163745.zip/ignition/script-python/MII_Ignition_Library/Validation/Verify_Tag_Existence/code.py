def Tag_Existence_Report(Path,Error_Title,Error_Message):
	
	if system.tag.exists(Path) == True:
		return True
	
	else:
		MII_Ignition_Library.Logger.Insert_Log.Insert_Error_Log(Error_Title,Error_Message)
		return False
		
		


def Tag_Existence_Non_Report(Path):
	
	if system.tag.exists(Path) == True:
		return True
	
	else:
		return False