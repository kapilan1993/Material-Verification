def Material_Data(Client, Plant, Server, Material):
	#Get required material data to populate Sanitation Function
	try:
		import xml.etree.ElementTree as SR
		#prcidb66
		
		import xml.etree.ElementTree as SR
		Material = str(Material)
		
		res = system.net.httpPost("http://" + Server + "/PR-CID/ShopFloor/WebServices/CSharp/WebServicesCS/Common.asmx?op=Material_Data", "text/xml",
		'''<?xml version="1.0" encoding="utf-8"?>
		<soap12:Envelope xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xsd="http://www.w3.org/2001/XMLSchema" xmlns:soap12="http://www.w3.org/2003/05/soap-envelope">
		  <soap12:Body>
		    <Material_Data xmlns="http://cri.ko.com/">
		      <Material>''' + Material + '''</Material>
		    </Material_Data>
		  </soap12:Body>
		</soap12:Envelope>''')
		
		#Response Message
		#root = SR.fromstring(res)
		#Material_ID = root[0][0][0].text
		#Material_Description = root[0][0][0].text
		#return Response_Message
		return res
	
	except:
		MII_Ignition_Library.Logger.Insert_Log.Insert_Error_Log(Client + "_" + Plant + "_" + "Sanitation", "Error: MII_Ignition_Library.Validation.Sanitation.GetSanTypeDesc has failed. Check log for details. Entered Values: Material: " + str(Material))
		return "Error: MII_Ignition_Library.Validation.Sanitation.Material_Data has failed. Check log for details. Entered Values: Material: " + str(Material)



def GetSanTypeDesc(Client, Plant, Server,MatBefId,MatNxtId):

	try:
		import xml.etree.ElementTree as SR
		#prcidb66
		
		import xml.etree.ElementTree as SR
		MatBefId_Value = str(MatBefId)
		MatNxtId_Value = str(MatNxtId)
		
		res = system.net.httpPost("http://" + Server + "/PR-CID/ShopFloor/WebServices/CSharp/WebServicesCS/Sanitation.asmx?op=GetSanTypeDesc", "text/xml",
		'''<soap12:Envelope xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xsd="http://www.w3.org/2001/XMLSchema" xmlns:soap12="http://www.w3.org/2003/05/soap-envelope">
		<soap12:Body>
		<GetSanTypeDesc xmlns="http://cri.ko.com/">
		<MatBefId>''' + MatBefId_Value + '''</MatBefId>
		<MatNxtId>''' + MatNxtId_Value + '''</MatNxtId>
		</GetSanTypeDesc>
		</soap12:Body>
		</soap12:Envelope>''')
		
		#Response Message
		#root = SR.fromstring(res)
		#Response_Message = root[0][0][0].text
		#return Response_Message
		return res
	
	except:
		MII_Ignition_Library.Logger.Insert_Log.Insert_Error_Log(Client + "_" + Plant + "_" + "Sanitation", "Error: MII_Ignition_Library.Validation.Sanitation.GetSanTypeDesc has failed. Check log for details. Entered Values: MatBefId: " + str(MatBefId) + " , MatNxtId: " + str(MatNxtId))
		return "Error: MII_Ignition_Library.Validation.Sanitation.GetSanTypeDesc has failed. Check log for details. Entered Values: MatBefId: " + str(MatBefId) + " , MatNxtId: " + str(MatNxtId)


