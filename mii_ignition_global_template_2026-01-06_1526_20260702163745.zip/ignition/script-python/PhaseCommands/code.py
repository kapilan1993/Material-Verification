def cmd_function(phaseCommand,command1,command2,currentPhase):
	import time
	time.sleep(0.5)
	command_tag = "[Shop_Floor]Coca-Cola/CPS/5040/LF/LFFML1/TransferPhase/BatchTags/SYS"+str(currentPhase)+"/PhaseCommand"
	req_tag = "[Shop_Floor]Coca-Cola/CPS/5040/LF/LFFML1/TransferPhase/BatchTags/SYS"+str(currentPhase)+"/PhaseReq"
	
	# Write PhaseCommand initially
	system.tag.writeBlocking([command_tag], [phaseCommand])
	time.sleep(0.5)
	while True:
		# Read the value of PhaseReq
		request = system.tag.readBlocking([req_tag])[0].value
		if request > 50:
			# Write to PhaseCommand if PhaseReq > 50
			system.tag.writeBlocking([command_tag], [command1])
			# Monitor until PhaseReq becomes 10
			while True:
				request = system.tag.readBlocking([req_tag])[0].value
				if request >= 10:
					# Write to PhaseCommand when PhaseReq == 10
					system.tag.writeBlocking([command_tag], [command2])
					return