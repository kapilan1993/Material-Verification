def addDevice(database, workCenter, devices, user):
	#Get WC id
	namedQuery = 'WcConfigurationnew/getWorkCentersDetails'
	parameter = {"database":database,"workCenter" : workCenter}
	wcId = system.db.runNamedQuery(namedQuery,parameter)
	
	#Add deivces in tblDeviceMaster
	for device in devices:
	    types = device['deviceType']
	    name = device['deviceName']
	    capacityMin = device['min']
	    capacityMax = device['max']
	    resolution = device['resolution']
	    priOrSec = device['priOrSec']
	    fixOrManual= device['fixedOrManual']
	    usbOrGateway = device['usbOrGateway']
	    uomId = device['deviceCapacityUnit']
	    deviceDesc = device['deviceDesc']
	    bufferMidLim = device['bufferMidLim']
	    bufferHighLim = device['bufferHighLim']
	    bufferCriticalLim = device['bufferCriticalLim']
	    namedQuery = 'WcConfigurationnew/addDevice'
	    parameter = {"database":database, "name" : name, "type" : types,  "capacityMin" :capacityMin, "capacityMax": capacityMax, "resolution":resolution, "uomId" :uomId,"priOrSec":priOrSec, "fixOrManual": fixOrManual , "wcId" : wcId[0][0], "usbOrGateway":usbOrGateway, "deviceDesc":deviceDesc,
	    "bufferMidLim" :bufferMidLim, "bufferHighLim" :bufferHighLim, "bufferCriticalLim" :bufferCriticalLim, "updateBy" : user}
	    
	    print parameter
	    system.db.runNamedQuery(namedQuery,parameter)
	   
def updateWorkCenter(database,workCenter, wcType, description, area):
	namedQuery = 'WcConfigurationnew/updateWorkCenters'
	parameter = {"database":database, "wc" : workCenter, "isConfigured" : 1, "workCenterType" : wcType, "description": description, "area":area}
	wcId = system.db.runNamedQuery(namedQuery,parameter)
	
def creareUdtInstance(tagPath, udtName, udtType):
	udtInstance = {	"name" : udtName,
		"typeId" : udtType,
		"tagType" : "UdtInstance",
		}

	system.tag.configure(tagPath, udtInstance)
	    
def addnewDevice(database, workCenter, deviceType,deviceName,capacityMin,capacityMax, resolution,priOrSec, fixOrManual, usbOrGateway, deviceDesc, bufferMidLim, bufferHighLim, bufferCriticalLim, uomId, user):

	#Get WC id
	namedQuery = 'WcConfigurationnew/getWorkCentersDetails'
	parameter = {"database":database, "workCenter" : workCenter}
	wcId = system.db.runNamedQuery(namedQuery,parameter)
	
	#Add deivces in tblDeviceMaster
	namedQuery = 'WcConfigurationnew/addDevice'
	parameter = {"database":database, "name" : deviceName, "type" : deviceType,  "capacityMin" :capacityMin, "capacityMax": capacityMax, "resolution":resolution, "uomId" :uomId, "priOrSec":priOrSec, "fixOrManual": fixOrManual , "wcId" : wcId[0][0],"usbOrGateway":usbOrGateway,
	 "bufferMidLim" :bufferMidLim, "bufferHighLim" :bufferHighLim, "bufferCriticalLim" :bufferCriticalLim, "deviceDesc":deviceDesc, "updateBy" : user}
	system.db.runNamedQuery(namedQuery,parameter)

def updateFunctions(database, workCenter, functions, user):
	params = {'source':'/system/images/Icons/Alert.svg','text':'Error while updating the function!'}
	try:
		values = []
		uomIDs=[]
		for function in functions:
			uomID = function['unit']
			uomIDs.append(uomID)
			system.perspective.print("uomID"+str(uomID))
			values.append(function["value"])
		idu = uomIDs[12]
		
		namedQuery = 'WcConfigurationnew/updateWcFuncitons'
#		parameter = {"database": database, "wc" : workCenter, "enableAutoGi" : values[0], "enableAutoPr" : values[2], "enableAutoPhaseCom" : values[1], "enableBbd" : values[3], "enableMatManage" : values[5], "enableStockValidation" : values[10], "enablePartialGi" : values[11], "enableSkipBbd" : values[4], "partialGiFreq" : values[12], "enablePartialSplit" :values[7],  "enableFullSplit":values[8], "enableScrapReason":values[9], "enableBarcodeValidation":values[6],"enableBBDValidation":values[13] ,"enableBarcodeValidationPrePOExecution":values[14] ,"enableBarcodeValidationPostPOExecution":values[15],"enableMovableScales":values[16],"enableManualFilling":values[17], "enableAutoSamplingForQuality": values[18], "uomId":idu,  "user" : user}
#		system.db.runNamedQuery(namedQuery,parameter)
#		parameter = {"database": database, "wc" : workCenter, "enableAutoGi" : values[0], "enableAutoPr" : values[2], "enableAutoPhaseCom" : values[1], "enableBbd" : values[3], "enableMatManage" : values[5], "enableStockValidation" : values[10], "enablePartialGi" : values[11], "enableSkipBbd" : values[4], "partialGiFreq" : values[12], "enablePartialSplit" :values[7],  "enableFullSplit":values[8], "enableScrapReason":values[9], "enableBarcodeValidation":values[6],"enableBBDValidation":values[13] ,
#		"enableBarcodeValidationPrePOExecution":values[14] ,"enableBarcodeValidationPostPOExecution":values[15],"enableMovableScales":values[16],"enableManualFilling":values[17], "enableAutoSamplingForQuality": values[18], "densitySampleFrquency": values[19], "inlineDensityParam1": values[20], "inlineDensityParam2": values[21],"enableDosingType": values[22], "enableZoning": values[23], "enableParallelOrder": values[24], "productionPercentage": values[25],"enable2010BufferTransfer":values[26],  "uomId":idu,  "user" : user}
#		system.db.runNamedQuery(namedQuery,parameter)
#		parameter = {"database": database, "wc" : workCenter, "enableAutoGi" : values[0], "enableAutoPr" : values[2], "enableAutoPhaseCom" : values[1], "enableBbd" : values[3], "enableMatManage" : values[5], "enableStockValidation" : values[10], "enablePartialGi" : values[11], "enableSkipBbd" : values[4], "partialGiFreq" : values[12], "enablePartialSplit" : values[7], "enableFullSplit": values[8], "enableScrapReason": values[9], "enableBarcodeValidation": values[6], "enableBBDValidation": values[13], "enableBarcodeValidationPrePOExecution": values[14], "enableBarcodeValidationPostPOExecution": values[15], "enableMovableScales": values[16], "enableManualFilling": values[17], "enableAutoSamplingForQuality": values[18], "densitySampleFrquency": values[19], "inlineDensityParam1": values[20], "inlineDensityParam2": values[21], "enableDosingType": values[22], "enableZoning": values[23], "enableParallelOrder": values[24], "productionPercentage": values[25], "enable2010BufferTransfer": values[26], "enableGLSPrint": values[27], "maxPOQueue": values[33], "maxPOin2020": values[34], "maxPOin2030": values[35], "enableMaterialValidation": values[28], "enableHOLDABORTctrl": values[30], "enablePODownloadctrl": values[31], "enable2020CMPL": values[32], "enableBagInserterPhantomMaterial": values[29], "completionzone": values[37], "noofZones": values[38], "partialAutoGIfrequency": values[36],
#		"uomId":idu,  "user" : user}
		parameter = {"database": database, "wc" : workCenter, 
		"enableAutoGi" : values[0],"partialAutoGIfrequency": values[1],"enableAutoPr" : values[2],"enableScrapReason": values[3],"enableBbd" : values[4],"enableBBDValidation": values[5],
		"enablePartialSplit" : values[6],"enableFullSplit": values[7],"enableMovableScales": values[8],"enableManualFilling": values[9],"enableAutoSamplingForQuality": values[10],
		"densitySampleFrquency": values[11],"inlineDensityParam1": values[12],"inlineDensityParam2": values[13],"enableDosingType": values[14],"productionPercentage": values[15],
		"enableGLSPrint": values[16],"enableMaterialValidation": values[17],"enableBagInserterPhantomMaterial": values[18],"enableHoldAbortCtrl": values[19],
		"enablePODownloadCtrl": values[20],"enable2020CMPL": values[21],"maxPOqueue": values[22],"maxPOin2020": values[23],"maxPOin2030": values[24],"noofzones": values[25],"completionzone": values[26],"completionzonePhantom": values[27],"enable2010": values[28],"enable2030": values[29],
		"uomId":idu,  "user" : user}
		system.db.runNamedQuery(namedQuery,parameter)
	except:
		MII_Ignition_Library.Logger.Insert_Log.Insert_Error_Log('UpdateWCFunctionInDB', str(sys.exc_info()))
		MII_Ignition_Library.OpenPopup.openErrorPopup(params)
	
def updateDevicesToDelete(workCenter):
	params = {"IsDeleted": 1, "wc":workCenter}
	system.db.runNamedQuery("WcConfigurationnew/updateDevices", params)
	

def folderExist(tagPath):
	folderExist = system.tag.exists(tagPath)
	return folderExist

def createFolder(basePath, folderName):
	#creating workcenter folder
	tagFolder = {'tagtype' : 'Folder',
					'name' : folderName,
				}
	system.tag.configure(basePath, tagFolder, 'o')
	
def createQueueFolder(tagPath, folderName):
	basePath = tagPath
	tagFolder = {
		  "name": folderName,
		  "tagType": "Folder",
		  "tags": [
		    {
		      "valueSource": "memory",
		      "dataType": "DataSet",
		      "name": "Queue",
		      "value": "",
		      "tagType": "AtomicTag",
		      "timestamp": 1722020062000
		    }
		  ]
		}
	system.tag.configure(basePath, tagFolder, 'o')
	

	
def createWcFolder(tagPath, folderName, plant, wcType, tagProvider,functions):
	opcSer = system.opc.getServers(includeDisabled = True)[0]
#	opcSer = "BRMAO-MIIT.la.ko.com"
	basePath = tagPath
	#Functions
	values=[]
	for function in functions:
		values.append(function["value"])
#	maxPOin2020= values[23]
#	maxPOin2030= values[24]
	noofZones= int(values[25])
#	if 	maxPOin2020 == 1 and maxPOin2030 == 1:
#		udtfolder1="UNS/GatewayPO"
#	elif maxPOin2020 >= 2 and maxPOin2030 == 1:
#		udtfolder1="UNS/PO_m2020"
#	elif maxPOin2020 == 1 and maxPOin2030 >= 2:
#		udtfolder1="UNS/PO_m2030"
#	MII_Ignition_Library.Logger.Insert_Log.Insert_Error_Log('Max PO Log', str(udtfolder1))
	
	#NoofZones
	
	#creating workcenter folder
	tagFolder = {
  "name": folderName,
  "tagType": "Folder",
  "tags": [
    {
      "name": "OEE",
      "typeId": "UNS/OEE",
      "tagType": "UdtInstance"
    },
    {
      "name": "Gateway_Devices",
      "tagType": "Folder",
      "tags": [
        {
          "name": "Metering",
          "tagType": "Folder",
          "tags": [
            {
              "name": "Humidity",
              "tagType": "Folder"
            },
            {
              "name": "Energy",
              "tagType": "Folder"
            }
          ]
        },
        {
          "name": "Barcode_Scanner",
          "tagType": "Folder",
          "tags": [
            {
              "name": "Fixed_Scanner",
              "tagType": "Folder"
            },
            {
              "name": "Handheld_Scanner",
              "tagType": "Folder"
            }
          ]
        },
		{
		  "name": "BBN",
		  "typeId": "UNS/GatewayBBN",
		  "parameters": {
		    "wcName": {
		      "dataType": "String",
		      "value": folderName
		    }
		  },
		  "tagType": "UdtInstance"
		},
		{
		  "name": "BOM",
		  "typeId": "UNS/GatewayBOM",
		  "parameters": {
		    "workCenter": {
		      "dataType": "String",
		      "value": folderName
		    }
		  },
		  "tagType": "UdtInstance"
		},
        {
          "name": "Checkweigher",
          "tagType": "Folder"
        },
        {
          "name": "CapperHead",
          "tagType": "Folder"
        },
        {
          "name": "Palletizer",
          "tagType": "Folder"
        },
        {
		  "name": "Line",
		  "typeId": "UNS/GatewayLine",
		  "parameters": {
		    "wcName": {
		      "dataType": "String",
		      "value": folderName
		    }
		  },
		  "tagType": "UdtInstance"
		},
#		{
#		  "name": "Listeners",
#		  "typeId": "UNS/Listeners",
#		  "parameters": {
#		    "workCenter": {
#		      "dataType": "String",
#		      "value": folderName
#		    }
#		  },
#		  "tagType": "UdtInstance"
#		},
		{
		  "name": "TrackAndTrace",
		  "typeId": "UNS/GatewayTrackAndTrace",
  		  "parameters": {
		    "wcName": {
		      "dataType": "String",
		      "value": folderName
		    }
		   },
		  "tagType": "UdtInstance"
		},
		{
		  "name": "WIP",
		  "typeId": "UNS/GatewayWIP",
		  "parameters": {
		    "workCenter": {
		      "dataType": "String",
		      "value": folderName
		    }
		  },
		  "tagType": "UdtInstance"
		},
		{
		  "valueSource": "opc",
		  "opcItemPath": "ns=1;s=[DCPLC]"+folderName+".ZoningConfig",
		  "dataType": "Boolean",
		  "name": "ZoningConfig",
		  "tagType": "AtomicTag",
		  "opcServer": opcSer
		},
        {
          "name": "Sensors",
          "tagType": "Folder",
          "tags": [
            {
              "name": "Humidity",
              "tagType": "Folder"
            },
            {
              "name": "Temperature",
              "tagType": "Folder"
            },
            {
              "name": "Alarm",
              "tagType": "Folder"
            }
          ]
        },
        {
          "name": "Filler",
          "tagType": "Folder",
          "tags": [
			{
			  "valueSource": "opc",
			  "opcItemPath": "ns=1;s=[DCPLC]"+folderName+".Filler.Status",
			  "dataType": "Boolean",
			  "alarms": [
			    {
			      "name": "Filler Status Alarm",
			      "label": folderName +" Filler PLC Connection is lost",
			      "displayPath": folderName +" Filler PLC",
			      "priority": "High"
			    }
			  ],
			  "name": "FillerPlcStatus",
			  "value": False,
			  "tagType": "AtomicTag",
			  "opcServer": opcSer
			}
		  ]
        },
        {
		  "name": "PLCStatus",
		  "tagType": "Folder",
		  "tags": [
		    {
		      "valueSource": "opc",
		      "opcItemPath": "ns=1;s=[DCPLC]"+folderName+"_LinePLCCommSts",
		      "dataType": "Int2",
		      "name": folderName + "_LinePLCCommSts",
		      "tagType": "AtomicTag",
		      "opcServer": opcSer
		    }
		  ]
		},
        {
		  "name": "PO",
		  "typeId": "UNS/GatewayPO",
		  "parameters": {
		    "workCenter": {
		      "dataType": "String",
		      "value": folderName
		    }
		  },
		  "tagType": "UdtInstance"
		},
        {
          "name": "SpcWeight",
          "tagType": "Folder"
        }
      ]
    },
#    {
#      "name": "PO",
#      "typeId": udtfolder1,
#      "parameters": {
#        "2020TagReferencePath": {
#          "dataType": "String",
#          "value": tagProvider+"Coca-Cola/CPS/"+plant+"/"+wcType+"/"+folderName+"/Gateway_Devices/PO/2020/"
#        },
#        "2010TagReferencePath": {
#		"dataType": "String",
#		"value":  tagProvider+"Coca-Cola/CPS/"+plant+"/"+wcType+"/"+folderName+"/Gateway_Devices/PO/2010/"
#    	}
#	},
#      "tagType": "UdtInstance"
#    },
    {
	  "name": "InventoryValidation",
	  "typeId": "UNS/InventoryValidation",
	  "parameters": {
	    "basePath": {
	      "dataType": "String",
	      "value": "ns=1;s=[DCPLC]"+folderName+".ScanLotMan"
	    }
	  },
	  "tagType": "UdtInstance"
	},
	{
	  "name": "TrackAndTrace",
	  "typeId": "UNS/TrackAndTrace",
	  "parameters": {
	    "tagReferencePath": {
	      "dataType": "String",
	      "value": tagProvider+"Coca-Cola/CPS/"+plant+"/"+wcType+"/"+folderName+"/Gateway_Devices/TrackAndTrace/"
	    }
	  },
	  "tagType": "UdtInstance"
	},
	{
	  "name": "WIP",
	  "typeId": "UNS/WIP",
	  "parameters": {
	    "tagReferencePath": {
	      "dataType": "String",
	      "value": tagProvider+"Coca-Cola/CPS/"+plant+"/"+wcType+"/"+folderName+"/Gateway_Devices/WIP"
	    }
	  },
	  "tagType": "UdtInstance"
	},
#	{
#	  "name": "Listeners",
#	  "typeId": "UNS/Listeners",
#	  "parameters": {
#	    "tagReferencePath": {
#	      "dataType": "String",
#	      "value": tagProvider+"Coca-Cola/CPS/"+plant+"/"+wcType+"/"+folderName+"/Gateway_Devices/Listeners"
#	    }
#	  },
#	  "tagType": "UdtInstance"
#	},
    {
      "name": "SF_Equipment",
      "tagType": "Folder",
      "tags": [
        {
          "name": "Camera",
          "tagType": "Folder"
        },
        {
          "name": "Palletizer",
          "tagType": "Folder"
        },
        {
          "name": "BagLabeler",
          "tagType": "Folder"
        },
        {
          "name": "CaseLabeler",
          "tagType": "Folder"
        },
        {
          "name": "BagInserter",
          "tagType": "Folder"
        },
        {
          "name": "BagSealer",
          "tagType": "Folder"
        },
        {
          "name": "CaseSealer",
          "tagType": "Folder"
        },
        {
          "name": "BagTumbler",
          "tagType": "Folder"
        },
        {
          "name": "MetalDetector",
          "tagType": "Folder"
        },
        {
          "name": "WIPAddition",
          "tagType": "Folder"
        },
        {
          "name": "CaseErector",
          "tagType": "Folder"
        },
        {
          "name": "Wrapper",
          "tagType": "Folder"
        },
        {
          "name": "Filler",
          "tagType": "Folder"
        },
        {
          "name": "CapperHead",
          "tagType": "Folder"
        },
        {
          "name": "BarcodeReader",
          "tagType": "Folder"
        },
		{
		  "name": "Checkweigher",
		  "tagType": "Folder",
		  "tags": [
		    {
		      "name": "Primary_Packaging",
		      "tagType": "Folder"
		    },
		    {
		      "name": "Secondary_Packaging",
		      "tagType": "Folder"
		    }
		  ]
		},
        {
          "name": "Scale",
          "tagType": "Folder"
        },
        {
          "name": "Conveyor",
          "tagType": "Folder"
        }
      ]
    },
    {
      "name": "MII_Posting",
      "tagType": "Folder"
    },
    {
      "name": "Zones",
      "tagType": "Folder"
    },
    {
      "name": "PO",
      "tagType": "Folder"
    }
  ]
}
	#inside Zones folder
	for i in range (1,noofZones+1):
		WcConfigurationnew.creareUdtInstance(tagPath +'/'+folderName + '/Zones', "Z"+str(i)+"_Listener", "UNS/Listener")
		MII_Ignition_Library.Logger.Insert_Log.Insert_Error_Log('No of Zones', str(noofZones))
		
	#inside filler folder in SF_Equipmet
	WcConfigurationnew.creareUdtInstance(tagPath +'/'+folderName + '/SF_Equipment/Filler', "FillerRawData", "UNS/FillerRawData")
	WcConfigurationnew.creareUdtInstance(tagPath +'/'+folderName + '/SF_Equipment/Filler', "Header", "UNS/Filler")
	WcConfigurationnew.creareUdtInstance(tagPath +'/'+folderName + '/SF_Equipment/Filler', "Metering", "UNS/Metering")
	WcConfigurationnew.creareUdtInstance(tagPath +'/'+folderName + '/SF_Equipment/Filler', "SPC", "UNS/SPC")
	
	# insert into MII_Posting folder
	WcConfigurationnew.creareUdtInstance(tagPath +'/'+folderName + '/MII_Posting', "GoodIssuePosting", "UNS/GoodIssuePosting")
	WcConfigurationnew.creareUdtInstance(tagPath +'/'+folderName + '/MII_Posting', "MachineStatusPosting", "UNS/MachineStatusPosting")
	WcConfigurationnew.creareUdtInstance(tagPath +'/'+folderName + '/MII_Posting', "PhaseStatusPosting", "UNS/PhaseStatusPosting")
	WcConfigurationnew.creareUdtInstance(tagPath +'/'+folderName + '/MII_Posting', "ProductionReportPosting", "UNS/ProductionReportPosting")
	
	# create CIP udt istance inside work center folder
	WcConfigurationnew.creareUdtInstance(tagPath +'/'+folderName, "Metering", "UNS/Metering")
	
	# create CIP udt istance inside work center folder
	WcConfigurationnew.creareUdtInstance(tagPath +'/'+folderName, "CIP", "UNS/CIP")
	
	# create WIP's in workcenter
#	WcConfigurationnew.creareUdtInstance(tagPath +'/'+folderName, "WIP", "UNS/WIP")
	
	# create Device Tracking in workcenter
#	WcConfigurationnew.creareUdtInstance(tagPath +'/'+folderName, "TrackAndTrace", "UNS/TrackAndTrace")
	
	# create Inventory Validation in workcenter
#	WcConfigurationnew.creareUdtInstance(tagPath +'/'+folderName, "InventoryValidation", "UNS/InventoryValidation")
	        
	#add checweigherRawData UDT instance inside Primary_Packaging 
	WcConfigurationnew.creareUdtInstance(tagPath +'/'+ folderName + '/SF_Equipment/Checkweigher', "ChechweigherRawData", "UNS/ChechweigherRawData")
	
	#create workCenterConfiguration UDT
	WcConfigurationnew.creareUdtInstance(tagPath +'/'+folderName, "WorkCenterConfiguration", "UNS/WorkCenterConfiguration")
	
	#create Alert instance for work center
	udtInstance = {
	  "name": folderName,
	  "typeId": "UNS/Alarms",
	  "parameters": {
	    "tagPath1": {
	      "dataType": "String",
	      "value": tagProvider+"Coca-Cola/CPS/"+plant+"/"+wcType+"/"+folderName+"/Gateway_Devices/TrackAndTrace/Sts_Alert"
	    },
	    "tagPath": {
	      "dataType": "String",
	      "value": tagProvider+"Coca-Cola/CPS/"+plant+"/"+wcType+"/"+folderName+"/Gateway_Devices/PLCStatus/"+folderName+"_LinePLCCommSts"
	    }
	  },
	  "tagType": "UdtInstance"
	}

	system.tag.configure(tagProvider + "Coca-Cola/CPS/Alarms", udtInstance)
	
#	WcConfigurationnew.BBNGatewayTags('[DCPLC]', tagPath +'/'+folderName+'/Gateway_Devices', folderName)
	system.tag.configure(basePath, tagFolder, 'o')

	
	
def createAutoPhaseCompletionTag(tagPath, deviceType):
	autoPhaseCompletionTag = {
	  "alarms": [
	    {
	      "setpointA": 1.0,
	      "name": "2010AutoPhaseCompletion",
	      "priority": "Critical",
	      "ackMode": "Unused",
	      "displayPath": {
	        "bindType": "Expression",
	        "value": "concat({[.]../../../WorkCenterConfiguration/workCenterName},\"--\",{[.]../../../PO/Header/processOrder}}"
	      }
	    }
	  ],
	  "name": "2010AutoPhaseCompletionAlert",
	  "value": 0,
	  "tagType": "AtomicTag"
	}
	
	phaseCompletionTrigger = {
	  "eventScripts": [
	    {
	      "eventid": "valueChanged",
	      "script":  "\tif currentValue.value == 1 and previousValue.value == 0:\n\t\ttry:\n\t\t\tAutoPhaseCompletion =True\n\t\t\tTag_Provider = str(system.tag.readBlocking(\"[.]../../../../../../Site_Settings/General_Configuration/sfTagProvider\")[0].value)\n\t\t\tMII_Ignition_Library.Logger.Insert_Log.Insert_Error_Log(\"Auto Phase completion tag script\",\"Message 3\")\n\t\t\tAPI_Protocol = system.tag.readBlocking(\"[.]../../../../../../Site_Settings/MII_Configuration/miiApiProtocol\")[0].value\n\t\t\tAPI_Server = system.tag.readBlocking(\"[.]../../../../../../Site_Settings/MII_Configuration/miiApiServer\")[0].value\n\t\t\tSAP_Status = system.tag.readBlocking(\"[.]../../../../../../Site_Settings/MII_Configuration/sapStatus\")[0].value\n\t\t\tMII_Status = system.tag.readBlocking(\"[.]../../../../../../Site_Settings/MII_Configuration/miiStatus\")[0].value\n\t\t\tDB_Status = system.tag.readBlocking(\"[.]../../../../../../Site_Settings/dB_Configuration/ignitiondBStatus\")[0].value\n\t\t\tDatabase = str(system.tag.readBlocking(\"[.]../../../../../../Site_Settings/dB_Configuration/ignitiondB\")[0].value)\n\t\t\tMII_Ignition_Library.Logger.Insert_Log.Insert_Error_Log(\"Auto Phase completion tag script\",\"DB Status : \" + str(DB_Status))\n\t\t\tClient = str(system.tag.readBlocking(\"[.]../../../PO/2010/Phase/pClient\")[0].value)\n\t\t\tPlant = str(system.tag.readBlocking(\"[.]../../../PO/2010/Phase/pPlant\")[0].value)\n\t\t\tWork_Center = str(system.tag.readBlocking(\"[.]../../../WorkCenterConfiguration/workCenterName\")[0].value)\n\t\t\tSAP_Resource_Name = str(system.tag.readBlocking(\"[.]../../../PO/2010/Phase/pNodeName\")[0].value)\n\t\t\tPO = str(system.tag.readBlocking(\"[.]../../../PO/2010/Header/processOrder\")[0].value)\n\t\t\tOperation = str(system.tag.readBlocking(\"[.]../../../PO/2010/Phase/pOperation\")[0].value)\n\t\t\tPhase = str(system.tag.readBlocking(\"[.]../../../PO/2010/Phase/pPhase\")[0].value)\n\t\t\tcurrentPhase = str(system.tag.readBlocking(\"[.]../../../PO/2010/Phase/pMIIPHStatus\")[0].value)\n\t\t\tPhaseStatus = \"CMPL\"\n\t\t\tNext_Status = \"ACT\"\n\t\t\tSLOC = \"\"\n\t\t\tEventTime = system.date.format(system.date.now(), \"yyyy-MM-dd HH:mm:ss\").replace(\" \",\"T\")\n\t\t\tMessage_ID = \"\" \n\t\t\tUser_ID = \"Auto\"\n\t\t\tArea = str(system.tag.readBlocking(\"[.]../../../PO/2010/Phase/pArea\")[0].value)\n\t\t\tBufferCount = False\n\t\t\t\n\t\t\t\n\t\t\tif Work_Center[0:2] == 'DA' and Phase == '2010':\n\t\t\t\tvalidate2020ActForDa = poExecution.zoning.validate2020ActForDa(Database, Tag_Provider, Plant, Work_Center, BufferCount)\n\t\t\t\tif validate2020ActForDa == True:\n\t\t\t\t\t#Open confirmation Popup\n\t\t\t\t\tZoning = True\n\t\t\t\t\t\n\t\t\t\telse:\n\t\t\t\t\t#open alert popup\n\t\t\t\t\tZoning = False\n\t\t\t\n\t\t\telif Work_Center[0:2] == 'DF' and Phase == '2010':\n\t\t\t\ttagPath = \"[.]../../../PO/2010/PrePackTol/isPhantom\"\n\t\t\t\ttagRead = system.tag.readBlocking([tagPath])\n\t\t\t\tisPhantom = tagRead[0].value\n\t\t\t\tMII_Ignition_Library.Logger.Insert_Log.Insert_Error_Log(\"Auto Phase completion tag script\",\"params : \" + str(Database) + \"----\" +str(Tag_Provider)+ \"----\" +str(Plant)+ \"----\" +str(Work_Center)+ \"----\" +str(isPhantom))\n\t\t\t\tvalidate2020ActForDf = poExecution.zoning.validate2020ActForDf(Database, Tag_Provider, Plant, Work_Center, isPhantom, BufferCount)\n\t\t\t\tMII_Ignition_Library.Logger.Insert_Log.Insert_Error_Log(\"Auto Phase completion tag script\",\"validate2010ActForDf : \" + str(validate2020ActForDf))\n\t\t\t\tif validate2020ActForDf == True:\n\t\t\t\t\t#Open confirmation Popup\n\t\t\t\t\tZoning = True\n\t\t\t\t\t\n\t\t\t\telse:\n\t\t\t\t\t#open alert popup\n\t\t\t\t\tZoning = False\n\t\t\t\n\t\t\telse:\n\t\t\t\tZoning = True\n\t\t\t\n\t\n\t\t\t#MII_Ignition_Library.Logger.Insert_Log.Insert_Error_Log(\"Auto Phase completion tag script\",PhaseStatus + \" \" + Phase)\n\t\t\tMII_Ignition_Library.Logger.Insert_Log.Insert_Error_Log(\"Auto Phase completion tag script\",\"zoning : \" + str(Zoning))\n\t\t\tif Phase == '2010' and (currentPhase == 'ACT' or currentPhase == 'RESUME') and Zoning == True:\n\t\t\t\tMII_Ignition_Library.Logger.Insert_Log.Insert_Error_Log(\"Auto Phase completion tag script\",\"zoning2 : \" + str(Zoning))\n\t\t\t\tMII_Ignition_Library.Logger.Insert_Log.Insert_Error_Log(\"Auto Phase completion tag script\",\"phase1 : \" + str(Phase))\n\t\t\t\tMII_Ignition_Library.Logger.Insert_Log.Insert_Error_Log(\"Auto Phase completion tag script\",\"phase2 : \" + str(currentPhase))\n\t\t\t\tpoExecution.AutoCompletion2010.autoCompletion(AutoPhaseCompletion, API_Protocol, API_Server, SAP_Status, MII_Status, DB_Status, Database, Client, Plant, Work_Center, SAP_Resource_Name, PO, Operation, Phase, PhaseStatus, Next_Status, SLOC, EventTime, Message_ID, User_ID, Area)\n\t\t\t\tMII_Ignition_Library.Logger.Insert_Log.Insert_Error_Log(\"Auto Phase completion tag script\",\"zoning3 : \" + str(Zoning))\n\t\t\t\t#system.tag.writeBlocking(\"[.]../../../PO/Phase/pMIIPHStatus\", Next_Status)\n\t\t\telse:\n\t\t\t\tMII_Ignition_Library.Logger.Insert_Log.Insert_Error_Log(\"Auto Phase completion tag script\",\"Not correct Phase or Phase status\")\n\t\texcept:\n\t\t\tMII_Ignition_Library.Logger.Insert_Log.Insert_Error_Log(\"Auto Phase completion tag script\",str(sys.exc_info()))"
    
	    }
	  ],
	  "valueSource": "expr",
	  "expression": "{[.]CheckWeigher_"+deviceType+"_1/firstGoodFillSts}||{[.]CheckWeigher_"+deviceType+"_2/firstGoodFillSts}",
	  "name": "2010CompletionTrigger",
	  "tagType": "AtomicTag"
	}
	
	system.tag.configure(tagPath, autoPhaseCompletionTag)
	system.tag.configure(tagPath, phaseCompletionTrigger)
	

def createDensityTriggerTag(tagPath,wc):
	densityTriggerTag = {
	  "valueSource": "reference",
	  "eventScripts": [
	    {
	      "eventid": "valueChanged",
	      "script": "\timport math\n\tlogger = system.util.getLogger(\"Quality\")\t\n\ttry:\n\t\tlogger.info(\"script started\")\n\t\tdatabase = system.tag.readBlocking(\"[.]../../../../../Site_Settings/dB_Configuration/ignitiondB\")[0].value\n\t\tpo = system.tag.readBlocking(\"[.]../../PO/Header/processOrder\")[0].value\n\t\ttagProvider = system.tag.readBlocking(\"[.]../../../../../Site_Settings/General_Configuration/sfTagProvider\")[0].value\n\t\tresource = system.tag.readBlocking(\"[.]../../WorkCenterConfiguration/workCenterName\")[0].value\n\t\ttotalCount = currentValue.value\n\t\tpoTargetQuantity = system.tag.readBlocking(\"[.]../../PO/Header/requiredQuantity\")[0].value\n\t\t\n\t\tuom = \"N/A\"\n\t\tparameter1 = system.tag.readBlocking(\"[.]../../WorkCenterConfiguration/inlineDensityParameter1\")[0].value\n\t\tparameter2 = system.tag.readBlocking(\"[.]../../WorkCenterConfiguration/inlineDensityParameter2\")[0].value\n\t\tlogger.info(\"message 1\")\n\t\t\n\t\tif poTargetQuantity == 1:\n\t\t\tsampleType = 1\n\t\t\t#Function will run to insert single result\n\t\t\tpoExecution.InlineDensityMeter.getDensitySamples(database, po, sampleType, resource, tagProvider, uom)\n\t\telif 2 <= poTargetQuantity <= 20:\n\t\t\tlogger.info(\"message 2\")\n\t\t\t#Parameters to calculate sample by PO size < 20\n\t\t\tparam1percentual = parameter1\n\t\t\tsampleSize1 = poTargetQuantity / 2\n\t\t\tsizePercentual = round((float(poTargetQuantity * param1percentual) / 100),1)\n\t\t\troundUp = int(math.ceil(poTargetQuantity - sizePercentual))\n\t\t\tlogger.info(\"message 3\")\n\t\t\tif roundUp <= sampleSize1:\n\t\t\t\tsampleSize2 = roundUp + 1\n\t\t\telse:\n\t\t\t\tsampleSize2 = roundUp\n\t\t\t\t\n\t\t\tif totalCount == sampleSize1:\n\t\t\t\tsampleType = 1\n\t\t\t\t#Function will run to insert single result\n\t\t\t\tpoExecution.InlineDensityMeter.getDensitySamples(database, po, sampleType, resource, tagProvider, uom)\n\t\t\telif totalCount == sampleSize2:\n\t\t\t\tsampleType = 2\n\t\t\t\t#Function will run to insert single result\n\t\t\t\tpoExecution.InlineDensityMeter.getDensitySamples(database, po, sampleType, resource, tagProvider, uom)\n\t\telif poTargetQuantity > 20:\n\t\t\t#Parameters to calculate sample by PO size > 20\n\t\t\tparam2percentual = parameter2\n\t\t\tsampleSize1 = poTargetQuantity / 3\n\t\t\tsampleSize2 = 2 * poTargetQuantity / 3\n\t\t\tsizePercentual = round((float(poTargetQuantity * param2percentual) / 100),1)\n\t\t\troundUp = int(math.ceil(poTargetQuantity - sizePercentual))\n\t\t\tif roundUp <= sampleSize2:\n\t\t\t\tsampleSize3 = roundUp + 1\n\t\t\telse:\n\t\t\t\tsampleSize3 = roundUp\n\t\t\t\t\n\t\t\tif totalCount == int(sampleSize1):\n\t\t\t\tsampleType = 1\n\t\t\t\t#Function will run to insert single result\n\t\t\t\tpoExecution.InlineDensityMeter.getDensitySamples(database, po, sampleType, resource, tagProvider, uom)\n\t\t\telif totalCount == int(sampleSize2):\n\t\t\t\tsampleType = 2\n\t\t\t\t#Function will run to insert single result\n\t\t\t\tpoExecution.InlineDensityMeter.getDensitySamples(database, po, sampleType, resource, tagProvider, uom)\n\t\t\telif totalCount == sampleSize3:\n\t\t\t\tsampleType = 3\n\t\t\t\t#Function will run to insert single result\n\t\t\t\tpoExecution.InlineDensityMeter.getDensitySamples(database, po, sampleType, resource, tagProvider, uom)\n\texcept:\n\t\tlogger.error(\"Quality Tag change - \" +  str(sys.exc_info()))\t"
	    }
	  ],
	  "expression": "{[{[.]../../../"+wc+"/SF_Equipment/Checkweigher/Primary_Packaging/CheckWeigher_PP_1/totalCount}",
	  "dataType": "Int4",
	  "sourceTagPath": "[.]../Checkweigher/Primary_Packaging/CheckWeigher_PP_1/totalCount",
	  "name": "FinishedGoodTotalCount",
	  "value": 0,
	  "tagType": "AtomicTag"
	}
	
	system.tag.configure(tagPath, densityTriggerTag)
	

def addWorkCenterTags(tagProvider, plant, workCenterType, workCenter, devices):
	basePath = tagProvider + 'Coca-Cola/CPS/' + plant + '/'  + workCenterType
	#creating workcenter folder
	tagFolder = {'tagtype' : 'Folder',
					'name' : workCenter,
				}
	system.tag.configure(basePath, tagFolder, 'o')
	


#	creating udt instance as per devices
	tagPath = basePath + '/' + workCenter
	tags = []
	for device in devices:
		tag = {	"name" : device["deviceName"],
				"typeId" : "UNS/" + device["deviceType"],
				"tagType" : "UdtInstance",
				}
		tags.append(tag)
	print tags
	system.tag.configure(tagPath, tags)
	
	
	#adding values to udt tags of devices
	nameTagPath = []
	nameTagValue = []
	for device in dvices:
		nameTagPathList = tagPath + '/' + device["deviceName"] + '/' + 'Name'
		nameTagValueList = device["deviceName"]
		nameTagPath.append(nameTagPathList)
		nameTagValue.append(nameTagValueList)
	
	system.tag.writeBlocking(nameTagPath, nameTagValue)
	
	
	
def addWorkCenterUdts(tagProvider, workCenter, configurations):
	
	basePath = tagProvider + '_types_/'
	
	#creating workcenter UDTs
	tagFolder =	{'tagtype' : 'UdtType',
				 'name' : workCenter,
	}
	system.tag.configure(basePath, tagFolder, 'o')
	
	
	#creating udt instance as per workcenter
	tagPath = basePath + '/' + workCenter
	tags = []
	for configuration in configurations:
		tag = {
				"valueSource": "memory",
				"dataType": "String",
				"name": configuration,
				"tagType": "AtomicTag",
				"value": "null"
		}
		tags.append(tag)
	print tags
	system.tag.configure(tagPath, tags)
	
def addDeviceTags(tagPath ,deviceName,deviceType):
	tags = []	
	tag = {	"name" : deviceName,
				"typeId" : "UNS/" + deviceType,
				"tagType" : "UdtInstance",
				}
	tags.append(tag)

	print system.tag.configure(tagPath, tags,"o")
	
def deleteDevices(basePath, plant,workCenterType,workCenter,updatedDevices):
	devicepath  = basePath +'/'+ plant +'/'+ workCenterType +'/' + workCenter
	system.perspective.print(devicepath)
	equimentName ='SF_Equipment'
	system.perspective.print("len(devices)"+ str(len(updatedDevices)))
	
	params = {"workCenter":workCenter}
	wcId = system.db.runNamedQuery('WcConfigurationnew/getWorkCenterID', params)
	for i in range(0,len(updatedDevices)):
		if len(updatedDevices)!= 0:
			deviceType = updatedDevices[i]['deviceType']
			deviceName = updatedDevices[i]['deviceName']
			isDeleted = updatedDevices[i]['isDeleted']
			system.perspective.print(deviceType)
			### ADD Tags for Checkweigher  
			if deviceType=='CheckWeigher':
				
				if 'PP' in deviceName:			 	
				 	print deviceName	 	
				 	primarycwtagpath = devicepath +'/'+ equimentName +'/'+ deviceType + '/Primary_Packaging/' 			 		
				 	primaryCWexist = system.tag.exists(devicepath +'/'+ equimentName +'/'+ deviceType + '/Primary_Packaging/' + deviceName)
				 	
				 	#print primaryCWexist
				 	if primaryCWexist == True:
				 		if isDeleted == 1:
				 			dv_params = {"IsDeleted": 1, "wc":workCenter,"deviceName":deviceName}
							system.db.runNamedQuery("WcConfigurationnew/deleteDevices", dv_params)
							params = {"deviceName":deviceName, "wcId":wcId}
							deviceExistInScale = system.db.runNamedQuery("WcConfigurationnew/deviceExist", params)
							if deviceExistInScale != None or deviceExistInScale != '':
								params = {'workCenter':'', 'deviceId':'', 'scaleId':deviceExistInScale}
								system.db.runNamedQuery('MovableScaleAssignment/updateScale', params )
					 		system.tag.deleteTags([devicepath +'/'+ equimentName +'/'+ deviceType + '/Primary_Packaging/' + deviceName])
					 		system.tag.deleteTags([devicepath + '/Gateway_Devices/SpcWeight/'+deviceName])
					 		system.tag.deleteTags([devicepath + '/Gateway_Devices/'+ deviceType +'/'+ deviceName])
				 			system.perspective.print('okay')
				 		
				 	else:
						continue

				elif 'SP' in deviceName:			 	
				 	print deviceName						 	
				 	secondarycwtagpath = devicepath +'/'+ equimentName +'/'+ deviceType + '/Secondary_Packaging/' 
				 	secondaryCWexist = system.tag.exists(devicepath +'/'+ equimentName +'/'+ deviceType + '/Secondary_Packaging/' + deviceName)
				 	
				 	if secondaryCWexist == True:
				 		if isDeleted == 1:
			 				dv_params = {"IsDeleted": 1, "wc":workCenter,"deviceName":deviceName}
							system.db.runNamedQuery("WcConfigurationnew/deleteDevices", dv_params)
							params = {"deviceName":deviceName, "wcId":wcId}
							deviceExistInScale = system.db.runNamedQuery("WcConfigurationnew/deviceExist", params)
							if deviceExistInScale != None or deviceExistInScale != '':
								params = {'workCenter':'', 'deviceId':'', 'scaleId':deviceExistInScale}
								system.db.runNamedQuery('MovableScaleAssignment/updateScale', params )
				 			system.tag.deleteTags([devicepath +'/'+ equimentName +'/'+ deviceType + '/Secondary_Packaging/' + deviceName])
				 			system.tag.deleteTags([devicepath + '/Gateway_Devices/SpcWeight/'+deviceName])
				 			system.tag.deleteTags([devicepath + '/Gateway_Devices/' + deviceType +'/'+ deviceName])
				 		
				 	else:
						continue
			elif deviceType=='FillerHead':
				 	deviceTagpath =  devicepath +'/'+ equimentName +'/Filler'
				 	deviceTagExist = system.tag.exists(devicepath +'/'+ equimentName +'/Filler/' + deviceName)
				 	
				 	if deviceTagExist == True:
				 		if isDeleted == 1:
			 				dv_params = {"IsDeleted": 1, "wc":workCenter,"deviceName":deviceName}
							system.db.runNamedQuery("WcConfigurationnew/deleteDevices", dv_params)
							params = {"deviceName":deviceName, "wcId":wcId}
							deviceExistInScale = system.db.runNamedQuery("WcConfigurationnew/deviceExist", params)
							if deviceExistInScale != None or deviceExistInScale != '':
								params = {'workCenter':'', 'deviceId':'', 'scaleId':deviceExistInScale}
								system.db.runNamedQuery('MovableScaleAssignment/updateScale', params )
				 			system.tag.deleteTags([devicepath +'/'+ equimentName +'/Filler/' + deviceName])
				 			system.tag.deleteTags([devicepath + '/Gateway_Devices/SpcWeight/'+ deviceName])
				 			system.tag.deleteTags([devicepath + '/Gateway_Devices/' + deviceType +'/'+ deviceName])
				 		
				 	else:
						continue

			else :
			  	devicetagPath = devicepath +'/'+ equimentName +'/'+ deviceType
			  	system.perspective.print(devicetagPath)
			  	
			  	tagPathexist = system.tag.exists(devicepath +'/'+ equimentName +'/'+ deviceType +'/' + deviceName)		  	
			  	system.perspective.print("tagPathexist" +str(tagPathexist))
			  	
			  	
			  	if tagPathexist == True:
			  		if isDeleted == 1:
			  			system.perspective.print("isDelete 1")
			  			dv_params = {"IsDeleted": 1, "wc":workCenter,"deviceName":deviceName}
						system.db.runNamedQuery("WcConfigurationnew/deleteDevices", dv_params)
						system.perspective.print("delete NQ RUn")
						system.tag.deleteTags([devicepath +'/'+ equimentName +'/'+ deviceType +'/' + deviceName])
						system.tag.deleteTags([devicepath + '/Gateway_Devices/SpcWeight/'+deviceName])
						system.tag.deleteTags([devicepath + '/Gateway_Devices/' + deviceType +'/'+ deviceName])
						system.perspective.print("deleted")
			  		
			  	else:
			  		continue


def addWcConfigutationInTags(tagProvider, plant, workCenterType, workCenter, functions, wcDes):
	basePath = tagProvider + 'Coca-Cola/CPS/' + plant + '/'  + workCenterType
	tagPath = basePath + '/' + workCenter
	tags = []
	tag = {	"name" : 'WorkCenterConfiguration',
			"typeId" : 'UNS/WorkCenterConfiguration',
			"tagType" : "UdtInstance",
			}
	tags.append(tag)
	system.tag.configure(tagPath, tags)
	for function in functions:
		if function['label'] == 'Enable Auto GI':
			enableAutoGI = function['value']
		elif function['label']=='Partial Auto GI Frequency':
			partialAutoGIfrequency = function['value']
		elif function['label'] == 'Enable Auto PR':
			enableAutoPR = function['value']
		elif function['label'] == 'Enable Scrap Reason':
			enableScrapReason = function['value']
		elif function['label'] == 'Enable BBD':
			enableBBD = function['value']
		elif function['label']=='Enable BBD Validation':
			enableBBDValidation = function['value']
		elif function['label'] == 'Enable Partial Split':
			enableFullSplit = function['value']
		elif function['label'] == 'Enable Full Split':
			enablePartialSplit = function['value']
		elif function['label']=='Enable Movable Scales':
			enableMovableScales = function['value']
		elif function['label']=='Enable Manual Filling':
			enableManualFilling = function['value']
		elif function['label']=='Enable Inline Density Sample Collection':
			enableAutoSamplingForQuality = function['value']
		elif function['label']=='Inline Density Sample Collection Frequency':
			densitySampleFrequency = function['value']
		elif function['label']=='Inline Density Parameter 1 (0-50%)':
			inlineDensityParameter1 = function['value']
		elif function['label']=='Inline Density Parameter 2 (0-33%)':
			inlineDensityParameter2 = function['value']
		elif function['label']=='Enable Dosing Type':
			enableDosingType = function['value']
		elif function['label']=='Production Percentage':
			productionPercentage = function['value']
		elif function['label']=='Enable GLS Print':
			enableGLSPrint = function['value']
		elif function['label']=='Enable Material Validation':
			enableMaterialValidation = function['value']
		elif function['label']=='Enable Bag Inserter Phantom Material':
			enableBagInserterPhantomMaterial = function['value']
		elif function['label']=='Enable Hold and Abort Control':
			enableHoldAbortCtrl = function['value']
		elif function['label']=='Enable PO Download Control':
			enablePODownloadctrl = function['value']
		elif function['label']=='Enable 2020 CMPL Button Visibility':
			enable2020CMPL = function['value']
		elif function['label']=='Max PO in the Queue':
			maxPOqueue = function['value']
		elif function['label']=='Max PO in 2020':
			maxPOin2020 = function['value']
		elif function['label']=='Max PO in 2030':
			maxPOin2030 = function['value']
		elif function['label']=='No of Zones':
			noofzones = function['value']
		elif function['label']=='Completion Zone for Non Phantom PO':
			completionzone = function['value']	
		elif function['label']=='Completion Zone for Phantom PO':
			completionzonePhantom = function['value']		
		elif function['label']=='Enable 2010':
			enable2010 = function['value']
		elif function['label']=='Enable 2030':
			enable2030 = function['value']	
			
	basePath = tagProvider+'Coca-Cola/CPS/'+plant+'/'+workCenterType+'/'+workCenter+'/WorkCenterConfiguration/'
	path = basePath + 'enableAutoGI'
	path1 = basePath + 'partialAutoGIfrequency'
	path2 = basePath + 'enableAutoPR'
	path3 = basePath + 'enableScrapReason'
	path4 = basePath + 'enableBBD'
	path5 = basePath + 'enableBBDValidation'
	path6 = basePath + 'enablePartialSplit'
	path7 = basePath + 'enableFullSplit'
	path8 = basePath + 'workCenterName'
	path9 = basePath + 'Parameters.TagProvider'
	path10 = basePath + 'areaDescription'
	path11 = basePath + 'enableMovableScales'
	path12 = basePath + 'enableManualFilling'
	path13 = basePath + 'enableAutoSamplingForQuality'
	path14 = basePath + 'densitySampleFrequency'
	path15 = basePath + 'inlineDensityParameter1'
	path16 = basePath + 'inlineDensityParameter2'
	path17 = basePath + 'enableDosingType'
	path18 = basePath + 'productionPercentage'
	path20 = basePath + 'enableGLSPrint'
	path21 = basePath + 'enableMaterialValidation'
	path22 = basePath + 'enableBagInserterPhantomMaterial'
	path23 = basePath + 'enableHoldAbortCtrl'
	path24 = basePath + 'enablePODownloadCtrl'
	path25 = basePath + 'enable2020CMPL'
	path26 = basePath + 'maxPOqueue'
	path27 = basePath + 'maxPOin2020'
	path28 = basePath + 'maxPOin2030'
	path29 = basePath + 'noofzones'
	path30 = basePath + 'completionzone'
	path31 = basePath + 'completionzonePhantom'
	path32 = basePath + 'enable2010'
	path33 = basePath + 'enable2030'
#	path34 = basepath + ''
	nameTagPath = [path,path1,path2,path3,path4,path5,path6,path7,path8,path9,path10,path11,path12,path13,path14,path15,path16,path17,path18,path20,path21,path22,path23,path24,path25,path26,path27,path28,path29,path30,path31,path32,path33]
	nameTagValue = [enableAutoGI,partialAutoGIfrequency,enableAutoPR,enableScrapReason,enableBBD,enableBBDValidation,enablePartialSplit,enableFullSplit,workCenter,tagProvider,wcDes,enableMovableScales,enableManualFilling,enableAutoSamplingForQuality,densitySampleFrequency,inlineDensityParameter1,inlineDensityParameter2,enableDosingType,productionPercentage,enableGLSPrint,enableMaterialValidation,enableBagInserterPhantomMaterial,enableHoldAbortCtrl,enablePODownloadctrl,enable2020CMPL,maxPOqueue,maxPOin2020,maxPOin2030,noofzones,completionzone,completionzonePhantom,enable2010,enable2030]
	system.tag.writeBlocking(nameTagPath, nameTagValue)

	
	
	
def updateDbDevices(database, workCenter, capacityMin,capacityMax, resolution,  uomId, deviceName, deviceDesc, bufferMidLim, bufferHighLim, bufferCriticalLim):
	namedQuery = 'WcConfigurationnew/updateDbDevices'
	params = {'database':database, 'wc':workCenter, 'capacityMin':capacityMin, 'capacityMax':capacityMax, 'resolution':resolution,'uomId':uomId, 'deviceName':deviceName,
	'deviceDesc' :deviceDesc, 'bufferMidLim' :bufferMidLim, 'bufferHighLim' :bufferHighLim, 'bufferCriticalLim' :bufferCriticalLim}
	system.db.runNamedQuery(namedQuery, params)
	

def insertWorkCenter(database, workCenter, wcType, description, area):
	params = {"database": database, "workCenter": workCenter, "wcType": wcType, "description": description, "area":area,"isConfig":1}
	system.db.runNamedQuery('WcConfigurationnew/insertWc', params)
	
def workCenterExist(database, workCenter):
	params = {"database": database, "workCenter": workCenter}
	system.db.runNamedQuery('WcConfigurationnew/wcExist', params)
	
	
def updateMultipleDbDevices(database, workCenter,devicepath, updatedDevices):
	for i in range(0,len(updatedDevices)):
		if len(updatedDevices)!= 0:
			deviceType = updatedDevices[i]['deviceType']
			deviceName = updatedDevices[i]['deviceName']
			capacityMin = updatedDevices[i]['min']
			capacityMax = updatedDevices[i]['max']
			resolution = updatedDevices[i]['resolution']
			uomId = updatedDevices[i]['deviceCapacityUnit']
			priOrSec = updatedDevices[i]['priOrSec']
			fixOrManual = updatedDevices[i]['fixedOrManual']
			usbOrGateway = updatedDevices[i]['usbOrGateway']
			deviceDesc = updatedDevices[i]['deviceDesc']
			bufferMidLim = updatedDevices[i]['bufferMidLim']
			bufferHighLim = updatedDevices[i]['bufferHighLim']
			bufferCriticalLim = updatedDevices[i]['bufferCriticalLim']
	
			namedQuery = 'WcConfigurationnew/updateDbDevices'
			params = {'database':database, 'wc':workCenter, 'capacityMin':capacityMin, 'capacityMax':capacityMax, 'resolution':resolution,'uomId':uomId, 
			'deviceName':deviceName, 'deviceDesc':deviceDesc, 'bufferMidLim':bufferMidLim, 'bufferHighLim':bufferHighLim, 'bufferCriticalLim':bufferCriticalLim}
			print params
			system.db.runNamedQuery(namedQuery, params)
			equimentName = 'SF_Equipment'

			if deviceType=='CheckWeigher':
				if 'PP' in deviceName:			 		 	
				 	basePath = devicepath +'/'+ equimentName +'/'+ deviceType + '/Primary_Packaging/'
				 	WcConfigurationnew.writeDeviceBufferTags(basePath + '/' + deviceName, bufferMidLim, bufferHighLim, bufferCriticalLim)
				
				elif 'SP' in deviceName:
					basePat1h = devicepath +'/'+ equimentName +'/'+ deviceType + '/Secondary_Packaging/'
			 		WcConfigurationnew.writeDeviceBufferTags(basePath + '/' + deviceName, bufferMidLim, bufferHighLim, bufferCriticalLim)
			 		
			elif deviceType=='FillerHead':
				basePath = devicepath +'/'+ equimentName +'/Filler/' + deviceName
				WcConfigurationnew.writeDeviceBufferTags(basePath , bufferMidLim, bufferHighLim, bufferCriticalLim)
			else:
				basePath = devicepath +'/'+ equimentName +'/'+ deviceType+'/' + deviceName
				WcConfigurationnew.writeDeviceBufferTags(basePath , bufferMidLim, bufferHighLim, bufferCriticalLim)
			
			
def createSiteSettingFolder(basePath, folderName):
	#create wc type/ plant folder (basePath, wctype)
	#creating workcenter folder
	tagFolder ={
  "name": "Site_Settings",
  "tagType": "Folder",
  "tags": [
    {
      "name": "MII_Configuration",
      "tagType": "Folder",
      "tags": [
        {
          "valueSource": "memory",
          "dataType": "String",
          "name": "miiApiProtocol",
          "value": "",
          "tagType": "AtomicTag"
        },
        {
          "valueSource": "memory",
          "dataType": "String",
          "name": "miiApiServer",
          "value": "",
          "tagType": "AtomicTag"
        },
        {
          "valueSource": "memory",
          "dataType": "Int4",
          "name": "sapStatus",
          "value": "",
          "tagType": "AtomicTag"
        },
        {
          "valueSource": "memory",
          "dataType": "Int4",
          "name": "miiStatus",
          "value": "",
          "tagType": "AtomicTag"
        },
        {
          "valueSource": "memory",
          "dataType": "String",
          "name": "miiTime",
          "tagType": "AtomicTag"
        }
      ]
    },
    {
      "name": "GLS_Configuration",
      "tagType": "Folder",
      "tags": [
        {
          "valueSource": "memory",
          "dataType": "String",
          "name": "glsApiProtocol",
          "value": "",
          "tagType": "AtomicTag"
        },
        {
          "valueSource": "memory",
          "dataType": "String",
          "name": "glsApiServer",
          "value": "",
          "tagType": "AtomicTag"
        },
        {
          "valueSource": "memory",
          "dataType": "Int4",
          "name": "glsStatus",
          "value": "",
          "tagType": "AtomicTag"
        },
        {
          "valueSource": "memory",
          "dataType": "String",
          "name": "glsTime",
          "tagType": "AtomicTag"
        }
      ]
    },
    {
      "name": "Plant_Configuration",
      "tagType": "Folder",
      "tags": [
        {
          "valueSource": "memory",
          "dataType": "String",
          "name": "client",
          "value": "",
          "tagType": "AtomicTag"
        },
        {
          "valueSource": "memory",
          "dataType": "String",
          "name": "cpsLocation",
          "value": "",
          "tagType": "AtomicTag"
        },
        {
          "valueSource": "memory",
          "dataType": "String",
          "name": "plantName",
          "value": "",
          "tagType": "AtomicTag"
        },
        {
          "valueSource": "memory",
          "dataType": "String",
          "name": "plant",
          "value": "",
          "tagType": "AtomicTag"
        }
      ]
    },
    {
      "name": "General_Configuration",
      "tagType": "Folder",
      "tags": [
        {
          "valueSource": "memory",
          "dataType": "String",
          "name": "sfTagProviderRemote03",
          "tagType": "AtomicTag"
        },
        {
          "valueSource": "memory",
          "name": "defaultDaysForPoData",
          "value": "",
          "tagType": "AtomicTag"
        },
        {
          "valueSource": "memory",
          "dataType": "String",
          "name": "sfTagProvider",
          "value": "",
          "tagType": "AtomicTag"
        },
        {
          "valueSource": "memory",
          "dataType": "String",
          "name": "sfTagProviderRemote01",
          "tagType": "AtomicTag"
        },
        {
          "valueSource": "memory",
          "dataType": "String",
          "name": "sfTagProviderRemote02",
          "tagType": "AtomicTag"
        },
        {
          "valueSource": "memory",
          "name": "bbdBackDateDays",
          "value": "",
          "tagType": "AtomicTag"
        },
        {
          "valueSource": "memory",
          "name": "apiTimeoutDuration",
          "value": "",
          "tagType": "AtomicTag"
        }
      ]
    },
    {
      "name": "dB_Configuration",
      "tagType": "Folder",
      "tags": [
        {
          "valueSource": "memory",
          "dataType": "String",
          "name": "ignitiondB",
          "value": "",
          "tagType": "AtomicTag"
        },
        {
          "valueSource": "memory",
          "dataType": "Int4",
          "name": "ignitiondBStatus",
          "value": "",
          "tagType": "AtomicTag"
        }
      ]
    },
    {
      "name": "CIP_Configuration",
      "tagType": "Folder",
      "tags": [
        {
          "valueSource": "memory",
          "dataType": "String",
          "name": "cipApiProtocol",
          "tagType": "AtomicTag"
        },
        {
          "valueSource": "memory",
          "dataType": "String",
          "name": "cipApiServer",
          "tagType": "AtomicTag"
        }
      ]
    }
  ]
}
	system.tag.configure(basePath, tagFolder, 'o')
	
	
	
def createSPCWeightDeviceTag(basePath, parentUDT, instanceName, workCenter):
	opcSer = system.opc.getServers(includeDisabled = True)[0]

	udtInstance = {	"name" : instanceName,
		"typeId" : parentUDT,
		  "parameters": {
		    "wcName": {
		      "dataType": "String",
		      "value": workCenter
		    }
		  },
		"tagType" : "UdtInstance",
		}

	system.tag.configure(basePath, udtInstance)
	
	
def createGatewayDeviceInstance(basePath, instanceName, deviceType, workCenter):
	
	udtInstance = {
	  "name": instanceName,
	  "typeId": "UNS/Gateway" + deviceType,
	  "parameters": {
	    "wcName": {
	      "dataType": "String",
	      "value": workCenter
	    }
	  },
	  "tagType": "UdtInstance",
	}
	
	system.tag.configure(basePath, udtInstance, 'o')
	
	
def writeDeviceBufferTags(tagPath, bufferMidLim, bufferHighLim, bufferCriticalLim):
	system.tag.writeBlocking(tagPath + '/BufferWarnLim' , bufferMidLim)
	system.tag.writeBlocking(tagPath + '/BufferAlarmLim' , bufferHighLim)
	system.tag.writeBlocking(tagPath + '/BufferLineStopLim' , bufferCriticalLim)

 
def paths(name):
 	folder={
 	"name": name,
   	"tagType": "Folder",
 	"tags": [
     {
       "sTagPath": "Header",
       "name": "Header",
       "tagType": "Folder",
       "tags": [
         {
           "valueSource": "memory",
           "dataType": "String",
           "documentation": "PP_ORDER_TYPE",
           "name": "ppOrderType",
           "tagType": "AtomicTag"
         },
         {
           "valueSource": "memory",
           "dataType": "Float4",
           "documentation": "DURATION",
           "name": "duration",
           "tagType": "AtomicTag"
         },
         {
           "valueSource": "memory",
           "dataType": "String",
           "documentation": "GLTRS",
           "name": "scheduledEndDate",
           "tagType": "AtomicTag"
         },
         {
           "valueSource": "memory",
           "dataType": "String",
           "documentation": "DURATION_UOM",
           "name": "durationUom",
           "tagType": "AtomicTag"
         },
         {
           "valueSource": "memory",
           "dataType": "String",
           "documentation": "MII_PO_STATUS",
           "name": "miiPoStatus",
           "tagType": "AtomicTag"
         },
         {
           "valueSource": "memory",
           "dataType": "String",
           "documentation": "INSPLOT",
           "name": "inspectionLot",
           "tagType": "AtomicTag"
         },
         {
           "valueSource": "memory",
           "dataType": "String",
           "documentation": "Batch management requirement indicator",
           "name": "batchMgmtReqInd",
           "tagType": "AtomicTag"
         },
         {
           "valueSource": "memory",
           "dataType": "String",
           "documentation": "GSUZS",
           "name": "scheduledStartTime",
           "formatString": "#,##0.##",
           "tagType": "AtomicTag"
         },
         {
           "valueSource": "memory",
           "dataType": "String",
           "documentation": "WERKS",
           "name": "plant",
           "tagGroup": "Default",
           "tagType": "AtomicTag"
         },
         {
           "valueSource": "memory",
           "dataType": "String",
           "documentation": "BMEINS",
           "name": "requiredQuantityUom",
           "tagType": "AtomicTag"
         },
         {
           "valueSource": "memory",
           "dataType": "String",
           "documentation": "GSTRS",
           "name": "scheduledStartDate",
           "formatString": "#,##0.##",
           "tagType": "AtomicTag"
         },
         {
           "valueSource": "memory",
           "dataType": "String",
           "documentation": "SPRAS",
           "name": "languageKey",
           "tagType": "AtomicTag"
         },
         {
           "valueSource": "memory",
           "dataType": "String",
           "documentation": "GLUZS",
           "name": "scheduledEndTime",
           "formatString": "#,##0.##",
           "tagType": "AtomicTag"
         },
         {
           "valueSource": "memory",
           "dataType": "String",
           "documentation": "MTART",
           "name": "materialType",
           "tagType": "AtomicTag"
         },
         {
           "valueSource": "memory",
           "dataType": "String",
           "documentation": "MAKTX",
           "name": "materialDescription",
           "tagType": "AtomicTag"
         },
         {
           "valueSource": "memory",
           "dataType": "String",
           "documentation": "MSGFN is the \"Message Function\". It\u0027s a code that defines the action to be performed with (or by) the IDoc itself. Supported codes are:\n\n003  Delete: Message contains objects to be deleted004  Change: Message contains changes005  Replace: This message replaces previous messages009  Original: First message for process023  Wait/Adjust: Data should not be imported018  Resend\n\n003  Delete: Message contains objects to be deleted\n\n004  Change: Message contains changes\n\n005  Replace: This message replaces previous messages\n\n009  Original: First message for process\n\n023  Wait/Adjust: Data should not be imported\n\n018  Resend",
           "name": "msgFunctionCode",
           "tagType": "AtomicTag"
         },
         {
           "valueSource": "memory",
           "dataType": "String",
           "documentation": "ORDERLGORT",
           "name": "storageLocation",
           "tagType": "AtomicTag"
         },
         {
           "valueSource": "memory",
           "dataType": "String",
           "documentation": "Bussiness Logic Status",
           "name": "blsStatus",
           "tagType": "AtomicTag"
         },
         {
           "valueSource": "memory",
           "dataType": "String",
           "documentation": "PLNAL",
           "name": "groupCounter",
           "tagType": "AtomicTag"
         },
         {
           "valueSource": "memory",
           "dataType": "String",
           "documentation": "CLIENT",
           "name": "client",
           "tagGroup": "Default",
           "tagType": "AtomicTag"
         },
         {
           "sourceTagPath": {
             "bindType": "parameter",
             "binding": "{TagReferencePath}HMI_SetStsPhase"
           },
           "valueSource": "memory",
           "dataType": "String",
           "documentation": "S4_MII_STATUS",
           "name": "s4MIIStatus",
           "tagType": "AtomicTag"
         },
         {
           "sourceTagPath": {
             "bindType": "parameter",
             "binding": "{2010TagReferencePath}Set_BatchNo"
           },
           "valueSource": "reference",
           "dataType": "String",
           "documentation": "ORDERCHARG",
           "name": "batchNumber",
           "tagGroup": "Default",
           "tagType": "AtomicTag"
         },
         {
           "valueSource": "memory",
           "dataType": "String",
           "documentation": "SPRAS_ISO",
           "name": "sapLanguageKey",
           "tagType": "AtomicTag"
         },
         {
           "valueSource": "memory",
           "dataType": "Float4",
           "documentation": "Secondary Packaging Target",
           "name": "spTarget",
           "tagType": "AtomicTag"
         },
         {
           "valueSource": "memory",
           "dataType": "String",
           "documentation": "PP_MATERIAL_GROUP",
           "name": "ppMaterialGroup",
           "tagGroup": "Default",
           "tagType": "AtomicTag"
         },
         {
           "valueSource": "memory",
           "dataType": "String",
           "documentation": "PLNTY",
           "name": "taskListType",
           "tagType": "AtomicTag"
         },
         {
           "valueSource": "memory",
           "dataType": "String",
           "documentation": "AUART",
           "name": "orderType",
           "tagType": "AtomicTag"
         },
         {
           "valueSource": "memory",
           "dataType": "String",
           "documentation": "PLNME",
           "name": "taskListUom",
           "tagType": "AtomicTag"
         },
         {
           "sourceTagPath": {
             "bindType": "parameter",
             "binding": "{2010TagReferencePath}Set_TargetQty"
           },
           "valueSource": "reference",
           "dataType": "Float4",
           "documentation": "BMENGE",
           "name": "requiredQuantity",
           "tagType": "AtomicTag"
         },
         {
           "valueSource": "memory",
           "dataType": "Float4",
           "documentation": "Secondary Packaging Target Lower Limit",
           "name": "spTargetLL",
           "tagType": "AtomicTag"
         },
         {
           "valueSource": "memory",
           "dataType": "String",
           "documentation": "Bussiness Logic Message",
           "name": "blsMessage",
           "tagType": "AtomicTag"
         },
         {
           "valueSource": "memory",
           "dataType": "String",
           "documentation": "MATKL",
           "name": "materialGroup",
           "tagGroup": "Default",
           "tagType": "AtomicTag"
         },
         {
           "sourceTagPath": {
             "bindType": "parameter",
             "binding": "{2010TagReferencePath}Set_PONo"
           },
           "valueSource": "reference",
           "dataType": "String",
           "documentation": "AUFNR",
           "name": "processOrder",
           "tagGroup": "Default",
           "tagType": "AtomicTag"
         },
         {
           "valueSource": "memory",
           "dataType": "String",
           "documentation": "PLGRP",
           "name": "responsiblePlannerGroup",
           "tagType": "AtomicTag"
         },
         {
           "valueSource": "memory",
           "dataType": "String",
           "documentation": "COLLECTIVE_ORDER_LEADER",
           "name": "collectiveOrderLeader",
           "tagType": "AtomicTag"
         },
         {
           "valueSource": "memory",
           "dataType": "String",
           "documentation": "PLNNR",
           "name": "taskListGroupKey",
           "tagType": "AtomicTag"
         },
         {
           "valueSource": "memory",
           "dataType": "String",
           "documentation": "COL_ORDER",
           "name": "collectiveOrder",
           "tagType": "AtomicTag"
         },
         {
           "sourceTagPath": {
             "bindType": "parameter",
             "binding": "{2010TagReferencePath}BBD"
           },
           "valueSource": "reference",
           "dataType": "String",
           "documentation": "Best Before Date",
           "name": "BBD",
           "tagGroup": "Default",
           "tagType": "AtomicTag"
         },
         {
           "sourceTagPath": {
             "bindType": "parameter",
             "binding": "{2010TagReferencePath}Set_MatNo"
           },
           "valueSource": "reference",
           "dataType": "String",
           "documentation": "MATNR",
           "name": "materialNumber",
           "value": "",
           "tagType": "AtomicTag"
         },
         {
           "valueSource": "memory",
           "dataType": "String",
           "documentation": "Secondary Packaging Target Unit of Measure",
           "name": "spTargetUom",
           "tagType": "AtomicTag"
         },
         {
           "valueSource": "memory",
           "dataType": "String",
           "documentation": "AREA\n",
           "name": "area",
           "tagType": "AtomicTag"
         },
         {
           "valueSource": "memory",
           "dataType": "String",
           "documentation": "COLLECTIVE_ORDER_DEPENDENT",
           "name": "collectiveOrderDependent",
           "tagType": "AtomicTag"
         },
         {
           "valueSource": "memory",
           "dataType": "Float4",
           "documentation": "Secondary Packaging Target Upper Limit",
           "name": "spTargetUL",
           "tagType": "AtomicTag"
         }
       ]
     },
     {
       "name": "Phase",
       "tagType": "Folder",
       "tags": [
         {
           "valueSource": "memory",
           "dataType": "String",
           "documentation": "MATNR",
           "name": "pMaterialNumber",
           "tagType": "AtomicTag"
         },
         {
           "valueSource": "memory",
           "dataType": "String",
           "documentation": "OEE_RELEVANT",
           "name": "pOEERelevant",
           "tagType": "AtomicTag"
         },
         {
           "valueSource": "memory",
           "dataType": "String",
           "documentation": "NODE_ID",
           "name": "pNodeID",
           "tagType": "AtomicTag"
         },
         {
           "valueSource": "memory",
           "dataType": "String",
           "documentation": "RESBMATNR",
           "name": "pReservedMaterial",
           "tagType": "AtomicTag"
         },
         {
           "valueSource": "expr",
           "expression": "{[.]../Header/miiPoStatus}",
           "dataType": "String",
           "documentation": "MII_PO_STATUS",
           "sourceTagPath": "[.]../Header/miiPoStatus",
           "name": "pMIIPOStatus",
           "tagType": "AtomicTag"
         },
         {
           "valueSource": "memory",
           "dataType": "String",
           "documentation": "NODENAME",
           "name": "pNodeName",
           "tagType": "AtomicTag"
         },
         {
           "sourceTagPath": {
             "bindType": "parameter",
             "binding": "{2010TagReferencePath}Set_StsPhase"
           },
           "valueSource": "reference",
           "dataType": "String",
           "documentation": "MII_PH_STATUS",
           "name": "pMIIPHStatus",
           "tagType": "AtomicTag"
         },
         {
           "valueSource": "memory",
           "dataType": "Float4",
           "documentation": "STDVAL_DURATION",
           "name": "pStdValDuration",
           "tagType": "AtomicTag"
         },
         {
           "valueSource": "memory",
           "dataType": "String",
           "documentation": "SPRAS_ISO",
           "name": "pSAPLanguageKey",
           "tagType": "AtomicTag"
         },
         {
           "valueSource": "memory",
           "dataType": "String",
           "documentation": "PLNNR",
           "name": "pTaskListGroupKey",
           "tagType": "AtomicTag"
         },
         {
           "valueSource": "memory",
           "dataType": "String",
           "documentation": "VGE05",
           "name": "pStandardValueUom05",
           "tagType": "AtomicTag"
         },
         {
           "valueSource": "memory",
           "dataType": "String",
           "documentation": "RESB_XCHPF",
           "name": "pResbBatchMgmtReqInd",
           "tagType": "AtomicTag"
         },
         {
           "valueSource": "memory",
           "dataType": "String",
           "documentation": "PLNTY",
           "name": "pTaskListType",
           "tagType": "AtomicTag"
         },
         {
           "valueSource": "memory",
           "dataType": "String",
           "documentation": "VGW01",
           "name": "pStandardValue01",
           "tagType": "AtomicTag"
         },
         {
           "valueSource": "memory",
           "dataType": "String",
           "documentation": "PLGRP",
           "name": "pResponsiblePlannerGroup",
           "tagType": "AtomicTag"
         },
         {
           "valueSource": "memory",
           "dataType": "Float4",
           "documentation": "BMSCH",
           "name": "pBaseQuantity",
           "tagType": "AtomicTag"
         },
         {
           "valueSource": "memory",
           "dataType": "Float4",
           "documentation": "SBMNG",
           "name": "pBaseQuantityForMaterial",
           "tagType": "AtomicTag"
         },
         {
           "valueSource": "memory",
           "dataType": "String",
           "documentation": "Ddiff_DURATION_UOM",
           "name": "pDdiffDurationUom",
           "tagType": "AtomicTag"
         },
         {
           "sourceTagPath": {
             "bindType": "parameter",
             "binding": "{2010TagReferencePath}Set_Phase"
           },
           "valueSource": "reference",
           "eventScripts": [
             {
               "eventid": "valueChanged",
               "script": "\tif not initialChange and currentValue.value \u003d\u003d \u00272020\u0027:\n\t\tsystem.tag.writeBlocking(\"[.]../../SF_Equipment/Checkweigher/Primary_Packaging/2010AutoPhaseCompletionAlert\", 0)"
             }
           ],
           "dataType": "String",
           "documentation": "VORNR",
           "name": "pPhase",
           "tagType": "AtomicTag"
         },
         {
           "valueSource": "memory",
           "dataType": "String",
           "documentation": "Ph_Execution_Start_Time",
           "name": "pPhExecutionEndDateTime",
           "tagType": "AtomicTag"
         },
         {
           "valueSource": "memory",
           "dataType": "String",
           "documentation": "MATKL",
           "name": "pMaterialGroup",
           "tagType": "AtomicTag"
         },
         {
           "valueSource": "memory",
           "dataType": "String",
           "documentation": "VGE02",
           "name": "pStandardValueUom02",
           "tagType": "AtomicTag"
         },
         {
           "valueSource": "memory",
           "dataType": "String",
           "documentation": "VGE06",
           "name": "pStandardValueUom06",
           "tagType": "AtomicTag"
         },
         {
           "valueSource": "memory",
           "dataType": "String",
           "documentation": "INSPLOT",
           "name": "pInspectionLot",
           "tagType": "AtomicTag"
         },
         {
           "valueSource": "memory",
           "dataType": "String",
           "documentation": "MSGFN is the \"Message Function\". It\u0027s a code that defines the action to be performed with (or by) the IDoc itself. Supported codes are:\n\n003  Delete: Message contains objects to be deleted004  Change: Message contains changes005  Replace: This message replaces previous messages009  Original: First message for process023  Wait/Adjust: Data should not be imported018  Resend\n\n003  Delete: Message contains objects to be deleted\n\n004  Change: Message contains changes\n\n005  Replace: This message replaces previous messages\n\n009  Original: First message for process\n\n023  Wait/Adjust: Data should not be imported\n\n018  Resend",
           "name": "pMsgFunctionCode",
           "tagType": "AtomicTag"
         },
         {
           "valueSource": "memory",
           "dataType": "String",
           "documentation": "BreakTimeUOM",
           "name": "pBreakTimeUom",
           "tagType": "AtomicTag"
         },
         {
           "valueSource": "memory",
           "dataType": "String",
           "documentation": "RESB_MATKL",
           "name": "pReservedMaterialGroup",
           "tagType": "AtomicTag"
         },
         {
           "valueSource": "memory",
           "dataType": "String",
           "documentation": "LTXA1",
           "name": "pPhaseShortText",
           "tagType": "AtomicTag"
         },
         {
           "valueSource": "memory",
           "dataType": "String",
           "documentation": "VGW06",
           "name": "pStandardValue06",
           "tagType": "AtomicTag"
         },
         {
           "valueSource": "memory",
           "dataType": "String",
           "documentation": "STDVAL_DURATION_UOM",
           "name": "pStdValDurationUom",
           "tagType": "AtomicTag"
         },
         {
           "valueSource": "memory",
           "dataType": "String",
           "documentation": "AUFNR",
           "name": "pProcessOrder",
           "tagType": "AtomicTag"
         },
         {
           "valueSource": "memory",
           "dataType": "String",
           "name": "pMIIPHStatusStatic",
           "tagType": "AtomicTag"
         },
         {
           "valueSource": "memory",
           "dataType": "String",
           "documentation": "BMEINS",
           "name": "pRequiredQuantityUom",
           "tagType": "AtomicTag"
         },
         {
           "valueSource": "memory",
           "dataType": "String",
           "documentation": "RESB_SPRAS",
           "name": "pReservedLanguageKey",
           "tagType": "AtomicTag"
         },
         {
           "valueSource": "memory",
           "dataType": "Float4",
           "documentation": "BMENGE",
           "name": "pRequiredQuantity",
           "tagType": "AtomicTag"
         },
         {
           "valueSource": "memory",
           "dataType": "String",
           "documentation": "DESCRIPTION",
           "name": "pWorkCenterDescription",
           "tagType": "AtomicTag"
         },
         {
           "valueSource": "memory",
           "dataType": "String",
           "documentation": "MEINS",
           "name": "pBaseUOM",
           "tagType": "AtomicTag"
         },
         {
           "valueSource": "memory",
           "dataType": "String",
           "documentation": "GSUZS",
           "name": "pScheduledStartTime",
           "tagType": "AtomicTag"
         },
         {
           "valueSource": "memory",
           "dataType": "String",
           "documentation": "PVZNR",
           "name": "pOperation",
           "tagType": "AtomicTag"
         },
         {
           "valueSource": "memory",
           "dataType": "String",
           "documentation": "RESB_MTART",
           "name": "pReservedMaterialType",
           "tagType": "AtomicTag"
         },
         {
           "valueSource": "memory",
           "dataType": "String",
           "documentation": "VGW03",
           "name": "pStandardValue03",
           "tagType": "AtomicTag"
         },
         {
           "valueSource": "memory",
           "dataType": "Float4",
           "documentation": "Ddiff_DURATION",
           "name": "pDdiffDuration",
           "tagType": "AtomicTag"
         },
         {
           "valueSource": "memory",
           "dataType": "String",
           "documentation": "RESBMAKTX",
           "name": "pReservedMaterialDescription",
           "tagType": "AtomicTag"
         },
         {
           "valueSource": "memory",
           "dataType": "String",
           "documentation": "SSEDZ",
           "name": "pLatestScheduledFinishTime",
           "tagType": "AtomicTag"
         },
         {
           "valueSource": "memory",
           "dataType": "String",
           "documentation": "XCHPF",
           "name": "pBatchMgmtReqInd",
           "tagType": "AtomicTag"
         },
         {
           "valueSource": "memory",
           "dataType": "String",
           "documentation": "AREA\n",
           "name": "pArea",
           "tagType": "AtomicTag"
         },
         {
           "valueSource": "memory",
           "dataType": "Float4",
           "documentation": "RECORD_FOUND_QTY",
           "name": "pRecordFoundQty",
           "tagType": "AtomicTag"
         },
         {
           "valueSource": "memory",
           "dataType": "String",
           "documentation": "PLNME",
           "name": "pTaskListUom",
           "tagType": "AtomicTag"
         },
         {
           "valueSource": "memory",
           "dataType": "String",
           "name": "pMIIPHPOStatic",
           "tagType": "AtomicTag"
         },
         {
           "valueSource": "memory",
           "dataType": "String",
           "documentation": "ORDERLGORT",
           "name": "pStorageLocation",
           "tagType": "AtomicTag"
         },
         {
           "valueSource": "memory",
           "dataType": "String",
           "documentation": "ARBPL",
           "name": "pWorkCenter",
           "tagType": "AtomicTag"
         },
         {
           "valueSource": "memory",
           "dataType": "String",
           "documentation": "SSEDD",
           "name": "pLatestScheduledFinishDate",
           "tagType": "AtomicTag"
         },
         {
           "valueSource": "memory",
           "dataType": "String",
           "documentation": "BEAZE",
           "name": "pProcessingTimeUOM",
           "tagType": "AtomicTag"
         },
         {
           "valueSource": "memory",
           "dataType": "String",
           "documentation": "AUART",
           "name": "pOrderType",
           "tagType": "AtomicTag"
         },
         {
           "valueSource": "memory",
           "dataType": "String",
           "documentation": "VGW05",
           "name": "pStandardValue05",
           "tagType": "AtomicTag"
         },
         {
           "valueSource": "memory",
           "dataType": "String",
           "documentation": "SBMEH\n",
           "name": "pBaseUOMForMaterial",
           "tagType": "AtomicTag"
         },
         {
           "valueSource": "memory",
           "dataType": "String",
           "documentation": "BEARZ",
           "name": "pProcessingTime",
           "tagType": "AtomicTag"
         },
         {
           "valueSource": "memory",
           "dataType": "String",
           "documentation": "SSAVZ",
           "name": "pLatestScheduledStartTime",
           "tagType": "AtomicTag"
         },
         {
           "valueSource": "memory",
           "dataType": "String",
           "documentation": "STEUS",
           "name": "pControlKey",
           "tagType": "AtomicTag"
         },
         {
           "valueSource": "memory",
           "dataType": "String",
           "documentation": "WERKS",
           "name": "pPlant",
           "tagType": "AtomicTag"
         },
         {
           "valueSource": "memory",
           "dataType": "String",
           "documentation": "Ph_Execution_End_Date",
           "name": "pPhExecutionStartDateTime",
           "tagType": "AtomicTag"
         },
         {
           "valueSource": "memory",
           "dataType": "String",
           "documentation": "GSTRS",
           "name": "pScheduledStartDate",
           "tagType": "AtomicTag"
         },
         {
           "valueSource": "memory",
           "dataType": "String",
           "documentation": "RESB_MSGFN",
           "name": "pResbMsgFunctionCode",
           "tagType": "AtomicTag"
         },
         {
           "valueSource": "memory",
           "dataType": "String",
           "documentation": "MAKTX",
           "name": "pMaterialDescription",
           "tagType": "AtomicTag"
         },
         {
           "valueSource": "memory",
           "dataType": "String",
           "documentation": "PLNAL",
           "name": "pGroupCounter",
           "tagType": "AtomicTag"
         },
         {
           "valueSource": "memory",
           "dataType": "String",
           "documentation": "BLS_MESSAGE",
           "name": "pBlsMessage",
           "tagType": "AtomicTag"
         },
         {
           "valueSource": "memory",
           "dataType": "String",
           "documentation": "GLUZS",
           "name": "pScheduledFinishTime",
           "tagType": "AtomicTag"
         },
         {
           "valueSource": "memory",
           "dataType": "String",
           "documentation": "VGW02",
           "name": "pStandardValue02",
           "tagType": "AtomicTag"
         },
         {
           "valueSource": "memory",
           "dataType": "String",
           "name": "pMIIPHPhaseStatic",
           "tagType": "AtomicTag"
         },
         {
           "valueSource": "memory",
           "dataType": "String",
           "documentation": "ERP_SEND_TIME",
           "name": "pErpSendTime",
           "tagType": "AtomicTag"
         },
         {
           "valueSource": "memory",
           "dataType": "String",
           "documentation": "SSAVD",
           "name": "pLatestScheduledStartDate",
           "tagType": "AtomicTag"
         },
         {
           "valueSource": "memory",
           "dataType": "String",
           "documentation": "VGE04",
           "name": "pStandardValueUom04",
           "tagType": "AtomicTag"
         },
         {
           "valueSource": "memory",
           "dataType": "Float4",
           "documentation": "MGVRG",
           "name": "pPhaseQuantity",
           "tagType": "AtomicTag"
         },
         {
           "valueSource": "reference",
           "dataType": "String",
           "documentation": "S4_MII_STATUS",
           "sourceTagPath": "[.]../Header/s4MIIStatus",
           "name": "pS4MIIStatus",
           "tagType": "AtomicTag"
         },
         {
           "valueSource": "memory",
           "dataType": "String",
           "documentation": "VGW04",
           "name": "pStandardValue04",
           "tagType": "AtomicTag"
         },
         {
           "valueSource": "memory",
           "dataType": "String",
           "documentation": "VGE01",
           "name": "pStandardValueUom01",
           "tagType": "AtomicTag"
         },
         {
           "valueSource": "memory",
           "dataType": "String",
           "documentation": "MEINH",
           "name": "pPhaseUom",
           "tagType": "AtomicTag"
         },
         {
           "valueSource": "memory",
           "dataType": "String",
           "name": "pMIIPHMaterialStatic",
           "tagType": "AtomicTag"
         },
         {
           "valueSource": "memory",
           "dataType": "String",
           "documentation": "ORDERCHARG",
           "name": "pBatchNumber",
           "tagType": "AtomicTag"
         },
         {
           "valueSource": "memory",
           "dataType": "String",
           "documentation": "SPRAS",
           "name": "pLanguageKey",
           "tagType": "AtomicTag"
         },
         {
           "valueSource": "memory",
           "dataType": "String",
           "documentation": "VGE03",
           "name": "pStandardValueUom03",
           "tagType": "AtomicTag"
         },
         {
           "valueSource": "memory",
           "dataType": "Float4",
           "documentation": "BDMNG",
           "name": "pRequirementQuantity",
           "tagType": "AtomicTag"
         },
         {
           "valueSource": "memory",
           "dataType": "String",
           "documentation": "GLTRS",
           "name": "pScheduledFinishDate",
           "tagType": "AtomicTag"
         },
         {
           "valueSource": "memory",
           "dataType": "String",
           "documentation": "BreakTime",
           "name": "pBreakTime",
           "tagType": "AtomicTag"
         },
         {
           "valueSource": "memory",
           "dataType": "String",
           "documentation": "MTART",
           "name": "pMaterialType",
           "tagType": "AtomicTag"
         },
         {
           "valueSource": "memory",
           "dataType": "String",
           "documentation": "CLIENT",
           "name": "pClient",
           "tagType": "AtomicTag"
         },
         {
           "valueSource": "memory",
           "dataType": "String",
           "documentation": "BLS_STATUS",
           "name": "pBlsStatus",
           "tagType": "AtomicTag"
         },
         {
           "valueSource": "memory",
           "dataType": "String",
           "documentation": "RESB_SPRAS_ISO",
           "name": "pReservedSAPLanguageKey",
           "tagType": "AtomicTag"
         }
       ]
     },
     {
       "name": "PrePackTol",
       "tagType": "Folder",
       "tags": [
         {
           "sourceTagPath": {
             "bindType": "parameter",
             "binding": "{2010TagReferencePath}IsPhantom"
           },
           "valueSource": "reference",
           "dataType": "Boolean",
           "name": "isPhantom",
           "tagType": "AtomicTag"
         }
       ]
     },
     {
       "name": "BBN",
       "typeId": "UNS/BBN",
       "tagType": "UdtInstance",
       "tags": [
         {
           "name": "BbnPhantom",
           "tagType": "Folder",
           "tags": [
             {
               "parameters": {
                 "device": {
                   "dataType": "String",
                   "value": "4"
                 }
               },
               "name": "3",
               "tagType": "UdtInstance",
               "tags": [
                 {
                   "name": "MaterialNo",
                   "tagType": "AtomicTag"
                 },
                 {
                   "name": "Weight",
                   "tagType": "AtomicTag"
                 },
                 {
                   "name": "Unit",
                   "tagType": "AtomicTag"
                 },
                 {
                   "name": "BatchNo",
                   "tagType": "AtomicTag"
                 },
                 {
                   "name": "Bbn",
                   "tagType": "AtomicTag"
                 },
                 {
                   "name": "Part",
                   "tagType": "AtomicTag"
                 },
                 {
                   "name": "Uom",
                   "tagType": "AtomicTag"
                 },
                 {
                   "name": "ProductionDate",
                   "tagType": "AtomicTag"
                 },
                 {
                   "name": "PoNumber",
                   "tagType": "AtomicTag"
                 }
               ]
             },
             {
               "parameters": {
                 "device": {
                   "dataType": "String",
                   "value": "5"
                 }
               },
               "name": "4",
               "tagType": "UdtInstance",
               "tags": [
                 {
                   "name": "PoNumber",
                   "tagType": "AtomicTag"
                 },
                 {
                   "name": "ProductionDate",
                   "tagType": "AtomicTag"
                 },
                 {
                   "name": "Part",
                   "tagType": "AtomicTag"
                 },
                 {
                   "name": "Weight",
                   "tagType": "AtomicTag"
                 },
                 {
                   "name": "Unit",
                   "tagType": "AtomicTag"
                 },
                 {
                   "name": "Uom",
                   "tagType": "AtomicTag"
                 },
                 {
                   "name": "Bbn",
                   "tagType": "AtomicTag"
                 },
                 {
                   "name": "MaterialNo",
                   "tagType": "AtomicTag"
                 },
                 {
                   "name": "BatchNo",
                   "tagType": "AtomicTag"
                 }
               ]
             },
             {
               "parameters": {
                 "device": {
                   "dataType": "String",
                   "value": "2"
                 }
               },
               "name": "1",
               "tagType": "UdtInstance",
               "tags": [
                 {
                   "name": "Uom",
                   "tagType": "AtomicTag"
                 },
                 {
                   "name": "Unit",
                   "tagType": "AtomicTag"
                 },
                 {
                   "name": "BatchNo",
                   "tagType": "AtomicTag"
                 },
                 {
                   "name": "ProductionDate",
                   "tagType": "AtomicTag"
                 },
                 {
                   "name": "MaterialNo",
                   "tagType": "AtomicTag"
                 },
                 {
                   "name": "PoNumber",
                   "tagType": "AtomicTag"
                 },
                 {
                   "name": "Weight",
                   "tagType": "AtomicTag"
                 },
                 {
                   "name": "Part",
                   "tagType": "AtomicTag"
                 },
                 {
                   "name": "Bbn",
                   "tagType": "AtomicTag"
                 }
               ]
             },
             {
               "parameters": {
                 "device": {
                   "dataType": "String",
                   "value": "1"
                 }
               },
               "name": "0",
               "tagType": "UdtInstance",
               "tags": [
                 {
                   "name": "Uom",
                   "tagType": "AtomicTag"
                 },
                 {
                   "name": "Unit",
                   "tagType": "AtomicTag"
                 },
                 {
                   "name": "PoNumber",
                   "tagType": "AtomicTag"
                 },
                 {
                   "name": "BatchNo",
                   "tagType": "AtomicTag"
                 },
                 {
                   "name": "ProductionDate",
                   "tagType": "AtomicTag"
                 },
                 {
                   "name": "MaterialNo",
                   "tagType": "AtomicTag"
                 },
                 {
                   "name": "Part",
                   "tagType": "AtomicTag"
                 },
                 {
                   "name": "Weight",
                   "tagType": "AtomicTag"
                 },
                 {
                   "name": "Bbn",
                   "tagType": "AtomicTag"
                 }
               ]
             },
             {
               "parameters": {
                 "device": {
                   "dataType": "String",
                   "value": "3"
                 }
               },
               "name": "2",
               "tagType": "UdtInstance",
               "tags": [
                 {
                   "name": "BatchNo",
                   "tagType": "AtomicTag"
                 },
                 {
                   "name": "Part",
                   "tagType": "AtomicTag"
                 },
                 {
                   "name": "MaterialNo",
                   "tagType": "AtomicTag"
                 },
                 {
                   "name": "ProductionDate",
                   "tagType": "AtomicTag"
                 },
                 {
                   "name": "Uom",
                   "tagType": "AtomicTag"
                 },
                 {
                   "name": "PoNumber",
                   "tagType": "AtomicTag"
                 },
                 {
                   "name": "Unit",
                   "tagType": "AtomicTag"
                 },
                 {
                   "name": "Bbn",
                   "tagType": "AtomicTag"
                 },
                 {
                   "name": "Weight",
                   "tagType": "AtomicTag"
                 }
               ]
             }
           ]
         },
         {
           "name": "BbnFinsihedGood",
           "tagType": "Folder",
           "tags": [
             {
               "name": "Unit",
               "tagType": "AtomicTag"
             },
             {
               "name": "Uom",
               "tagType": "AtomicTag"
             },
             {
               "name": "Weight",
               "tagType": "AtomicTag"
             },
             {
               "name": "BatchNo",
               "tagType": "AtomicTag"
             },
             {
               "name": "MaterialNo",
               "tagType": "AtomicTag"
             },
             {
               "name": "Part",
               "tagType": "AtomicTag"
             },
             {
               "name": "PoNumber",
               "tagType": "AtomicTag"
             },
             {
               "name": "Bbd",
               "tagType": "AtomicTag"
             },
             {
               "name": "Bbn",
               "tagType": "AtomicTag"
             }
           ]
         }
       ]
     },
     {
       "name": "BOM",
       "typeId": "UNS/BOM",
       "tagType": "UdtInstance",
       "tags": [
         {
           "name": "BOM_10",
           "tagType": "UdtInstance",
           "tags": [
             {
               "name": "MaterialDesc",
               "tagType": "AtomicTag"
             },
             {
               "name": "MaterialNo",
               "tagType": "AtomicTag"
             },
             {
               "name": "Uom",
               "tagType": "AtomicTag"
             },
             {
               "name": "BatchNo",
               "tagType": "AtomicTag"
             },
             {
               "name": "Phase",
               "tagType": "AtomicTag"
             },
             {
               "name": "WorkCenter",
               "tagType": "AtomicTag"
             },
             {
               "name": "MatGroup",
               "tagType": "AtomicTag"
             },
             {
               "name": "Target",
               "tagType": "AtomicTag"
             },
             {
               "name": "MaterialType",
               "tagType": "AtomicTag"
             },
             {
               "name": "ReservationPOS",
               "tagType": "AtomicTag"
             },
             {
               "name": "StorageLocation",
               "tagType": "AtomicTag"
             },
             {
               "name": "ReservationItem",
               "tagType": "AtomicTag"
             },
             {
               "name": "UpperLimit",
               "tagType": "AtomicTag"
             },
             {
               "name": "LowerLimit",
               "tagType": "AtomicTag"
             },
             {
               "name": "BackFlush",
               "tagType": "AtomicTag"
             },
             {
               "name": "MatQty",
               "tagType": "AtomicTag"
             }
           ]
         },
         {
           "name": "BOM_7",
           "tagType": "UdtInstance",
           "tags": [
             {
               "name": "WorkCenter",
               "tagType": "AtomicTag"
             },
             {
               "name": "MaterialType",
               "tagType": "AtomicTag"
             },
             {
               "name": "ReservationPOS",
               "tagType": "AtomicTag"
             },
             {
               "name": "MatQty",
               "tagType": "AtomicTag"
             },
             {
               "name": "ReservationItem",
               "tagType": "AtomicTag"
             },
             {
               "name": "StorageLocation",
               "tagType": "AtomicTag"
             },
             {
               "name": "LowerLimit",
               "tagType": "AtomicTag"
             },
             {
               "name": "MaterialNo",
               "tagType": "AtomicTag"
             },
             {
               "name": "UpperLimit",
               "tagType": "AtomicTag"
             },
             {
               "name": "BackFlush",
               "tagType": "AtomicTag"
             },
             {
               "name": "Phase",
               "tagType": "AtomicTag"
             },
             {
               "name": "MaterialDesc",
               "tagType": "AtomicTag"
             },
             {
               "name": "BatchNo",
               "tagType": "AtomicTag"
             },
             {
               "name": "Target",
               "tagType": "AtomicTag"
             },
             {
               "name": "MatGroup",
               "tagType": "AtomicTag"
             },
             {
               "name": "Uom",
               "tagType": "AtomicTag"
             }
           ]
         },
         {
           "name": "BOM_4",
           "tagType": "UdtInstance",
           "tags": [
             {
               "name": "Target",
               "tagType": "AtomicTag"
             },
             {
               "name": "MaterialNo",
               "tagType": "AtomicTag"
             },
             {
               "name": "MaterialDesc",
               "tagType": "AtomicTag"
             },
             {
               "name": "BatchNo",
               "tagType": "AtomicTag"
             },
             {
               "name": "MatGroup",
               "tagType": "AtomicTag"
             },
             {
               "name": "Phase",
               "tagType": "AtomicTag"
             },
             {
               "name": "MaterialType",
               "tagType": "AtomicTag"
             },
             {
               "name": "WorkCenter",
               "tagType": "AtomicTag"
             },
             {
               "name": "Uom",
               "tagType": "AtomicTag"
             },
             {
               "name": "MatQty",
               "tagType": "AtomicTag"
             },
             {
               "name": "ReservationPOS",
               "tagType": "AtomicTag"
             },
             {
               "name": "ReservationItem",
               "tagType": "AtomicTag"
             },
             {
               "name": "StorageLocation",
               "tagType": "AtomicTag"
             },
             {
               "name": "UpperLimit",
               "tagType": "AtomicTag"
             },
             {
               "name": "LowerLimit",
               "tagType": "AtomicTag"
             },
             {
               "name": "BackFlush",
               "tagType": "AtomicTag"
             }
           ]
         },
         {
           "name": "BOM_5",
           "tagType": "UdtInstance",
           "tags": [
             {
               "name": "WorkCenter",
               "tagType": "AtomicTag"
             },
             {
               "name": "MaterialType",
               "tagType": "AtomicTag"
             },
             {
               "name": "ReservationPOS",
               "tagType": "AtomicTag"
             },
             {
               "name": "MatQty",
               "tagType": "AtomicTag"
             },
             {
               "name": "StorageLocation",
               "tagType": "AtomicTag"
             },
             {
               "name": "ReservationItem",
               "tagType": "AtomicTag"
             },
             {
               "name": "LowerLimit",
               "tagType": "AtomicTag"
             },
             {
               "name": "UpperLimit",
               "tagType": "AtomicTag"
             },
             {
               "name": "MaterialNo",
               "tagType": "AtomicTag"
             },
             {
               "name": "BackFlush",
               "tagType": "AtomicTag"
             },
             {
               "name": "MaterialDesc",
               "tagType": "AtomicTag"
             },
             {
               "name": "Phase",
               "tagType": "AtomicTag"
             },
             {
               "name": "BatchNo",
               "tagType": "AtomicTag"
             },
             {
               "name": "Target",
               "tagType": "AtomicTag"
             },
             {
               "name": "MatGroup",
               "tagType": "AtomicTag"
             },
             {
               "name": "Uom",
               "tagType": "AtomicTag"
             }
           ]
         },
         {
           "name": "BOM_13",
           "tagType": "UdtInstance",
           "tags": [
             {
               "name": "Target",
               "tagType": "AtomicTag"
             },
             {
               "name": "MaterialNo",
               "tagType": "AtomicTag"
             },
             {
               "name": "UpperLimit",
               "tagType": "AtomicTag"
             },
             {
               "name": "MaterialDesc",
               "tagType": "AtomicTag"
             },
             {
               "name": "MatGroup",
               "tagType": "AtomicTag"
             },
             {
               "name": "BatchNo",
               "tagType": "AtomicTag"
             },
             {
               "name": "Phase",
               "tagType": "AtomicTag"
             },
             {
               "name": "Uom",
               "tagType": "AtomicTag"
             },
             {
               "name": "WorkCenter",
               "tagType": "AtomicTag"
             },
             {
               "name": "MaterialType",
               "tagType": "AtomicTag"
             },
             {
               "name": "ReservationPOS",
               "tagType": "AtomicTag"
             },
             {
               "name": "MatQty",
               "tagType": "AtomicTag"
             },
             {
               "name": "ReservationItem",
               "tagType": "AtomicTag"
             },
             {
               "name": "StorageLocation",
               "tagType": "AtomicTag"
             },
             {
               "name": "LowerLimit",
               "tagType": "AtomicTag"
             },
             {
               "name": "BackFlush",
               "tagType": "AtomicTag"
             }
           ]
         },
         {
           "name": "BOM_2",
           "tagType": "UdtInstance",
           "tags": [
             {
               "name": "Target",
               "tagType": "AtomicTag"
             },
             {
               "name": "MaterialNo",
               "tagType": "AtomicTag"
             },
             {
               "name": "MaterialDesc",
               "tagType": "AtomicTag"
             },
             {
               "name": "UpperLimit",
               "tagType": "AtomicTag"
             },
             {
               "name": "LowerLimit",
               "tagType": "AtomicTag"
             },
             {
               "name": "MatQty",
               "tagType": "AtomicTag"
             },
             {
               "name": "BackFlush",
               "tagType": "AtomicTag"
             },
             {
               "name": "ReservationPOS",
               "tagType": "AtomicTag"
             },
             {
               "name": "ReservationItem",
               "tagType": "AtomicTag"
             },
             {
               "name": "StorageLocation",
               "tagType": "AtomicTag"
             },
             {
               "name": "BatchNo",
               "tagType": "AtomicTag"
             },
             {
               "name": "MatGroup",
               "tagType": "AtomicTag"
             },
             {
               "name": "Phase",
               "tagType": "AtomicTag"
             },
             {
               "name": "MaterialType",
               "tagType": "AtomicTag"
             },
             {
               "name": "WorkCenter",
               "tagType": "AtomicTag"
             },
             {
               "name": "Uom",
               "tagType": "AtomicTag"
             }
           ]
         },
         {
           "name": "BOM_15",
           "tagType": "UdtInstance",
           "tags": [
             {
               "name": "Target",
               "tagType": "AtomicTag"
             },
             {
               "name": "LowerLimit",
               "tagType": "AtomicTag"
             },
             {
               "name": "BackFlush",
               "tagType": "AtomicTag"
             },
             {
               "name": "Phase",
               "tagType": "AtomicTag"
             },
             {
               "name": "ReservationPOS",
               "tagType": "AtomicTag"
             },
             {
               "name": "Uom",
               "tagType": "AtomicTag"
             },
             {
               "name": "WorkCenter",
               "tagType": "AtomicTag"
             },
             {
               "name": "MatQty",
               "tagType": "AtomicTag"
             },
             {
               "name": "MaterialType",
               "tagType": "AtomicTag"
             },
             {
               "name": "MaterialDesc",
               "tagType": "AtomicTag"
             },
             {
               "name": "MatGroup",
               "tagType": "AtomicTag"
             },
             {
               "name": "BatchNo",
               "tagType": "AtomicTag"
             },
             {
               "name": "UpperLimit",
               "tagType": "AtomicTag"
             },
             {
               "name": "ReservationItem",
               "tagType": "AtomicTag"
             },
             {
               "name": "MaterialNo",
               "tagType": "AtomicTag"
             },
             {
               "name": "StorageLocation",
               "tagType": "AtomicTag"
             }
           ]
         },
         {
           "name": "BOM_11",
           "tagType": "UdtInstance",
           "tags": [
             {
               "name": "LowerLimit",
               "tagType": "AtomicTag"
             },
             {
               "name": "Target",
               "tagType": "AtomicTag"
             },
             {
               "name": "UpperLimit",
               "tagType": "AtomicTag"
             },
             {
               "name": "WorkCenter",
               "tagType": "AtomicTag"
             },
             {
               "name": "MaterialDesc",
               "tagType": "AtomicTag"
             },
             {
               "name": "MatGroup",
               "tagType": "AtomicTag"
             },
             {
               "name": "MaterialNo",
               "tagType": "AtomicTag"
             },
             {
               "name": "MaterialType",
               "tagType": "AtomicTag"
             },
             {
               "name": "ReservationPOS",
               "tagType": "AtomicTag"
             },
             {
               "name": "BatchNo",
               "tagType": "AtomicTag"
             },
             {
               "name": "MatQty",
               "tagType": "AtomicTag"
             },
             {
               "name": "ReservationItem",
               "tagType": "AtomicTag"
             },
             {
               "name": "StorageLocation",
               "tagType": "AtomicTag"
             },
             {
               "name": "Uom",
               "tagType": "AtomicTag"
             },
             {
               "name": "Phase",
               "tagType": "AtomicTag"
             },
             {
               "name": "BackFlush",
               "tagType": "AtomicTag"
             }
           ]
         },
         {
           "name": "BOM_3",
           "tagType": "UdtInstance",
           "tags": [
             {
               "name": "LowerLimit",
               "tagType": "AtomicTag"
             },
             {
               "name": "UpperLimit",
               "tagType": "AtomicTag"
             },
             {
               "name": "MaterialNo",
               "tagType": "AtomicTag"
             },
             {
               "name": "BackFlush",
               "tagType": "AtomicTag"
             },
             {
               "name": "ReservationItem",
               "tagType": "AtomicTag"
             },
             {
               "name": "StorageLocation",
               "tagType": "AtomicTag"
             },
             {
               "name": "Uom",
               "tagType": "AtomicTag"
             },
             {
               "name": "MatQty",
               "tagType": "AtomicTag"
             },
             {
               "name": "BatchNo",
               "tagType": "AtomicTag"
             },
             {
               "name": "ReservationPOS",
               "tagType": "AtomicTag"
             },
             {
               "name": "WorkCenter",
               "tagType": "AtomicTag"
             },
             {
               "name": "MaterialDesc",
               "tagType": "AtomicTag"
             },
             {
               "name": "MatGroup",
               "tagType": "AtomicTag"
             },
             {
               "name": "Phase",
               "tagType": "AtomicTag"
             },
             {
               "name": "Target",
               "tagType": "AtomicTag"
             },
             {
               "name": "MaterialType",
               "tagType": "AtomicTag"
             }
           ]
         },
         {
           "name": "BOM_12",
           "tagType": "UdtInstance",
           "tags": [
             {
               "name": "Target",
               "tagType": "AtomicTag"
             },
             {
               "name": "MaterialNo",
               "tagType": "AtomicTag"
             },
             {
               "name": "Phase",
               "tagType": "AtomicTag"
             },
             {
               "name": "LowerLimit",
               "tagType": "AtomicTag"
             },
             {
               "name": "BackFlush",
               "tagType": "AtomicTag"
             },
             {
               "name": "UpperLimit",
               "tagType": "AtomicTag"
             },
             {
               "name": "BatchNo",
               "tagType": "AtomicTag"
             },
             {
               "name": "ReservationItem",
               "tagType": "AtomicTag"
             },
             {
               "name": "StorageLocation",
               "tagType": "AtomicTag"
             },
             {
               "name": "WorkCenter",
               "tagType": "AtomicTag"
             },
             {
               "name": "MaterialDesc",
               "tagType": "AtomicTag"
             },
             {
               "name": "MatGroup",
               "tagType": "AtomicTag"
             },
             {
               "name": "ReservationPOS",
               "tagType": "AtomicTag"
             },
             {
               "name": "MaterialType",
               "tagType": "AtomicTag"
             },
             {
               "name": "Uom",
               "tagType": "AtomicTag"
             },
             {
               "name": "MatQty",
               "tagType": "AtomicTag"
             }
           ]
         },
         {
           "name": "BOM_8",
           "tagType": "UdtInstance",
           "tags": [
             {
               "name": "BatchNo",
               "tagType": "AtomicTag"
             },
             {
               "name": "MatGroup",
               "tagType": "AtomicTag"
             },
             {
               "name": "BackFlush",
               "tagType": "AtomicTag"
             },
             {
               "name": "MatQty",
               "tagType": "AtomicTag"
             },
             {
               "name": "Phase",
               "tagType": "AtomicTag"
             },
             {
               "name": "Uom",
               "tagType": "AtomicTag"
             },
             {
               "name": "MaterialNo",
               "tagType": "AtomicTag"
             },
             {
               "name": "Target",
               "tagType": "AtomicTag"
             },
             {
               "name": "ReservationPOS",
               "tagType": "AtomicTag"
             },
             {
               "name": "MaterialDesc",
               "tagType": "AtomicTag"
             },
             {
               "name": "ReservationItem",
               "tagType": "AtomicTag"
             },
             {
               "name": "StorageLocation",
               "tagType": "AtomicTag"
             },
             {
               "name": "UpperLimit",
               "tagType": "AtomicTag"
             },
             {
               "name": "WorkCenter",
               "tagType": "AtomicTag"
             },
             {
               "name": "MaterialType",
               "tagType": "AtomicTag"
             },
             {
               "name": "LowerLimit",
               "tagType": "AtomicTag"
             }
           ]
         },
         {
           "name": "BOM_6",
           "tagType": "UdtInstance",
           "tags": [
             {
               "name": "MaterialType",
               "tagType": "AtomicTag"
             },
             {
               "name": "UpperLimit",
               "tagType": "AtomicTag"
             },
             {
               "name": "LowerLimit",
               "tagType": "AtomicTag"
             },
             {
               "name": "MatQty",
               "tagType": "AtomicTag"
             },
             {
               "name": "BackFlush",
               "tagType": "AtomicTag"
             },
             {
               "name": "Phase",
               "tagType": "AtomicTag"
             },
             {
               "name": "MaterialDesc",
               "tagType": "AtomicTag"
             },
             {
               "name": "MaterialNo",
               "tagType": "AtomicTag"
             },
             {
               "name": "ReservationItem",
               "tagType": "AtomicTag"
             },
             {
               "name": "StorageLocation",
               "tagType": "AtomicTag"
             },
             {
               "name": "BatchNo",
               "tagType": "AtomicTag"
             },
             {
               "name": "Uom",
               "tagType": "AtomicTag"
             },
             {
               "name": "MatGroup",
               "tagType": "AtomicTag"
             },
             {
               "name": "ReservationPOS",
               "tagType": "AtomicTag"
             },
             {
               "name": "Target",
               "tagType": "AtomicTag"
             },
             {
               "name": "WorkCenter",
               "tagType": "AtomicTag"
             }
           ]
         },
         {
           "name": "BOM_9",
           "tagType": "UdtInstance",
           "tags": [
             {
               "name": "MaterialType",
               "tagType": "AtomicTag"
             },
             {
               "name": "WorkCenter",
               "tagType": "AtomicTag"
             },
             {
               "name": "MatQty",
               "tagType": "AtomicTag"
             },
             {
               "name": "ReservationItem",
               "tagType": "AtomicTag"
             },
             {
               "name": "StorageLocation",
               "tagType": "AtomicTag"
             },
             {
               "name": "UpperLimit",
               "tagType": "AtomicTag"
             },
             {
               "name": "LowerLimit",
               "tagType": "AtomicTag"
             },
             {
               "name": "MaterialDesc",
               "tagType": "AtomicTag"
             },
             {
               "name": "MatGroup",
               "tagType": "AtomicTag"
             },
             {
               "name": "Phase",
               "tagType": "AtomicTag"
             },
             {
               "name": "BackFlush",
               "tagType": "AtomicTag"
             },
             {
               "name": "MaterialNo",
               "tagType": "AtomicTag"
             },
             {
               "name": "BatchNo",
               "tagType": "AtomicTag"
             },
             {
               "name": "ReservationPOS",
               "tagType": "AtomicTag"
             },
             {
               "name": "Target",
               "tagType": "AtomicTag"
             },
             {
               "name": "Uom",
               "tagType": "AtomicTag"
             }
           ]
         },
         {
           "name": "BOM_14",
           "tagType": "UdtInstance",
           "tags": [
             {
               "name": "ReservationPOS",
               "tagType": "AtomicTag"
             },
             {
               "name": "MatQty",
               "tagType": "AtomicTag"
             },
             {
               "name": "MaterialType",
               "tagType": "AtomicTag"
             },
             {
               "name": "Uom",
               "tagType": "AtomicTag"
             },
             {
               "name": "MaterialNo",
               "tagType": "AtomicTag"
             },
             {
               "name": "Target",
               "tagType": "AtomicTag"
             },
             {
               "name": "LowerLimit",
               "tagType": "AtomicTag"
             },
             {
               "name": "BackFlush",
               "tagType": "AtomicTag"
             },
             {
               "name": "Phase",
               "tagType": "AtomicTag"
             },
             {
               "name": "MatGroup",
               "tagType": "AtomicTag"
             },
             {
               "name": "UpperLimit",
               "tagType": "AtomicTag"
             },
             {
               "name": "WorkCenter",
               "tagType": "AtomicTag"
             },
             {
               "name": "StorageLocation",
               "tagType": "AtomicTag"
             },
             {
               "name": "ReservationItem",
               "tagType": "AtomicTag"
             },
             {
               "name": "BatchNo",
               "tagType": "AtomicTag"
             },
             {
               "name": "MaterialDesc",
               "tagType": "AtomicTag"
             }
           ]
         },
         {
           "name": "BOM_1",
           "tagType": "UdtInstance",
           "tags": [
             {
               "name": "LowerLimit",
               "tagType": "AtomicTag"
             },
             {
               "name": "Target",
               "tagType": "AtomicTag"
             },
             {
               "name": "UpperLimit",
               "tagType": "AtomicTag"
             },
             {
               "name": "WorkCenter",
               "tagType": "AtomicTag"
             },
             {
               "name": "MaterialDesc",
               "tagType": "AtomicTag"
             },
             {
               "name": "MaterialNo",
               "tagType": "AtomicTag"
             },
             {
               "name": "MaterialType",
               "tagType": "AtomicTag"
             },
             {
               "name": "BatchNo",
               "tagType": "AtomicTag"
             },
             {
               "name": "MatGroup",
               "tagType": "AtomicTag"
             },
             {
               "name": "ReservationPOS",
               "tagType": "AtomicTag"
             },
             {
               "name": "StorageLocation",
               "tagType": "AtomicTag"
             },
             {
               "name": "MatQty",
               "tagType": "AtomicTag"
             },
             {
               "name": "ReservationItem",
               "tagType": "AtomicTag"
             },
             {
               "name": "Uom",
               "tagType": "AtomicTag"
             },
             {
               "name": "Phase",
               "tagType": "AtomicTag"
             },
             {
               "name": "BackFlush",
               "tagType": "AtomicTag"
             }
           ]
         }
       ]
     },
     {
       "name": "WIP",
       "typeId": "UNS/WIP",
       "tagType": "UdtInstance",
       "tags": [
         {
           "parameters": {
             "Phase": {
               "dataType": "String",
               "value": "2010"
             }
           },
           "name": "WIP_18",
           "tagType": "UdtInstance",
           "tags": [
             {
               "name": "BagSize",
               "tagType": "AtomicTag"
             },
             {
               "name": "MaterialDesc",
               "tagType": "AtomicTag"
             },
             {
               "name": "Quantity",
               "tagType": "AtomicTag"
             },
             {
               "name": "MaterialNo",
               "tagType": "AtomicTag"
             },
             {
               "name": "Uom",
               "tagType": "AtomicTag"
             },
             {
               "name": "BatchQty",
               "tagType": "AtomicTag"
             },
             {
               "name": "IsPhantom",
               "tagType": "AtomicTag"
             },
             {
               "name": "Target",
               "tagType": "AtomicTag"
             },
             {
               "name": "BatchNo",
               "tagType": "AtomicTag"
             },
             {
               "name": "QuantityUom",
               "tagType": "AtomicTag"
             },
             {
               "name": "EquipID",
               "tagType": "AtomicTag"
             },
             {
               "name": "LowerLimit",
               "tagType": "AtomicTag"
             },
             {
               "name": "UpperLimit",
               "tagType": "AtomicTag"
             }
           ]
         },
         {
           "parameters": {
             "Phase": {
               "dataType": "String",
               "value": "2010"
             }
           },
           "name": "WIP_12",
           "tagType": "UdtInstance",
           "tags": [
             {
               "name": "LowerLimit",
               "tagType": "AtomicTag"
             },
             {
               "name": "BatchNo",
               "tagType": "AtomicTag"
             },
             {
               "name": "Target",
               "tagType": "AtomicTag"
             },
             {
               "name": "MaterialNo",
               "tagType": "AtomicTag"
             },
             {
               "name": "BagSize",
               "tagType": "AtomicTag"
             },
             {
               "name": "Quantity",
               "tagType": "AtomicTag"
             },
             {
               "name": "Uom",
               "tagType": "AtomicTag"
             },
             {
               "name": "MaterialDesc",
               "tagType": "AtomicTag"
             },
             {
               "name": "UpperLimit",
               "tagType": "AtomicTag"
             },
             {
               "name": "BatchQty",
               "tagType": "AtomicTag"
             },
             {
               "name": "IsPhantom",
               "tagType": "AtomicTag"
             },
             {
               "name": "QuantityUom",
               "tagType": "AtomicTag"
             },
             {
               "name": "EquipID",
               "tagType": "AtomicTag"
             }
           ]
         },
         {
           "parameters": {
             "Phase": {
               "dataType": "String",
               "value": "2010"
             }
           },
           "name": "WIP_19",
           "tagType": "UdtInstance",
           "tags": [
             {
               "name": "BatchQty",
               "tagType": "AtomicTag"
             },
             {
               "name": "IsPhantom",
               "tagType": "AtomicTag"
             },
             {
               "name": "LowerLimit",
               "tagType": "AtomicTag"
             },
             {
               "name": "MaterialNo",
               "tagType": "AtomicTag"
             },
             {
               "name": "Uom",
               "tagType": "AtomicTag"
             },
             {
               "name": "Target",
               "tagType": "AtomicTag"
             },
             {
               "name": "BatchNo",
               "tagType": "AtomicTag"
             },
             {
               "name": "MaterialDesc",
               "tagType": "AtomicTag"
             },
             {
               "name": "UpperLimit",
               "tagType": "AtomicTag"
             },
             {
               "name": "BagSize",
               "tagType": "AtomicTag"
             },
             {
               "name": "Quantity",
               "tagType": "AtomicTag"
             },
             {
               "name": "QuantityUom",
               "tagType": "AtomicTag"
             },
             {
               "name": "EquipID",
               "tagType": "AtomicTag"
             }
           ]
         },
         {
           "parameters": {
             "Phase": {
               "dataType": "String",
               "value": "2010"
             }
           },
           "name": "WIP_13",
           "tagType": "UdtInstance",
           "tags": [
             {
               "name": "IsPhantom",
               "tagType": "AtomicTag"
             },
             {
               "name": "Target",
               "tagType": "AtomicTag"
             },
             {
               "name": "BatchQty",
               "tagType": "AtomicTag"
             },
             {
               "name": "QuantityUom",
               "tagType": "AtomicTag"
             },
             {
               "name": "MaterialDesc",
               "tagType": "AtomicTag"
             },
             {
               "name": "Quantity",
               "tagType": "AtomicTag"
             },
             {
               "name": "Uom",
               "tagType": "AtomicTag"
             },
             {
               "name": "UpperLimit",
               "tagType": "AtomicTag"
             },
             {
               "name": "BagSize",
               "tagType": "AtomicTag"
             },
             {
               "name": "EquipID",
               "tagType": "AtomicTag"
             },
             {
               "name": "LowerLimit",
               "tagType": "AtomicTag"
             },
             {
               "name": "MaterialNo",
               "tagType": "AtomicTag"
             },
             {
               "name": "BatchNo",
               "tagType": "AtomicTag"
             }
           ]
         },
         {
           "parameters": {
             "Phase": {
               "dataType": "String",
               "value": "2010"
             }
           },
           "name": "WIP_20",
           "tagType": "UdtInstance",
           "tags": [
             {
               "name": "BatchQty",
               "tagType": "AtomicTag"
             },
             {
               "name": "LowerLimit",
               "tagType": "AtomicTag"
             },
             {
               "name": "IsPhantom",
               "tagType": "AtomicTag"
             },
             {
               "name": "MaterialNo",
               "tagType": "AtomicTag"
             },
             {
               "name": "BatchNo",
               "tagType": "AtomicTag"
             },
             {
               "name": "MaterialDesc",
               "tagType": "AtomicTag"
             },
             {
               "name": "Uom",
               "tagType": "AtomicTag"
             },
             {
               "name": "Target",
               "tagType": "AtomicTag"
             },
             {
               "name": "BagSize",
               "tagType": "AtomicTag"
             },
             {
               "name": "EquipID",
               "tagType": "AtomicTag"
             },
             {
               "name": "Quantity",
               "tagType": "AtomicTag"
             },
             {
               "name": "UpperLimit",
               "tagType": "AtomicTag"
             },
             {
               "name": "QuantityUom",
               "tagType": "AtomicTag"
             }
           ]
         },
         {
           "parameters": {
             "Phase": {
               "dataType": "String",
               "value": "2010"
             }
           },
           "name": "WIP_14",
           "tagType": "UdtInstance",
           "tags": [
             {
               "name": "BagSize",
               "tagType": "AtomicTag"
             },
             {
               "name": "Quantity",
               "tagType": "AtomicTag"
             },
             {
               "name": "UpperLimit",
               "tagType": "AtomicTag"
             },
             {
               "name": "EquipID",
               "tagType": "AtomicTag"
             },
             {
               "name": "QuantityUom",
               "tagType": "AtomicTag"
             },
             {
               "name": "IsPhantom",
               "tagType": "AtomicTag"
             },
             {
               "name": "BatchQty",
               "tagType": "AtomicTag"
             },
             {
               "name": "LowerLimit",
               "tagType": "AtomicTag"
             },
             {
               "name": "MaterialDesc",
               "tagType": "AtomicTag"
             },
             {
               "name": "BatchNo",
               "tagType": "AtomicTag"
             },
             {
               "name": "MaterialNo",
               "tagType": "AtomicTag"
             },
             {
               "name": "Uom",
               "tagType": "AtomicTag"
             },
             {
               "name": "Target",
               "tagType": "AtomicTag"
             }
           ]
         },
         {
           "parameters": {
             "Phase": {
               "dataType": "String",
               "value": "2010"
             }
           },
           "name": "WIP_10",
           "tagType": "UdtInstance",
           "tags": [
             {
               "name": "LowerLimit",
               "tagType": "AtomicTag"
             },
             {
               "name": "UpperLimit",
               "tagType": "AtomicTag"
             },
             {
               "name": "IsPhantom",
               "tagType": "AtomicTag"
             },
             {
               "name": "BatchQty",
               "tagType": "AtomicTag"
             },
             {
               "name": "QuantityUom",
               "tagType": "AtomicTag"
             },
             {
               "name": "EquipID",
               "tagType": "AtomicTag"
             },
             {
               "name": "BagSize",
               "tagType": "AtomicTag"
             },
             {
               "name": "MaterialDesc",
               "tagType": "AtomicTag"
             },
             {
               "name": "Quantity",
               "tagType": "AtomicTag"
             },
             {
               "name": "MaterialNo",
               "tagType": "AtomicTag"
             },
             {
               "name": "Uom",
               "tagType": "AtomicTag"
             },
             {
               "name": "Target",
               "tagType": "AtomicTag"
             },
             {
               "name": "BatchNo",
               "tagType": "AtomicTag"
             }
           ]
         },
         {
           "parameters": {
             "Phase": {
               "dataType": "String",
               "value": "2010"
             }
           },
           "name": "WIP_8",
           "tagType": "UdtInstance",
           "tags": [
             {
               "name": "UpperLimit",
               "tagType": "AtomicTag"
             },
             {
               "name": "MaterialNo",
               "tagType": "AtomicTag"
             },
             {
               "name": "Quantity",
               "tagType": "AtomicTag"
             },
             {
               "name": "BagSize",
               "tagType": "AtomicTag"
             },
             {
               "name": "Uom",
               "tagType": "AtomicTag"
             },
             {
               "name": "IsPhantom",
               "tagType": "AtomicTag"
             },
             {
               "name": "LowerLimit",
               "tagType": "AtomicTag"
             },
             {
               "name": "MaterialDesc",
               "tagType": "AtomicTag"
             },
             {
               "name": "BatchNo",
               "tagType": "AtomicTag"
             },
             {
               "name": "Target",
               "tagType": "AtomicTag"
             },
             {
               "name": "QuantityUom",
               "tagType": "AtomicTag"
             },
             {
               "name": "BatchQty",
               "tagType": "AtomicTag"
             },
             {
               "name": "EquipID",
               "tagType": "AtomicTag"
             }
           ]
         },
         {
           "parameters": {
             "Phase": {
               "dataType": "String",
               "value": "2010"
             }
           },
           "name": "WIP_9",
           "tagType": "UdtInstance",
           "tags": [
             {
               "name": "UpperLimit",
               "tagType": "AtomicTag"
             },
             {
               "name": "MaterialNo",
               "tagType": "AtomicTag"
             },
             {
               "name": "MaterialDesc",
               "tagType": "AtomicTag"
             },
             {
               "name": "BatchNo",
               "tagType": "AtomicTag"
             },
             {
               "name": "LowerLimit",
               "tagType": "AtomicTag"
             },
             {
               "name": "BatchQty",
               "tagType": "AtomicTag"
             },
             {
               "name": "IsPhantom",
               "tagType": "AtomicTag"
             },
             {
               "name": "QuantityUom",
               "tagType": "AtomicTag"
             },
             {
               "name": "EquipID",
               "tagType": "AtomicTag"
             },
             {
               "name": "Target",
               "tagType": "AtomicTag"
             },
             {
               "name": "Uom",
               "tagType": "AtomicTag"
             },
             {
               "name": "BagSize",
               "tagType": "AtomicTag"
             },
             {
               "name": "Quantity",
               "tagType": "AtomicTag"
             }
           ]
         },
         {
           "parameters": {
             "Phase": {
               "dataType": "String",
               "value": "2010"
             }
           },
           "name": "WIP_17",
           "tagType": "UdtInstance",
           "tags": [
             {
               "name": "BatchQty",
               "tagType": "AtomicTag"
             },
             {
               "name": "IsPhantom",
               "tagType": "AtomicTag"
             },
             {
               "name": "LowerLimit",
               "tagType": "AtomicTag"
             },
             {
               "name": "UpperLimit",
               "tagType": "AtomicTag"
             },
             {
               "name": "EquipID",
               "tagType": "AtomicTag"
             },
             {
               "name": "QuantityUom",
               "tagType": "AtomicTag"
             },
             {
               "name": "BagSize",
               "tagType": "AtomicTag"
             },
             {
               "name": "Uom",
               "tagType": "AtomicTag"
             },
             {
               "name": "MaterialDesc",
               "tagType": "AtomicTag"
             },
             {
               "name": "Quantity",
               "tagType": "AtomicTag"
             },
             {
               "name": "BatchNo",
               "tagType": "AtomicTag"
             },
             {
               "name": "MaterialNo",
               "tagType": "AtomicTag"
             },
             {
               "name": "Target",
               "tagType": "AtomicTag"
             }
           ]
         },
         {
           "parameters": {
             "Phase": {
               "dataType": "String",
               "value": "2010"
             }
           },
           "name": "WIP_6",
           "tagType": "UdtInstance",
           "tags": [
             {
               "name": "MaterialNo",
               "tagType": "AtomicTag"
             },
             {
               "name": "LowerLimit",
               "tagType": "AtomicTag"
             },
             {
               "name": "UpperLimit",
               "tagType": "AtomicTag"
             },
             {
               "name": "BatchQty",
               "tagType": "AtomicTag"
             },
             {
               "name": "MaterialDesc",
               "tagType": "AtomicTag"
             },
             {
               "name": "Uom",
               "tagType": "AtomicTag"
             },
             {
               "name": "IsPhantom",
               "tagType": "AtomicTag"
             },
             {
               "name": "Target",
               "tagType": "AtomicTag"
             },
             {
               "name": "BatchNo",
               "tagType": "AtomicTag"
             },
             {
               "name": "QuantityUom",
               "tagType": "AtomicTag"
             },
             {
               "name": "EquipID",
               "tagType": "AtomicTag"
             },
             {
               "name": "BagSize",
               "tagType": "AtomicTag"
             },
             {
               "name": "Quantity",
               "tagType": "AtomicTag"
             }
           ]
         },
         {
           "parameters": {
             "Phase": {
               "dataType": "String",
               "value": "2010"
             }
           },
           "name": "WIP_4",
           "tagType": "UdtInstance",
           "tags": [
             {
               "name": "BatchQty",
               "tagType": "AtomicTag"
             },
             {
               "name": "IsPhantom",
               "tagType": "AtomicTag"
             },
             {
               "name": "LowerLimit",
               "tagType": "AtomicTag"
             },
             {
               "name": "UpperLimit",
               "tagType": "AtomicTag"
             },
             {
               "name": "QuantityUom",
               "tagType": "AtomicTag"
             },
             {
               "name": "EquipID",
               "tagType": "AtomicTag"
             },
             {
               "name": "BagSize",
               "tagType": "AtomicTag"
             },
             {
               "name": "MaterialDesc",
               "tagType": "AtomicTag"
             },
             {
               "name": "Quantity",
               "tagType": "AtomicTag"
             },
             {
               "name": "Uom",
               "tagType": "AtomicTag"
             },
             {
               "name": "MaterialNo",
               "tagType": "AtomicTag"
             },
             {
               "name": "BatchNo",
               "tagType": "AtomicTag"
             },
             {
               "name": "Target",
               "tagType": "AtomicTag"
             }
           ]
         },
         {
           "parameters": {
             "Phase": {
               "dataType": "String",
               "value": "2010"
             }
           },
           "name": "WIP_15",
           "tagType": "UdtInstance",
           "tags": [
             {
               "name": "UpperLimit",
               "tagType": "AtomicTag"
             },
             {
               "name": "MaterialNo",
               "tagType": "AtomicTag"
             },
             {
               "name": "MaterialDesc",
               "tagType": "AtomicTag"
             },
             {
               "name": "Uom",
               "tagType": "AtomicTag"
             },
             {
               "name": "BatchNo",
               "tagType": "AtomicTag"
             },
             {
               "name": "EquipID",
               "tagType": "AtomicTag"
             },
             {
               "name": "QuantityUom",
               "tagType": "AtomicTag"
             },
             {
               "name": "LowerLimit",
               "tagType": "AtomicTag"
             },
             {
               "name": "IsPhantom",
               "tagType": "AtomicTag"
             },
             {
               "name": "BatchQty",
               "tagType": "AtomicTag"
             },
             {
               "name": "Target",
               "tagType": "AtomicTag"
             },
             {
               "name": "BagSize",
               "tagType": "AtomicTag"
             },
             {
               "name": "Quantity",
               "tagType": "AtomicTag"
             }
           ]
         },
         {
           "parameters": {
             "Phase": {
               "dataType": "String",
               "value": "2010"
             }
           },
           "name": "WIP_11",
           "tagType": "UdtInstance",
           "tags": [
             {
               "name": "QuantityUom",
               "tagType": "AtomicTag"
             },
             {
               "name": "EquipID",
               "tagType": "AtomicTag"
             },
             {
               "name": "BatchQty",
               "tagType": "AtomicTag"
             },
             {
               "name": "IsPhantom",
               "tagType": "AtomicTag"
             },
             {
               "name": "BatchNo",
               "tagType": "AtomicTag"
             },
             {
               "name": "LowerLimit",
               "tagType": "AtomicTag"
             },
             {
               "name": "UpperLimit",
               "tagType": "AtomicTag"
             },
             {
               "name": "BagSize",
               "tagType": "AtomicTag"
             },
             {
               "name": "MaterialDesc",
               "tagType": "AtomicTag"
             },
             {
               "name": "Quantity",
               "tagType": "AtomicTag"
             },
             {
               "name": "Target",
               "tagType": "AtomicTag"
             },
             {
               "name": "MaterialNo",
               "tagType": "AtomicTag"
             },
             {
               "name": "Uom",
               "tagType": "AtomicTag"
             }
           ]
         },
         {
           "parameters": {
             "Phase": {
               "dataType": "String",
               "value": "2010"
             }
           },
           "name": "WIP_16",
           "tagType": "UdtInstance",
           "tags": [
             {
               "name": "BatchNo",
               "tagType": "AtomicTag"
             },
             {
               "name": "MaterialNo",
               "tagType": "AtomicTag"
             },
             {
               "name": "UpperLimit",
               "tagType": "AtomicTag"
             },
             {
               "name": "LowerLimit",
               "tagType": "AtomicTag"
             },
             {
               "name": "BatchQty",
               "tagType": "AtomicTag"
             },
             {
               "name": "IsPhantom",
               "tagType": "AtomicTag"
             },
             {
               "name": "EquipID",
               "tagType": "AtomicTag"
             },
             {
               "name": "QuantityUom",
               "tagType": "AtomicTag"
             },
             {
               "name": "MaterialDesc",
               "tagType": "AtomicTag"
             },
             {
               "name": "Quantity",
               "tagType": "AtomicTag"
             },
             {
               "name": "BagSize",
               "tagType": "AtomicTag"
             },
             {
               "name": "Uom",
               "tagType": "AtomicTag"
             },
             {
               "name": "Target",
               "tagType": "AtomicTag"
             }
           ]
         },
         {
           "parameters": {
             "Phase": {
               "dataType": "String",
               "value": "2010"
             }
           },
           "name": "WIP_7",
           "tagType": "UdtInstance",
           "tags": [
             {
               "name": "UpperLimit",
               "tagType": "AtomicTag"
             },
             {
               "name": "MaterialNo",
               "tagType": "AtomicTag"
             },
             {
               "name": "BatchNo",
               "tagType": "AtomicTag"
             },
             {
               "name": "MaterialDesc",
               "tagType": "AtomicTag"
             },
             {
               "name": "IsPhantom",
               "tagType": "AtomicTag"
             },
             {
               "name": "LowerLimit",
               "tagType": "AtomicTag"
             },
             {
               "name": "QuantityUom",
               "tagType": "AtomicTag"
             },
             {
               "name": "BatchQty",
               "tagType": "AtomicTag"
             },
             {
               "name": "EquipID",
               "tagType": "AtomicTag"
             },
             {
               "name": "Target",
               "tagType": "AtomicTag"
             },
             {
               "name": "BagSize",
               "tagType": "AtomicTag"
             },
             {
               "name": "Uom",
               "tagType": "AtomicTag"
             },
             {
               "name": "Quantity",
               "tagType": "AtomicTag"
             }
           ]
         },
         {
           "name": "WIP_1",
           "tagType": "UdtInstance",
           "tags": [
             {
               "name": "MaterialDesc",
               "tagType": "AtomicTag"
             },
             {
               "name": "BagSize",
               "tagType": "AtomicTag"
             },
             {
               "name": "Quantity",
               "tagType": "AtomicTag"
             },
             {
               "name": "Uom",
               "tagType": "AtomicTag"
             },
             {
               "name": "QuantityUom",
               "tagType": "AtomicTag"
             },
             {
               "name": "UpperLimit",
               "tagType": "AtomicTag"
             },
             {
               "name": "EquipID",
               "tagType": "AtomicTag"
             },
             {
               "name": "BatchQty",
               "tagType": "AtomicTag"
             },
             {
               "name": "Target",
               "tagType": "AtomicTag"
             },
             {
               "name": "IsPhantom",
               "tagType": "AtomicTag"
             },
             {
               "name": "LowerLimit",
               "tagType": "AtomicTag"
             },
             {
               "name": "BatchNo",
               "tagType": "AtomicTag"
             },
             {
               "name": "MaterialNo",
               "tagType": "AtomicTag"
             }
           ]
         },
         {
           "parameters": {
             "Phase": {
               "dataType": "String",
               "value": "2010"
             }
           },
           "name": "WIP_5",
           "tagType": "UdtInstance",
           "tags": [
             {
               "name": "BagSize",
               "tagType": "AtomicTag"
             },
             {
               "name": "Uom",
               "tagType": "AtomicTag"
             },
             {
               "name": "MaterialDesc",
               "tagType": "AtomicTag"
             },
             {
               "name": "Quantity",
               "tagType": "AtomicTag"
             },
             {
               "name": "UpperLimit",
               "tagType": "AtomicTag"
             },
             {
               "name": "QuantityUom",
               "tagType": "AtomicTag"
             },
             {
               "name": "EquipID",
               "tagType": "AtomicTag"
             },
             {
               "name": "BatchQty",
               "tagType": "AtomicTag"
             },
             {
               "name": "IsPhantom",
               "tagType": "AtomicTag"
             },
             {
               "name": "LowerLimit",
               "tagType": "AtomicTag"
             },
             {
               "name": "MaterialNo",
               "tagType": "AtomicTag"
             },
             {
               "name": "BatchNo",
               "tagType": "AtomicTag"
             },
             {
               "name": "Target",
               "tagType": "AtomicTag"
             }
           ]
         },
         {
           "parameters": {
             "Phase": {
               "dataType": "String",
               "value": "2010"
             }
           },
           "name": "WIP_3",
           "tagType": "UdtInstance",
           "tags": [
             {
               "name": "BatchQty",
               "tagType": "AtomicTag"
             },
             {
               "name": "IsPhantom",
               "tagType": "AtomicTag"
             },
             {
               "name": "LowerLimit",
               "tagType": "AtomicTag"
             },
             {
               "name": "Uom",
               "tagType": "AtomicTag"
             },
             {
               "name": "BatchNo",
               "tagType": "AtomicTag"
             },
             {
               "name": "MaterialNo",
               "tagType": "AtomicTag"
             },
             {
               "name": "MaterialDesc",
               "tagType": "AtomicTag"
             },
             {
               "name": "Target",
               "tagType": "AtomicTag"
             },
             {
               "name": "BagSize",
               "tagType": "AtomicTag"
             },
             {
               "name": "Quantity",
               "tagType": "AtomicTag"
             },
             {
               "name": "UpperLimit",
               "tagType": "AtomicTag"
             },
             {
               "name": "EquipID",
               "tagType": "AtomicTag"
             },
             {
               "name": "QuantityUom",
               "tagType": "AtomicTag"
             }
           ]
         },
         {
           "parameters": {
             "Phase": {
               "dataType": "String",
               "value": "2010"
             }
           },
           "name": "WIP_2",
           "tagType": "UdtInstance",
           "tags": [
             {
               "name": "LowerLimit",
               "tagType": "AtomicTag"
             },
             {
               "name": "MaterialNo",
               "tagType": "AtomicTag"
             },
             {
               "name": "BatchNo",
               "tagType": "AtomicTag"
             },
             {
               "name": "MaterialDesc",
               "tagType": "AtomicTag"
             },
             {
               "name": "Quantity",
               "tagType": "AtomicTag"
             },
             {
               "name": "Uom",
               "tagType": "AtomicTag"
             },
             {
               "name": "Target",
               "tagType": "AtomicTag"
             },
             {
               "name": "BagSize",
               "tagType": "AtomicTag"
             },
             {
               "name": "QuantityUom",
               "tagType": "AtomicTag"
             },
             {
               "name": "IsPhantom",
               "tagType": "AtomicTag"
             },
             {
               "name": "UpperLimit",
               "tagType": "AtomicTag"
             },
             {
               "name": "EquipID",
               "tagType": "AtomicTag"
             },
             {
               "name": "BatchQty",
               "tagType": "AtomicTag"
             }
           ]
         }
       ]
     }
   ]}
 	return folder
	 
def po(basepath,config,cnt):
	MII_Ignition_Library.Logger.Insert_Log.Insert_Error_Log('PO', "Started")
 	for i in range(3):
 		if config[i]==True:
 			tag=[]
 			path="20"+str(i+1)+"0"
 			print path
 			print tag
 			j=0
 			if i>0:
 				for j in range(cnt[i-1]):
 					if cnt[i-1]>1:
 						if j==0:
 							p1={"name": path,"tagType": "Folder","tags": [WcConfigurationnewnew.paths(j)]}
 							system.tag.configure(basepath, [p1],"a")
 						else:
 							p1=WcConfigurationnewnew.paths(j)
 							bp1=basepath+"/"+path
 							system.tag.configure(bp1, [p1],"a")
 					else:
 						tag=(WcConfigurationnew.paths(path))
 						system.tag.configure(basepath, [tag],"a")
 			else:
 				tag=(WcConfigurationnew.paths(path))
 				system.tag.configure(basepath, [tag],"a")
 	tag={
 	  "name": "PhaseUNS",
 	  "tagType": "Folder",
 	  "tags": [
 	    {
 	      "valueSource": "memory",
 	      "dataType": "String",
 	      "name": "pMIIPHPOOEE",
 	      "tagType": "AtomicTag"
 	    },
 	    {
 	      "valueSource": "memory",
 	      "dataType": "String",
 	      "name": "pMIIPHStatusOEE",
 	      "tagType": "AtomicTag"
 	    },
 	    {
 	      "valueSource": "memory",
 	      "dataType": "String",
 	      "name": "pMIIPHMaterialOEE",
 	      "tagType": "AtomicTag"
 	    },
 	    {
 	      "valueSource": "memory",
 	      "dataType": "String",
 	      "name": "pMIIPHPhaseOEE",
 	      "tagType": "AtomicTag"
 	    },
 	    {
 	      "valueSource": "memory",
 	      "dataType": "String",
 	      "name": "pMIIPHZoneOEE",
 	      "tagType": "AtomicTag"
 	    }
 	  ]
 	}
 	system.tag.configure(basepath, [tag],"a") 
	MII_Ignition_Library.Logger.Insert_Log.Insert_Error_Log('PO', "Success")