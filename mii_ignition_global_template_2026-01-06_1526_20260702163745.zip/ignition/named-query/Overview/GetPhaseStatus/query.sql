Select PhaseStatus from ufn_GetWorkCells( :client , :plant )
JOIN tblWorkCenterMaster 
ON ufn_GetWorkCells.ARBPL = tblWorkCenterMaster.RESOURCE_NAME
WHERE [Order] =  :order 