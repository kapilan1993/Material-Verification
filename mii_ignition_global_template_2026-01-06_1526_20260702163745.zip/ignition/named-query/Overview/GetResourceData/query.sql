Select [ARBPL],[Order],[SAPResourceName] from ufn_GetWorkCells( :client , :plant )
JOIN tblWorkCenterMaster 
ON ufn_GetWorkCells.ARBPL = tblWorkCenterMaster.RESOURCE_NAME
Where ufn_GetWorkCells.ARBPL = :resource
Order By  ufn_GetWorkCells.AREA DESC, ufn_GetWorkCells.ARBPL DESC, ufn_GetWorkCells.EventTime DESC