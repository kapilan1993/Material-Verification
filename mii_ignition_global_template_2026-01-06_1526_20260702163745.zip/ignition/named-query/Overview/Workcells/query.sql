Select * from ufn_GetWorkCells( :client , :plant )
JOIN tblWorkCenterMaster 
ON ufn_GetWorkCells.ARBPL = tblWorkCenterMaster.RESOURCE_NAME
Order By  ufn_GetWorkCells.AREA DESC, ufn_GetWorkCells.ARBPL DESC, ufn_GetWorkCells.EventTime DESC