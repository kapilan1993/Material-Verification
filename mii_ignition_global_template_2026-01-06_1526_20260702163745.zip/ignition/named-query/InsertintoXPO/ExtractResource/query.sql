DECLARE @PO_DATA  nvarchar(max)
DECLARE @PO_DATA_XML xml
DECLARE @hDoc AS INT
DECLARE @RESOURCE nvarchar(50)
SET @PO_DATA =(Select [PO_DATA] from [dbo].[xMII_PROCESS_ORDER_DATA] where [PROCESS_ORDER]=:PO)
Set @PO_DATA_XML = cast(replace(@PO_DATA,'<?xml version="1.0" encoding="UTF-8"?>','') as xml)
EXEC sp_xml_preparedocument @hDoc OUTPUT, @PO_DATA_XML 	
SET @RESOURCE = (SELECT T.REC.value('./Row[1]/ARBPL[1]','nvarchar(50)') as SAPResourceName FROM @PO_DATA_XML.nodes('/DOWNLOAD_RECIPE/PO_HEADER_PHASES/Rowsets/Rowset') AS T(REC))
Select @RESOURCE AS RESOURCE