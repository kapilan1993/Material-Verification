DECLARE @PO_DATA  nvarchar(max)
DECLARE @PO_DATA_XML xml
DECLARE @hDoc AS INT
DECLARE @RESOURCE nvarchar(50)
SET @PO_DATA =(Select [PO_DATA] from [dbo].[xMII_PROCESS_ORDER_DATA] where [PROCESS_ORDER]=:PO)
Set @PO_DATA_XML = cast(replace(@PO_DATA,'<?xml version="1.0" encoding="UTF-8"?>','') as xml)
EXEC sp_xml_preparedocument @hDoc OUTPUT, @PO_DATA_XML 	

   
INSERT INTO xPhase
  SELECT 
	  :PO,
   Q.REC.query('./ARBPL').value('.','nvarchar(50)') AS 'ARBPL',
   Q.REC.query('./PVZNR').value('.','nvarchar(5)') AS 'PVZNR',
   Q.REC.query('./VORNR').value('.','numeric(5)') AS 'VORNR',
   Q.REC.query('./STEUS').value('.','nvarchar(50)') AS 'STEUS',
   Q.REC.query('./MATNR').value('.','nvarchar(50)') AS 'MATNR',
   Q.REC.query('./PLNNR').value('.','nvarchar(50)') AS 'PLNNR',
   Q.REC.query('./AUART').value('.','nvarchar(50)') AS 'AUART',
   Q.REC.query('./MATKL').value('.','nvarchar(50)') AS 'MATKL',
   Q.REC.query('./MTART').value('.','nvarchar(50)') AS 'MTART'
  FROM @PO_DATA_XML.nodes('/DOWNLOAD_RECIPE/PO_HEADER_PHASES/Rowsets/Rowset/Row') AS Q(REC)