INSERT INTO XPO ([CLIENT],[PLANT],[RESOURCE],[AREA],[PROCESS_ORDER],[PO_DATA],[STATUS],[INSPLOT]
      ,[COLLECTIVE_LEADER]
      ,[COLLECTIVE_DEPENDENT]
      ,[COL_ORDER]
      ,[PO_DATA_Json]
      ,[CREATED_DATE]
      ,[CREATED_BY]
      ,[UPDATED_DATE]
      ,[UPDATED_BY]) 
      Select 
      [CLIENT],[PLANT],:RESOURCE ,[AREA],[PROCESS_ORDER],[PO_DATA],[STATUS] ,[INSPLOT]
      ,[Collective_Leader]
      ,[Collective_Dependent]
      ,[COL_ORDER]
       ,CONVERT(varchar(max),[PO_DATA_JSon])
      ,[CREATED_DATE]
      ,[CREATED_BY]
      ,[UPDATED_DATE]
      ,[UPDATED_BY]
      
      FROM [dbo].[xMII_PROCESS_ORDER_DATA] where PROCESS_ORDER= :PO 