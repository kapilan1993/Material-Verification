-----Update Workcenter
	 UPDATE [dbo].[tblWorkCenterMaster] 
	 SET    [TYPE]= :AREA
		 ,[DESCRIPTION] = :NODENAME
			,[UPDATED_ON]  =CURRENT_TIMESTAMP                 
	   ,[UPDATED_BY]  = 'trigger',
	   [AREA] =:AREA
	 where [RESOURCE_NAME] = :RESOURCE