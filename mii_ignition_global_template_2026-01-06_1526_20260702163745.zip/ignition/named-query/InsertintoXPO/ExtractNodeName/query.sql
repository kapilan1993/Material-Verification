DECLARE @PO_DATA  nvarchar(max)
DECLARE @PO_DATA_XML xml
DECLARE @hDoc AS INT
Declare @NODENAME varchar(255)

SET @PO_DATA =(Select [PO_DATA] from [dbo].[xMII_PROCESS_ORDER_DATA] where [PROCESS_ORDER]=:PO)
Set @PO_DATA_XML = cast(replace(@PO_DATA,'<?xml version="1.0" encoding="UTF-8"?>','') as xml)
EXEC sp_xml_preparedocument @hDoc OUTPUT, @PO_DATA_XML 
Set @NODENAME =(Select top 1 NODENAME FROM OPENXML(@hDoc, 'DOWNLOAD_RECIPE/PO_HEADER_PHASES/Rowsets/Rowset/Row')WITH ( NODENAME varchar(255) 'NODENAME'))	

Select @NODENAME AS NODENAME