SELECT * FROM  xMII_PO_Header_Phases 
WHERE CLIENT =  :client AND WERKS = :plant 