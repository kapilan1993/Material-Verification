INSERT INTO [dbo].[tblBbdMaterialHistory]
           ([PO_NUMBER]
           ,[MATERIAL]
            ,[BATCH]
           ,[UPDATED_ON]
           , UPDATE_BY )
     VALUES
           ( :po 
           , :material
           , :batch 
           ,GETDATE()
           , :updatedBy )