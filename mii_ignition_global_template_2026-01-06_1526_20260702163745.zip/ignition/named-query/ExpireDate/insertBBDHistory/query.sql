INSERT INTO [dbo].[tblBbdHistory]
           ([PO_NUMBER]
           ,[BBD]
           ,[UPDATED_ON]
           ,[UPDATED_BY])
     VALUES
           ( :po 
           , :bbd 
           ,GETDATE()
           , :updatedBy )