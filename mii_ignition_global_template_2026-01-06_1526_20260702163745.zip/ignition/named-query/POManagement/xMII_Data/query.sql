Select PO_Data_Json, PO_Data
From xMII_PROCESS_ORDER_DATA 
Where  CLIENT =  :CLIENT  and PLANT =  :PLANT  and PROCESS_ORDER =  :PO 