DECLARE @PO nvarchar(12) =:PO
BEGIN
	Delete p3 
	from xMII_PO_Header_Phases p3 
	join xMII_PROCESS_ORDER_DATA p1 on p3.AUFNR = p1.PROCESS_ORDER
	where p1.PROCESS_ORDER = @PO;
	
	Delete p2 
	from xMII_PO_Header p2 
	join xMII_PROCESS_ORDER_DATA p1 on p2.AUFNR = p1.PROCESS_ORDER
	where p1.PROCESS_ORDER = @PO;
	
	Delete p1
	from xMII_PROCESS_ORDER_DATA p1
	where p1.PROCESS_ORDER = @PO
END