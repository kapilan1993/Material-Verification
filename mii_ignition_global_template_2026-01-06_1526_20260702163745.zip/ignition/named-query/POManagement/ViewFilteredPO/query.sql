Select * from ufn_GetScheduleMonitor_GlobalTemplate(:client,  :plant , :po,   :resource  , :startTime , :endTime )

--Select * from ufn_GetScheduleMonitor(:client,  :plant , :po,   :resource  , :startTime , :endTime )