Select * from ufn_GetGoodsIssuePerMaterial( :Client , :Plant , :PO, :SAPResourceName)
WHERE BDMNG > '0'
Order By RSPOS ASC