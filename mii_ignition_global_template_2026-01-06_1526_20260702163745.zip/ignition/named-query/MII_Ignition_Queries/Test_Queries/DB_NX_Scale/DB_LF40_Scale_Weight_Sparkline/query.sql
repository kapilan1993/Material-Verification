Select wc, po, Net_W 
From  LF40_scale_weight_data 
where wc = :wc  and po= :po 


