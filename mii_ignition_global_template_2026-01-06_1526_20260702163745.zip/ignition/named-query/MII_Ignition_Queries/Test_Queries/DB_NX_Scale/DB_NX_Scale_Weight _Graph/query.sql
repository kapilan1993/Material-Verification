SELECT  datetime(t_stamp/1000,'unixepoch') as t_stamp, Net_W
FROM scale_weight_data 
order by t_stamp
