SELECT lf40_scale_weight_data_ndx,wc,po, Gross_W, Lower_Limit, Net_W, Pass_not_Pass, Setpoint, Tare_W, Tolerance_Percent, Units, Upper_Limit, datetime(t_stamp/1000,'unixepoch') as t_stamp
FROM LF40_scale_weight_data 
where wc= :wc  and po =  :po 
order by lf40_scale_weight_data_ndx desc
