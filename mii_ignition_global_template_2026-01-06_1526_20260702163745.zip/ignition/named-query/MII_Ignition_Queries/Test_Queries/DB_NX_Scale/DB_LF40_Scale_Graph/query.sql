SELECT wc, po,Net_W, COUNT(Net_W) as Count 
FROM LF40_scale_weight_data
where wc= :wc  and po =  :po
Group By Net_W;