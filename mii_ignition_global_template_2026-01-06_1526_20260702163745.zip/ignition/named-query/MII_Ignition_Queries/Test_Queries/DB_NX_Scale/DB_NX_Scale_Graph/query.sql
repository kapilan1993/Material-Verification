SELECT Net_W, COUNT(Net_W) as Count 
FROM scale_weight_data
Group By Net_W;