SELECT scale_weight_data_ndx, Gross_W, Lower_Limit, Net_W, Pass_not_Pass, Setpoint, Tare_W, Tolerance_Percent, Units, Upper_Limit, datetime(t_stamp/1000,'unixepoch') as t_stamp
FROM scale_weight_data 
order by scale_weight_data_ndx desc
