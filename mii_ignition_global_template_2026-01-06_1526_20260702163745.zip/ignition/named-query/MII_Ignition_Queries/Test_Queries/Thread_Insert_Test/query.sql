INSERT INTO [IGNPEDB].[dbo].[GatewayEventTestThread](Work_Center,Ignition_Time)
Values( :Work_Center ,  :Ignition_Posted_Time )