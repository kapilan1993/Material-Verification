SELECT TOP (1) [STATE]
FROM [dbo].[xMII_PO_STATE]
WHERE CLIENT =  :Client  and PLANT =  :Plant  and PROCESS_ORDER =  :PO 
Order By ID DESC