DELETE FROM [dbo].[xMII_Checkweigher_Raw_Data]
WHERE Message LIKE '%WD_OK%' or Message = ''