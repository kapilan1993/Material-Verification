  SELECT TOP (1) *
  FROM [dbo].[xMII_Queue_Message_Log]
  WHERE SAPClient =  :Client  and SAPPlant =  :Plant and Work_Center =  :Work_Center   and Processed = '0' and Attempts < Retry_Limit