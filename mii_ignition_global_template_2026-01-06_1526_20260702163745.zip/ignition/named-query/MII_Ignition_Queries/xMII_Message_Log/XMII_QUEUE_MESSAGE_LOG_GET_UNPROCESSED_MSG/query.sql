  SELECT TOP (1) * FROM [dbo].[xMII_Queue_Message_Log]
  WHERE SAPClient =  :SAPClient  and SAPPlant =  :SAPPlant  and Processed = 0 
  and Attempts < Retry_Limit
  Order By ID ASC