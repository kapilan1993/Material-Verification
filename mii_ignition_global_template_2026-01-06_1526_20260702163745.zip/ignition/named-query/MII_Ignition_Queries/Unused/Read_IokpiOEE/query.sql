SELECT *
FROM xMII_Oee_IokpiOEE
WHERE [order] =  :Order 