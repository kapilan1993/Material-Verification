UPDATE xMII_Ignition_PO_PHASES_RESB 
SET Reported_Quantity =  CONVERT(nvarchar(50),CAST((SELECT Reported_Quantity FROM xMII_Ignition_PO_PHASES_RESB WHERE AUFNR = :PO  and MATNR =  :Material  and RSPOS = :RSPOS   ) AS decimal(18,3)) + :Qty) 
WHERE AUFNR = :PO  and MATNR =  :Material  and RSPOS = :RSPOS 