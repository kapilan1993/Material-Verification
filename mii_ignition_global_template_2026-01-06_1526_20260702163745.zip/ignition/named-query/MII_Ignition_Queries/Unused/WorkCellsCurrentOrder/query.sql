	Select "Order" as 'PO' from ufn_GetWorkCells( :client , :plant )
	where ARBPL =  :ARBPL 
	Order By  AREA DESC, ARBPL DESC, EventTime DESC