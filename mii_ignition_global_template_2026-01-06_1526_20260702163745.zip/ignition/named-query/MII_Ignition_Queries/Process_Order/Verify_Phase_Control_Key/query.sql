SELECT TOP (1) STEUS
FROM [dbo].[xMII_PO_Header_Phases]
WHERE CLIENT =  :Client  and WERKS =  :Plant  and AUFNR =  :PO  and VORNR =  :Phase 