UPDATE xMII_PO_Header_Phases
SET ARBPL =  :To_Work_Center , [DESCRIPTION] =   :To_Node_Name , NODE_ID =  :To_Node_ID , NODENAME =  :To_Node_Name 
WHERE CLIENT =  :Client and WERKS =  :Plant  and AUFNR =  :PO  and (PVZNR =  :Operation  or (PVZNR = '---' and VORNR =  :Operation))

EXEC [dbo].[usp_xMII_Update_Download_JSON]  :Client, :Plant, :PO, :Operation , :From_Work_Center, :From_Node_Name, :From_Node_ID, :To_Work_Center , :To_Node_Name , :To_Node_ID 

EXEC [dbo].[usp_xMII_Update_Download_XML]  :Client, :Plant, :PO, :Operation , :From_Work_Center, :From_Node_Name, :From_Node_ID, :To_Work_Center , :To_Node_Name , :To_Node_ID 
