Select * from ufn_GetPOHeaderPhasesLocalStatus( :Client , :Plant , :PO,  :SAPResourceName  )
	WHERE row_num = '1'
	Order By VORNR ASC