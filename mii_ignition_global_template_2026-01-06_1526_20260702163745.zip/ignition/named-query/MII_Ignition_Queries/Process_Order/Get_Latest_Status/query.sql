Select TOP(1) Phase_Status_Requested, Phase_Status, MII_PO_STATUS, S4_MII_STATUS
from ufn_GetPhase_PO_S4_MII_Status( :Client , :Plant , :PO , :SAPResourceName , :Message_Type ) 
where row_number = 1
Order By Phase_Status_Precedence DESC