Select * from ufn_GetScheduleMonitor(:client,  :plant , :po,   :resource  , :startTime , :endTime )
Order By GSTRS DESC, AUFNR ASC, VORNR ASC
