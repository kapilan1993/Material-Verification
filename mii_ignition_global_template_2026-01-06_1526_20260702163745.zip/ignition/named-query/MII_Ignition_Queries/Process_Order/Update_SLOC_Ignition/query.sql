UPDATE xMII_PO_Header
SET ORDERLGORT =   :SLOC 
WHERE CLIENT =  :Client and WERKS =  :Plant  and AUFNR =  :PO  


UPDATE xMII_PO_Header_Phases
SET ORDERLGORT =   :SLOC 
WHERE CLIENT =  :Client and WERKS =  :Plant  and AUFNR =  :PO  
