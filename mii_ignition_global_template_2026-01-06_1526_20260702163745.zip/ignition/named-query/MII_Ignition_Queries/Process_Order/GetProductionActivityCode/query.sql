SELECT  [client]
      ,[plant]
      ,[order]
      ,[routingOperNo]
      ,[productionActivity]
	  ,resource
  FROM [dbo].[xMII_Oee_RawDataByPhase]
  WHERE client =  :client  and plant =  :plant  and [order] =  :order and resource =  :resource  and routingOperNo =  :phase 