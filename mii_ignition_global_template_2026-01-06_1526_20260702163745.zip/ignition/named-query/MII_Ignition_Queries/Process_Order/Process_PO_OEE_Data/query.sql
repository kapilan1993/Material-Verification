BEGIN TRANSACTION;

BEGIN TRY
    
	-- Remove Previous Records
    DELETE FROM [dbo].[OEE_Data_Ignition]
    WHERE client =  :client  AND plant =  :plant  AND [order] =  :order  AND [resource] =  :resource;
    
    -- Insert New Records
    INSERT INTO [dbo].[OEE_Data_Ignition]
    SELECT * FROM ufn_Get_OEE_Data_Ignition( :client ,  :plant ,  :order ,  :SAPResourceName );

    -- Commit the transaction
   
   COMMIT TRANSACTION;

END TRY

BEGIN CATCH
   
   -- Rollback the transaction in case of an error
   
   ROLLBACK TRANSACTION;

END CATCH;