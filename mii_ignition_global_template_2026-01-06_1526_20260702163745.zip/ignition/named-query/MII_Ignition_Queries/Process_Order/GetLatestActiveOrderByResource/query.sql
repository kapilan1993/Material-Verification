Select [order] from ufn_GetLatestOrderPhaseStatusByResource( :client , :plant ,'', :SAPResourceName ,'<Phase_Status>')
WHERE SAPResourceName =  :SAPResourceName