Select * from ufn_GetGoodsIssuePerMaterial( :Client , :Plant , :PO,  :SAPResourceName  )
WHERE BDMNG > '0' and MATNR =  :Material 
Order By RSPOS ASC