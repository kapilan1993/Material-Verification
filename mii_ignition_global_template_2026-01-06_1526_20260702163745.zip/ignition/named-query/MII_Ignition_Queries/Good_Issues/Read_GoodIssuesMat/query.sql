Select MATNR as 'value', MATNR as 'label' from ufn_GetGoodsIssuePerMaterial( :Client , :Plant , :PO )
WHERE BDMNG > '0' and MEINS = 'KG'
Order By RSPOS ASC