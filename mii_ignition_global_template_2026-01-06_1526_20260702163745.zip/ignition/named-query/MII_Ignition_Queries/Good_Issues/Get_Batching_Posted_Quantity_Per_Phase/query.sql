SELECT SUM(POSTED_QUANTITY) as 'POSTED_QUANTITY' 

FROM (


SELECT
 
	CLIENT,
	WERKS,
	AUFNR,
	ARBPL,
	MATNR,
	MATNR_DESC,
	BDMNG,
	MEINS,
	ING_TARGET,
	ING_TARGET_LL,
	ING_TARGET_UL,
	CHARG,
	LGORT,
	BWART,
	WAREHOUSE_NO,
	PVZNR,
	VORNR,
	RSPOS,
	RSNUM,
	BACKFLUSH,
	MTART = CASE WHEN MTART = '---' 
			
	and (SELECT TOP (1) ID FROM [dbo].[ABS_ConfigRecipe_Phases_Relationship] 
	WHERE Client = CLIENT and WERKS = WERKS and Phase = VORNR and InstructionParmName = 'REMNANT') IS NOT NULL
			
	then (Select MTART FROM [dbo].[xMII_PO_Header] 
	WHERE ORDERCHARG = CHARG)
			
	else MTART
			
	end,
	POSTED_QUANTITY,
	POSTED_QUANTITY_UOM,
	POSTED_QUANTITY_261,
	POSTED_QUANTITY_262,
	SAPResourceName,
	
ROW_NUMBER() OVER(PARTITION BY MATNR ORDER BY MATNR ASC) AS row_number


FROM ufn_GetGoodsIssuePerMaterial(  :Client  ,   :Plant  ,  :PO  ,  :SAPResourceName  )
WHERE BDMNG > '0'

) T
 
WHERE row_number = 1 and MTART in ('ROH','HALB') and MEINS = 'KG' and VORNR =   :Phase 