Select TOP(1)
Machine_Status,Client,Plant,[Order],Resource,Phase,Reason_ID,Description,Comment,Event_Time
FROM ufn_GetMachineStatus( :Client , :Plant , :Order,  :SAPResourceName  )  
Order By  Event_Time DESC, Machine_Status ASC