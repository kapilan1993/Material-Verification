Select * from ufn_GetMachineStatus( :Client , :Plant , :Order,  :SAPResourceName  )  
	Order By Event_Time ASC