BEGIN TRANSACTION;

BEGIN TRY
    
	-- Remove Previous Records
    DELETE FROM [dbo].[Downtime_Data_Ignition]
    WHERE client =  :client  AND plant =  :plant  AND [order] =  :order  AND [resource] =  :resource;
    
    -- Insert New Records
    INSERT INTO [dbo].[Downtime_Data_Ignition](client, plant, [order], [resource], nodeDescription, routingOperNo,
	downtimeType, DC_ELEMENT, EFFEC_DURATION, EFFEC_DURATION_UOM, START_TIMESTAMP, END_TIMESTAMP,
	REASON_CODE1, REASON_CODE2, REASON_CODE3, REASON_CODE4, REASON_CODE5, REASON_CODE6, REASON_CODE7, REASON_CODE8,
	REASON_CODE9, REASON_CODE10, [DESCRIPTION], COMMENTS, CREATED_BY)
	
	Select Client, Plant, [Order], [Resource], SAPResourceName, Phase, Event_Type, DC_Element, (DT_Duration_Sec / 60), 'MIN',
	Unscheddown_Event_Time, Uptime_Event_Time,REASON_CODE1,REASON_CODE2,REASON_CODE3,REASON_CODE4,REASON_CODE5,REASON_CODE6,
	REASON_CODE7,REASON_CODE8,REASON_CODE9,REASON_CODE10, [Description], Comment, CREATED_BY
	from ufn_GetMachineStatusDuration(:client, :plant,:order, :SAPResourceName );

    -- Commit the transaction
   
   COMMIT TRANSACTION;

END TRY

BEGIN CATCH
   
   -- Rollback the transaction in case of an error
   
   ROLLBACK TRANSACTION;

END CATCH;