SELECT *
FROM [dbo].[Downtime_Data_Ignition]
WHERE client =  :client  and plant =  :plant  and [order] =  :order  and [resource] =  :resource