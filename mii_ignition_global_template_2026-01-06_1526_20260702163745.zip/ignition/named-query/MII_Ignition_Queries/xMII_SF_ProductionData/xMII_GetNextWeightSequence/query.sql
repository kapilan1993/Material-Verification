SELECT ISNULL(MAX(PDSequence_IN) + 1,1) As 'PDSequence_IN' FROM [dbo].[SF_ProductionData]
WHERE PDClient_VC =  :client  and PDPlant_VC =  :plant  and PDOrder_CH =  :order 
and PDHeadNo_IN =  :head_number  and PDHeadMaterial_VC =  :material 