INSERT INTO [dbo].[SF_ProductionData]
  ([PDClient_VC],[PDPlant_VC],[PDOrder_CH],[PDBatch_VC],[PDMaterial_VC],[PDResource_VC],[PDNodeName_VC]
  ,[PDNodeID_VC],[PDEquipment_VC],[PDOperator_VC],[PDOP_VC],[PDPhase_VC],[PDSequence_IN],[PDHeadNo_IN]
  ,[PDHeadMaterial_VC],[PDSetPoint_DC],[PDSetPointUOM_VC],[PDSpTolMin_DC],[PDSpTolMax_DC],[PDTareWt_DC]
  ,[PDValue_DC],[PDValue_VC],[PDValueUOM_VC],[PDGrossWt_DC],[PDGrossUOM_VC],[PDStart_DT],[PD_End_DT]
  ,[PDRejected_VC],[PDAcceptedOutofSpec_BT],[PDComments_VC],[PDChecksum_IN],[PDInsDateTime_DT],[PDxMIIPostedStampTime_DT])
  VALUES( :client , :plant , :order , :batch , :material , :resource , :nodename 
         ,'', :nodename2 ,'MII', :operation , :phase , :sequence , :scale_head_number 
		 , :scale_head_material , :setpoint , :setpointUOM , :MinSetpoint , :MaxSetpoint , :Tare 
		 , :CapturedValue ,'', :CapturedValueUOM , :GrossWeight , :GrossWeightUOM ,convert(varchar, getdate(), 121),convert(varchar, getdate(), 121)
		 , :RejectedFlag ,'0','MII SPC','0',convert(varchar, getdate(), 121),convert(varchar, getdate(), 121))