SELECT * FROM [dbo].[SF_ProductionData]
WHERE PDClient_VC =  :client  and PDPlant_VC =  :plant  and PDOrder_CH =  :order 
and PDHeadNo_IN =  :head_number  and PDHeadMaterial_VC =  :material
Order By PDSequence_IN ASC