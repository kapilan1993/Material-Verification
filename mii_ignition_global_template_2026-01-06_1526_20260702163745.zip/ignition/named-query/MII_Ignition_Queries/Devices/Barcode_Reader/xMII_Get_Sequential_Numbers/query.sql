SELECT ScannedSequentialNum FROM xMII_Scanner_Raw_Data where Process_Order = :PO   and Device_Name =  :DeviceName 
