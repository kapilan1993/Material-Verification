SELECT * FROM [dbo].[xMII_Scanner_Raw_Data]
WHERE Client =  :Client  and Plant =  :Plant  and Process_Order =  :PO 
Order By ID ASC