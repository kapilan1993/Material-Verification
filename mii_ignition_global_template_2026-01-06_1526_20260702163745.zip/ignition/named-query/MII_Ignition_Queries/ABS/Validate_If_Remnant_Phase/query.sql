SELECT *
FROM [dbo].[ABS_ConfigRecipe_Phases_Relationship]
WHERE Client =  :Client  and WERKS =  :Plant and Phase =  :Phase   and InstructionParmName = 'REMNANT'