Select * from ufn_Get_Quality_Characteristics_and_Response( :Client , :Plant , :Order,  :Resource  ,:SAPResourceName  )
WHERE PPPI_PHASE =  :Phase 
and PPPI_INSPECTION_CHARACTERISTIC =  :Inspchar 