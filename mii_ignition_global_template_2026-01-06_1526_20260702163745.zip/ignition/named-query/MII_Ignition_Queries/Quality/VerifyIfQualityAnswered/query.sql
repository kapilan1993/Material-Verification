  SELECT
  
  'Required_Quality_Count' = ISNULL((SELECT COUNT(*) FROM [dbo].[xMII_QUALITY_CHARACTERISTICS] WHERE SapClient =  :client  and Plant =  :plant  and PROCESS_ORDER =  :order and PPPI_PHASE_RESOURCE =   :Resource  and PPPI_PHASE =  :phase ),0)
  
  ,'Answered_Quality_Count' = (SELECT ISNULL((Select Message.value('count(/CHAR_RESULTS/item)', 'int')
  FROM [dbo].[xMII_Queue_Message_Log]
  WHERE SAPClient =  :client  and SAPPlant =  :plant  and ProcessOrder =  :order  and SAPResourceName =  :SAPResourceName  and Phase =  :phase  and MessageType = '<CHAR_RESULTS>'),0))