Select COUNT(*) from ufn_GetQualitySingleResultsXML_All( :client , :plant , :order,  :SAPResourceName  )
  WHERE INSPOPER =  :phase  and INSPCHAR =  :inspchar  and RES_VALUAT =  :evaluation 