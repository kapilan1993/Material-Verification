Select * from ufn_Get_Quality_Characteristics_Single_Result_and_Response( :client , :plant , :order , :SAPResourceName  )
	WHERE PPPI_INSPECTION_LOT =   :inspection_lot  
	and PPPI_OPERATION =  :operation 
	and PPPI_PHASE =  :phase 
	and PPPI_INSPECTION_CHARACTERISTIC =  :inspection_characteristic 
	Order By PPPI_PHASE, PPPI_INSPECTION_CHARACTERISTIC, RES_NO ASC