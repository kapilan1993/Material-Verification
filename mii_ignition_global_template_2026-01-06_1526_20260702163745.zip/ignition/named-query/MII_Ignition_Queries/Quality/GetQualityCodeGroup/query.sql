Select CODE_GROUP from ufn_GetQualityCharacteristicsSetCode_All( :client , :plant , :order )
	WHERE CODE =  :code  and MSTR_CHAR =  :mstr_char 