INSERT INTO [dbo].[CONSUMPTIONS_FOR_DAI]
           ([BATCHID]
           ,[DAI_MESSAGE])
     VALUES
           ( :po 
           , :daiMessage)