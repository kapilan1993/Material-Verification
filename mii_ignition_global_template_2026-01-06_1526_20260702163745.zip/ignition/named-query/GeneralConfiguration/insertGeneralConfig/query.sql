INSERT INTO tblGeneralConfiguration
           ([API_Timeout]
           ,[Default_Days_PO]
           ,[Max_Days_BBD]
           ,[SF_Tag_Provider]
           ,[Client]
           ,[CPS_Location]
           ,[Plant_Code]
           ,[Plant_Name]
           ,[MII_API_Protocol]
           ,[MII_API_Server]
           ,[Event_Time]
           ,[Updated_By])
     VALUES
           ( :apiTimeout 
           , :defaultDaysPO 
           , :maxDaysBBD 
           , :sfTagProvider 
           , :client 
           , :cpsLocation 
           , :plantCode 
           , :plantName 
           , :miiApiProtocol 
           , :miiApiServer
           , :eventTime 
           , :updatedBy )