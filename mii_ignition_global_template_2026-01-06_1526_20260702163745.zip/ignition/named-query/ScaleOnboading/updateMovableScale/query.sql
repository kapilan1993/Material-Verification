UPDATE [dbo].[tblMovableScaleMaster]
   SET [SERIAL_NO] =  :serialNo 
      ,[IP] =  :ip 
      ,[SCALE_MIN] =  :scaleMin 
      ,[SCALE_MAX] =  :scaleMax 
      ,[SCALE_RESOLUTION] =  :scaleResolution 
      ,[UOM_ID] =  :uomId 
      ,[UPDATED_ON] = GETDATE()
      ,[UPDATED_BY] =  :updateBy 
 WHERE  [SCALE_NAME] =  :scaleName 