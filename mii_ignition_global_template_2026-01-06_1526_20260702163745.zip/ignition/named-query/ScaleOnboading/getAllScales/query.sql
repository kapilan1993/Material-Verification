SELECT 
tblMovableScaleMaster.SCALE_NAME,
  tblMovableScaleMaster.SERIAL_NO,
  tblMovableScaleMaster.IP,
  tblMovableScaleMaster.WC_ID,
  tblWorkCenterMaster.RESOURCE_NAME
  
FROM tblMovableScaleMaster
  LEFT JOIN tblWorkCenterMaster ON tblMovableScaleMaster.WC_ID =
    tblWorkCenterMaster.ID
    
    