INSERT INTO [dbo].[tblMovableScaleMaster]
           ([SCALE_NAME]
           ,[SERIAL_NO]
           ,[IP]
           ,[SCALE_MIN]
           ,[SCALE_MAX]
           ,[SCALE_RESOLUTION]
           ,[UOM_ID]
           ,[UPDATED_ON]
           ,[UPDATED_BY]
           ,[WC_ID])
     VALUES
          (:scaleName,  :serialNo,  :ip , :scaleMin , :scaleMax , :scaleResolution, :uomId,  GETDATE(), :updateBy,  :wcId )