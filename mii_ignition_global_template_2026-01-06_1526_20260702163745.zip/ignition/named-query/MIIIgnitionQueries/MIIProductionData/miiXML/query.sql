Select * From   xMII_PROCESS_ORDER_DATA 
Where  CLIENT = :client  and PLANT = :plant  and PROCESS_ORDER = :po 