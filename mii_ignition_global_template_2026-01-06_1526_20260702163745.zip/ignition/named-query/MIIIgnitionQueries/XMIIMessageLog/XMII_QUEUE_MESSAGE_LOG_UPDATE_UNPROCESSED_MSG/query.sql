  UPDATE [xMII].[dbo].[xMII_Queue_Message_Log]
  SET Processed = 1
  WHERE SAPClient =  :SAPClient  and SAPPlant =  :SAPPlant  and ID =  :Message_ID 