Select PO_Data_JSon, PROCESS_ORDER
From  xtestPO 
Where  CLIENT = :client    and PLANT =  :plant   and PROCESS_ORDER =  :po 