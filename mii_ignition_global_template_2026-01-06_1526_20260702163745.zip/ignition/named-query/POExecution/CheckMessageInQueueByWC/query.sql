SELECT COUNT(*)
FROM xMII_Queue_Message_Log 
WHERE SAPClient = :SAPClient AND SAPPlant = :SAPPlant AND Work_Center = :Work_Center AND Processed = '0' AND Attempts < Retry_Limit 