UPDATE [dbo].[xtestPO]
SET [PO_DATA_Json] =  :newJson 
Where  CLIENT =  :client   and PLANT =  :plant  and PROCESS_ORDER =  :po 