SELECT  DEVICE_NAME
FROM  tblProductionReportConfiguration 
WHERE  PO_NUMBER = :po AND  WORK_CENTER = :wc AND USED_FOR_PR = 1