UPDATE [dbo].[xMII_PO_STATUS]
   SET [TIMESTAMP] = GETDATE()
      ,[PHASE] =  :phase 
      ,[PHSTATUS] =  :phaseStatus 
      ,[POSTATUS] =  :poStatus 
      ,[S4STATUS] =   :s4Status 
 WHERE PROCESS_ORDER =  :po 