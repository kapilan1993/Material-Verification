Select * from ufn_GetPOHeaderPhasesLocalStatus( :Client , :Plant , :PO, :Resource)
	WHERE row_num = '1'
	Order By VORNR ASC