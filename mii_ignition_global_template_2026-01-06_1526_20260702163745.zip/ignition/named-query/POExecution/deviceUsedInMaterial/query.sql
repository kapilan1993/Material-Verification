SELECT DISTINCT [WEIGHER_NAME]
FROM [IGNPEDB].[dbo].[tblPOMaterialMangementHistory] where PO_NUMBER =  :po