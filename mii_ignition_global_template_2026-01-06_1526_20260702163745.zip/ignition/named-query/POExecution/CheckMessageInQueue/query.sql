SELECT TOP(1) *
FROM xMII_Queue_Message_Log 
WHERE SAPClient = :SAPClient AND SAPPlant = :SAPPlant AND Work_Center = :Work_Center AND Processed = '0' AND MessageType = 'Production Report' AND Attempts < Retry_Limit 