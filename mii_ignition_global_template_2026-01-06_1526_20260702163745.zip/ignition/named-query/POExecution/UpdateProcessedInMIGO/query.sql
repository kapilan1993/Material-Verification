UPDATE xMII_Queue_Message_Log 
SET Processed = 1
WHERE ProcessOrder = :po AND Work_Center = :wc ;

UPDATE xMII_GI_Queue_Message_Log 
SET Processed = 1
WHERE ProcessOrder = :po AND Work_Center = :wc 