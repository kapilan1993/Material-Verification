INSERT INTO [dbo].[tblMigoLog]
           ([PO]
           ,[WORK_CENTER]
           ,[REASON]
           ,[UPDATED_ON]
           ,[UPDATED_BY])
     VALUES
           (:po
           ,:wc
           ,:reason
           ,GETDATE()
           ,:updatedBy)
