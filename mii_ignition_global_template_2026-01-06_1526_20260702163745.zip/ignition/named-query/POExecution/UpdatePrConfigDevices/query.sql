UPDATE tblProductionReportConfiguration
SET GOOD_COUNT = :goodCount  , TOTAL_COUNT = :totalCount  , [DATETIME] = GetDate()
WHERE PO_NUMBER = :po  AND WORK_CENTER = :wc  AND DEVICE_NAME =  :device 