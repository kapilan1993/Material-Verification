INSERT INTO tblWorkCenterSecurityConfig ( IP_ADDRESS , WORK_CENTER ) VALUES ( :ip , :wc )
