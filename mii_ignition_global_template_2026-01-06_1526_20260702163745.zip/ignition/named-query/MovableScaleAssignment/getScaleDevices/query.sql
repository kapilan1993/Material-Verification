SELECT dm.NAME,
	dm.ID as deviceId,
	ms.ID,
  ms.SCALE_NAME,
  ms.SERIAL_NO,
  ms.IP,
  ms.SCALE_MIN,
  ms.SCALE_MAX,
  ms.SCALE_RESOLUTION
FROM tblDeviceMaster dm
  LEFT JOIN  tblMovableScaleMaster ms ON dm.[ID] =
    ms.[DEVICE_ID]
WHERE dm.[WC_ID] = (select [ID] from [dbo].[tblWorkCenterMaster] where [RESOURCE_NAME] =  :wc ) and [IsDeleted] = 0 and [FIX_AND_MANUAL]= 1

