SELECT m.*,
        wcm.RESOURCE_NAME,
       dm.NAME,
       dm.IsDeleted
FROM tblMovableScaleMaster AS m
LEFT JOIN tblWorkCenterMaster AS wcm ON m.WC_ID = wcm.ID
LEFT JOIN tblDeviceMaster AS dm ON m.DEVICE_ID = dm.ID 

--where dm.IsDeleted = 0
 