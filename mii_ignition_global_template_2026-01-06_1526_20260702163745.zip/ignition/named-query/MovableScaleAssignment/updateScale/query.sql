UPDATE [dbo].[tblMovableScaleMaster]
   SET [WC_ID] = (SELECT ID FROM  tblWorkCenterMaster  WHERE  RESOURCE_NAME = :workCenter)
      ,[DEVICE_ID] =  :deviceId 
 WHERE [ID] =   :scaleId 