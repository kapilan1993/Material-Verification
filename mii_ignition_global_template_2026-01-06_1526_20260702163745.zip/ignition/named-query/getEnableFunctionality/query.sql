SELECT tblWorkCenterMaster.ENABLE_AUTO_PHASE_COMPLETION,
  tblWorkCenterMaster.ENABLE_AUTO_PR,
  tblWorkCenterMaster.ENABLE_AUTO_GI,
  tblWorkCenterMaster.ENABLE_BBD,
  tblWorkCenterMaster.ENABLE_MATERIAL_MANAGEMENT,
  tblWorkCenterMaster.ENABLE_PARTIAL_GI,
  tblWorkCenterMaster.ENABLE_SKIP_BBD,
  tblWorkCenterMaster.ENABLE_STOCK_VALIDATION,
  tblWorkCenterMaster.PARITAL_GI_FREQUENCY,
  tblUomMaster.UOM
FROM tblWorkCenterMaster
  INNER JOIN tblUomMaster ON tblWorkCenterMaster.GI_FREQUENCY_UOM =
    tblUomMaster.ID
WHERE tblWorkCenterMaster.RESOURCE_NAME = :workCenter