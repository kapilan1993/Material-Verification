UPDATE [dbo].[tblSvMaterialHistory]
   SET [VALIDATE] = 1, [UPDATED_ON] = GETDATE(), [UPDATE_BY] = :updatedBy  
 WHERE [PO_NUMBER] =  :po 
      and [WORK_CENTER] =  :wc 
      and [MATERIAL] =   :mat 
      and [BATCH] =   :batch 
      and [PSA] =  :psa 
      and [STORAGE_LOC] =  :storage 
      and [WAREHOUSE] =  :warehouse 