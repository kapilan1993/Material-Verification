INSERT INTO [dbo].[tblSvHistory]
           ([PO_NUMBER]
           ,[IS_COMPLETED])
     VALUES
           ( :po ,  :isCompleted )