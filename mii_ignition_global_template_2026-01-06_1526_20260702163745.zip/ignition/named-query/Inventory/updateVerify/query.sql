UPDATE tblBatchManagement
SET  IS_VERIFIED  = :verify 
WHERE ID = :id