SELECT distinct(PROCESS_ORDER)
FROM tblBatchManagement
WHERE (
    ( UPDATED_ON  >= DATEADD(day, -7, GETDATE()) and RESOURCE= :resource  and :startDate  IS NULL AND :endDate IS NULL)
    OR
    (:startDate IS NOT NULL AND :endDate IS NOT NULL AND UPDATED_ON BETWEEN :startDate AND :endDate and RESOURCE= :resource)
);

