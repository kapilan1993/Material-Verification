select MATERIAL_NUMBER FROM tblBatchManagement
WHERE ((RESOURCE != '' and PROCESS_ORDER != '' and  RESOURCE = :resource  and  BACKFLUSH!='X'
and PROCESS_ORDER = :po   and   :startDate  = '' and   :endDate  = '' )
or 
(RESOURCE != '' and PROCESS_ORDER != ''   and  RESOURCE = :resource  and  BACKFLUSH!='X'
and PROCESS_ORDER = :po  and :startDate != '' and  :endDate != '' and  UPDATED_ON BETWEEN :startDate AND :endDate ))
group by MATERIAL_NUMBER ORDER BY MATERIAL_NUMBER