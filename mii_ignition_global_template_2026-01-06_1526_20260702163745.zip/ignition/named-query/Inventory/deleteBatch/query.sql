UPDATE tblBatchManagement
SET IS_DELETED = :isDeleted,
 IS_VERIFIED =  :isVerified 
WHERE ID = :id