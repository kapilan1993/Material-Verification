INSERT INTO [dbo].[tblBatchManagement]
           ([CLIENT]
           ,[PLANT]
           ,[PROCESS_ORDER]
           ,[RESOURCE]
           ,[MATERIAL_NUMBER]
           ,[BATCH_NUMBER]
           ,[SHELF_LIFE]
           ,[STORAGE_LOCATION]
           ,[PLANNED_QUANTITY]
           ,[UOM]
           ,[UPDATED_ON]
           ,[UPDATED_BY]
           ,[IS_DELETED])
     VALUES
           (CLIENT,client ,
           PLANT, plant,
           PROCESS_ORDER, po,
           RESOURCE, resource,
           MATERIAL_NUMBER, material,
           BATCH_NUMBER,batch,
           SHELF_LIFE,shelfLife ,
           STORAGE_LOCATION,sloc ,
           PLANNED_QUANTITY,quanity ,
           UOM, uom ,
           UPDATED_ON,updatedOn ,
           UPDATED_BY,updatedBy,
           IS_DELETED,isDeleted)