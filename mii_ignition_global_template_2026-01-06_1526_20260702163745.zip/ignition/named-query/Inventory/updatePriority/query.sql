UPDATE tblBatchManagement
SET  PRIORITY  =  :priority 
WHERE ID = :id