With cte as 
(select top (1) * from [dbo].[tblBatchManagement] WHERE [MATERIAL_NUMBER] =  :materialNo and IS_DELETED=1 and PROCESS_ORDER = :po and BATCH_NUMBER = :batchNo )
Update cte  Set BATCH_TARGET  = :plannedQty , PRIORITY = :priority , BATCH_NUMBER =:batchNo,  SHELF_LIFE = :shelfLife , STORAGE_LOCATION = :sloc 
,UPDATED_BY =:UPDATED_BY , UPDATED_ON = GETDATE() ,IS_DELETED=0 ,IS_VERIFIED =  :isVerified 