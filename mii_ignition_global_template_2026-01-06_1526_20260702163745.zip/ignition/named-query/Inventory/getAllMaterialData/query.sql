SELECT * FROM tblBatchManagement
WHERE (( :startDate  = '' and  :endDate  = '' and RESOURCE != '' and PROCESS_ORDER != '' and RESOURCE = :resource and  BACKFLUSH!='X' AND PROCESS_ORDER =  :po
and MATERIAL_NUMBER =  :material and IS_DELETED = 0 and  CONVERT(FLOAT, BATCH_TARGET) > 0)
or
( :startDate  != '' and  :endDate != '' and  UPDATED_ON BETWEEN :startDate AND :endDate and RESOURCE != '' and PROCESS_ORDER != '' and
RESOURCE = :resource and  BACKFLUSH!='X' AND PROCESS_ORDER =  :po and MATERIAL_NUMBER =  :material and IS_DELETED = 0 and CONVERT(FLOAT,BATCH_TARGET) > 0))
ORDER BY PRIORITY;