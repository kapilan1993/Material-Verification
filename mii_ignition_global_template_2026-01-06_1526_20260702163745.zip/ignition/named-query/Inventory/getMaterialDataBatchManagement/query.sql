SELECT * 
FROM [dbo].[tblBatchManagement] WHERE [MATERIAL_NUMBER] =   :materialNo   AND  PROCESS_ORDER =  :po AND RESOURCE= :wc --and BATCH_NUMBER!='---'