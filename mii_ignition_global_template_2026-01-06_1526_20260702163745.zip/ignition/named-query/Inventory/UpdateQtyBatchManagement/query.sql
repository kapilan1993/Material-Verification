Update [dbo].[tblBatchManagement] Set BATCH_TARGET  = :plannedQty , PRIORITY = :priority , SHELF_LIFE = :shelfLife  ,UPDATED_BY =:UPDATED_BY , IS_VERIFIED = :isVerified ,
UPDATED_ON = GETDATE() ,IS_DELETED=0 WHERE [MATERIAL_NUMBER] =  :materialNo  AND BATCH_NUMBER =  :batchNo AND STORAGE_LOCATION =  :sloc 
AND PROCESS_ORDER =  :po AND RESOURCE= :wc 
AND IS_DELETED!=1 AND STORAGE_LOCATION =:sloc
