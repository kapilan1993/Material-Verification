SELECT  b.PO_NUMBER,  b.DEVICE_NAME ,  MAX(convert(int,m.[TotalCount])) AS TotalCount,
    MAX(convert(int,m.[GoodCount])) AS GoodCount, MAX(convert(int,m.[RejectCount])) AS RejectCount ,
    MAX(m.EventTime) AS EventTime    
  FROM [tblProductionReportConfiguration] b inner join 
  [tblSpcWeightHistory] m on b.DEVICE_NAME= m.DeviceName  and  b.PO_NUMBER=m.PO 
  where b.USED_FOR_PR=1 and b.WORK_CENTER =  :workCenter  group by   b.PO_NUMBER, b.[DEVICE_NAME]
