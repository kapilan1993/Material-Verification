SELECT 
	   [PO]
      ,[WorkCenter]
      ,[Phase]
      ,[EventTime]
      ,[DeviceName]
      ,[Material]
      ,[BatchNumber]
      ,ROUND([NetWeight],5) as NetWeight
      ,[UOM]
	  ,ROUND([TotalCount], 5) as TotalCount
      ,ROUND([UpperLimit], 5) as UpperLimit
      ,ROUND([Target], 5) as Target
      ,ROUND([LowerLimit], 5) as LowerLimit
      ,[ItemCount]
      ,[ProductionStatus]
  FROM [tblSpcWeightHistory]
  Where [DeviceName] like  :weigher and [PO] =  :po  order by TotalCount Desc