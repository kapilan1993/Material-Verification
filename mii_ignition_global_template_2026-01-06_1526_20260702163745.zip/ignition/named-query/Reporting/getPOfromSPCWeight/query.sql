SELECT distinct PO
  FROM [IGNPEDB].[dbo].[tblSpcWeightHistory] where  EventTime between  :startDate and  :endDate  and workCenter=:wc and PO != ''