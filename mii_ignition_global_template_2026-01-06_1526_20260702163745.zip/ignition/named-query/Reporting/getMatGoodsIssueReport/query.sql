SELECT Distinct b.Material
FROM [dbo].[ufn_GetGoodsIssuePerMaterial] ( :client , :plant ,  :po , :workCenter) a
JOIN[dbo].[ufn_GetGoodsIssuePerPO] (:client , :plant ,  :po, :workCenter  ) b ON a.MATNR = b.Material where a.BDMNG!='0'