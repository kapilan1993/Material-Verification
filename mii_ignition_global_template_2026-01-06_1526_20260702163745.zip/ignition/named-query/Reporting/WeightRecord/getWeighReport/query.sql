SELECT 
       [PO]
      ,[WorkCenter]
      ,[Phase]
      ,[EventTime]
      ,[DeviceName]
      ,[Material]
      ,[BatchNumber]
      ,ROUND([NetWeight], 5) AS NetWeight
      ,[UOM]
      ,ROUND([TotalCount], 5) AS TotalCount
      ,ROUND([UpperLimit], 5) AS UpperLimit
      ,ROUND([Target], 5) AS Target
      ,ROUND([LowerLimit], 5) AS LowerLimit
      ,[ItemCount]
      ,[ProductionStatus]
FROM [tblSpcWeightHistory]
WHERE [DeviceName] like  :weigher AND [PO] = :po AND [WorkCenter] = :workCenter AND [PO] != ''
--  AND ( 
--        (:startTime != '' AND :endTime != ''  AND [EventTime] BETWEEN :startTime AND :endTime)
--        OR
--        (:startTime = '' AND :endTime = '')
--      )
ORDER BY TotalCount DESC;