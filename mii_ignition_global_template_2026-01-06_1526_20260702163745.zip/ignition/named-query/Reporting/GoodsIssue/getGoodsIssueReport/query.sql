SELECT b.ProcessOrder ,b.ResourceName,b.Material,b.Batch,b.Quantity,b.BagNumber, b.UOM,b.StorageLoc,b.MovementType, b.EventTime ,a.ING_TARGET,a.ING_TARGET_UL,a.ING_TARGET_LL
FROM [dbo].[ufn_GetGoodsIssuePerMaterial] ( :client , :plant ,  :po , :workCenter) a
JOIN[dbo].[ufn_GetGoodsIssuePerPO] (:client , :plant ,  :po, :workCenter  ) b ON a.MATNR = b.Material where a.BDMNG!='0'