SELECT DISTINCT ProcessOrder from  xMII_Queue_Message_Log WHERE ProcessOrder != '' AND Work_Center =  :workCenter 
 AND EventTime BETWEEN :startTime AND :endTime
