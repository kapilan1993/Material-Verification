SELECT
    p.PO_NUMBER,
    p.DEVICE_NAME,
    p.TotalCount,
    p.GoodCount,
    p.RejectCount,
    p.EventTime
FROM
    (
        SELECT
            b.PO_NUMBER,
            b.DEVICE_NAME,
            SUM(CONVERT(int, m.ItemCount)) AS TotalCount,
            SUM(CASE WHEN m.ProductionStatus = 1 THEN 1 ELSE 0 END) AS GoodCount,
            SUM(CASE WHEN m.ProductionStatus = 0 THEN 1 ELSE 0 END) AS RejectCount,
            MAX(m.EventTime) AS EventTime    
        FROM
            tblProductionReportConfiguration b
        INNER JOIN
            tblSpcWeightHistory m ON b.DEVICE_NAME = m.DeviceName AND b.PO_NUMBER = m.PO
        WHERE
            b.USED_FOR_PR = 1
            AND b.WORK_CENTER = :workCenter
            AND ((:po = '' and m.EventTime BETWEEN :startTime AND :endTime)
            OR (:po != '' and  b.PO_NUMBER = :po))
        GROUP BY
            b.PO_NUMBER,
            b.DEVICE_NAME
    ) p
WHERE
	(:po = '' and p.EventTime BETWEEN :startTime AND :endTime)
     OR (:po != '' and  p.PO_NUMBER = :po)