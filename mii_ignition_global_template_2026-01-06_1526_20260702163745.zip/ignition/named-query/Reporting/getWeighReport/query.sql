SELECT 
	   [PO]
      ,[WorkCenter]
      ,[Phase]
      ,[EventTime]
      ,[DeviceName]
      ,[Material]
      ,[BatchNumber]
      ,ROUND([NetWeight],5) as NetWeight
      ,[UOM]
	  ,ROUND([TotalCount], 5) as TotalCount
      ,ROUND([UpperLimit], 5) as UpperLimit
      ,ROUND([Target], 5) as Target
      ,ROUND([LowerLimit], 5) as LowerLimit
      ,[ItemCount]
      ,[ProductionStatus]
  FROM [tblSpcWeightHistory]
  Where ([DeviceName] like  :weigher and [PO] =  :po and [WorkCenter] =  :workCenter and [EventTime] between  :startTime  and   :endTime) or [Material] = :material order by TotalCount Desc