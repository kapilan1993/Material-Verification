SELECT distinct [UpperLimit] ,[LowerLimit]
FROM [tblSpcWeightHistory] where WorkCenter = :workCenter  and Material = :material  and PO =  :po  and [EventTime] between :startDate and  :endDate