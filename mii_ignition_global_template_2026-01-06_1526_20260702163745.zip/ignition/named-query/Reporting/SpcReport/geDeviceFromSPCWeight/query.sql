SELECT distinct [DeviceName]
  FROM [IGNPEDB].[dbo].[tblSpcWeightHistory] where  EventTime between  :startDate and  :endDate  and workCenter=:wc and PO = :po
--  order by CASE WHEN [DeviceName] like 'Checkweigher_SP%' THEN 1
--              WHEN [DeviceName] like 'Checkweigher_PP%' THEN 2
--              WHEN  [DeviceName] like 'FillerHead%' THEN 3
--              ELSE 4 END