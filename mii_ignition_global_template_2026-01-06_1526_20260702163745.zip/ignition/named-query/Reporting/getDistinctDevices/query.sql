SELECT DISTINCT [DeviceName], [DeviceName]
 fROM [tblSpcWeightHistory] WHERE PO =  :po  and DeviceName like  :deviceName 