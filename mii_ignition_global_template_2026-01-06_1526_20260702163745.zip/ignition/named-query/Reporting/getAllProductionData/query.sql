SELECT a.[Order], a.POSTED_QUANTITY, b.[EventTime], b.[UpdatedBy]
FROM [dbo].ufn_GetAllProductionReport( :client , :plant ,  :po ,  :workCenter  ) a
JOIN (
    SELECT TOP 1 [EventTime], [ProcessOrder], [UpdatedBy]
    FROM [IGNPEDB].[dbo].[xMII_Queue_Message_Log]
    WHERE [MessageType] = 'Production Report' AND [ProcessOrder] =  :po 
    ORDER BY [EventTime] DESC
) b ON a.[Order] = b.[ProcessOrder];