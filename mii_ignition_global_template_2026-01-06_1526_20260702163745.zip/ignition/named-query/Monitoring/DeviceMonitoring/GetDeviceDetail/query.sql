SELECT  DEVICE_NAME,  GOOD_COUNT,  TOTAL_COUNT,  USED_FOR_PR 
FROM  tblProductionReportConfiguration 
WHERE  PO_NUMBER = :po AND  WORK_CENTER = :wc and DEVICE_NAME= :devicename 