select distinct(AUFNR)
from xMII_PO_Header_Phases 
where (
    ( GSTRS >= DATEADD(day, -7, GETDATE()) and ARBPL=:workCenter and :startDate = '' AND :endDate = '' )
    OR
    (:startDate IS NOT NULL AND :endDate IS NOT NULL AND GSTRS BETWEEN :startDate AND :endDate and ARBPL=:workCenter)
)