SELECT  [ID],[MessageType],
      [ProcessOrder],
      [SAPResourceName]
       ,[Message],[Updatedby]
      ,[EventTime]
      ,[Response] ,[Response] as Actions, Processed, Attempts
  FROM [dbo].[xMII_Queue_Message_Log] where PROCESSOrder= :PO
  and MessageType=:messageType
  