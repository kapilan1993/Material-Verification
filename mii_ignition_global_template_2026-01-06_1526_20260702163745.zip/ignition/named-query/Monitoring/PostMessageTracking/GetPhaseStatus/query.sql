--select Top(1) [Order], Phase, PhaseStatus from [dbo].[ufn_GetPhaseStatusLast]('010' , '0103', '000100048703', '' , '<Phase_Status>') order by EventTime desc

select [Order], Phase, PhaseStatus from ufn_GetPhaseStatusLast(:Client ,:Plant , :Order , :Resource , '<Phase_Status>') where Phase = '2020' and PhaseStatus = 'CMPL' 