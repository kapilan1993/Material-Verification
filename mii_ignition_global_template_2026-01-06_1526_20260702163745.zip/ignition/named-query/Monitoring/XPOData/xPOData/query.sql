Select CAST (replace(PO_DATA,'<?xml version="1.0" encoding="UTF-8"?>', '') AS XML) From   xMII_PROCESS_ORDER_DATA 
Where  CLIENT =  :client  and PLANT = :plant   and PROCESS_ORDER = :po 
