SELECT Count(*) as Cnt   FROM [dbo].[xMII_Queue_Message_Log]
where Work_Center=:workcenter and MessageType=:messageType and Processed=0 and Response =''  and ProcessOrder=:PO
