SELECT Count(*) as Cnt   FROM [dbo].[xMII_GI_Queue_Message_Log]
where Work_Center=:workcenter and MessageType=:messageType and ProcessOrder=:PO
