SELECT Count(*) as Cnt   FROM [dbo].[xMII_GI_Queue_Message_Log]
where Work_Center=:workcenter and MessageType=:messageType and Processed=0 and Attempts =3 and ProcessOrder=:PO
