SELECT [Usage],[EventTime]
FROM [dbo].[tblIgnitionPerformance]
WHERE  UsageType = :type AND (EventTime BETWEEN  :startTime AND :endTime )
