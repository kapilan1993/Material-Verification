INSERT INTO [dbo].[tblIgnitionPerformance]
           ([Usage]
           ,[EventTime]
           ,[UsageType])
     VALUES
           ( :usage 
           , :eventTime 
           , :usageType )