UPDATE tempBatchManagement SET CONSUMED_QUANTITY = :consumedQty, CONSUMED = :consumed
WHERE [PROCESS_ORDER] = :po AND [RESOURCE] = :wc AND [MATERIAL_NUMBER] = :material AND [BATCH_NUMBER] = :batch