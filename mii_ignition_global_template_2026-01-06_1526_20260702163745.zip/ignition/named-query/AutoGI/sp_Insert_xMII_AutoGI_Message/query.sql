DECLARE	@return_value int

EXEC	@return_value = [dbo].[sp_Insert_xMII_AutoGI_Message]
		@Conf_Freequency = :partialFreq,
		@Sap_Client = :client,
		@Sap_Plant = :plant,
		@Process_Order = :po,
		@Sap_Resource = :resource,
		@Node_Name = :nodename,
		@Node_ID = :nodeID,
		@Phase = :phase,
		@Operations = :operation,
		@Area = :area

SELECT	'Return Value' = @return_value