SELECT COUNT([ID])
FROM [dbo].[tempBatchingTable]
WHERE [PO] = :po AND [WorkCenter] = :wc AND [Material] = :material