UPDATE tempBatchManagement SET CONSUMED_QUANTITY = :consumedQty
WHERE [PROCESS_ORDER] = :po AND [RESOURCE] = :wc AND [MATERIAL_NUMBER] = :material AND [BATCH_NUMBER] = :batch