  UPDATE [dbo].[xMII_GI_Queue_Message_Log]
  SET Response =  :Response 
  WHERE SAPClient =  :SAPClient  and SAPPlant =  :SAPPlant  and  ID in ({Message_ID})