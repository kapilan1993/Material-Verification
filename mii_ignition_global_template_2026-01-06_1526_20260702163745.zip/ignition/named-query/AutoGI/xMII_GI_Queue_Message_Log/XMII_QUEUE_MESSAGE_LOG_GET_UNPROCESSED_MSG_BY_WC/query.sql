  SELECT TOP (1) * FROM [dbo].[xMII_GI_Queue_Message_Log]
  WHERE SAPClient =  :SAPClient  and SAPPlant =  :SAPPlant  and Processed = 0 
  and Work_Center =  :Work_Center 
  and Attempts < Retry_Limit
  Order By ID ASC