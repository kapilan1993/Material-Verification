  UPDATE [dbo].[xMII_GI_Queue_Message_Log]
  SET Attempts = (Attempts + 1)
  WHERE SAPClient =  :SAPClient  and SAPPlant =  :SAPPlant  and  ID in ({Message_ID})