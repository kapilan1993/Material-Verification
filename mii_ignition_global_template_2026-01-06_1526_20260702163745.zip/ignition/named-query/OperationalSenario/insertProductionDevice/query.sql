INSERT INTO [dbo].[tblProductionReportConfiguration]
           ([PO_NUMBER]
           ,[WORK_CENTER]
           ,[DEVICE_NAME]
           ,[DATETIME]
           ,[GOOD_COUNT]
           ,[TOTAL_COUNT],
           [USED_FOR_PR])
     VALUES
           ( :po 
           , :wc 
           , :prDevice 
           ,GETDATE()
           , :goodCount 
           , :totalCount,:usedforPR )