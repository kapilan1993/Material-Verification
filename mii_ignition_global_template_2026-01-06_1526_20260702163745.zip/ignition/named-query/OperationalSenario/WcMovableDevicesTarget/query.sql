Select   [SCALE_MAX] , [SCALE_MIN]  
from  tblMovableScaleMaster where   WC_ID = (Select id from [dbo].[tblWorkCenterMaster] where RESOURCE_NAME = :wc )  and  [DEVICE_ID]=:ID
