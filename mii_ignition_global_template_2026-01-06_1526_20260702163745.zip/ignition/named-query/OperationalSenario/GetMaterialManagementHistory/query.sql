SELECT [WEIGHER_NAME]
      ,[MATERIAL_NO]
	  ,COUNT(MATERIAL_NO) AS COUNT
  FROM [dbo].[tblPOMaterialMangementHistory]
  WHERE [WORK_CENTER] = :wc AND [PO_TYPE] = :poType AND [OPERATIONAL_SCENARIO] = :scenarioNr  
  AND  [DATETIME] >= DATEADD(Month, DATEDIFF(Month, 0, DATEADD(Month, -6,current_timestamp)), 0)
  GROUP BY [MATERIAL_NO],[WEIGHER_NAME]