SELECT COUNT(*)
  FROM [IGNPEDB].[dbo].[tblSvMaterialHistory] where PO_NUMBER = :po  and WORK_CENTER = :wc 