INSERT INTO [dbo].[tblOperationalScenarioHistory]
           ([PO_NUMBER]
           ,[RESOURCE_NAME]
           ,[PO_TYPE]
           ,[OPERATIONAL_SCENARIO]
           ,[OPERATIONAL_SCENARIO_DESC]
           ,[DATE])
     VALUES
           (:po 
           ,:wc 
           , :poType 
           , :operationalScenario
           , :operationalScenarioDesc
           ,GETDATE())