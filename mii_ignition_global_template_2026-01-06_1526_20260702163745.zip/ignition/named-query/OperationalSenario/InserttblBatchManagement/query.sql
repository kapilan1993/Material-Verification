INSERT INTO tblBatchManagement 
           (  CLIENT ,PLANT ,RESOURCE ,PROCESS_ORDER ,  MATERIAL_NUMBER , SHELF_LIFE ,BATCH_NUMBER,  STORAGE_LOCATION , PRIORITY ,PLANNED_QUANTITY, BATCH_TARGET,
            ING_TARGET , ING_TARGET_LL , ING_TARGET_UL , ING_TARGET_UOM , MATERIAL_DESCRIPTION ,
 			MATERIAL_HLVL, MATERIAL_TYPE , MOVEMENT_REASON , MOVEMENT_TYPE , SETPOINT , SETPOINT_UOM , UOM,RESB_POS ,BACKFLUSH , MATKL , PAS_NO , PVZNR , RSNUM , VORNR , WAREHOUSE_NO , XCHPF 
 			 ,CONSUMED , CONSUMED_QUANTITY ,IS_DELETED, IS_VERIFIED, UPDATED_BY,  UPDATED_ON )
     VALUES
           (:client,:plant,:wc,:po,:materialNo, :shelfLife , :batchNo , :sloc , :priority , :plannedQty , :batchTarget ,
            :target , :target_LL ,:target_UL , :target_UOM ,:description,
             :hlvl , :materilaType , :movementReason ,'261', :setpoint , :setpointUOM , :UOM , :resbPos ,:backflush,:matkl,:passNo,:pvznr,:rsnum,:vorNr,:warehouseNr,:xcpf
            ,0,0 ,0,0 , :updatedBy  ,GETDATE())