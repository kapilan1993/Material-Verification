SELECT * FROM [dbo].[ufn_Get_Ingredients] (
    :po 
  , :wc)