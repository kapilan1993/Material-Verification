
SELECT * FROM [dbo].[getRecentProductionReportTriggerDevice] ( :poType , :wc  )