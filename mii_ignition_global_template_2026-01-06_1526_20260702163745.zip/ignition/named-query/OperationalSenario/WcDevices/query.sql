Select  [NAME],[TYPE]
from [dbo].[tblDeviceMaster] where WC_ID = (Select id from [dbo].[tblWorkCenterMaster] where RESOURCE_NAME = :wc )and (TYPE ='FillerHead'or TYPE ='CheckWeigher') and  IsDeleted = 0 order by CASE WHEN [NAME] like 'Checkweigher_SP%' THEN 1
              WHEN [NAME] like 'Checkweigher_PP%' THEN 2
              WHEN  [NAME] like 'FillerHead%' THEN 3
              WHEN  [NAME] like 'Palletizer%' THEN 4
              ELSE 5 END
