UPDATE [dbo].[tblProductionReportConfiguration]
   SET [PR_DEVICE] = :prDevice 
      ,[DATETIME] = GETDATE()
 WHERE [PO_NUMBER] = :po  AND [WORK_CENTER] = :wc