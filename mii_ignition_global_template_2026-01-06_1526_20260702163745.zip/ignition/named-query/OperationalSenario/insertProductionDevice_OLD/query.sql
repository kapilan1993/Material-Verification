INSERT INTO [dbo].[tblProductionReportConfiguration]
           ([PO_NUMBER]
           ,[WORK_CENTER]
           ,[PR_DEVICE]
           ,[DATETIME]
           ,[GOOD_COUNT]
           ,[TOTAL_COUNT])
     VALUES
           ( :po 
           , :wc 
           , :prDevice 
           ,GETDATE()
           , :goodCount 
           , :totalCount )