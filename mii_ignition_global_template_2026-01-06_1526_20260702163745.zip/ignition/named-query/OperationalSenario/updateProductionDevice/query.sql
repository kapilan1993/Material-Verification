UPDATE [dbo].[tblProductionReportConfiguration]
   SET  [Used_For_PR]= CASE WHEN [DEVICE_NAME] = :newDevice  Then 1 
   							WHEN [DEVICE_NAME] = :prDevice  Then 0
   							ELSE [USED_FOR_PR] END
      ,[DATETIME] = GETDATE()
 WHERE [PO_NUMBER] = :po  AND [WORK_CENTER] = :wc  