INSERT INTO [dbo].[tblPOMaterialMangementHistory]
           ([PO_NUMBER]
           ,[WORK_CENTER]
           ,[PO_TYPE]
           ,[OPERATIONAL_SCENARIO]
           ,[WEIGHER_NAME]
           ,[MATERIAL_NO]
           ,[DATETIME])
     VALUES
           (:po
           ,:wc
           ,:poType
           ,:scenarioNr
           ,:weigher
           ,:material 
           ,GETDATE())