UPDATE tblDeviceMaster 
SET IsDeleted =  :IsDeleted 
WHERE WC_ID = (SELECT id FROM tblWorkCenterMaster WHERE RESOURCE_NAME = :wc )
