UPDATE tblWorkCenterMaster
SET IS_CONFIGURED = :isConfigured 
WHERE RESOURCE_NAME = :wc