SELECT  ID 
FROM tblWorkCenterMaster
WHERE tblWorkCenterMaster.RESOURCE_NAME = :workCenter