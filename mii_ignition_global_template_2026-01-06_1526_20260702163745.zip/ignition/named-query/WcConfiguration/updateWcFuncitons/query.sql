UPDATE [dbo].[tblWorkCenterMaster]
   SET [ENABLE_AUTO_GI] =  :enableAutoGi 
      ,[ENABLE_AUTO_PR] =  :enableAutoPr 
      ,[ENABLE_AUTO_PHASE_COMPLETION] =  :enableAutoPhaseCom 
      ,[ENABLE_BBD] =  :enableBbd 
      ,[ENABLE_MATERIAL_MANAGEMENT] =  :enableMatManage 
      ,[ENABLE_STOCK_VALIDATION] =  :enableStockValidation 
      ,[ENABLE_PARTIAL_GI] =  :enablePartialGi 
      ,[ENABLE_SKIP_BBD] =  :enableSkipBbd 
      ,[PARITAL_GI_FREQUENCY] =  :partialGiFreq 
      ,[UPDATED_ON] = GETDATE()
      ,[UPDATED_BY] =  :user
      ,[GI_FREQUENCY_UOM] =  :uomId 
      ,[ENABLE_PARTIAL_SPLIT] = :enablePartialSplit 
      ,[ENABLE_FULL_SPLIT] =  :enableFullSplit 
      ,[ENABLE_SCRAP_REASON] = :enableScrapReason  
      ,[ENABLE_BARCODE_VALIDATION] = :enableBarcodeValidation
      ,[ENABLE_BARCODE_VALIDATION_PRE_POEXECUTION] = :enableBarcodeValidationPrePOExecution
      ,[ENABLE_BARCODE_VALIDATION_POST_POEXECUTION] = :enableBarcodeValidationPostPOExecution
      , [ENABLE_VIEW_SCALES]=  :enableViewScales 
      , [ENABLE_MANUAL_FILLING]= :enableManualFilling 
      , ENABLE_BBD_VALIDATION = :enableBBDValidation 
      , ENABLE_BATCHVERIFIED_PREPOEXECUTION = :enableBatchVerifiedPrePOExecution
 WHERE [RESOURCE_NAME] =  :wc 
 