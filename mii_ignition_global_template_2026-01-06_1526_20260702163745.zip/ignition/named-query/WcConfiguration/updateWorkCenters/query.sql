UPDATE tblWorkCenterMaster
SET IS_CONFIGURED = :isConfigured,
TYPE =  :workCenterType,
AREA =  :area,
DESCRIPTION = :description 
WHERE RESOURCE_NAME = :wc