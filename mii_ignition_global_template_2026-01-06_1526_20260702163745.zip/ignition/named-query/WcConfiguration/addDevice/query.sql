 INSERT INTO [dbo].[tblDeviceMaster]
   ([NAME]
           ,[TYPE]
           ,[WC_ID]
           ,[IsDeleted]
           ,[CAPACITY_MIN]
           ,[CAPACITY_MAX]
           ,[CAPACITY_RESOLUTION]
           ,[UOM_ID]
           ,[PRI_AND_SEC]
           ,[FIX_AND_MANUAL]
           ,[UPDATED_ON]
           ,[USB_AND_GATEWAY] 
           ,[UPDATED_BY])
VALUES
   ( :name
           , :type
           , :wcId
           , 0
           , :capacityMin 
           , :capacityMax 
           , :resolution 
           , :uomId
           , :priOrSec 
           , :fixOrManual 
           ,GETDATE()
           , :usbOrGateway 
           , :updatedBy)
