Select * from ufn_GetWorkCells( :client , :plant)
Order By  AREA DESC, ARBPL DESC, EventTime DESC