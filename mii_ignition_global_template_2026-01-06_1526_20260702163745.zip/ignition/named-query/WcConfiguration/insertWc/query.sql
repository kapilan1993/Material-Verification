INSERT INTO [dbo].[tblWorkCenterMaster]
           ([RESOURCE_NAME]
           ,[TYPE]
           ,[DESCRIPTION]
           ,[AREA]
           ,[IS_CONFIGURED]
           )
     VALUES
           ( :workCenter ,  :wcType ,  :description , :area , :isConfig)