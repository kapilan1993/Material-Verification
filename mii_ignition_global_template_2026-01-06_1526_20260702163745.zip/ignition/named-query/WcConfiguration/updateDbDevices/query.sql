UPDATE tblDeviceMaster 
SET  [CAPACITY_MIN] = :capacityMin 
           ,[CAPACITY_MAX] =  :capacityMax 
           ,[CAPACITY_RESOLUTION] =  :resolution 
           ,[UOM_ID] = :uomId
           ,[UPDATED_ON]= GETDATE()
WHERE  IsDeleted = 0 and NAME = :deviceName and WC_ID = (SELECT id FROM tblWorkCenterMaster WHERE RESOURCE_NAME = :wc  ) 
