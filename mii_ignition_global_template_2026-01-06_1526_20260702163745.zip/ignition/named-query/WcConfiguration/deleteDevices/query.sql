UPDATE tblDeviceMaster 
SET IsDeleted =  :IsDeleted 
WHERE NAME =:deviceName  AND WC_ID = (SELECT id FROM tblWorkCenterMaster WHERE RESOURCE_NAME = :wc )
