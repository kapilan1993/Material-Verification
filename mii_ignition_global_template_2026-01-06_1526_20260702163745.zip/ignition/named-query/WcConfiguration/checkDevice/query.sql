SELECT top (1) IsDeleted, NAME FROM  tblDeviceMaster WHERE  NAME = :deviceName and WC_ID = (SELECT id FROM tblWorkCenterMaster WHERE RESOURCE_NAME = :wc ) order by UPDATED_ON desc 
