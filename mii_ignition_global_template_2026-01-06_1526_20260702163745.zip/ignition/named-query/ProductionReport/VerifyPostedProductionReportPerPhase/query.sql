Select COUNT(*) FROM  [dbo].[xMII_Queue_Message_Log]
WHERE SAPClient =  :client  and SAPPlant =  :plant and ProcessOrder =  :order  and Processed = '1' and MessageType = 'Production Report'
and Phase =  :Phase 
