Select * from ufn_Get_Quality_Characteristics_and_Response( :Client , :Plant , :Order, :Resource, :SAPResourceName)
Order By PPPI_PHASE ASC, PPPI_INSPECTION_CHARACTERISTIC ASC