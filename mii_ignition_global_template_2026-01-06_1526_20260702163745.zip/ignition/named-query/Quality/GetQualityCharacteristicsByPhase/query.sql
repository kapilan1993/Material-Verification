Select COUNT(*) from ufn_Get_Quality_Characteristics_and_Response( :Client , :Plant , :Order, :Resource, :SAPResourceName)
Where PPPI_PHASE = :Phase 