UPDATE tblBatchManagement
SET IS_VERIFIED = 1
WHERE Process_Order = :processorder
  AND (MATERIAL_TYPE = 'HALB' OR MATERIAL_TYPE = 'ROH')
  AND MATERIAL_NUMBER= :matnumber
  AND BACKFLUSH = '---';