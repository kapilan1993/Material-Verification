SELECT distinct Workcenter FROM Work_Center
WHERE Area = :area