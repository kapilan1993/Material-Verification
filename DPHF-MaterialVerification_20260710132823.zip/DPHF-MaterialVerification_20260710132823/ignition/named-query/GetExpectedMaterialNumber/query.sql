SELECT DISTINCT Material_Number
FROM tblBatchManagement
WHERE Process_Order = :processorder
  AND (Material_Type = 'ROH' OR Material_Type = 'HALB');