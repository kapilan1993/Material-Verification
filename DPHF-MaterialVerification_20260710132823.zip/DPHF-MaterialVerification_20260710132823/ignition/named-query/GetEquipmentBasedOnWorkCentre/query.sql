SELECT EquipmentId FROM Work_Center
WHERE Workcenter = :workcenter