SELECT ISNULL(IS_VERIFIED, 0) FROM tblBatchManagement
where process_order = :poNumber
and material_number = :materialNumber