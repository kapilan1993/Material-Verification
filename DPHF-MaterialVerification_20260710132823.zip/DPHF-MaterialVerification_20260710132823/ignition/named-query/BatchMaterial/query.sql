SELECT Material_Number
FROM tblBatchManagement
WHERE Process_Order = :processorder
  AND (MATERIAL_TYPE = 'HALB' OR MATERIAL_TYPE = 'ROH')
  AND BACKFLUSH = '---';