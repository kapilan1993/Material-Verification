SELECT BATCH_NUMBER
FROM tblBatchManagement
WHERE Process_Order = :processorder
  AND MATERIAL_NUMBER = :materialNumber
  AND IS_DELETED = 0