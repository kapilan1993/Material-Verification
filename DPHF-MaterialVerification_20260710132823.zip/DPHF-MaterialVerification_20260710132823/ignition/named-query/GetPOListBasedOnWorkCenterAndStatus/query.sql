SELECT 
    po.process_order, 
    po.S4status, 
    CASE 
        WHEN (SELECT COUNT(*) 
              FROM tblBatchManagement mv 
              WHERE mv.process_order = po.process_order
              AND (mv.material_type = 'HALB' OR mv.material_type = 'ROH')
              AND (mv.IS_verified IS NULL OR mv.IS_verified != 1)) > 0 
        THEN 0 ELSE 1 
    END AS materials_verified
FROM Xmii_PO_STATUS po
WHERE po.S4status = 'RELEASED' and resource =  :workCenter 